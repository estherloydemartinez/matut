# 📡 BibliaApp Pro - Documentación de API

## Arquitectura de la Aplicación

### Stack Tecnológico

- **Framework**: Kivy + KivyMD
- **Lenguaje**: Python 3.8+
- **Base de Datos**: SQLite
- **Almacenamiento**: JsonStore + archivos binarios
- **UI**: Material Design 3
- **Empaquetado**: Buildozer (Python-for-Android)

### Estructura Modular

```python
# Gestor de Base de Datos
class DatabaseManager:
    def __init__(self, db_path: str)
    def execute_query(self, query: str, params: tuple = None) -> List[Dict]
    def execute_command(self, query: str, params: tuple = None) -> bool

# Gestor de Datos Bíblicos
class BibleDataManager:
    def search_verses(self, query: str) -> List[Dict]
    def get_books(self, testament: str = None) -> List[Dict]
    def get_chapter(self, book_id: str, chapter: int) -> List[Dict]

# Gestor de Configuraciones
class SettingsManager:
    def get_setting(self, key: str, default: str = None) -> str
    def set_setting(self, key: str, value: str)
    def get_bool_setting(self, key: str, default: bool = False) -> bool

# Gestor de Progreso
class ProgressManager:
    def add_xp(self, amount: int, activity: str = "")
    def unlock_achievement(self, achievement_id: str, achievement_data: Dict)
    def calculate_streak(self)
```

### Pantallas Principales

```python
# Pantalla Base
class BaseScreen(MDScreen):
    def setup_ui(self)
    def show_loading(self, message: str = "Cargando...")
    def show_message(self, message: str, duration: int = 3)

# Pantalla de Inicio
class HomeScreen(BaseScreen):
    def create_header_card(self)
    def create_checkin_card(self)
    def create_progress_card(self)

# Pantalla de Teoría
class TheoryScreen(BaseScreen):
    def create_reading_modes(self)
    def create_study_tools(self)
    def create_memory_section(self)

# Pantalla de Práctica
class PracticeScreen(BaseScreen):
    def create_prayer_section(self)
    def create_life_section(self)
    def create_tracking_section(self)
```

## Base de Datos

### Esquema Principal

```sql
-- Libros bíblicos
CREATE TABLE bible_books (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    abbreviation TEXT NOT NULL,
    testament TEXT NOT NULL,
    order_num INTEGER NOT NULL,
    chapters INTEGER NOT NULL,
    category TEXT NOT NULL,
    author TEXT,
    theme TEXT,
    key_verse TEXT,
    summary TEXT
);

-- Versículos
CREATE TABLE bible_verses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id TEXT NOT NULL,
    chapter INTEGER NOT NULL,
    verse INTEGER NOT NULL,
    text TEXT NOT NULL,
    version TEXT DEFAULT 'RV1960',
    FOREIGN KEY (book_id) REFERENCES bible_books (id)
);

-- Progreso del usuario
CREATE TABLE user_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT DEFAULT 'default',
    activity_type TEXT NOT NULL,
    data TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Notas del usuario
CREATE TABLE notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL,
    title TEXT,
    content TEXT NOT NULL,
    tags TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Consultas Comunes

```python
# Buscar versículos
def search_verses(query):
    return db.execute_query("""
        SELECT bv.*, bb.name as book_name, bb.abbreviation
        FROM bible_verses bv
        JOIN bible_books bb ON bv.book_id = bb.id
        WHERE bv.text LIKE ? OR bb.name LIKE ?
        ORDER BY bb.order_num, bv.chapter, bv.verse
        LIMIT 50
    """, (f'%{query}%', f'%{query}%'))

# Obtener progreso
def get_user_xp():
    result = db.execute_query("""
        SELECT data FROM user_progress 
        WHERE activity_type = 'xp_update' 
        ORDER BY timestamp DESC LIMIT 1
    """)
    if result:
        return json.loads(result[0]['data'])['xp']
    return 0
```

## Configuración

### Archivo config.py

```python
# Información de la aplicación
APP_INFO = {
    'name': 'BibliaApp Pro',
    'version': '2.0.0',
    'package': 'com.bibliaapp.pro'
}

# Configuración de UI
UI_CONFIG = {
    'colors': {
        'primary': '#4F46E5',
        'secondary': '#F59E0B',
        'accent': '#EC4899'
    },
    'fonts': {
        'primary': 'Roboto',
        'sizes': {
            'body': '14sp',
            'title': '20sp'
        }
    }
}

# Características habilitadas
FEATURES = {
    'offline_mode': True,
    'notifications': True,
    'gamification': True,
    'social_features': True
}
```

## Sistema de Gamificación

### Experiencia (XP)

```python
XP_VALUES = {
    'daily_reading': 10,
    'chapter_complete': 25,
    'book_complete': 100,
    'verse_memorized': 15,
    'prayer_session': 5,
    'achievement_unlocked': 50
}

# Cálculo de nivel
def calculate_level(xp):
    return int(math.sqrt(xp / 100)) + 1
```

### Logros

```python
ACHIEVEMENTS = {
    'first_read': {
        'name': 'Primer Paso',
        'description': 'Primera lectura bíblica',
        'xp': 50
    },
    'week_streak': {
        'name': 'Constante',
        'description': '7 días seguidos leyendo',
        'xp': 100
    }
}
```

## Herramientas de Estudio

### Categorías Principales

1. **Hermenéutica** (12 herramientas)
2. **Análisis Crítico** (10 herramientas)  
3. **Lingüística** (10 herramientas)
4. **Historia y Arqueología** (9 herramientas)
5. **Teología Sistemática** (7 herramientas)
6. **Visualización** (6 herramientas)

### Implementación

```python
class StudyTool:
    def __init__(self, name, category, description):
        self.name = name
        self.category = category
        self.description = description
    
    def analyze(self, passage):
        # Implementación específica de cada herramienta
        pass

# Herramienta de contexto histórico
class HistoricalContextTool(StudyTool):
    def analyze(self, passage):
        return {
            'period': self.get_historical_period(passage),
            'culture': self.get_cultural_context(passage),
            'geography': self.get_geographical_context(passage)
        }
```

## Notificaciones

### Sistema de Recordatorios

```python
NOTIFICATION_TYPES = {
    'daily_reminder': {
        'title': '📖 Tiempo de Lectura',
        'message': '¡Es hora de tu lectura bíblica diaria!',
        'time': '08:00'
    },
    'prayer_reminder': {
        'title': '🙏 Momento de Oración',
        'message': 'Dedica unos minutos para orar',
        'times': ['12:00', '18:00']
    }
}

def schedule_notification(notification_type, custom_time=None):
    if PLYER_AVAILABLE:
        notification.notify(
            title=notification_type['title'],
            message=notification_type['message'],
            timeout=10
        )
```

## Extensibilidad

### Plugin System (Futuro)

```python
class PluginInterface:
    def __init__(self):
        self.name = ""
        self.version = ""
    
    def initialize(self, app_context):
        pass
    
    def get_tools(self):
        return []
    
    def process_passage(self, passage):
        pass

# Registro de plugins
class PluginManager:
    def __init__(self):
        self.plugins = []
    
    def register_plugin(self, plugin):
        self.plugins.append(plugin)
    
    def get_available_tools(self):
        tools = []
        for plugin in self.plugins:
            tools.extend(plugin.get_tools())
        return tools
```

---

Esta documentación técnica permite a los desarrolladores entender y extender BibliaApp Pro eficientemente.
