#!/usr/bin/env python3
"""
Script de compilación para BibliaApp Pro Android
Automatiza el proceso de compilación y empaquetado de la APK
"""

import os
import sys
import subprocess
import shutil
import time
from pathlib import Path

class AndroidCompiler:
    """Compilador automatizado para la aplicación Android"""
    
    def __init__(self):
        self.project_dir = Path(__file__).parent
        self.src_dir = self.project_dir / "src"
        self.assets_dir = self.project_dir / "assets"
        self.buildozer_dir = self.project_dir / ".buildozer"
        self.bin_dir = self.project_dir / "bin"
        
        # Colores para output
        self.GREEN = '\033[92m'
        self.RED = '\033[91m'
        self.YELLOW = '\033[93m'
        self.BLUE = '\033[94m'
        self.ENDC = '\033[0m'
        self.BOLD = '\033[1m'
    
    def log(self, message, color=None):
        """Log con colores"""
        if color:
            print(f"{color}{message}{self.ENDC}")
        else:
            print(message)
    
    def log_success(self, message):
        """Log de éxito"""
        self.log(f"✅ {message}", self.GREEN)
    
    def log_error(self, message):
        """Log de error"""
        self.log(f"❌ {message}", self.RED)
    
    def log_warning(self, message):
        """Log de advertencia"""
        self.log(f"⚠️ {message}", self.YELLOW)
    
    def log_info(self, message):
        """Log de información"""
        self.log(f"ℹ️ {message}", self.BLUE)
    
    def check_requirements(self):
        """Verificar requisitos del sistema"""
        self.log_info("Verificando requisitos del sistema...")
        
        requirements = {
            'python3': 'Python 3.8+',
            'buildozer': 'Buildozer',
            'git': 'Git',
            'zip': 'Zip'
        }
        
        missing = []
        
        for cmd, name in requirements.items():
            try:
                result = subprocess.run([cmd, '--version'], 
                                      capture_output=True, text=True)
                if result.returncode == 0:
                    self.log_success(f"{name} encontrado")
                else:
                    missing.append(name)
            except FileNotFoundError:
                missing.append(name)
        
        if missing:
            self.log_error(f"Requisitos faltantes: {', '.join(missing)}")
            self.log_info("Instala los requisitos faltantes:")
            self.log("pip install buildozer cython")
            return False
        
        return True
    
    def setup_environment(self):
        """Configurar entorno de compilación"""
        self.log_info("Configurando entorno de compilación...")
        
        # Crear directorios necesarios
        os.makedirs(self.assets_dir, exist_ok=True)
        os.makedirs(self.bin_dir, exist_ok=True)
        
        # Crear assets básicos si no existen
        self.create_basic_assets()
        
        self.log_success("Entorno configurado")
    
    def create_basic_assets(self):
        """Crear assets básicos de la aplicación"""
        self.log_info("Creando assets básicos...")
        
        # Crear icono básico (placeholder)
        icon_path = self.assets_dir / "icon.png"
        if not icon_path.exists():
            self.create_basic_icon(icon_path)
        
        # Crear splash básico (placeholder)
        splash_path = self.assets_dir / "splash.png"
        if not splash_path.exists():
            self.create_basic_splash(splash_path)
        
        self.log_success("Assets básicos creados")
    
    def create_basic_icon(self, path):
        """Crear icono básico usando PIL"""
        try:
            from PIL import Image, ImageDraw, ImageFont
            
            # Crear imagen 512x512
            size = 512
            img = Image.new('RGBA', (size, size), color='#4F46E5')
            draw = ImageDraw.Draw(img)
            
            # Dibujar círculo
            margin = 50
            draw.ellipse([margin, margin, size-margin, size-margin], 
                        fill='#FFFFFF', outline='#E5E7EB', width=10)
            
            # Intentar agregar texto
            try:
                font = ImageFont.truetype("/System/Library/Fonts/Arial.ttf", 120)
            except:
                try:
                    font = ImageFont.truetype("arial.ttf", 120)
                except:
                    font = ImageFont.load_default()
            
            # Texto centrado
            text = "📖"
            bbox = draw.textbbox((0, 0), text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
            
            x = (size - text_width) // 2
            y = (size - text_height) // 2
            
            draw.text((x, y), text, fill='#4F46E5', font=font)
            
            img.save(path, 'PNG')
            self.log_success(f"Icono creado: {path}")
            
        except ImportError:
            self.log_warning("PIL no disponible, creando icono básico")
            # Crear archivo placeholder
            with open(path, 'wb') as f:
                # PNG mínimo (placeholder)
                f.write(b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x02\x00\x00\x00\x02\x00\x08\x06\x00\x00\x00\xf4x\xd4\xfa\x00\x00\x00\tpHYs\x00\x00\x0b\x13\x00\x00\x0b\x13\x01\x00\x9a\x9c\x18\x00\x00\x00\x19tEXtSoftware\x00www.inkscape.org\x9b\xee<\x1a\x00\x00\x00\x11IDATx\x9cc\xf8\x0f\x00\x00\x01\x00\x01\x00\x00\x00\x00\x00\x00IEND\xaeB`\x82')
    
    def create_basic_splash(self, path):
        """Crear splash básico"""
        try:
            from PIL import Image, ImageDraw, ImageFont
            
            # Crear imagen de splash (1080x1920 - proporción móvil)
            width, height = 1080, 1920
            img = Image.new('RGBA', (width, height), color='#4F46E5')
            draw = ImageDraw.Draw(img)
            
            # Fondo gradiente (simulado)
            for y in range(height):
                alpha = int(255 * (1 - y / height * 0.3))
                color = f"#{hex(alpha)[2:].zfill(2)}46E5"
                draw.line([(0, y), (width, y)], fill=color)
            
            # Logo/texto centrado
            try:
                font_large = ImageFont.truetype("/System/Library/Fonts/Arial.ttf", 80)
                font_small = ImageFont.truetype("/System/Library/Fonts/Arial.ttf", 40)
            except:
                font_large = ImageFont.load_default()
                font_small = ImageFont.load_default()
            
            # Título
            title = "BibliaApp Pro"
            bbox = draw.textbbox((0, 0), title, font=font_large)
            title_width = bbox[2] - bbox[0]
            
            x = (width - title_width) // 2
            y = height // 2 - 100
            
            draw.text((x, y), title, fill='#FFFFFF', font=font_large)
            
            # Subtítulo
            subtitle = "Formación Bíblica de Clase Mundial"
            bbox = draw.textbbox((0, 0), subtitle, font=font_small)
            subtitle_width = bbox[2] - bbox[0]
            
            x = (width - subtitle_width) // 2
            y = height // 2 + 50
            
            draw.text((x, y), subtitle, fill='#E0F2FE', font=font_small)
            
            img.save(path, 'PNG')
            self.log_success(f"Splash creado: {path}")
            
        except ImportError:
            self.log_warning("PIL no disponible, creando splash básico")
            # Crear archivo placeholder
            shutil.copy(self.assets_dir / "icon.png", path)
    
    def clean_build(self):
        """Limpiar compilación anterior"""
        self.log_info("Limpiando compilación anterior...")
        
        if self.buildozer_dir.exists():
            shutil.rmtree(self.buildozer_dir)
            self.log_success("Directorio .buildozer eliminado")
        
        # Limpiar archivos temporales
        temp_files = [
            self.project_dir / "*.pyc",
            self.project_dir / "__pycache__",
            self.src_dir / "__pycache__"
        ]
        
        for pattern in temp_files:
            if pattern.exists():
                if pattern.is_dir():
                    shutil.rmtree(pattern)
                else:
                    pattern.unlink()
        
        self.log_success("Archivos temporales eliminados")
    
    def compile_debug(self):
        """Compilar versión debug"""
        self.log_info("Compilando versión debug...")
        
        try:
            # Cambiar al directorio del proyecto
            os.chdir(self.project_dir)
            
            # Ejecutar buildozer
            cmd = ["buildozer", "android", "debug"]
            
            self.log_info(f"Ejecutando: {' '.join(cmd)}")
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            # Mostrar output en tiempo real
            for line in iter(process.stdout.readline, ''):\n                print(line.rstrip())\n            \n            process.wait()\n            \n            if process.returncode == 0:\n                self.log_success("Compilación debug exitosa")\n                \n                # Buscar APK generada\n                apk_files = list(self.bin_dir.glob("*.apk"))\n                if apk_files:\n                    apk_path = apk_files[-1]  # La más reciente\n                    self.log_success(f"APK generada: {apk_path}")\n                    \n                    # Mostrar información de la APK\n                    self.show_apk_info(apk_path)\n                    \n                    return apk_path\n                else:\n                    self.log_warning("APK no encontrada en bin/")\n                    return None\n            else:\n                self.log_error(f"Compilación falló con código: {process.returncode}")\n                return None\n                \n        except Exception as e:\n            self.log_error(f"Error durante compilación: {e}")\n            return None\n    \n    def compile_release(self):\n        """Compilar versión release"""\n        self.log_info("Compilando versión release...")\n        \n        try:\n            # Cambiar al directorio del proyecto\n            os.chdir(self.project_dir)\n            \n            # Ejecutar buildozer para release\n            cmd = ["buildozer", "android", "release"]\n            \n            self.log_info(f"Ejecutando: {' '.join(cmd)}")\n            \n            process = subprocess.Popen(\n                cmd,\n                stdout=subprocess.PIPE,\n                stderr=subprocess.STDOUT,\n                universal_newlines=True,\n                bufsize=1\n            )\n            \n            # Mostrar output en tiempo real\n            for line in iter(process.stdout.readline, ''):\n                print(line.rstrip())\n            \n            process.wait()\n            \n            if process.returncode == 0:\n                self.log_success("Compilación release exitosa")\n                \n                # Buscar APK generada\n                apk_files = list(self.bin_dir.glob("*release*.apk"))\n                if not apk_files:\n                    apk_files = list(self.bin_dir.glob("*.apk"))\n                \n                if apk_files:\n                    apk_path = apk_files[-1]  # La más reciente\n                    self.log_success(f"APK release generada: {apk_path}")\n                    \n                    # Mostrar información de la APK\n                    self.show_apk_info(apk_path)\n                    \n                    return apk_path\n                else:\n                    self.log_warning("APK release no encontrada")\n                    return None\n            else:\n                self.log_error(f"Compilación release falló con código: {process.returncode}")\n                return None\n                \n        except Exception as e:\n            self.log_error(f"Error durante compilación release: {e}")\n            return None\n    \n    def show_apk_info(self, apk_path):\n        """Mostrar información de la APK generada"""\n        try:\n            stat = apk_path.stat()\n            size_mb = stat.st_size / (1024 * 1024)\n            \n            self.log_info("Información de la APK:")\n            print(f"  📦 Archivo: {apk_path.name}")\n            print(f"  📏 Tamaño: {size_mb:.1f} MB")\n            print(f"  📅 Creado: {time.ctime(stat.st_mtime)}")\n            print(f"  📂 Ruta: {apk_path.absolute()}")\n            \n        except Exception as e:\n            self.log_warning(f"No se pudo obtener información de la APK: {e}")\n    \n    def install_debug_apk(self, apk_path):\n        """Instalar APK debug en dispositivo conectado"""\n        self.log_info("Instalando APK en dispositivo...")\n        \n        try:\n            # Verificar si adb está disponible\n            subprocess.run(["adb", "version"], capture_output=True, check=True)\n            \n            # Verificar dispositivos conectados\n            result = subprocess.run(["adb", "devices"], capture_output=True, text=True)\n            devices = [line for line in result.stdout.split('\\n') if '\\tdevice' in line]\n            \n            if not devices:\n                self.log_warning("No hay dispositivos Android conectados")\n                self.log_info("Conecta un dispositivo y habilita la depuración USB")\n                return False\n            \n            self.log_info(f"Dispositivos encontrados: {len(devices)}")\n            \n            # Instalar APK\n            cmd = ["adb", "install", "-r", str(apk_path)]\n            result = subprocess.run(cmd, capture_output=True, text=True)\n            \n            if result.returncode == 0:\n                self.log_success("APK instalada correctamente")\n                self.log_info("Puedes encontrar BibliaApp Pro en tu dispositivo")\n                return True\n            else:\n                self.log_error(f"Error instalando APK: {result.stderr}")\n                return False\n                \n        except FileNotFoundError:\n            self.log_warning("ADB no encontrado - instala Android SDK Platform Tools")\n            return False\n        except subprocess.CalledProcessError as e:\n            self.log_error(f"Error ejecutando ADB: {e}")\n            return False\n    \n    def create_installation_package(self, apk_path):\n        """Crear paquete de instalación"""\n        self.log_info("Creando paquete de instalación...")\n        \n        try:\n            # Crear directorio de distribución\n            dist_dir = self.project_dir / "dist"\n            dist_dir.mkdir(exist_ok=True)\n            \n            # Copiar APK\n            final_apk_name = f"BibliaApp_Pro_v2.0.0_Android.apk"\n            final_apk_path = dist_dir / final_apk_name\n            shutil.copy2(apk_path, final_apk_path)\n            \n            # Crear archivo README\n            readme_content = f\"\"\"# BibliaApp Pro - Aplicación Android\n\n## Instalación\n\n1. **Habilitar fuentes desconocidas:**\n   - Ve a Configuración > Seguridad\n   - Activa "Fuentes desconocidas" o "Instalar aplicaciones desconocidas"\n\n2. **Instalar la aplicación:**\n   - Toca el archivo `{final_apk_name}`\n   - Sigue las instrucciones en pantalla\n   - Acepta los permisos solicitados\n\n3. **Permisos necesarios:**\n   - 📱 Almacenamiento: Para guardar datos offline\n   - 📷 Cámara: Para funciones de escáner (opcional)\n   - 🔔 Notificaciones: Para recordatorios de lectura\n   - 📍 Ubicación: Para funciones comunitarias (opcional)\n\n## Características\n\n✅ **Funciona 100% offline**\n📖 **Biblioteca completa de herramientas bíblicas**\n🙏 **Guías de oración interactivas**\n👥 **Funciones sociales y comunitarias**\n🏆 **Sistema de gamificación y progreso**\n🎯 **Más de 50 herramientas de estudio profundo**\n\n## Información Técnica\n\n- **Versión:** 2.0.0\n- **Tamaño:** {apk_path.stat().st_size / (1024*1024):.1f} MB\n- **Android mínimo:** 5.0 (API 21)\n- **Compilado:** {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n## Soporte\n\nPara soporte técnico o reportar problemas:\n- Email: soporte@bibliaapp.com\n- GitHub: https://github.com/bibliaapp/pro\n\n---\n\n**BibliaApp Pro v2.0.0**\n*Formación Bíblica de Clase Mundial*\n\"\"\"\n            \n            readme_path = dist_dir / "README.md"\n            with open(readme_path, 'w', encoding='utf-8') as f:\n                f.write(readme_content)\n            \n            # Crear archivo de instalación automática\n            install_script = f\"\"\"#!/bin/bash\n# Script de instalación automática para BibliaApp Pro\n\necho "📱 Instalador de BibliaApp Pro v2.0.0"\necho "======================================="\necho\n\n# Verificar si adb está disponible\nif ! command -v adb &> /dev/null; then\n    echo "❌ ADB no encontrado"\n    echo "   Instala Android SDK Platform Tools"\n    echo "   o instala manualmente el archivo APK"\n    exit 1\nfi\n\n# Verificar dispositivos\necho "🔍 Buscando dispositivos Android..."\ndevices=$(adb devices | grep -w device | wc -l)\n\nif [ $devices -eq 0 ]; then\n    echo "❌ No hay dispositivos conectados"\n    echo "   1. Conecta tu dispositivo Android"\n    echo "   2. Habilita la depuración USB"\n    echo "   3. Ejecuta este script nuevamente"\n    exit 1\nfi\n\necho "✅ Dispositivo(s) encontrado(s): $devices"\necho\n\n# Instalar APK\necho "📦 Instalando BibliaApp Pro..."\nadb install -r "{final_apk_name}"\n\nif [ $? -eq 0 ]; then\n    echo "✅ ¡BibliaApp Pro instalada correctamente!"\n    echo "   Busca el icono en tu dispositivo y disfruta"\nelse\n    echo "❌ Error durante la instalación"\n    echo "   Intenta instalar manualmente el archivo APK"\nfi\n\necho\necho "🙏 ¡Que Dios bendiga tu estudio bíblico!"\n\"\"\"\n            \n            install_script_path = dist_dir / "instalar.sh"\n            with open(install_script_path, 'w', encoding='utf-8') as f:\n                f.write(install_script)\n            \n            # Hacer ejecutable en sistemas Unix\n            if os.name != 'nt':\n                os.chmod(install_script_path, 0o755)\n            \n            # Crear archivo .bat para Windows\n            install_bat = f\"\"\"@echo off\nchcp 65001 >nul\necho 📱 Instalador de BibliaApp Pro v2.0.0\necho =======================================\necho.\n\necho 🔍 Buscando dispositivos Android...\nadb devices | findstr device >nul\nif errorlevel 1 (\n    echo ❌ No hay dispositivos conectados\n    echo    1. Conecta tu dispositivo Android\n    echo    2. Habilita la depuración USB\n    echo    3. Ejecuta este script nuevamente\n    pause\n    exit /b 1\n)\n\necho ✅ Dispositivo encontrado\necho.\n\necho 📦 Instalando BibliaApp Pro...\nadb install -r "{final_apk_name}"\n\nif errorlevel 1 (\n    echo ❌ Error durante la instalación\n    echo    Intenta instalar manualmente el archivo APK\n) else (\n    echo ✅ ¡BibliaApp Pro instalada correctamente!\n    echo    Busca el icono en tu dispositivo y disfruta\n)\n\necho.\necho 🙏 ¡Que Dios bendiga tu estudio bíblico!\npause\n\"\"\"\n            \n            install_bat_path = dist_dir / "instalar.bat"\n            with open(install_bat_path, 'w', encoding='utf-8') as f:\n                f.write(install_bat)\n            \n            self.log_success(f"Paquete de instalación creado en: {dist_dir}")\n            self.log_info("Archivos incluidos:")\n            print(f"  📦 {final_apk_name} - Aplicación Android")\n            print(f"  📄 README.md - Instrucciones de instalación")\n            print(f"  🔧 instalar.sh - Script de instalación (Linux/Mac)")\n            print(f"  🔧 instalar.bat - Script de instalación (Windows)")\n            \n            return dist_dir\n            \n        except Exception as e:\n            self.log_error(f"Error creando paquete: {e}")\n            return None\n    \n    def run_full_build(self, build_type=\"debug\", install=False, clean=False):\n        """Ejecutar compilación completa"""\n        start_time = time.time()\n        \n        self.log(f\"{self.BOLD}🚀 BibliaApp Pro - Compilador Android{self.ENDC}\")\n        self.log(f\"{self.BOLD}========================================{self.ENDC}\")\n        print()\n        \n        # Verificar requisitos\n        if not self.check_requirements():\n            return False\n        \n        # Configurar entorno\n        self.setup_environment()\n        \n        # Limpiar si se solicita\n        if clean:\n            self.clean_build()\n        \n        # Compilar\n        if build_type == "release":\n            apk_path = self.compile_release()\n        else:\n            apk_path = self.compile_debug()\n        \n        if not apk_path:\n            self.log_error("Compilación falló")\n            return False\n        \n        # Crear paquete de instalación\n        dist_dir = self.create_installation_package(apk_path)\n        \n        # Instalar si se solicita\n        if install and build_type == "debug":\n            self.install_debug_apk(apk_path)\n        \n        # Tiempo total\n        total_time = time.time() - start_time\n        minutes = int(total_time // 60)\n        seconds = int(total_time % 60)\n        \n        print()\n        self.log_success(f"¡Compilación completada en {minutes}m {seconds}s!")\n        \n        if dist_dir:\n            self.log_info(f"Archivos listos en: {dist_dir.absolute()}")\n        \n        print()\n        self.log(f\"{self.BOLD}🙏 ¡BibliaApp Pro lista para bendecir vidas!{self.ENDC}\")\n        \n        return True

def main():\n    \"\"\"Función principal\"\"\"\n    import argparse\n    \n    parser = argparse.ArgumentParser(\n        description='Compilador de BibliaApp Pro para Android'\n    )\n    \n    parser.add_argument(\n        '--type', '-t',\n        choices=['debug', 'release'],\n        default='debug',\n        help='Tipo de compilación (default: debug)'\n    )\n    \n    parser.add_argument(\n        '--install', '-i',\n        action='store_true',\n        help='Instalar automáticamente en dispositivo conectado'\n    )\n    \n    parser.add_argument(\n        '--clean', '-c',\n        action='store_true',\n        help='Limpiar compilación anterior'\n    )\n    \n    parser.add_argument(\n        '--verbose', '-v',\n        action='store_true',\n        help='Output detallado'\n    )\n    \n    args = parser.parse_args()\n    \n    compiler = AndroidCompiler()\n    success = compiler.run_full_build(\n        build_type=args.type,\n        install=args.install,\n        clean=args.clean\n    )\n    \n    sys.exit(0 if success else 1)\n\nif __name__ == '__main__':\n    main()\n