import { Brain, BookOpen, Trophy, Users, Zap, Clock } from "lucide-react"

export function FeatureSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32" id="features">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-muted px-3 py-1 text-sm">Características</div>
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">
              Aprendizaje bíblico potenciado por neurociencia
            </h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              BibliaMente utiliza principios de neurociencia y psicología cognitiva para crear una experiencia de
              aprendizaje bíblico más efectiva y memorable.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
            <div className="rounded-full bg-primary/10 p-3">
              <Brain className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Aprendizaje espaciado</h3>
            <p className="text-center text-muted-foreground">
              Algoritmos basados en neurociencia que presentan preguntas en intervalos óptimos para maximizar la
              retención a largo plazo.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
            <div className="rounded-full bg-primary/10 p-3">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Contenido contextualizado</h3>
            <p className="text-center text-muted-foreground">
              Preguntas organizadas por contexto histórico y teológico para una comprensión más profunda de las
              Escrituras.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
            <div className="rounded-full bg-primary/10 p-3">
              <Trophy className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Gamificación inteligente</h3>
            <p className="text-center text-muted-foreground">
              Sistema de recompensas diseñado para estimular los centros de dopamina del cerebro y mantener la
              motivación.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
            <div className="rounded-full bg-primary/10 p-3">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Comunidad de aprendizaje</h3>
            <p className="text-center text-muted-foreground">
              Grupos de estudio y competencias amistosas que aprovechan el aprendizaje social para mejorar la retención.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
            <div className="rounded-full bg-primary/10 p-3">
              <Zap className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Adaptación personalizada</h3>
            <p className="text-center text-muted-foreground">
              El sistema aprende de tus respuestas para adaptar las preguntas a tu nivel de conocimiento y estilo de
              aprendizaje.
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2 rounded-lg border p-6 shadow-sm">
            <div className="rounded-full bg-primary/10 p-3">
              <Clock className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold">Microaprendizaje</h3>
            <p className="text-center text-muted-foreground">
              Sesiones cortas diseñadas para encajar en tu rutina diaria, optimizando la atención y evitando la fatiga
              cognitiva.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
