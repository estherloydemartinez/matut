import Image from "next/image"

export function TestimonialSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-muted" id="testimonials">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-background px-3 py-1 text-sm">Testimonios</div>
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Lo que dicen nuestros usuarios</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Descubre cómo BibliaMente ha transformado el estudio bíblico para miles de personas.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-3">
          <div className="flex flex-col justify-between rounded-lg border bg-background p-6 shadow-sm">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    stroke="none"
                    className="h-5 w-5 text-yellow-500"
                  >
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                  </svg>
                ))}
              </div>
              <p className="text-muted-foreground">
                "BibliaMente ha revolucionado mi estudio bíblico. Las preguntas espaciadas en el tiempo realmente me han
                ayudado a retener lo que aprendo. ¡Increíble aplicación!"
              </p>
            </div>
            <div className="mt-6 flex items-center gap-4">
              <div className="rounded-full bg-muted h-10 w-10 overflow-hidden">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Avatar"
                  width={40}
                  height={40}
                  className="object-cover"
                />
              </div>
              <div>
                <p className="text-sm font-medium">Carlos Rodríguez</p>
                <p className="text-xs text-muted-foreground">Pastor, Madrid</p>
              </div>
            </div>
          </div>
          <div className="flex flex-col justify-between rounded-lg border bg-background p-6 shadow-sm">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    stroke="none"
                    className="h-5 w-5 text-yellow-500"
                  >
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                  </svg>
                ))}
              </div>
              <p className="text-muted-foreground">
                "Como profesora de escuela dominical, BibliaMente me ha proporcionado herramientas increíbles para
                enseñar a mis alumnos. Los elementos de gamificación mantienen a todos comprometidos."
              </p>
            </div>
            <div className="mt-6 flex items-center gap-4">
              <div className="rounded-full bg-muted h-10 w-10 overflow-hidden">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Avatar"
                  width={40}
                  height={40}
                  className="object-cover"
                />
              </div>
              <div>
                <p className="text-sm font-medium">Ana Martínez</p>
                <p className="text-xs text-muted-foreground">Profesora, Bogotá</p>
              </div>
            </div>
          </div>
          <div className="flex flex-col justify-between rounded-lg border bg-background p-6 shadow-sm">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <svg
                    key={star}
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    stroke="none"
                    className="h-5 w-5 text-yellow-500"
                  >
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                  </svg>
                ))}
              </div>
              <p className="text-muted-foreground">
                "Llevo años estudiando la Biblia, pero nunca había retenido tanto conocimiento como ahora con
                BibliaMente. La combinación de neurociencia y estudio bíblico es genial."
              </p>
            </div>
            <div className="mt-6 flex items-center gap-4">
              <div className="rounded-full bg-muted h-10 w-10 overflow-hidden">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="Avatar"
                  width={40}
                  height={40}
                  className="object-cover"
                />
              </div>
              <div>
                <p className="text-sm font-medium">Miguel Sánchez</p>
                <p className="text-xs text-muted-foreground">Estudiante, Lima</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
