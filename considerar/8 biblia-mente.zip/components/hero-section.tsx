import Link from "next/link"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-background to-muted">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <div className="flex flex-col justify-center space-y-4">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                Profundiza tu conocimiento bíblico con neurociencia
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl">
                BibliaMente combina estudios bíblicos con principios de neurociencia para maximizar tu aprendizaje y
                retención. Aprende, crece y compite mientras exploras las Escrituras.
              </p>
            </div>
            <div className="flex flex-col gap-2 min-[400px]:flex-row">
              <Link href="/quiz">
                <Button size="lg" className="bg-primary text-primary-foreground">
                  Comenzar ahora
                </Button>
              </Link>
              <Link href="/about">
                <Button size="lg" variant="outline">
                  Conocer más
                </Button>
              </Link>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4 text-primary"
                >
                  <path d="M12 2H2v10h10V2Z" />
                  <path d="M12 12H2v10h10V12Z" />
                  <path d="M22 2h-10v20h10V2Z" />
                </svg>
                <span>+1000 preguntas bíblicas</span>
              </div>
              <div className="flex items-center gap-1">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4 text-primary"
                >
                  <circle cx="12" cy="8" r="6" />
                  <path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11" />
                </svg>
                <span>Basado en neurociencia</span>
              </div>
              <div className="flex items-center gap-1">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4 text-primary"
                >
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
                <span>+50,000 usuarios</span>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-center">
            <div className="relative w-full max-w-[400px] aspect-[4/3] overflow-hidden rounded-xl border bg-gradient-to-br from-purple-100 to-indigo-100 p-4 shadow-xl">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-indigo-500/20 backdrop-blur-sm"></div>
              <div className="relative z-10 h-full rounded-lg bg-white/90 p-6 shadow-lg">
                <div className="flex flex-col h-full justify-between">
                  <div>
                    <h3 className="text-xl font-semibold text-center mb-6">Pregunta del día</h3>
                    <p className="text-lg mb-4">"¿Quién fue el primer rey de Israel mencionado en la Biblia?"</p>
                    <div className="space-y-2">
                      <div className="rounded-md border p-2 cursor-pointer hover:bg-muted/50 transition-colors">
                        A. David
                      </div>
                      <div className="rounded-md border p-2 cursor-pointer hover:bg-muted/50 transition-colors">
                        B. Saúl
                      </div>
                      <div className="rounded-md border p-2 cursor-pointer hover:bg-muted/50 transition-colors">
                        C. Salomón
                      </div>
                      <div className="rounded-md border p-2 cursor-pointer hover:bg-muted/50 transition-colors">
                        D. Samuel
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center mt-4">
                    <div className="text-sm text-muted-foreground">Dificultad: Media</div>
                    <Button size="sm">Responder</Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
