import Link from "next/link"
import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"

export function PricingSection() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32" id="pricing">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-muted px-3 py-1 text-sm">Planes</div>
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Elige el plan perfecto para ti</h2>
            <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Ofrecemos diferentes opciones para adaptarnos a tus necesidades de estudio bíblico.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 lg:grid-cols-3">
          <div className="flex flex-col rounded-lg border bg-background p-6 shadow-sm">
            <div className="space-y-2">
              <h3 className="text-2xl font-bold">Gratuito</h3>
              <p className="text-muted-foreground">Perfecto para comenzar tu viaje de aprendizaje bíblico.</p>
            </div>
            <div className="mt-4 flex items-baseline text-3xl font-bold">
              $0<span className="text-sm font-normal text-muted-foreground">/mes</span>
            </div>
            <ul className="mt-6 space-y-2.5 text-sm">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>100 preguntas bíblicas</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Seguimiento básico de progreso</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Acceso a la pregunta diaria</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Publicidad limitada</span>
              </li>
            </ul>
            <div className="mt-6">
              <Link href="/register">
                <Button className="w-full" variant="outline">
                  Comenzar gratis
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex flex-col rounded-lg border bg-primary p-6 shadow-sm">
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-primary-foreground">Premium</h3>
              <p className="text-primary-foreground/80">Para estudiantes serios de la Biblia.</p>
            </div>
            <div className="mt-4 flex items-baseline text-3xl font-bold text-primary-foreground">
              $4.99<span className="text-sm font-normal text-primary-foreground/80">/mes</span>
            </div>
            <ul className="mt-6 space-y-2.5 text-sm text-primary-foreground">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                <span>Acceso ilimitado a preguntas</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                <span>Análisis detallado de progreso</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                <span>Sin publicidad</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                <span>Modo estudio personalizado</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4" />
                <span>Competencias semanales</span>
              </li>
            </ul>
            <div className="mt-6">
              <Link href="/register?plan=premium">
                <Button className="w-full bg-background text-primary hover:bg-background/90">Suscribirse ahora</Button>
              </Link>
            </div>
          </div>
          <div className="flex flex-col rounded-lg border bg-background p-6 shadow-sm">
            <div className="space-y-2">
              <h3 className="text-2xl font-bold">Familiar</h3>
              <p className="text-muted-foreground">Ideal para familias y grupos pequeños.</p>
            </div>
            <div className="mt-4 flex items-baseline text-3xl font-bold">
              $9.99<span className="text-sm font-normal text-muted-foreground">/mes</span>
            </div>
            <ul className="mt-6 space-y-2.5 text-sm">
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Todo lo incluido en Premium</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Hasta 5 cuentas</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Competencias familiares</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Contenido para todas las edades</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                <span>Soporte prioritario</span>
              </li>
            </ul>
            <div className="mt-6">
              <Link href="/register?plan=family">
                <Button className="w-full">Obtener plan familiar</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
