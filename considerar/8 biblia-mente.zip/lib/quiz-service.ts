// Tipos para las preguntas y respuestas
export interface Option {
  id: string
  text: string
}

export interface Question {
  id: string
  text: string
  options: Option[]
  correctOptionId: string
  explanation: string
  difficulty: "easy" | "medium" | "hard"
  category: string
  reference: string
  lastReviewed?: Date
  nextReviewDate?: Date
  memoryStrength?: number
}

export interface QuizResult {
  quizId: string
  score: number
  correctAnswers: number
  totalQuestions: number
  timeSpent: number
  completedAt: Date
}

export interface UserProgress {
  userId: string
  answeredQuestions: {
    questionId: string
    correctlyAnswered: boolean
    answerCount: number
    lastAnswered: Date
    nextReviewDate: Date
    memoryStrength: number
  }[]
  quizResults: QuizResult[]
  streakDays: number
  lastStreak: Date
  xpPoints: number
  level: number
}

// Implementación del algoritmo de repetición espaciada basado en SM-2
export function calculateNextReviewDate(
  memoryStrength: number,
  wasCorrect: boolean,
): { nextDate: Date; newMemoryStrength: number } {
  // Si la respuesta fue incorrecta, resetear la fuerza de memoria a 1
  if (!wasCorrect) {
    const nextDate = new Date()
    nextDate.setDate(nextDate.getDate() + 1) // Revisar al día siguiente
    return { nextDate, newMemoryStrength: 1 }
  }

  // Si la respuesta fue correcta, aumentar la fuerza de memoria
  const newMemoryStrength = memoryStrength + 1

  // Calcular el intervalo basado en la fuerza de memoria
  // Usando una versión simplificada del algoritmo SM-2
  let interval: number

  if (newMemoryStrength === 1) {
    interval = 1 // 1 día
  } else if (newMemoryStrength === 2) {
    interval = 3 // 3 días
  } else {
    // Para memoryStrength >= 3, usamos una fórmula exponencial
    interval = Math.round(Math.pow(2, newMemoryStrength - 2) * 5)

    // Limitamos el intervalo máximo a 60 días para evitar intervalos demasiado largos
    if (interval > 60) interval = 60
  }

  const nextDate = new Date()
  nextDate.setDate(nextDate.getDate() + interval)

  return { nextDate, newMemoryStrength: newMemoryStrength }
}

// Función para seleccionar preguntas para revisión basadas en el algoritmo de repetición espaciada
export function selectQuestionsForReview(allQuestions: Question[], userProgress: UserProgress, count = 10): Question[] {
  const today = new Date()

  // Mapear las preguntas con su información de progreso
  const questionsWithProgress = allQuestions.map((question) => {
    const progress = userProgress.answeredQuestions.find((q) => q.questionId === question.id)

    return {
      question,
      progress,
      dueForReview: progress ? progress.nextReviewDate <= today : true,
      // Si nunca se ha respondido, tiene alta prioridad
      priority: progress
        ? progress.nextReviewDate <= today
          ? (today.getTime() - progress.nextReviewDate.getTime()) / (1000 * 3600 * 24)
          : -1
        : 100,
    }
  })

  // Ordenar por prioridad (preguntas vencidas primero, luego las nunca respondidas)
  const sortedQuestions = questionsWithProgress.sort((a, b) => b.priority - a.priority).map((q) => q.question)

  // Devolver el número solicitado de preguntas
  return sortedQuestions.slice(0, count)
}

// Función para calcular XP basado en dificultad, tiempo de respuesta y racha
export function calculateXP(
  difficulty: "easy" | "medium" | "hard",
  timeSpentInSeconds: number,
  streakCount: number,
  wasCorrect: boolean,
): number {
  if (!wasCorrect) return 0

  // Base XP por dificultad
  let baseXP = 0
  switch (difficulty) {
    case "easy":
      baseXP = 5
      break
    case "medium":
      baseXP = 10
      break
    case "hard":
      baseXP = 15
      break
  }

  // Bonus por tiempo de respuesta rápida (máximo 100% extra)
  const timeBonus = Math.max(0, Math.min(1, (30 - timeSpentInSeconds) / 20))

  // Bonus por racha (2 puntos extra por cada respuesta correcta consecutiva)
  const streakBonus = Math.min(10, streakCount) * 2

  // Calcular XP total
  const totalXP = Math.round(baseXP * (1 + timeBonus) + streakBonus)

  return totalXP
}

// Función para determinar el nivel basado en XP
export function calculateLevel(xp: number): number {
  // Fórmula: nivel = 1 + sqrt(xp / 100)
  // Esto hace que los niveles sean cada vez más difíciles de alcanzar
  return Math.floor(1 + Math.sqrt(xp / 100))
}

// Función para obtener XP necesario para el siguiente nivel
export function getXPForNextLevel(currentLevel: number): number {
  // Basado en la fórmula inversa: xp = 100 * (nivel - 1)^2
  return 100 * Math.pow(currentLevel, 2)
}
