import type { Question, QuizResult, UserProgress } from "./quiz-service"

// Interfaz para las estadísticas de aprendizaje
export interface LearningStats {
  daily: {
    questionsAnswered: number
    correctAnswers: number
    averageResponseTime: number
    xpEarned: number
    categories: Record<string, number> // Categoría -> número de preguntas
  }
  weekly: {
    questionsAnswered: number
    correctAnswers: number
    averageResponseTime: number
    xpEarned: number
    categories: Record<string, number>
    dailyActivity: number[] // Preguntas por día de la semana
  }
  monthly: {
    questionsAnswered: number
    correctAnswers: number
    averageResponseTime: number
    xpEarned: number
    categories: Record<string, number>
    weeklyProgress: number[] // Preguntas por semana
  }
}

// Función para calcular estadísticas de aprendizaje
export function calculateLearningStats(
  userProgress: UserProgress,
  quizResults: QuizResult[],
  answeredQuestions: { question: Question; wasCorrect: boolean; timeSpent: number; answeredAt: Date }[],
): LearningStats {
  const now = new Date()

  // Filtrar por períodos de tiempo
  const oneDayAgo = new Date(now)
  oneDayAgo.setDate(now.getDate() - 1)

  const oneWeekAgo = new Date(now)
  oneWeekAgo.setDate(now.getDate() - 7)

  const oneMonthAgo = new Date(now)
  oneMonthAgo.setMonth(now.getMonth() - 1)

  // Filtrar preguntas por período
  const dailyQuestions = answeredQuestions.filter((q) => q.answeredAt >= oneDayAgo)
  const weeklyQuestions = answeredQuestions.filter((q) => q.answeredAt >= oneWeekAgo)
  const monthlyQuestions = answeredQuestions.filter((q) => q.answeredAt >= oneMonthAgo)

  // Filtrar resultados de quiz por período
  const dailyResults = quizResults.filter((r) => r.completedAt >= oneDayAgo)
  const weeklyResults = quizResults.filter((r) => r.completedAt >= oneWeekAgo)
  const monthlyResults = quizResults.filter((r) => r.completedAt >= oneMonthAgo)

  // Calcular estadísticas diarias
  const dailyStats = {
    questionsAnswered: dailyQuestions.length,
    correctAnswers: dailyQuestions.filter((q) => q.wasCorrect).length,
    averageResponseTime:
      dailyQuestions.length > 0 ? dailyQuestions.reduce((sum, q) => sum + q.timeSpent, 0) / dailyQuestions.length : 0,
    xpEarned: dailyResults.reduce((sum, r) => sum + r.score, 0),
    categories: dailyQuestions.reduce(
      (acc, q) => {
        const category = q.question.category
        acc[category] = (acc[category] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    ),
  }

  // Calcular estadísticas semanales
  const weeklyStats = {
    questionsAnswered: weeklyQuestions.length,
    correctAnswers: weeklyQuestions.filter((q) => q.wasCorrect).length,
    averageResponseTime:
      weeklyQuestions.length > 0
        ? weeklyQuestions.reduce((sum, q) => sum + q.timeSpent, 0) / weeklyQuestions.length
        : 0,
    xpEarned: weeklyResults.reduce((sum, r) => sum + r.score, 0),
    categories: weeklyQuestions.reduce(
      (acc, q) => {
        const category = q.question.category
        acc[category] = (acc[category] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    ),
    dailyActivity: calculateDailyActivity(weeklyQuestions),
  }

  // Calcular estadísticas mensuales
  const monthlyStats = {
    questionsAnswered: monthlyQuestions.length,
    correctAnswers: monthlyQuestions.filter((q) => q.wasCorrect).length,
    averageResponseTime:
      monthlyQuestions.length > 0
        ? monthlyQuestions.reduce((sum, q) => sum + q.timeSpent, 0) / monthlyQuestions.length
        : 0,
    xpEarned: monthlyResults.reduce((sum, r) => sum + r.score, 0),
    categories: monthlyQuestions.reduce(
      (acc, q) => {
        const category = q.question.category
        acc[category] = (acc[category] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    ),
    weeklyProgress: calculateWeeklyProgress(monthlyQuestions),
  }

  return {
    daily: dailyStats,
    weekly: weeklyStats,
    monthly: monthlyStats,
  }
}

// Función auxiliar para calcular actividad diaria
function calculateDailyActivity(questions: { answeredAt: Date }[]): number[] {
  const activityByDay = Array(7).fill(0)

  questions.forEach((q) => {
    const dayOfWeek = q.answeredAt.getDay()
    activityByDay[dayOfWeek]++
  })

  return activityByDay
}

// Función auxiliar para calcular progreso semanal
function calculateWeeklyProgress(questions: { answeredAt: Date }[]): number[] {
  const now = new Date()
  const activityByWeek = Array(4).fill(0) // 4 semanas

  questions.forEach((q) => {
    const weekDiff = Math.floor((now.getTime() - q.answeredAt.getTime()) / (7 * 24 * 60 * 60 * 1000))
    if (weekDiff < 4) {
      activityByWeek[weekDiff]++
    }
  })

  return activityByWeek.reverse() // Más reciente primero
}

// Función para identificar áreas de mejora basadas en el rendimiento
export function identifyAreasForImprovement(
  answeredQuestions: { question: Question; wasCorrect: boolean }[],
): { category: string; correctRate: number }[] {
  // Agrupar por categoría
  const categoriesMap: Record<string, { total: number; correct: number }> = {}

  answeredQuestions.forEach((q) => {
    const category = q.question.category
    if (!categoriesMap[category]) {
      categoriesMap[category] = { total: 0, correct: 0 }
    }

    categoriesMap[category].total++
    if (q.wasCorrect) {
      categoriesMap[category].correct++
    }
  })

  // Convertir a array y calcular tasas de acierto
  const categories = Object.entries(categoriesMap).map(([category, stats]) => ({
    category,
    correctRate: stats.total > 0 ? stats.correct / stats.total : 0,
  }))

  // Ordenar por tasa de acierto (ascendente)
  return categories.sort((a, b) => a.correctRate - b.correctRate)
}

// Función para generar recomendaciones personalizadas
export function generatePersonalizedRecommendations(
  userProgress: UserProgress,
  answeredQuestions: { question: Question; wasCorrect: boolean }[],
  allQuestions: Question[],
): { id: string; name: string; description: string; type: string }[] {
  const recommendations = []

  // 1. Identificar áreas de mejora
  const weakAreas = identifyAreasForImprovement(answeredQuestions)

  // Recomendar la categoría más débil si la tasa de acierto es menor al 70%
  if (weakAreas.length > 0 && weakAreas[0].correctRate < 0.7) {
    recommendations.push({
      id: `improve-${weakAreas[0].category.toLowerCase().replace(/\s+/g, "-")}`,
      name: `Mejorar en ${weakAreas[0].category}`,
      description: `Tu tasa de acierto es del ${Math.round(weakAreas[0].correctRate * 100)}%. Practica más en esta área.`,
      type: "improvement",
    })
  }

  // 2. Recomendar categorías no exploradas
  const exploredCategories = new Set(answeredQuestions.map((q) => q.question.category))
  const allCategories = new Set(allQuestions.map((q) => q.category))

  const unexploredCategories = [...allCategories].filter((c) => !exploredCategories.has(c))

  if (unexploredCategories.length > 0) {
    recommendations.push({
      id: `explore-${unexploredCategories[0].toLowerCase().replace(/\s+/g, "-")}`,
      name: `Explorar ${unexploredCategories[0]}`,
      description: `Aún no has estudiado esta categoría. ¡Amplía tus conocimientos!`,
      type: "exploration",
    })
  }

  // 3. Recomendar revisión si hay preguntas que necesitan repaso
  const today = new Date()
  const questionsNeedingReview = userProgress.answeredQuestions.filter((q) => q.nextReviewDate <= today)

  if (questionsNeedingReview.length >= 5) {
    recommendations.push({
      id: "review-session",
      name: "Sesión de repaso",
      description: `Tienes ${questionsNeedingReview.length} preguntas que necesitan repaso según el algoritmo de repetición espaciada.`,
      type: "review",
    })
  }

  // 4. Recomendar mantener la racha si está en riesgo
  const lastStreakDate = userProgress.lastStreak
  const daysSinceLastStreak = Math.floor((today.getTime() - lastStreakDate.getTime()) / (24 * 60 * 60 * 1000))

  if (daysSinceLastStreak >= 1) {
    recommendations.push({
      id: "maintain-streak",
      name: "Mantener racha",
      description: "¡No pierdas tu racha actual! Completa al menos un quiz hoy.",
      type: "streak",
    })
  }

  return recommendations
}
