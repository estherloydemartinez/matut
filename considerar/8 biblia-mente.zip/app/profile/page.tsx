"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Settings, LogOut, Award, BookOpen, BarChart, Brain, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("progress")

  // Datos de ejemplo para el perfil
  const userStats = {
    quizzesTaken: 24,
    questionsAnswered: 342,
    correctAnswers: 289,
    streakDays: 7,
    xpPoints: 4250,
    level: 8,
    nextLevelXp: 5000,
    badges: [
      { id: "b1", name: "Estudioso", description: "Completar 20 quizzes", icon: <BookOpen className="h-4 w-4" /> },
      { id: "b2", name: "Preciso", description: "85% de respuestas correctas", icon: <Zap className="h-4 w-4" /> },
      { id: "b3", name: "Constante", description: "Racha de 7 días", icon: <Award className="h-4 w-4" /> },
    ],
    recentActivity: [
      { id: "a1", type: "quiz", name: "Evangelios", score: 90, date: "Hoy" },
      { id: "a2", type: "badge", name: "Constante", date: "Ayer" },
      { id: "a3", type: "quiz", name: "Antiguo Testamento", score: 75, date: "Hace 2 días" },
    ],
    categories: [
      { name: "Historia Bíblica", progress: 65 },
      { name: "Doctrina", progress: 42 },
      { name: "Evangelios", progress: 78 },
      { name: "Epístolas", progress: 30 },
      { name: "Profecía", progress: 25 },
    ],
    recommendations: [
      {
        id: "r1",
        name: "Profetas Menores",
        description: "Mejorar conocimiento en esta área",
        icon: <Brain className="h-5 w-5" />,
      },
      {
        id: "r2",
        name: "Repaso de Doctrina",
        description: "Reforzar conceptos básicos",
        icon: <BookOpen className="h-5 w-5" />,
      },
    ],
  }

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-6">
        <Link href="/">
          <Button variant="ghost" size="sm" className="gap-1">
            <ArrowLeft className="h-4 w-4" /> Volver
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon">
            <Settings className="h-5 w-5" />
            <span className="sr-only">Configuración</span>
          </Button>
          <Button variant="ghost" size="icon">
            <LogOut className="h-5 w-5" />
            <span className="sr-only">Cerrar sesión</span>
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6 mb-8">
        <div className="flex flex-col items-center md:items-start gap-4">
          <Avatar className="h-24 w-24 border-4 border-background">
            <AvatarImage src="/placeholder.svg?height=96&width=96" alt="@usuario" />
            <AvatarFallback>JP</AvatarFallback>
          </Avatar>
          <div className="text-center md:text-left">
            <h1 className="text-2xl font-bold">Juan Pérez</h1>
            <p className="text-muted-foreground">Miembro desde Abril 2023</p>
          </div>
        </div>
        <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 flex flex-col items-center justify-center">
              <p className="text-xs text-muted-foreground">Nivel</p>
              <p className="text-2xl font-bold">{userStats.level}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center justify-center">
              <p className="text-xs text-muted-foreground">XP</p>
              <p className="text-2xl font-bold">{userStats.xpPoints}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center justify-center">
              <p className="text-xs text-muted-foreground">Racha</p>
              <p className="text-2xl font-bold">{userStats.streakDays} días</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 flex flex-col items-center justify-center">
              <p className="text-xs text-muted-foreground">Precisión</p>
              <p className="text-2xl font-bold">
                {Math.round((userStats.correctAnswers / userStats.questionsAnswered) * 100)}%
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
          <p className="text-sm font-medium">Progreso al nivel {userStats.level + 1}</p>
          <p className="text-sm text-muted-foreground">
            {userStats.xpPoints}/{userStats.nextLevelXp} XP
          </p>
        </div>
        <Progress value={(userStats.xpPoints / userStats.nextLevelXp) * 100} className="h-2" />
      </div>

      <Tabs defaultValue="progress" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="progress">Progreso</TabsTrigger>
          <TabsTrigger value="badges">Logros</TabsTrigger>
          <TabsTrigger value="activity">Actividad</TabsTrigger>
        </TabsList>
        <TabsContent value="progress" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Progreso por categoría</CardTitle>
              <CardDescription>Tu dominio de diferentes áreas de conocimiento bíblico</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {userStats.categories.map((category) => (
                <div key={category.name} className="space-y-2">
                  <div className="flex justify-between">
                    <p className="text-sm font-medium">{category.name}</p>
                    <p className="text-sm text-muted-foreground">{category.progress}%</p>
                  </div>
                  <Progress value={category.progress} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recomendaciones personalizadas</CardTitle>
              <CardDescription>Basado en tu patrón de aprendizaje y neurociencia</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {userStats.recommendations.map((rec) => (
                <div key={rec.id} className="flex items-start gap-4 p-4 rounded-lg border">
                  <div className="rounded-full bg-primary/10 p-2">{rec.icon}</div>
                  <div>
                    <h4 className="font-medium">{rec.name}</h4>
                    <p className="text-sm text-muted-foreground">{rec.description}</p>
                  </div>
                  <Button size="sm" className="ml-auto">
                    Comenzar
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="badges" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Logros desbloqueados</CardTitle>
              <CardDescription>Tus reconocimientos por el progreso en el estudio bíblico</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {userStats.badges.map((badge) => (
                  <div key={badge.id} className="flex items-center gap-4 p-4 rounded-lg border">
                    <div className="rounded-full bg-primary/10 p-3">{badge.icon}</div>
                    <div>
                      <h4 className="font-medium">{badge.name}</h4>
                      <p className="text-sm text-muted-foreground">{badge.description}</p>
                    </div>
                  </div>
                ))}

                {/* Logros bloqueados */}
                <div className="flex items-center gap-4 p-4 rounded-lg border bg-muted/40">
                  <div className="rounded-full bg-muted p-3">
                    <Brain className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium text-muted-foreground">Erudito</h4>
                    <p className="text-sm text-muted-foreground">Completa 50 quizzes (24/50)</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-lg border bg-muted/40">
                  <div className="rounded-full bg-muted p-3">
                    <BarChart className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <h4 className="font-medium text-muted-foreground">Maestro</h4>
                    <p className="text-sm text-muted-foreground">Alcanza el nivel 15 (8/15)</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Actividad reciente</CardTitle>
              <CardDescription>Tu historial de actividades en BibliaMente</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {userStats.recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start">
                    <div className="mr-4 mt-1">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                        {activity.type === "quiz" ? (
                          <BookOpen className="h-4 w-4 text-primary" />
                        ) : (
                          <Award className="h-4 w-4 text-primary" />
                        )}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium leading-none">
                        {activity.type === "quiz" ? (
                          <>
                            Completaste el quiz: <span className="font-bold">{activity.name}</span>
                          </>
                        ) : (
                          <>
                            Desbloqueaste el logro: <span className="font-bold">{activity.name}</span>
                          </>
                        )}
                      </p>
                      {activity.score && <p className="text-sm text-muted-foreground">Puntuación: {activity.score}%</p>}
                      <p className="text-xs text-muted-foreground">{activity.date}</p>
                    </div>
                    {activity.type === "quiz" && (
                      <Badge variant="outline" className="ml-auto">
                        {activity.score >= 80 ? "Excelente" : activity.score >= 60 ? "Bueno" : "Regular"}
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
