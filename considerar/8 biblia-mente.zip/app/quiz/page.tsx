"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, HelpCircle, Timer, Award, Brain, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"

// Tipos para las preguntas
interface Option {
  id: string
  text: string
}

interface Question {
  id: string
  text: string
  options: Option[]
  correctOptionId: string
  explanation: string
  difficulty: "easy" | "medium" | "hard"
  category: string
  reference: string
}

// Datos de ejemplo para las preguntas
const sampleQuestions: Question[] = [
  {
    id: "q1",
    text: "¿Quién fue el primer rey de Israel mencionado en la Biblia?",
    options: [
      { id: "a", text: "David" },
      { id: "b", text: "Saúl" },
      { id: "c", text: "Salomón" },
      { id: "d", text: "Samuel" },
    ],
    correctOptionId: "b",
    explanation:
      "Saúl fue el primer rey de Israel, ungido por el profeta Samuel. Su historia se encuentra en 1 Samuel 9-10.",
    difficulty: "medium",
    category: "Historia Bíblica",
    reference: "1 Samuel 9-10",
  },
  {
    id: "q2",
    text: "¿Cuál de los siguientes NO es uno de los frutos del Espíritu mencionados en Gálatas 5?",
    options: [
      { id: "a", text: "Amor" },
      { id: "b", text: "Paciencia" },
      { id: "c", text: "Sabiduría" },
      { id: "d", text: "Bondad" },
    ],
    correctOptionId: "c",
    explanation:
      "Los frutos del Espíritu son: amor, gozo, paz, paciencia, benignidad, bondad, fe, mansedumbre y templanza. La sabiduría no está en esta lista específica.",
    difficulty: "medium",
    category: "Doctrina",
    reference: "Gálatas 5:22-23",
  },
  {
    id: "q3",
    text: "¿Cuántos libros tiene el Nuevo Testamento?",
    options: [
      { id: "a", text: "27" },
      { id: "b", text: "39" },
      { id: "c", text: "66" },
      { id: "d", text: "12" },
    ],
    correctOptionId: "a",
    explanation: "El Nuevo Testamento contiene 27 libros, desde Mateo hasta Apocalipsis.",
    difficulty: "easy",
    category: "Estructura Bíblica",
    reference: "Índice de la Biblia",
  },
  {
    id: "q4",
    text: "¿Quién escribió la mayoría de los Salmos?",
    options: [
      { id: "a", text: "Moisés" },
      { id: "b", text: "Salomón" },
      { id: "c", text: "David" },
      { id: "d", text: "Asaf" },
    ],
    correctOptionId: "c",
    explanation: "El rey David escribió la mayoría de los Salmos (aproximadamente 73 de los 150).",
    difficulty: "easy",
    category: "Autores Bíblicos",
    reference: "Libro de los Salmos",
  },
  {
    id: "q5",
    text: "¿Cuál de estas personas NO caminó sobre el agua con Jesús?",
    options: [
      { id: "a", text: "Pedro" },
      { id: "b", text: "Juan" },
      { id: "c", text: "Santiago" },
      { id: "d", text: "Ninguno excepto Pedro intentó caminar sobre el agua" },
    ],
    correctOptionId: "d",
    explanation: "Solo Pedro intentó caminar sobre el agua hacia Jesús, como se registra en Mateo 14:22-33.",
    difficulty: "medium",
    category: "Evangelios",
    reference: "Mateo 14:22-33",
  },
]

export default function QuizPage() {
  const { toast } = useToast()
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null)
  const [isAnswered, setIsAnswered] = useState(false)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(30)
  const [streakCount, setStreakCount] = useState(0)
  const [showExplanation, setShowExplanation] = useState(false)
  const [quizCompleted, setQuizCompleted] = useState(false)

  const currentQuestion = sampleQuestions[currentQuestionIndex]
  const progress = (currentQuestionIndex / sampleQuestions.length) * 100

  // Efecto para el temporizador
  useEffect(() => {
    if (isAnswered || quizCompleted) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          handleTimeUp()
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [isAnswered, currentQuestionIndex, quizCompleted])

  // Función para manejar cuando se acaba el tiempo
  const handleTimeUp = () => {
    setIsAnswered(true)
    setStreakCount(0)
    toast({
      title: "¡Tiempo agotado!",
      description: "No respondiste a tiempo. La respuesta correcta ha sido revelada.",
      variant: "destructive",
    })
  }

  // Función para seleccionar una opción
  const handleSelectOption = (optionId: string) => {
    if (isAnswered) return

    setSelectedOptionId(optionId)
    setIsAnswered(true)

    // Verificar si la respuesta es correcta
    if (optionId === currentQuestion.correctOptionId) {
      setScore((prev) => prev + 10 + streakCount * 2) // Bonus por racha
      setStreakCount((prev) => prev + 1)
      toast({
        title: "¡Correcto!",
        description: `+${10 + streakCount * 2} puntos. Racha actual: ${streakCount + 1}`,
        variant: "default",
      })
    } else {
      setStreakCount(0)
      toast({
        title: "Incorrecto",
        description: "La respuesta correcta ha sido revelada.",
        variant: "destructive",
      })
    }
  }

  // Función para pasar a la siguiente pregunta
  const handleNextQuestion = () => {
    if (currentQuestionIndex < sampleQuestions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1)
      setSelectedOptionId(null)
      setIsAnswered(false)
      setTimeLeft(30)
      setShowExplanation(false)
    } else {
      setQuizCompleted(true)
    }
  }

  // Función para reiniciar el quiz
  const handleRestartQuiz = () => {
    setCurrentQuestionIndex(0)
    setSelectedOptionId(null)
    setIsAnswered(false)
    setScore(0)
    setTimeLeft(30)
    setStreakCount(0)
    setShowExplanation(false)
    setQuizCompleted(false)
  }

  // Renderizar la pantalla de resultados finales
  if (quizCompleted) {
    return (
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <Card className="w-full">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl">¡Quiz Completado!</CardTitle>
            <CardDescription>Has completado el quiz de conocimiento bíblico</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="flex flex-col items-center justify-center space-y-4">
              <Award className="h-24 w-24 text-yellow-500" />
              <h2 className="text-4xl font-bold">{score} puntos</h2>
              <p className="text-muted-foreground text-center">
                Has respondido correctamente {Math.floor(score / 10)} de {sampleQuestions.length} preguntas.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-4">
                <Brain className="h-8 w-8 text-primary" />
                <h3 className="font-medium">Neurociencia</h3>
                <p className="text-sm text-center text-muted-foreground">
                  Volveremos a preguntarte estas preguntas en intervalos óptimos para mejorar tu retención.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-4">
                <BookOpen className="h-8 w-8 text-primary" />
                <h3 className="font-medium">Recomendaciones</h3>
                <p className="text-sm text-center text-muted-foreground">
                  Basado en tus respuestas, te recomendamos estudiar más sobre Historia Bíblica.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border p-4">
                <Award className="h-8 w-8 text-primary" />
                <h3 className="font-medium">Logros</h3>
                <p className="text-sm text-center text-muted-foreground">
                  ¡Has desbloqueado el logro "Estudiante Bíblico" por completar tu primer quiz!
                </p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <Button onClick={handleRestartQuiz} className="w-full">
              Intentar de nuevo
            </Button>
            <Link href="/" className="w-full">
              <Button variant="outline" className="w-full">
                Volver al inicio
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-6">
        <Link href="/">
          <Button variant="ghost" size="sm" className="gap-1">
            <ArrowLeft className="h-4 w-4" /> Volver
          </Button>
        </Link>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Award className="h-5 w-5 text-yellow-500" />
            <span className="font-medium">{score}</span>
          </div>
          <div className="flex items-center gap-1 bg-muted px-3 py-1 rounded-full">
            <Timer className="h-4 w-4" />
            <span className={cn("font-medium", timeLeft < 10 && "text-red-500")}>{timeLeft}s</span>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex justify-between text-sm mb-2">
          <span>
            Pregunta {currentQuestionIndex + 1} de {sampleQuestions.length}
          </span>
          <span className="text-muted-foreground">{currentQuestion.category}</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <Card className="w-full mb-6">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div className="px-3 py-1 rounded-full text-xs font-medium bg-muted inline-block">
              {currentQuestion.difficulty === "easy"
                ? "Fácil"
                : currentQuestion.difficulty === "medium"
                  ? "Media"
                  : "Difícil"}
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full"
              onClick={() => setShowExplanation(!showExplanation)}
              disabled={!isAnswered}
            >
              <HelpCircle className="h-5 w-5" />
              <span className="sr-only">Mostrar explicación</span>
            </Button>
          </div>
          <CardTitle className="text-xl mt-2">{currentQuestion.text}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {currentQuestion.options.map((option) => (
            <div
              key={option.id}
              className={cn(
                "flex items-center p-4 rounded-lg border cursor-pointer transition-colors",
                selectedOptionId === option.id &&
                  isAnswered &&
                  option.id === currentQuestion.correctOptionId &&
                  "bg-green-100 border-green-500",
                selectedOptionId === option.id &&
                  isAnswered &&
                  option.id !== currentQuestion.correctOptionId &&
                  "bg-red-100 border-red-500",
                !selectedOptionId &&
                  isAnswered &&
                  option.id === currentQuestion.correctOptionId &&
                  "bg-green-100 border-green-500",
                !isAnswered && "hover:bg-muted/50",
              )}
              onClick={() => !isAnswered && handleSelectOption(option.id)}
            >
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <div
                    className={cn(
                      "flex items-center justify-center w-6 h-6 rounded-full border text-xs font-medium",
                      selectedOptionId === option.id &&
                        isAnswered &&
                        option.id === currentQuestion.correctOptionId &&
                        "bg-green-500 text-white border-green-500",
                      selectedOptionId === option.id &&
                        isAnswered &&
                        option.id !== currentQuestion.correctOptionId &&
                        "bg-red-500 text-white border-red-500",
                      !selectedOptionId &&
                        isAnswered &&
                        option.id === currentQuestion.correctOptionId &&
                        "bg-green-500 text-white border-green-500",
                    )}
                  >
                    {option.id.toUpperCase()}
                  </div>
                  <span>{option.text}</span>
                </div>
              </div>
            </div>
          ))}

          {showExplanation && isAnswered && (
            <div className="mt-4 p-4 rounded-lg bg-muted/50 border">
              <h4 className="font-medium mb-1">Explicación:</h4>
              <p className="text-sm text-muted-foreground">{currentQuestion.explanation}</p>
              <p className="text-xs text-muted-foreground mt-2">Referencia: {currentQuestion.reference}</p>
            </div>
          )}
        </CardContent>
        <CardFooter>
          {isAnswered ? (
            <Button onClick={handleNextQuestion} className="w-full">
              {currentQuestionIndex < sampleQuestions.length - 1 ? "Siguiente pregunta" : "Ver resultados"}
            </Button>
          ) : (
            <Button disabled className="w-full">
              Selecciona una respuesta
            </Button>
          )}
        </CardFooter>
      </Card>

      {streakCount > 1 && (
        <div className="flex items-center justify-center gap-2 p-2 rounded-lg bg-amber-100 text-amber-800 border border-amber-200">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5"
          >
            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
          </svg>
          <span className="font-medium">
            ¡Racha de {streakCount}! +{streakCount * 2} puntos extra en la próxima respuesta correcta
          </span>
        </div>
      )}
    </div>
  )
}
