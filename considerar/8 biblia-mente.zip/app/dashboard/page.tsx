"use client"

import { useState } from "react"
import Link from "next/link"
import { BookOpen, Brain, Clock, Award, BarChart3, Calendar, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("daily")

  // Datos de ejemplo para el dashboard
  const dashboardData = {
    dailyStreak: 7,
    totalXp: 4250,
    weeklyProgress: 4,
    weeklyGoal: 7,
    todayQuestion: {
      text: "¿Quién fue el primer rey de Israel mencionado en la Biblia?",
      category: "Historia Bíblica",
      difficulty: "medium",
    },
    recommendedQuizzes: [
      { id: "q1", name: "Profetas Menores", questions: 15, category: "Antiguo Testamento", progress: 0 },
      { id: "q2", name: "Parábolas de Jesús", questions: 10, category: "Evangelios", progress: 30 },
      { id: "q3", name: "Epístolas de Pablo", questions: 20, category: "Nuevo Testamento", progress: 60 },
    ],
    leaderboard: [
      { rank: 1, name: "María G.", avatar: "/placeholder.svg?height=40&width=40", xp: 8750 },
      { rank: 2, name: "Carlos R.", avatar: "/placeholder.svg?height=40&width=40", xp: 7200 },
      { rank: 3, name: "Ana M.", avatar: "/placeholder.svg?height=40&width=40", xp: 6800 },
      { rank: 4, name: "Tú", avatar: "/placeholder.svg?height=40&width=40", xp: 4250, isUser: true },
      { rank: 5, name: "Pedro S.", avatar: "/placeholder.svg?height=40&width=40", xp: 3900 },
    ],
    upcomingReviews: [
      { id: "r1", name: "Reyes de Israel", dueIn: "2 horas", category: "Historia Bíblica" },
      { id: "r2", name: "Frutos del Espíritu", dueIn: "Mañana", category: "Doctrina" },
    ],
  }

  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Bienvenido de nuevo, Juan. Continúa tu aprendizaje bíblico.</p>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/profile">
            <Button variant="outline" className="gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src="/placeholder.svg?height=24&width=24" alt="@usuario" />
                <AvatarFallback>JP</AvatarFallback>
              </Avatar>
              Mi perfil
            </Button>
          </Link>
          <Link href="/quiz">
            <Button className="gap-2">
              <BookOpen className="h-4 w-4" />
              Nuevo quiz
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full bg-primary/10 p-3">
              <Award className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Racha diaria</p>
              <div className="flex items-baseline gap-1">
                <p className="text-2xl font-bold">{dashboardData.dailyStreak}</p>
                <p className="text-muted-foreground">días</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full bg-primary/10 p-3">
              <Brain className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">XP Total</p>
              <div className="flex items-baseline gap-1">
                <p className="text-2xl font-bold">{dashboardData.totalXp}</p>
                <p className="text-muted-foreground">puntos</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="rounded-full bg-primary/10 p-3">
              <Calendar className="h-6 w-6 text-primary" />
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-baseline mb-1">
                <p className="text-sm text-muted-foreground">Progreso semanal</p>
                <p className="text-xs text-muted-foreground">
                  {dashboardData.weeklyProgress}/{dashboardData.weeklyGoal} días
                </p>
              </div>
              <Progress value={(dashboardData.weeklyProgress / dashboardData.weeklyGoal) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Pregunta del día</CardTitle>
              <CardDescription>Responde para mantener tu racha diaria</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <Badge variant="outline">{dashboardData.todayQuestion.category}</Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>
                      Dificultad:{" "}
                      {dashboardData.todayQuestion.difficulty === "easy"
                        ? "Fácil"
                        : dashboardData.todayQuestion.difficulty === "medium"
                          ? "Media"
                          : "Difícil"}
                    </span>
                  </div>
                </div>
                <p className="text-lg">{dashboardData.todayQuestion.text}</p>
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/quiz" className="w-full">
                <Button className="w-full">Responder ahora</Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quizzes recomendados</CardTitle>
              <CardDescription>Basados en tu patrón de aprendizaje y neurociencia</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dashboardData.recommendedQuizzes.map((quiz) => (
                  <div key={quiz.id} className="flex flex-col sm:flex-row sm:items-center gap-4 p-4 rounded-lg border">
                    <div className="rounded-full bg-primary/10 p-3 sm:p-4">
                      <BookOpen className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-2">
                        <h4 className="font-medium">{quiz.name}</h4>
                        <Badge variant="outline">{quiz.category}</Badge>
                      </div>
                      <div className="flex justify-between items-center mb-1">
                        <p className="text-xs text-muted-foreground">{quiz.questions} preguntas</p>
                        <p className="text-xs text-muted-foreground">{quiz.progress}% completado</p>
                      </div>
                      <Progress value={quiz.progress} className="h-1.5" />
                    </div>
                    <Link href={`/quiz/${quiz.id}`}>
                      <Button variant="ghost" size="icon" className="rounded-full">
                        <ChevronRight className="h-5 w-5" />
                      </Button>
                    </Link>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tabla de clasificación</CardTitle>
              <CardDescription>Compite con otros estudiantes bíblicos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dashboardData.leaderboard.map((user) => (
                  <div
                    key={user.rank}
                    className={`flex items-center gap-4 p-3 rounded-lg ${user.isUser ? "bg-primary/10 border border-primary/20" : ""}`}
                  >
                    <div className="flex items-center justify-center w-6 h-6 rounded-full bg-muted text-xs font-medium">
                      {user.rank}
                    </div>
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                      <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{user.name}</p>
                    </div>
                    <p className="text-sm font-medium">{user.xp} XP</p>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Link href="/leaderboard" className="w-full">
                <Button variant="outline" className="w-full">
                  Ver tabla completa
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Próximas revisiones</CardTitle>
              <CardDescription>Basado en el aprendizaje espaciado</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {dashboardData.upcomingReviews.map((review) => (
                  <div key={review.id} className="flex items-center gap-4 p-3 rounded-lg border">
                    <div className="rounded-full bg-primary/10 p-2">
                      <Brain className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{review.name}</p>
                      <p className="text-xs text-muted-foreground">{review.category}</p>
                    </div>
                    <Badge variant="outline">{review.dueIn}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Estadísticas de aprendizaje</CardTitle>
          <CardDescription>Análisis de tu progreso basado en neurociencia</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="daily" onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="daily">Diario</TabsTrigger>
              <TabsTrigger value="weekly">Semanal</TabsTrigger>
              <TabsTrigger value="monthly">Mensual</TabsTrigger>
            </TabsList>
            <TabsContent value="daily" className="space-y-4">
              <div className="h-[200px] flex items-center justify-center bg-muted/40 rounded-lg">
                <BarChart3 className="h-16 w-16 text-muted-foreground" />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Preguntas</p>
                  <p className="text-2xl font-bold">24</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Precisión</p>
                  <p className="text-2xl font-bold">85%</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Tiempo medio</p>
                  <p className="text-2xl font-bold">18s</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">XP ganado</p>
                  <p className="text-2xl font-bold">120</p>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="weekly" className="space-y-4">
              <div className="h-[200px] flex items-center justify-center bg-muted/40 rounded-lg">
                <BarChart3 className="h-16 w-16 text-muted-foreground" />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Preguntas</p>
                  <p className="text-2xl font-bold">142</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Precisión</p>
                  <p className="text-2xl font-bold">78%</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Tiempo medio</p>
                  <p className="text-2xl font-bold">22s</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">XP ganado</p>
                  <p className="text-2xl font-bold">850</p>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="monthly" className="space-y-4">
              <div className="h-[200px] flex items-center justify-center bg-muted/40 rounded-lg">
                <BarChart3 className="h-16 w-16 text-muted-foreground" />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Preguntas</p>
                  <p className="text-2xl font-bold">512</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Precisión</p>
                  <p className="text-2xl font-bold">82%</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">Tiempo medio</p>
                  <p className="text-2xl font-bold">20s</p>
                </div>
                <div className="p-4 rounded-lg border">
                  <p className="text-sm text-muted-foreground">XP ganado</p>
                  <p className="text-2xl font-bold">3250</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
