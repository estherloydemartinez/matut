"""
Configuración de BibliaApp Pro Android
Contiene todas las configuraciones y constantes de la aplicación
"""

import os
from pathlib import Path

# ============================================================================
# INFORMACIÓN DE LA APLICACIÓN
# ============================================================================

APP_INFO = {
    'name': 'BibliaApp Pro',
    'version': '2.0.0',
    'build': '2024.12.17',
    'package': 'com.bibliaapp.pro',
    'author': 'BibliaApp Team',
    'description': 'Formación Bíblica de Clase Mundial',
    'website': 'https://bibliaapp.com',
    'support_email': 'soporte@bibliaapp.com'
}

# ============================================================================
# CONFIGURACIÓN DE PATHS
# ============================================================================

# Directorio base de la aplicación
if hasattr(os, 'environ') and 'ANDROID_STORAGE' in os.environ:
    # Estamos en Android
    BASE_DIR = Path(os.environ['ANDROID_STORAGE'])
    DATA_DIR = BASE_DIR / 'data' / APP_INFO['package']
    CACHE_DIR = BASE_DIR / 'cache' / APP_INFO['package']
    EXTERNAL_DIR = Path('/storage/emulated/0') / 'BibliaApp'
else:
    # Estamos en desktop/desarrollo
    BASE_DIR = Path.home() / '.bibliaapp'
    DATA_DIR = BASE_DIR / 'data'
    CACHE_DIR = BASE_DIR / 'cache'
    EXTERNAL_DIR = BASE_DIR / 'external'

# Crear directorios si no existen
for directory in [DATA_DIR, CACHE_DIR, EXTERNAL_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# Archivos de datos
DATABASE_PATH = DATA_DIR / 'bibliaapp.db'
SETTINGS_PATH = DATA_DIR / 'settings.json'
USER_DATA_PATH = DATA_DIR / 'user_data.json'
BIBLE_CACHE_PATH = CACHE_DIR / 'bible_cache'
ASSETS_CACHE_PATH = CACHE_DIR / 'assets'

# ============================================================================
# CONFIGURACIÓN DE UI/UX
# ============================================================================

UI_CONFIG = {
    # Paleta de colores principal
    'colors': {
        'primary': '#4F46E5',           # Indigo principal
        'primary_dark': '#4338CA',      # Indigo oscuro
        'primary_light': '#A5B4FC',     # Indigo claro
        'secondary': '#F59E0B',         # Ámbar
        'accent': '#EC4899',            # Rosa
        'success': '#10B981',           # Verde
        'warning': '#F59E0B',           # Ámbar
        'error': '#EF4444',             # Rojo
        'info': '#3B82F6',              # Azul
        
        # Colores de fondo
        'background': '#F8FAFC',        # Gris muy claro
        'surface': '#FFFFFF',           # Blanco
        'card': '#FFFFFF',              # Blanco para cards
        
        # Colores de texto
        'text_primary': '#1F2937',      # Gris oscuro
        'text_secondary': '#6B7280',    # Gris medio
        'text_hint': '#9CA3AF',         # Gris claro
        'text_on_primary': '#FFFFFF',   # Blanco sobre primario
        'text_on_secondary': '#000000', # Negro sobre secundario
        
        # Colores pastel para categorías
        'pastel_blue': '#E0F2FE',
        'pastel_green': '#ECFDF5',
        'pastel_yellow': '#FFFBEB',
        'pastel_purple': '#F3E8FF',
        'pastel_pink': '#FDF2F8',
        'pastel_orange': '#FFF7ED'
    },
    
    # Tipografía
    'fonts': {
        'primary': 'Roboto',
        'secondary': 'Roboto Condensed',
        'mono': 'Roboto Mono',
        'sizes': {
            'tiny': '10sp',
            'small': '12sp',
            'body': '14sp',
            'subtitle': '16sp',
            'title': '20sp',
            'headline': '24sp',
            'display': '32sp'
        }
    },
    
    # Espaciado
    'spacing': {
        'tiny': '4dp',
        'small': '8dp',
        'medium': '16dp',
        'large': '24dp',
        'xlarge': '32dp'
    },
    
    # Elevación y sombras
    'elevation': {
        'none': 0,
        'low': 2,
        'medium': 4,
        'high': 8,
        'highest': 16
    },
    
    # Radios de borde
    'radius': {
        'small': '4dp',
        'medium': '8dp',
        'large': '12dp',
        'xlarge': '16dp',
        'circle': '50dp'
    }
}

# ============================================================================
# CONFIGURACIÓN DE CARACTERÍSTICAS
# ============================================================================

FEATURES = {
    # Características principales
    'offline_mode': True,
    'bible_reading': True,
    'prayer_tools': True,
    'study_tools': True,
    'memorization': True,
    'social_features': True,
    'gamification': True,
    'notifications': True,
    'audio_features': True,
    'search': True,
    'bookmarks': True,
    'notes': True,
    'reading_plans': True,
    
    # Características avanzadas
    'advanced_analytics': True,
    'cross_references': True,
    'commentaries': True,
    'concordance': True,
    'maps': True,
    'timeline': True,
    'character_study': True,
    'word_study': True,
    'topic_study': True,
    
    # Características experimentales
    'ai_insights': False,           # Deshabilitado por ahora
    'voice_recognition': False,     # Deshabilitado por ahora
    'ar_features': False,           # Deshabilitado por ahora
    'collaborative_study': False,   # Deshabilitado por ahora
}

# ============================================================================
# CONFIGURACIÓN DE DATOS BÍBLICOS
# ============================================================================

BIBLE_CONFIG = {
    'default_version': 'RV1960',
    'available_versions': [
        'RV1960',   # Reina Valera 1960
        'NVI',      # Nueva Versión Internacional
        'LBLA',     # La Biblia de las Américas
        'DHH',      # Dios Habla Hoy
        'TLA',      # Traducción en Lenguaje Actual
        'PDT',      # Palabra de Dios para Todos
        'BLP',      # La Palabra (Blanco y Negro)
    ],
    
    'languages': {
        'es': 'Español',
        'en': 'English',
        'pt': 'Português',
        'fr': 'Français'
    },
    
    'default_language': 'es',
    
    # Configuración de lectura
    'reading': {
        'default_font_size': 16,
        'min_font_size': 12,
        'max_font_size': 24,
        'default_line_spacing': 1.5,
        'verse_numbers': True,
        'cross_references': True,
        'footnotes': True
    }
}

# ============================================================================
# CONFIGURACIÓN DE GAMIFICACIÓN
# ============================================================================

GAMIFICATION_CONFIG = {
    # Sistema de experiencia
    'xp': {
        'daily_reading': 10,
        'chapter_complete': 25,
        'book_complete': 100,
        'verse_memorized': 15,
        'prayer_session': 5,
        'note_created': 3,
        'bookmark_added': 2,
        'sharing': 8,
        'helping_others': 20,
        'achievement_unlocked': 50,
        'streak_milestone': 25,
        'plan_completed': 200
    },
    
    # Niveles
    'levels': {
        'beginner': 0,
        'seeker': 100,
        'disciple': 500,
        'student': 1500,
        'scholar': 3500,
        'teacher': 7500,
        'master': 15000,
        'sage': 25000,
        'elder': 40000,
        'legend': 60000
    },
    
    # Logros
    'achievements': {
        'first_read': {'name': 'Primer Paso', 'description': 'Primera lectura bíblica', 'xp': 50},
        'week_streak': {'name': 'Constante', 'description': '7 días seguidos leyendo', 'xp': 100},
        'month_streak': {'name': 'Fiel', 'description': '30 días seguidos leyendo', 'xp': 300},
        'year_streak': {'name': 'Perseverante', 'description': '365 días seguidos leyendo', 'xp': 1000},
        'bible_complete': {'name': 'Completista', 'description': 'Leyó toda la Biblia', 'xp': 2000},
        'verse_master': {'name': 'Memorizador', 'description': '100 versículos memorizados', 'xp': 500},
        'prayer_warrior': {'name': 'Guerrero de Oración', 'description': '100 sesiones de oración', 'xp': 300},
        'note_taker': {'name': 'Estudioso', 'description': '50 notas creadas', 'xp': 200},
        'helper': {'name': 'Ayudador', 'description': 'Ayudó a 10 personas', 'xp': 500},
        'teacher': {'name': 'Maestro', 'description': 'Compartió 100 insights', 'xp': 800}
    }
}

# ============================================================================
# CONFIGURACIÓN DE NOTIFICACIONES
# ============================================================================

NOTIFICATIONS_CONFIG = {
    'enabled': True,
    'daily_reminder': {
        'enabled': True,
        'time': '08:00',  # 8:00 AM
        'title': '📖 Tiempo de Lectura',
        'message': '¡Es hora de tu lectura bíblica diaria!'
    },
    'prayer_reminder': {
        'enabled': True,
        'times': ['12:00', '18:00'],  # 12:00 PM y 6:00 PM
        'title': '🙏 Momento de Oración',
        'message': 'Dedica unos minutos para orar'
    },
    'achievement': {
        'enabled': True,
        'title': '🏆 ¡Logro Desbloqueado!',
        'message': 'Has alcanzado un nuevo logro'
    },
    'streak': {
        'enabled': True,
        'title': '🔥 ¡Racha Activa!',
        'message': 'Mantén tu racha de lectura'
    }
}

# ============================================================================
# CONFIGURACIÓN DE RED
# ============================================================================

NETWORK_CONFIG = {
    'api_base_url': 'https://api.bibliaapp.com/v2',
    'cdn_base_url': 'https://cdn.bibliaapp.com',
    'timeout': 30,
    'max_retries': 3,
    'retry_delay': 1.0,
    
    'endpoints': {
        'auth': '/auth',
        'sync': '/sync',
        'bible': '/bible',
        'social': '/social',
        'analytics': '/analytics',
        'updates': '/updates'
    },
    
    'headers': {
        'User-Agent': f'BibliaApp Pro Android/{APP_INFO["version"]}',
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }
}

# ============================================================================
# CONFIGURACIÓN DE CACHE
# ============================================================================

CACHE_CONFIG = {
    'max_size_mb': 500,  # 500 MB máximo
    'expiry_days': 30,
    'cleanup_on_start': True,
    
    'categories': {
        'bible_text': {'size_mb': 200, 'expiry_days': 365},
        'images': {'size_mb': 100, 'expiry_days': 30},
        'audio': {'size_mb': 150, 'expiry_days': 7},
        'user_data': {'size_mb': 50, 'expiry_days': 1}
    }
}

# ============================================================================
# CONFIGURACIÓN DE LOGGING
# ============================================================================

LOGGING_CONFIG = {
    'enabled': True,
    'level': 'INFO',  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    'max_files': 10,
    'max_file_size_mb': 5,
    'log_file': DATA_DIR / 'app.log',
    
    'loggers': {
        'app': {'level': 'INFO', 'file': 'app.log'},
        'bible': {'level': 'DEBUG', 'file': 'bible.log'},
        'network': {'level': 'WARNING', 'file': 'network.log'},
        'ui': {'level': 'ERROR', 'file': 'ui.log'}
    }
}

# ============================================================================
# CONFIGURACIÓN DE DESARROLLO
# ============================================================================

DEBUG_CONFIG = {
    'enabled': False,  # Cambiar a True para desarrollo
    'show_fps': False,
    'log_touches': False,
    'mock_data': False,
    'skip_intro': False,
    'test_mode': False
}

# ============================================================================
# CONFIGURACIÓN DE ACCESIBILIDAD
# ============================================================================

ACCESSIBILITY_CONFIG = {
    'large_text': False,
    'high_contrast': False,
    'voice_over': False,
    'haptic_feedback': True,
    'screen_reader_support': True,
    'gesture_navigation': True
}

# ============================================================================
# FUNCIONES DE UTILIDAD
# ============================================================================

def get_config(section, key=None, default=None):
    """Obtener configuración de manera segura"""
    sections = {
        'app': APP_INFO,
        'ui': UI_CONFIG,
        'features': FEATURES,
        'bible': BIBLE_CONFIG,
        'gamification': GAMIFICATION_CONFIG,
        'notifications': NOTIFICATIONS_CONFIG,
        'network': NETWORK_CONFIG,
        'cache': CACHE_CONFIG,
        'logging': LOGGING_CONFIG,
        'debug': DEBUG_CONFIG,
        'accessibility': ACCESSIBILITY_CONFIG
    }
    
    if section not in sections:
        return default
    
    section_config = sections[section]
    
    if key is None:
        return section_config
    
    return section_config.get(key, default)

def is_debug_mode():
    """Verificar si estamos en modo debug"""
    return DEBUG_CONFIG.get('enabled', False)

def is_feature_enabled(feature_name):
    """Verificar si una característica está habilitada"""
    return FEATURES.get(feature_name, False)

def get_app_version():
    """Obtener versión de la aplicación"""
    return APP_INFO['version']

def get_app_name():
    """Obtener nombre de la aplicación"""
    return APP_INFO['name']

# ============================================================================
# EXPORTACIONES
# ============================================================================

__all__ = [
    'APP_INFO',
    'UI_CONFIG', 
    'FEATURES',
    'BIBLE_CONFIG',
    'GAMIFICATION_CONFIG',
    'NOTIFICATIONS_CONFIG',
    'NETWORK_CONFIG',
    'CACHE_CONFIG',
    'LOGGING_CONFIG',
    'DEBUG_CONFIG',
    'ACCESSIBILITY_CONFIG',
    'DATA_DIR',
    'CACHE_DIR',
    'DATABASE_PATH',
    'SETTINGS_PATH',
    'get_config',
    'is_debug_mode',
    'is_feature_enabled',
    'get_app_version',
    'get_app_name'
]
