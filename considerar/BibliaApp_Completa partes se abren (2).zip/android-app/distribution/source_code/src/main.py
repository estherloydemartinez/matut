"""
BibliaApp Pro - Aplicación Android
Aplicación nativa Android desarrollada con Kivy/KivyMD
"""

import os
import sys
import json
import sqlite3
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

# Kivy imports
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.slider import Slider
from kivy.uix.switch import Switch
from kivy.uix.checkbox import CheckBox
from kivy.uix.spinner import Spinner
from kivy.uix.filechooser import FileChooserIconView
from kivy.uix.image import Image
from kivy.uix.video import Video
from kivy.uix.camera import Camera
from kivy.uix.carousel import Carousel
from kivy.uix.tabbedpanel import TabbedPanel, TabbedPanelItem

# KivyMD imports
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.floatlayout import MDFloatLayout
from kivymd.uix.gridlayout import MDGridLayout
from kivymd.uix.scrollview import MDScrollView
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton, MDFloatingActionButton
from kivymd.uix.textfield import MDTextField
from kivymd.uix.card import MDCard
from kivymd.uix.list import MDList, OneLineListItem, TwoLineListItem, ThreeLineListItem, OneLineIconListItem
from kivymd.uix.dialog import MDDialog
from kivymd.uix.progressbar import MDProgressBar
from kivymd.uix.slider import MDSlider
from kivymd.uix.selectioncontrol import MDSwitch, MDCheckbox
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.navigationdrawer import MDNavigationDrawer, MDNavigationDrawerItem
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.bottomnavigation import MDBottomNavigation, MDBottomNavigationItem
from kivymd.uix.tab import MDTabs, MDTabsBase
from kivymd.uix.banner import MDBanner
from kivymd.uix.snackbar import Snackbar
from kivymd.uix.chip import MDChip
from kivymd.uix.expansionpanel import MDExpansionPanel, MDExpansionPanelOneLine
from kivymd.uix.imagelist import MDSmartTile
from kivymd.uix.filemanager import MDFileManager
from kivymd.uix.backdrop import MDBackdrop
from kivymd.uix.tooltip import MDTooltip
from kivymd.uix.bottomsheet import MDBottomSheet, MDListBottomSheet, MDGridBottomSheet

# Kivy core imports
from kivy.core.window import Window
from kivy.core.audio import SoundLoader
from kivy.core.clipboard import Clipboard
from kivy.core.image import Image as CoreImage
from kivy.clock import Clock
from kivy.animation import Animation
from kivy.properties import StringProperty, NumericProperty, BooleanProperty, ListProperty, ObjectProperty
from kivy.event import EventDispatcher
from kivy.storage.jsonstore import JsonStore
from kivy.network.urlrequest import UrlRequest
from kivy.utils import platform

# Plyer para características nativas
try:
    from plyer import notification, gps, camera, filechooser, email, sms, vibrator, audio, battery, brightness, orientation, accelerometer, gyroscope, compass
    PLYER_AVAILABLE = True
except ImportError:
    PLYER_AVAILABLE = False
    print("⚠️ Plyer no disponible - funcionalidades nativas limitadas")

# ============================================================================
# CONFIGURACIÓN DE LA APLICACIÓN
# ============================================================================

class AppConfig:
    """Configuración global de la aplicación"""
    
    VERSION = "2.0.0"
    APP_NAME = "BibliaApp Pro"
    AUTHOR = "BibliaApp Team"
    
    # Rutas de datos
    DATA_DIR = "./data"
    DATABASE_PATH = f"{DATA_DIR}/bibliaapp.db"
    SETTINGS_PATH = f"{DATA_DIR}/settings.json"
    CACHE_PATH = f"{DATA_DIR}/cache"
    
    # Configuración de UI
    PRIMARY_COLOR = "#4F46E5"
    SECONDARY_COLOR = "#F59E0B"
    ACCENT_COLOR = "#EC4899"
    BACKGROUND_COLOR = "#F8FAFC"
    TEXT_COLOR = "#1F2937"
    
    # Configuración de red
    API_BASE_URL = "https://api.bibliaapp.com"
    SYNC_INTERVAL = 300  # 5 minutos
    REQUEST_TIMEOUT = 30
    
    # Configuración de características
    FEATURES = {
        'offline_mode': True,
        'notifications': True,
        'location_services': True,
        'audio_features': True,
        'camera_features': True,
        'social_features': True,
        'gamification': True,
        'analytics': True
    }

# ============================================================================
# GESTOR DE BASE DE DATOS
# ============================================================================

class DatabaseManager:
    """Gestor de base de datos SQLite para almacenamiento offline"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Inicializar esquema de base de datos"""
        try:
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Tabla de libros bíblicos
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS bible_books (
                        id TEXT PRIMARY KEY,
                        name TEXT NOT NULL,
                        abbreviation TEXT NOT NULL,
                        testament TEXT NOT NULL,
                        order_num INTEGER NOT NULL,
                        chapters INTEGER NOT NULL,
                        category TEXT NOT NULL,
                        author TEXT,
                        theme TEXT,
                        key_verse TEXT,
                        summary TEXT
                    )
                ''')
                
                # Tabla de versículos
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS bible_verses (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        book_id TEXT NOT NULL,
                        chapter INTEGER NOT NULL,
                        verse INTEGER NOT NULL,
                        text TEXT NOT NULL,
                        version TEXT DEFAULT 'RV1960',
                        FOREIGN KEY (book_id) REFERENCES bible_books (id)
                    )
                ''')
                
                # Tabla de progreso del usuario
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS user_progress (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id TEXT DEFAULT 'default',
                        activity_type TEXT NOT NULL,
                        data TEXT NOT NULL,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Tabla de notas
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS notes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        reference TEXT NOT NULL,
                        title TEXT,
                        content TEXT NOT NULL,
                        tags TEXT,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Tabla de marcadores
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS bookmarks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        reference TEXT NOT NULL UNIQUE,
                        title TEXT,
                        category TEXT DEFAULT 'general',
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Tabla de planes de lectura
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS reading_plans (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        description TEXT,
                        duration_days INTEGER NOT NULL,
                        current_day INTEGER DEFAULT 1,
                        started_at DATETIME,
                        completed_at DATETIME,
                        active BOOLEAN DEFAULT 0
                    )
                ''')
                
                # Tabla de sesiones de oración
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS prayer_sessions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        type TEXT NOT NULL,
                        duration INTEGER,
                        notes TEXT,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                # Tabla de configuraciones
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS settings (
                        key TEXT PRIMARY KEY,
                        value TEXT NOT NULL,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                ''')
                
                conn.commit()
                print("✅ Base de datos inicializada correctamente")
                
        except Exception as e:
            print(f"❌ Error inicializando base de datos: {e}")
    
    def execute_query(self, query: str, params: tuple = None) -> List[Dict]:
        """Ejecutar consulta SELECT"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            print(f"❌ Error ejecutando consulta: {e}")
            return []
    
    def execute_command(self, query: str, params: tuple = None) -> bool:
        """Ejecutar comando INSERT/UPDATE/DELETE"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                if params:
                    cursor.execute(query, params)
                else:
                    cursor.execute(query)
                
                conn.commit()
                return True
        except Exception as e:
            print(f"❌ Error ejecutando comando: {e}")
            return False

# ============================================================================
# GESTOR DE DATOS BÍBLICOS
# ============================================================================

class BibleDataManager:
    """Gestor de datos bíblicos con funcionalidades de búsqueda y navegación"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.load_bible_data()
    
    def load_bible_data(self):
        """Cargar datos bíblicos básicos"""
        # Verificar si ya hay datos
        books = self.db.execute_query("SELECT COUNT(*) as count FROM bible_books")
        if books and books[0]['count'] > 0:
            print("📚 Datos bíblicos ya cargados")
            return
        
        # Cargar datos básicos de libros bíblicos
        bible_books = [
            # Antiguo Testamento
            ('genesis', 'Génesis', 'Gn', 'antiguo', 1, 50, 'pentateuco', 'Moisés', 'Orígenes', '1:1', 'El libro de los orígenes'),
            ('exodo', 'Éxodo', 'Ex', 'antiguo', 2, 40, 'pentateuco', 'Moisés', 'Liberación', '20:2', 'La liberación de Israel'),
            ('levitico', 'Levítico', 'Lv', 'antiguo', 3, 27, 'pentateuco', 'Moisés', 'Santidad', '19:2', 'Leyes ceremoniales'),
            ('numeros', 'Números', 'Nm', 'antiguo', 4, 36, 'pentateuco', 'Moisés', 'Peregrinaje', '14:34', 'Peregrinaje por el desierto'),
            ('deuteronomio', 'Deuteronomio', 'Dt', 'antiguo', 5, 34, 'pentateuco', 'Moisés', 'Segunda Ley', '6:4-5', 'Repetición de la Ley'),
            
            # Nuevo Testamento (ejemplos)
            ('mateo', 'Mateo', 'Mt', 'nuevo', 40, 28, 'evangelios', 'Mateo', 'Rey Mesías', '16:16', 'Jesús como Rey Mesías'),
            ('marcos', 'Marcos', 'Mr', 'nuevo', 41, 16, 'evangelios', 'Marcos', 'Siervo', '10:45', 'Jesús como Siervo'),
            ('lucas', 'Lucas', 'Lc', 'nuevo', 42, 24, 'evangelios', 'Lucas', 'Hijo del Hombre', '19:10', 'Jesús como Hijo del Hombre'),
            ('juan', 'Juan', 'Jn', 'nuevo', 43, 21, 'evangelios', 'Juan', 'Hijo de Dios', '20:31', 'Jesús como Hijo de Dios'),
            ('hechos', 'Hechos', 'Hch', 'nuevo', 44, 28, 'historia', 'Lucas', 'Iglesia primitiva', '1:8', 'Expansión del evangelio'),
        ]
        
        for book_data in bible_books:
            self.db.execute_command('''
                INSERT OR REPLACE INTO bible_books 
                (id, name, abbreviation, testament, order_num, chapters, category, author, theme, key_verse, summary)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', book_data)
        
        # Cargar algunos versículos de ejemplo
        sample_verses = [
            ('juan', 3, 16, 'Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito, para que todo aquel que en él cree, no se pierda, mas tenga vida eterna.'),
            ('filipenses', 4, 13, 'Todo lo puedo en Cristo que me fortalece.'),
            ('salmos', 23, 1, 'Jehová es mi pastor; nada me faltará.'),
            ('romanos', 8, 28, 'Y sabemos que a los que aman a Dios, todas las cosas les ayudan a bien, esto es, a los que conforme a su propósito son llamados.'),
        ]
        
        for verse_data in sample_verses:
            self.db.execute_command('''
                INSERT OR REPLACE INTO bible_verses (book_id, chapter, verse, text)
                VALUES (?, ?, ?, ?)
            ''', verse_data)
        
        print("✅ Datos bíblicos cargados")
    
    def search_verses(self, query: str) -> List[Dict]:
        """Buscar versículos por texto"""
        return self.db.execute_query('''
            SELECT bv.*, bb.name as book_name, bb.abbreviation
            FROM bible_verses bv
            JOIN bible_books bb ON bv.book_id = bb.id
            WHERE bv.text LIKE ? OR bb.name LIKE ?
            ORDER BY bb.order_num, bv.chapter, bv.verse
            LIMIT 50
        ''', (f'%{query}%', f'%{query}%'))
    
    def get_books(self, testament: str = None) -> List[Dict]:
        """Obtener libros bíblicos"""
        if testament:
            return self.db.execute_query('''
                SELECT * FROM bible_books 
                WHERE testament = ? 
                ORDER BY order_num
            ''', (testament,))
        else:
            return self.db.execute_query('''
                SELECT * FROM bible_books 
                ORDER BY order_num
            ''')
    
    def get_chapter(self, book_id: str, chapter: int) -> List[Dict]:
        """Obtener versículos de un capítulo"""
        return self.db.execute_query('''
            SELECT * FROM bible_verses 
            WHERE book_id = ? AND chapter = ?
            ORDER BY verse
        ''', (book_id, chapter))

# ============================================================================
# GESTOR DE CONFIGURACIONES
# ============================================================================

class SettingsManager:
    """Gestor de configuraciones de la aplicación"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.cache = {}
        self.load_default_settings()
    
    def load_default_settings(self):
        """Cargar configuraciones por defecto"""
        defaults = {
            'theme': 'light',
            'font_size': 'medium',
            'bible_version': 'RV1960',
            'notifications_enabled': 'true',
            'sync_enabled': 'true',
            'reading_plan_active': 'false',
            'prayer_reminders': 'true',
            'offline_mode': 'true',
            'language': 'es'
        }
        
        for key, value in defaults.items():
            if not self.get_setting(key):
                self.set_setting(key, value)
    
    def get_setting(self, key: str, default: str = None) -> str:
        """Obtener configuración"""
        if key in self.cache:
            return self.cache[key]
        
        result = self.db.execute_query(
            "SELECT value FROM settings WHERE key = ?", (key,)
        )
        
        if result:
            value = result[0]['value']
            self.cache[key] = value
            return value
        
        return default
    
    def set_setting(self, key: str, value: str):
        """Establecer configuración"""
        self.cache[key] = value
        self.db.execute_command('''
            INSERT OR REPLACE INTO settings (key, value, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
        ''', (key, value))
    
    def get_bool_setting(self, key: str, default: bool = False) -> bool:
        """Obtener configuración booleana"""
        value = self.get_setting(key, str(default).lower())
        return value.lower() in ('true', '1', 'yes', 'on')

# ============================================================================
# GESTOR DE PROGRESO
# ============================================================================

class ProgressManager:
    """Gestor de progreso y gamificación"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.current_level = 1
        self.current_xp = 0
        self.achievements = []
        self.streak = 0
        self.load_progress()
    
    def load_progress(self):
        """Cargar progreso del usuario"""
        try:
            # Cargar XP y nivel
            xp_data = self.db.execute_query('''
                SELECT data FROM user_progress 
                WHERE activity_type = 'xp_update' 
                ORDER BY timestamp DESC LIMIT 1
            ''')
            
            if xp_data:
                progress = json.loads(xp_data[0]['data'])
                self.current_xp = progress.get('xp', 0)
                self.current_level = progress.get('level', 1)
            
            # Cargar logros
            achievements_data = self.db.execute_query('''
                SELECT data FROM user_progress 
                WHERE activity_type = 'achievement_unlocked'
            ''')
            
            self.achievements = [
                json.loads(achievement['data'])['achievement_id']
                for achievement in achievements_data
            ]
            
            # Calcular racha
            self.calculate_streak()
            
        except Exception as e:
            print(f"❌ Error cargando progreso: {e}")
    
    def add_xp(self, amount: int, activity: str = ""):
        """Agregar experiencia"""
        old_level = self.current_level
        self.current_xp += amount
        
        # Calcular nuevo nivel
        new_level = self.calculate_level(self.current_xp)
        
        # Guardar progreso
        progress_data = {
            'xp': self.current_xp,
            'level': new_level,
            'activity': activity,
            'xp_gained': amount
        }
        
        self.db.execute_command('''
            INSERT INTO user_progress (activity_type, data)
            VALUES (?, ?)
        ''', ('xp_update', json.dumps(progress_data)))
        
        # Verificar subida de nivel
        if new_level > old_level:
            self.current_level = new_level
            return {'level_up': True, 'old_level': old_level, 'new_level': new_level}
        
        return {'level_up': False, 'xp_gained': amount}
    
    def calculate_level(self, xp: int) -> int:
        """Calcular nivel basado en XP"""
        # Fórmula: nivel = floor(sqrt(xp / 100)) + 1
        import math
        return int(math.sqrt(xp / 100)) + 1
    
    def unlock_achievement(self, achievement_id: str, achievement_data: Dict):
        """Desbloquear logro"""
        if achievement_id not in self.achievements:
            self.achievements.append(achievement_id)
            
            # Guardar logro
            self.db.execute_command('''
                INSERT INTO user_progress (activity_type, data)
                VALUES (?, ?)
            ''', ('achievement_unlocked', json.dumps({
                'achievement_id': achievement_id,
                'achievement_data': achievement_data
            })))
            
            # Bonus XP por logro
            self.add_xp(50, f"Logro desbloqueado: {achievement_data.get('name', achievement_id)}")
            
            return True
        
        return False
    
    def calculate_streak(self):
        """Calcular racha actual"""
        try:
            # Obtener últimas actividades diarias
            recent_activities = self.db.execute_query('''
                SELECT DATE(timestamp) as date 
                FROM user_progress 
                WHERE activity_type = 'daily_activity'
                ORDER BY timestamp DESC
                LIMIT 30
            ''')
            
            if not recent_activities:
                self.streak = 0
                return
            
            # Calcular días consecutivos
            today = datetime.now().date()
            streak = 0
            
            for activity in recent_activities:
                activity_date = datetime.strptime(activity['date'], '%Y-%m-%d').date()
                expected_date = today - timedelta(days=streak)
                
                if activity_date == expected_date:
                    streak += 1
                else:
                    break
            
            self.streak = streak
            
        except Exception as e:
            print(f"❌ Error calculando racha: {e}")
            self.streak = 0
    
    def record_daily_activity(self):
        """Registrar actividad diaria"""
        today = datetime.now().date().isoformat()
        
        # Verificar si ya hay actividad hoy
        existing = self.db.execute_query('''
            SELECT id FROM user_progress 
            WHERE activity_type = 'daily_activity' 
            AND DATE(timestamp) = DATE('now')
        ''')
        
        if not existing:
            self.db.execute_command('''
                INSERT INTO user_progress (activity_type, data)
                VALUES (?, ?)
            ''', ('daily_activity', json.dumps({'date': today})))
            
            self.calculate_streak()
            self.add_xp(10, "Actividad diaria")

# ============================================================================
# PANTALLA BASE
# ============================================================================

class BaseScreen(MDScreen):
    """Pantalla base con funcionalidades comunes"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.app = None
        self.loading = False
    
    def on_enter(self):
        """Llamado cuando se entra a la pantalla"""
        if not self.app:
            self.app = MDApp.get_running_app()
        self.setup_ui()
    
    def setup_ui(self):
        """Configurar interfaz de usuario"""
        pass
    
    def show_loading(self, message: str = "Cargando..."):
        """Mostrar indicador de carga"""
        self.loading = True
        # Implementar spinner de carga
    
    def hide_loading(self):
        """Ocultar indicador de carga"""
        self.loading = False
    
    def show_message(self, message: str, duration: int = 3):
        """Mostrar mensaje temporal"""
        Snackbar(text=message, duration=duration).open()

# ============================================================================
# PANTALLA DE INICIO
# ============================================================================

class HomeScreen(BaseScreen):
    """Pantalla principal de inicio"""
    
    def setup_ui(self):
        """Configurar interfaz de la pantalla de inicio"""
        layout = MDBoxLayout(orientation='vertical', spacing='20dp', padding='20dp')
        
        # Header con saludo
        header_card = self.create_header_card()
        layout.add_widget(header_card)
        
        # Check-in diario
        checkin_card = self.create_checkin_card()
        layout.add_widget(checkin_card)
        
        # Progreso
        progress_card = self.create_progress_card()
        layout.add_widget(progress_card)
        
        # Accesos rápidos
        quick_actions = self.create_quick_actions()
        layout.add_widget(quick_actions)
        
        # Versículo del día
        verse_card = self.create_verse_card()
        layout.add_widget(verse_card)
        
        scroll = MDScrollView()
        scroll.add_widget(layout)
        self.add_widget(scroll)
    
    def create_header_card(self):
        """Crear card de encabezado"""
        card = MDCard(
            size_hint_y=None,
            height='100dp',
            elevation=2,
            radius=[15],
            md_bg_color=AppConfig.PRIMARY_COLOR
        )
        
        layout = MDBoxLayout(
            orientation='horizontal',
            padding='20dp',
            spacing='15dp'
        )
        
        # Icono
        icon = MDLabel(
            text="📖",
            font_size='40sp',
            size_hint_x=None,
            width='60dp',
            halign='center'
        )
        
        # Contenido
        content = MDBoxLayout(orientation='vertical', spacing='5dp')
        
        greeting = MDLabel(
            text=self.get_greeting(),
            theme_text_color='Primary',
            font_style='H6',
            bold=True
        )
        
        subtitle = MDLabel(
            text="Bienvenido a tu jornada espiritual",
            theme_text_color='Secondary',
            font_style='Body1'
        )
        
        content.add_widget(greeting)
        content.add_widget(subtitle)
        
        layout.add_widget(icon)
        layout.add_widget(content)
        card.add_widget(layout)
        
        return card
    
    def create_checkin_card(self):
        """Crear card de check-in diario"""
        card = MDCard(
            size_hint_y=None,
            height='200dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='10dp')
        
        title = MDLabel(
            text="✅ Check-in Diario",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='40dp'
        )
        
        # Lista de actividades
        activities = [
            "📖 Lectura bíblica",
            "🙏 Tiempo de oración",
            "📝 Reflexión personal",
            "❤️ Acto de servicio"
        ]
        
        for i, activity in enumerate(activities):
            activity_layout = MDBoxLayout(
                orientation='horizontal',
                spacing='10dp',
                size_hint_y=None,
                height='30dp'
            )
            
            checkbox = MDCheckbox(
                size_hint_x=None,
                width='40dp',
                on_active=lambda x, value, idx=i: self.on_checkin_activity(idx, value)
            )
            
            label = MDLabel(
                text=activity,
                theme_text_color='Primary'
            )
            
            activity_layout.add_widget(checkbox)
            activity_layout.add_widget(label)
            layout.add_widget(activity_layout)
        
        layout.add_widget(title)
        card.add_widget(layout)
        
        return card
    
    def create_progress_card(self):
        """Crear card de progreso"""
        card = MDCard(
            size_hint_y=None,
            height='150dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='horizontal', padding='20dp', spacing='20dp')
        
        # Progreso de nivel
        level_layout = MDBoxLayout(orientation='vertical', spacing='5dp')
        
        level_title = MDLabel(
            text="🏆 Nivel",
            font_style='Subtitle1',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        level_value = MDLabel(
            text=str(self.app.progress_manager.current_level),
            font_style='H4',
            bold=True,
            halign='center'
        )
        
        xp_label = MDLabel(
            text=f"{self.app.progress_manager.current_xp} XP",
            font_style='Caption',
            halign='center'
        )
        
        level_layout.add_widget(level_title)
        level_layout.add_widget(level_value)
        level_layout.add_widget(xp_label)
        
        # Racha
        streak_layout = MDBoxLayout(orientation='vertical', spacing='5dp')
        
        streak_title = MDLabel(
            text="🔥 Racha",
            font_style='Subtitle1',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        streak_value = MDLabel(
            text=str(self.app.progress_manager.streak),
            font_style='H4',
            bold=True,
            halign='center'
        )
        
        streak_label = MDLabel(
            text="días",
            font_style='Caption',
            halign='center'
        )
        
        streak_layout.add_widget(streak_title)
        streak_layout.add_widget(streak_value)
        streak_layout.add_widget(streak_label)
        
        layout.add_widget(level_layout)
        layout.add_widget(streak_layout)
        card.add_widget(layout)
        
        return card
    
    def create_quick_actions(self):
        """Crear accesos rápidos"""
        card = MDCard(
            size_hint_y=None,
            height='120dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='10dp')
        
        title = MDLabel(
            text="🚀 Acceso Rápido",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        actions_layout = MDGridLayout(cols=4, spacing='10dp')
        
        actions = [
            ("📖", "Leer", "theory"),
            ("🙏", "Orar", "practice"),
            ("👥", "Social", "social"),
            ("⚙️", "Ajustes", "settings")
        ]
        
        for icon, text, screen in actions:
            action_btn = MDRaisedButton(
                text=f"{icon}\n{text}",
                theme_icon_color="Custom",
                md_bg_color=AppConfig.PRIMARY_COLOR,
                on_release=lambda x, s=screen: self.navigate_to(s),
                size_hint_y=None,
                height='60dp'
            )
            actions_layout.add_widget(action_btn)
        
        layout.add_widget(title)
        layout.add_widget(actions_layout)
        card.add_widget(layout)
        
        return card
    
    def create_verse_card(self):
        """Crear card de versículo del día"""
        card = MDCard(
            size_hint_y=None,
            height='150dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='10dp')
        
        title = MDLabel(
            text="📜 Versículo del Día",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        verse_text = MDLabel(
            text='"Todo lo puedo en Cristo que me fortalece."',
            font_style='Body1',
            italic=True,
            halign='center'
        )
        
        verse_ref = MDLabel(
            text="Filipenses 4:13",
            font_style='Caption',
            halign='center',
            theme_text_color='Secondary'
        )
        
        layout.add_widget(title)
        layout.add_widget(verse_text)
        layout.add_widget(verse_ref)
        card.add_widget(layout)
        
        return card
    
    def get_greeting(self):
        """Obtener saludo según la hora"""
        from datetime import datetime
        hour = datetime.now().hour
        
        if 5 <= hour < 12:
            return "¡Buenos días!"
        elif 12 <= hour < 18:
            return "¡Buenas tardes!"
        else:
            return "¡Buenas noches!"
    
    def on_checkin_activity(self, activity_index: int, checked: bool):
        """Manejar actividad de check-in"""
        if checked:
            self.app.progress_manager.add_xp(5, f"Check-in actividad {activity_index}")
            self.show_message(f"¡+5 XP! Actividad completada")
    
    def navigate_to(self, screen_name: str):
        """Navegar a otra pantalla"""
        self.app.root.current = screen_name

# ============================================================================
# PANTALLA DE TEORÍA
# ============================================================================

class TheoryScreen(BaseScreen):
    """Pantalla de teoría y estudio bíblico"""
    
    def setup_ui(self):
        """Configurar interfaz de teoría"""
        layout = MDBoxLayout(orientation='vertical', spacing='10dp', padding='20dp')
        
        # Título
        title = MDLabel(
            text="📚 Teoría Bíblica",
            font_style='H5',
            bold=True,
            size_hint_y=None,
            height='50dp'
        )
        
        # Modos de lectura
        reading_modes = self.create_reading_modes()
        layout.add_widget(reading_modes)
        
        # Herramientas de estudio
        study_tools = self.create_study_tools()
        layout.add_widget(study_tools)
        
        # Memorización
        memory_section = self.create_memory_section()
        layout.add_widget(memory_section)
        
        layout.add_widget(title)
        
        scroll = MDScrollView()
        scroll.add_widget(layout)
        self.add_widget(scroll)
    
    def create_reading_modes(self):
        """Crear sección de modos de lectura"""
        card = MDCard(
            size_hint_y=None,
            height='200dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='15dp')
        
        title = MDLabel(
            text="📖 Modos de Lectura",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        modes_layout = MDGridLayout(cols=2, spacing='15dp')
        
        # Modo Simple
        simple_btn = MDRaisedButton(
            text="🌱 Modo Simple\nLectura devocional",
            theme_icon_color="Custom",
            md_bg_color=AppConfig.SECONDARY_COLOR,
            size_hint_y=None,
            height='80dp',
            on_release=self.open_simple_mode
        )
        
        # Modo Profundo
        deep_btn = MDRaisedButton(
            text="🔬 Modo Profundo\nEstudio académico",
            theme_icon_color="Custom",
            md_bg_color=AppConfig.ACCENT_COLOR,
            size_hint_y=None,
            height='80dp',
            on_release=self.open_deep_mode
        )
        
        modes_layout.add_widget(simple_btn)
        modes_layout.add_widget(deep_btn)
        
        layout.add_widget(title)
        layout.add_widget(modes_layout)
        card.add_widget(layout)
        
        return card
    
    def create_study_tools(self):
        """Crear herramientas de estudio"""
        card = MDCard(
            size_hint_y=None,
            height='250dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='10dp')
        
        title = MDLabel(
            text="🛠️ Herramientas de Estudio",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        tools_grid = MDGridLayout(cols=3, spacing='10dp')
        
        tools = [
            ("📊", "Análisis"),
            ("🔍", "Búsqueda"),
            ("📝", "Notas"),
            ("🔖", "Marcadores"),
            ("🗂️", "Concordancia"),
            ("🎯", "Referencias")
        ]
        
        for icon, name in tools:
            tool_btn = MDIconButton(
                icon="circle",
                theme_icon_color="Custom",
                text=f"{icon}\n{name}",
                on_release=lambda x, tool=name: self.open_tool(tool)
            )
            tools_grid.add_widget(tool_btn)
        
        layout.add_widget(title)
        layout.add_widget(tools_grid)
        card.add_widget(layout)
        
        return card
    
    def create_memory_section(self):
        """Crear sección de memorización"""
        card = MDCard(
            size_hint_y=None,
            height='150dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='10dp')
        
        title = MDLabel(
            text="🧠 Memorización Bíblica",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        description = MDLabel(
            text="Técnicas científicamente probadas para memorizar las Escrituras",
            font_style='Body2',
            theme_text_color='Secondary'
        )
        
        memory_btn = MDRaisedButton(
            text="📚 Comenzar Memorización",
            theme_icon_color="Custom",
            md_bg_color=AppConfig.PRIMARY_COLOR,
            on_release=self.open_memory_tools,
            size_hint_y=None,
            height='40dp'
        )
        
        layout.add_widget(title)
        layout.add_widget(description)
        layout.add_widget(memory_btn)
        card.add_widget(layout)
        
        return card
    
    def open_simple_mode(self, instance):
        """Abrir modo de lectura simple"""
        self.show_message("Abriendo modo de lectura simple...")
        # Implementar navegación al modo simple
    
    def open_deep_mode(self, instance):
        """Abrir modo de estudio profundo"""
        self.show_message("Abriendo herramientas de estudio profundo...")
        # Implementar navegación al modo profundo
    
    def open_tool(self, tool_name: str):
        """Abrir herramienta específica"""
        self.show_message(f"Abriendo {tool_name}...")
        # Implementar herramientas específicas
    
    def open_memory_tools(self, instance):
        """Abrir herramientas de memorización"""
        self.show_message("Abriendo herramientas de memorización...")
        # Implementar herramientas de memorización

# ============================================================================
# PANTALLA DE PRÁCTICA
# ============================================================================

class PracticeScreen(BaseScreen):
    """Pantalla de práctica cristiana"""
    
    def setup_ui(self):
        """Configurar interfaz de práctica"""
        layout = MDBoxLayout(orientation='vertical', spacing='10dp', padding='20dp')
        
        # Título
        title = MDLabel(
            text="🙏 Práctica Cristiana",
            font_style='H5',
            bold=True,
            size_hint_y=None,
            height='50dp'
        )
        
        # Sección de oración
        prayer_section = self.create_prayer_section()
        layout.add_widget(prayer_section)
        
        # Vida cristiana
        life_section = self.create_life_section()
        layout.add_widget(life_section)
        
        # Seguimiento de actividades
        tracking_section = self.create_tracking_section()
        layout.add_widget(tracking_section)
        
        layout.add_widget(title)
        
        scroll = MDScrollView()
        scroll.add_widget(layout)
        self.add_widget(scroll)
    
    def create_prayer_section(self):
        """Crear sección de oración"""
        card = MDCard(
            size_hint_y=None,
            height='200dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='10dp')
        
        title = MDLabel(
            text="🙏 ¿Qué es Orar?",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        prayer_types = MDGridLayout(cols=2, spacing='10dp')
        
        types = [
            ("💫", "Adoración"),
            ("💔", "Confesión"),
            ("🎁", "Gratitud"),
            ("🤲", "Petición")
        ]
        
        for icon, prayer_type in types:
            type_btn = MDRaisedButton(
                text=f"{icon}\n{prayer_type}",
                theme_icon_color="Custom",
                md_bg_color=AppConfig.SECONDARY_COLOR,
                size_hint_y=None,
                height='60dp',
                on_release=lambda x, pt=prayer_type: self.start_prayer(pt)
            )
            prayer_types.add_widget(type_btn)
        
        layout.add_widget(title)
        layout.add_widget(prayer_types)
        card.add_widget(layout)
        
        return card
    
    def create_life_section(self):
        """Crear sección de vida cristiana"""
        card = MDCard(
            size_hint_y=None,
            height='180dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='10dp')
        
        title = MDLabel(
            text="💝 ¿Qué es Dar/Vivir?",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        life_areas = MDGridLayout(cols=2, spacing='10dp')
        
        areas = [
            ("❤️", "Relaciones"),
            ("💼", "Trabajo"),
            ("🌍", "Servicio"),
            ("💰", "Mayordomía")
        ]
        
        for icon, area in areas:
            area_btn = MDRaisedButton(
                text=f"{icon}\n{area}",
                theme_icon_color="Custom",
                md_bg_color=AppConfig.ACCENT_COLOR,
                size_hint_y=None,
                height='50dp',
                on_release=lambda x, a=area: self.explore_area(a)
            )
            life_areas.add_widget(area_btn)
        
        layout.add_widget(title)
        layout.add_widget(life_areas)
        card.add_widget(layout)
        
        return card
    
    def create_tracking_section(self):
        """Crear sección de seguimiento"""
        card = MDCard(
            size_hint_y=None,
            height='150dp',
            elevation=2,
            radius=[15]
        )
        
        layout = MDBoxLayout(orientation='vertical', padding='20dp', spacing='10dp')
        
        title = MDLabel(
            text="📊 Seguimiento de Acciones",
            font_style='H6',
            bold=True,
            size_hint_y=None,
            height='30dp'
        )
        
        stats_layout = MDGridLayout(cols=3, spacing='10dp')
        
        # Estadísticas de ejemplo
        stats = [
            ("12", "Actos de\nServicio"),
            ("6.5h", "Horas de\nVoluntariado"),
            ("23", "Personas\nBendecidas")
        ]
        
        for value, label in stats:
            stat_layout = MDBoxLayout(orientation='vertical', spacing='5dp')
            
            stat_value = MDLabel(
                text=value,
                font_style='H5',
                bold=True,
                halign='center'
            )
            
            stat_label = MDLabel(
                text=label,
                font_style='Caption',
                halign='center',
                theme_text_color='Secondary'
            )
            
            stat_layout.add_widget(stat_value)
            stat_layout.add_widget(stat_label)
            stats_layout.add_widget(stat_layout)
        
        layout.add_widget(title)
        layout.add_widget(stats_layout)
        card.add_widget(layout)
        
        return card
    
    def start_prayer(self, prayer_type: str):
        """Iniciar sesión de oración"""
        self.show_message(f"Iniciando oración de {prayer_type}...")
        
        # Registrar actividad
        self.app.progress_manager.add_xp(10, f"Oración de {prayer_type}")
        
        # Aquí se abriría la interfaz de oración específica
    
    def explore_area(self, area: str):
        """Explorar área de vida cristiana"""
        self.show_message(f"Explorando área: {area}...")
        # Implementar navegación a área específica

# ============================================================================
# APLICACIÓN PRINCIPAL
# ============================================================================

class BibliaAppPro(MDApp):
    """Aplicación principal BibliaApp Pro"""
    
    title = AppConfig.APP_NAME
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Configurar tema
        self.theme_cls.primary_palette = "Indigo"
        self.theme_cls.accent_palette = "Amber"
        self.theme_cls.theme_style = "Light"
        
        # Managers
        self.db_manager = None
        self.bible_manager = None
        self.settings_manager = None
        self.progress_manager = None
    
    def build(self):
        """Construir aplicación"""
        self.title = AppConfig.APP_NAME
        
        # Inicializar managers
        self.init_managers()
        
        # Crear screen manager
        sm = MDScreenManager()
        
        # Agregar pantallas
        sm.add_widget(HomeScreen(name='home'))
        sm.add_widget(TheoryScreen(name='theory'))
        sm.add_widget(PracticeScreen(name='practice'))
        
        # Crear navegación inferior
        return self.create_main_interface(sm)
    
    def init_managers(self):
        """Inicializar managers de datos"""
        try:
            # Crear directorio de datos
            os.makedirs(AppConfig.DATA_DIR, exist_ok=True)
            
            # Inicializar managers
            self.db_manager = DatabaseManager(AppConfig.DATABASE_PATH)
            self.bible_manager = BibleDataManager(self.db_manager)
            self.settings_manager = SettingsManager(self.db_manager)
            self.progress_manager = ProgressManager(self.db_manager)
            
            print("✅ Managers inicializados correctamente")
            
        except Exception as e:
            print(f"❌ Error inicializando managers: {e}")
    
    def create_main_interface(self, screen_manager):
        """Crear interfaz principal con navegación"""
        main_layout = MDBoxLayout(orientation='vertical')
        
        # Top bar
        toolbar = MDTopAppBar(
            title=AppConfig.APP_NAME,
            md_bg_color=AppConfig.PRIMARY_COLOR,
            specific_text_color="#FFFFFF",
            elevation=3
        )
        
        # Navegación inferior
        bottom_nav = MDBottomNavigation()
        
        # Tab de Inicio
        home_tab = MDBottomNavigationItem(
            name='home',
            text='Inicio',
            icon='home'
        )
        home_tab.add_widget(screen_manager.get_screen('home'))
        
        # Tab de Teoría
        theory_tab = MDBottomNavigationItem(
            name='theory',
            text='Teoría',
            icon='book-open-variant'
        )
        theory_tab.add_widget(screen_manager.get_screen('theory'))
        
        # Tab de Práctica
        practice_tab = MDBottomNavigationItem(
            name='practice',
            text='Práctica',
            icon='heart'
        )
        practice_tab.add_widget(screen_manager.get_screen('practice'))
        
        # Tab de Social
        social_tab = MDBottomNavigationItem(
            name='social',
            text='Social',
            icon='account-group'
        )
        social_tab.add_widget(MDLabel(text="🌟 Social - Próximamente", halign='center'))
        
        # Tab de Ajustes
        settings_tab = MDBottomNavigationItem(
            name='settings',
            text='Ajustes',
            icon='cog'
        )
        settings_tab.add_widget(MDLabel(text="⚙️ Configuración - Próximamente", halign='center'))
        
        bottom_nav.add_widget(home_tab)
        bottom_nav.add_widget(theory_tab)
        bottom_nav.add_widget(practice_tab)
        bottom_nav.add_widget(social_tab)
        bottom_nav.add_widget(settings_tab)
        
        main_layout.add_widget(toolbar)
        main_layout.add_widget(bottom_nav)
        
        return main_layout
    
    def on_start(self):
        """Llamado al iniciar la aplicación"""
        print(f"🚀 {AppConfig.APP_NAME} v{AppConfig.VERSION} iniciada")
        
        # Registrar actividad diaria
        if self.progress_manager:
            self.progress_manager.record_daily_activity()
        
        # Configuraciones iniciales
        self.setup_notifications()
        self.check_permissions()
    
    def setup_notifications(self):
        """Configurar notificaciones"""
        if PLYER_AVAILABLE and self.settings_manager.get_bool_setting('notifications_enabled'):
            try:
                notification.notify(
                    title=AppConfig.APP_NAME,
                    message="¡Bienvenido! Tu jornada espiritual comienza aquí.",
                    timeout=5
                )
            except Exception as e:
                print(f"⚠️ Error configurando notificaciones: {e}")
    
    def check_permissions(self):
        """Verificar permisos necesarios"""
        if platform == 'android':
            from android.permissions import request_permissions, Permission
            
            permissions = [
                Permission.WRITE_EXTERNAL_STORAGE,
                Permission.READ_EXTERNAL_STORAGE,
                Permission.CAMERA,
                Permission.RECORD_AUDIO,
                Permission.ACCESS_FINE_LOCATION
            ]
            
            request_permissions(permissions)
    
    def on_pause(self):
        """Llamado cuando la app va a segundo plano"""
        # Guardar datos importantes
        return True
    
    def on_resume(self):
        """Llamado cuando la app regresa del segundo plano"""
        # Recargar datos si es necesario
        pass

# ============================================================================
# FUNCIÓN PRINCIPAL
# ============================================================================

def main():
    """Función principal de la aplicación"""
    try:
        # Configurar Window si es necesario
        if platform != 'android':
            Window.size = (400, 700)  # Simular tamaño móvil en desktop
        
        # Crear y ejecutar aplicación
        app = BibliaAppPro()
        app.run()
        
    except Exception as e:
        print(f"💥 Error fatal en la aplicación: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
