"""
Datos bíblicos completos para BibliaApp Pro
Contiene estructura completa de libros, capítulos y datos de estudio
"""

# ============================================================================
# ESTRUCTURA COMPLETA DE LA BIBLIA
# ============================================================================

BIBLE_BOOKS_COMPLETE = {
    # ANTIGUO TESTAMENTO
    'genesis': {
        'name': 'Génesis',
        'abbrev': 'Gn',
        'testament': 'antiguo',
        'order': 1,
        'chapters': 50,
        'category': 'pentateuco',
        'author': 'Moisés',
        'theme': 'Orígenes',
        'key_verse': '1:1',
        'key_verse_text': 'En el principio creó Dios los cielos y la tierra.',
        'summary': 'El libro de los orígenes: creación, caída, diluvio y patriarcas',
        'outline': [
            'Creación y caída (1-11)',
            'Abraham (12-25)',
            'Isaac y Jacob (26-36)',
            'José en Egipto (37-50)'
        ],
        'themes': ['creación', 'pacto', 'promesa', 'providencia'],
        'characters': ['Adán', 'Eva', 'Noé', 'Abraham', 'Isaac', 'Jacob', 'José']
    },
    
    'exodo': {
        'name': 'Éxodo',
        'abbrev': 'Ex',
        'testament': 'antiguo',
        'order': 2,
        'chapters': 40,
        'category': 'pentateuco',
        'author': 'Moisés',
        'theme': 'Liberación',
        'key_verse': '20:2',
        'key_verse_text': 'Yo soy Jehová tu Dios, que te saqué de la tierra de Egipto, de casa de servidumbre.',
        'summary': 'La liberación de Israel de Egipto y el pacto en el Sinaí',
        'outline': [
            'Esclavitud en Egipto (1-11)',
            'El Éxodo (12-18)',
            'La Ley en el Sinaí (19-24)',
            'El Tabernáculo (25-40)'
        ],
        'themes': ['liberación', 'pacto', 'ley', 'adoración'],
        'characters': ['Moisés', 'Aarón', 'Faraón', 'Miriam']
    },
    
    # NUEVO TESTAMENTO
    'mateo': {
        'name': 'Mateo',
        'abbrev': 'Mt',
        'testament': 'nuevo',
        'order': 40,
        'chapters': 28,
        'category': 'evangelios',
        'author': 'Mateo',
        'theme': 'Rey Mesías',
        'key_verse': '16:16',
        'key_verse_text': 'Respondiendo Simón Pedro, dijo: Tú eres el Cristo, el Hijo del Dios viviente.',
        'summary': 'Jesús como el Rey Mesías prometido de Israel',
        'outline': [
            'Nacimiento del Rey (1-2)',
            'Preparación del Rey (3-4)',
            'Enseñanzas del Rey (5-7)',
            'Ministerio del Rey (8-20)',
            'Rechazo del Rey (21-27)',
            'Resurrección del Rey (28)'
        ],
        'themes': ['reino', 'mesías', 'profecía', 'enseñanza'],
        'characters': ['Jesús', 'Pedro', 'Juan el Bautista', 'María', 'José']
    },
    
    'juan': {
        'name': 'Juan',
        'abbrev': 'Jn',
        'testament': 'nuevo',
        'order': 43,
        'chapters': 21,
        'category': 'evangelios',
        'author': 'Juan',
        'theme': 'Hijo de Dios',
        'key_verse': '20:31',
        'key_verse_text': 'Pero éstas se han escrito para que creáis que Jesús es el Cristo, el Hijo de Dios, y para que creyendo, tengáis vida en su nombre.',
        'summary': 'Jesús como el Hijo de Dios que da vida eterna',
        'outline': [
            'Prólogo: El Verbo (1:1-18)',
            'Libro de las Señales (1:19-12:50)',
            'Libro de la Gloria (13:1-20:31)',
            'Epílogo: Apariciones (21:1-25)'
        ],
        'themes': ['divinidad', 'vida eterna', 'fe', 'amor'],
        'characters': ['Jesús', 'Juan el Bautista', 'María', 'Marta', 'Lázaro', 'Tomás']
    }
}

# ============================================================================
# VERSÍCULOS POPULARES
# ============================================================================

POPULAR_VERSES = [
    {
        'reference': 'Juan 3:16',
        'text': 'Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito, para que todo aquel que en él cree, no se pierda, mas tenga vida eterna.',
        'theme': 'salvación',
        'popularity': 10
    },
    {
        'reference': 'Filipenses 4:13',
        'text': 'Todo lo puedo en Cristo que me fortalece.',
        'theme': 'fortaleza',
        'popularity': 9
    },
    {
        'reference': 'Salmos 23:1',
        'text': 'Jehová es mi pastor; nada me faltará.',
        'theme': 'confianza',
        'popularity': 9
    },
    {
        'reference': 'Romanos 8:28',
        'text': 'Y sabemos que a los que aman a Dios, todas las cosas les ayudan a bien, esto es, a los que conforme a su propósito son llamados.',
        'theme': 'providencia',
        'popularity': 8
    },
    {
        'reference': 'Jeremías 29:11',
        'text': 'Porque yo sé los pensamientos que tengo acerca de vosotros, dice Jehová, pensamientos de paz, y no de mal, para daros el fin que esperáis.',
        'theme': 'esperanza',
        'popularity': 8
    },
    {
        'reference': 'Proverbios 3:5-6',
        'text': 'Fíate de Jehová de todo tu corazón, y no te apoyes en tu propia prudencia. Reconócelo en todos tus caminos, y él enderezará tus veredas.',
        'theme': 'confianza',
        'popularity': 8
    },
    {
        'reference': 'Isaías 40:31',
        'text': 'pero los que esperan a Jehová tendrán nuevas fuerzas; levantarán alas como las águilas; correrán, y no se cansarán; caminarán, y no se fatigarán.',
        'theme': 'renovación',
        'popularity': 7
    },
    {
        'reference': '1 Corintios 13:4-7',
        'text': 'El amor es sufrido, es benigno; el amor no tiene envidia, el amor no es jactancioso, no se envanece; no hace nada indebido, no busca lo suyo, no se irrita, no guarda rencor; no se goza de la injusticia, mas se goza de la verdad. Todo lo sufre, todo lo cree, todo lo espera, todo lo soporta.',
        'theme': 'amor',
        'popularity': 7
    },
    {
        'reference': 'Mateo 28:19-20',
        'text': 'Por tanto, id, y haced discípulos a todas las naciones, bautizándolos en el nombre del Padre, y del Hijo, y del Espíritu Santo; enseñándoles que guarden todas las cosas que os he mandado; y he aquí yo estoy con vosotros todos los días, hasta el fin del mundo.',
        'theme': 'gran comisión',
        'popularity': 7
    }
]

# ============================================================================
# TEMAS BÍBLICOS
# ============================================================================

BIBLICAL_THEMES = {
    'amor': {
        'name': 'Amor',
        'description': 'El amor de Dios y el amor hacia otros',
        'verses': [
            'Juan 3:16', '1 Juan 4:8', '1 Corintios 13:4-7',
            'Mateo 22:37-39', 'Romanos 5:8'
        ],
        'studies': ['El amor ágape', 'Amor fraternal', 'Amor sacrificial']
    },
    
    'fe': {
        'name': 'Fe',
        'description': 'Confianza y creencia en Dios',
        'verses': [
            'Hebreos 11:1', 'Romanos 10:17', 'Marcos 11:22',
            'Efesios 2:8-9', 'Santiago 2:17'
        ],
        'studies': ['Naturaleza de la fe', 'Fe vs obras', 'Crecimiento en fe']
    },
    
    'esperanza': {
        'name': 'Esperanza',
        'description': 'Esperanza eterna y temporal en Dios',
        'verses': [
            'Jeremías 29:11', 'Romanos 15:13', '1 Pedro 1:3',
            'Hebreos 6:19', 'Salmos 42:5'
        ],
        'studies': ['Esperanza eterna', 'Esperanza en dificultades', 'Ancla del alma']
    },
    
    'salvacion': {
        'name': 'Salvación',
        'description': 'La salvación por gracia mediante la fe',
        'verses': [
            'Juan 3:16', 'Efesios 2:8-9', 'Romanos 10:9',
            'Hechos 4:12', '1 Juan 1:9'
        ],
        'studies': ['Gracia vs obras', 'Plan de salvación', 'Seguridad eterna']
    },
    
    'oracion': {
        'name': 'Oración',
        'description': 'Comunicación con Dios',
        'verses': [
            'Mateo 6:9-13', '1 Tesalonicenses 5:17', 'Filipenses 4:6',
            'Santiago 5:16', 'Lucas 11:1-4'
        ],
        'studies': ['Modelo de oración', 'Oración persistente', 'Oración intercesora']
    }
}

# ============================================================================
# PLANES DE LECTURA
# ============================================================================

READING_PLANS = {
    'plan_30_dias': {
        'name': 'Fundamentos en 30 Días',
        'description': 'Lecturas fundamentales para nuevos creyentes',
        'duration': 30,
        'category': 'principiante',
        'readings': [
            {'day': 1, 'reference': 'Juan 1', 'title': 'El Verbo hecho carne'},
            {'day': 2, 'reference': 'Juan 3', 'title': 'Nuevo nacimiento'},
            {'day': 3, 'reference': 'Romanos 3:21-31', 'title': 'Justificación por fe'},
            {'day': 4, 'reference': 'Efesios 2:1-10', 'title': 'Salvos por gracia'},
            {'day': 5, 'reference': 'Filipenses 4:4-13', 'title': 'Gozo y contentamiento'},
            # ... continuaría con los 30 días
        ]
    },
    
    'plan_90_dias': {
        'name': 'Nuevo Testamento en 90 Días',
        'description': 'Lee todo el Nuevo Testamento en 3 meses',
        'duration': 90,
        'category': 'intermedio',
        'readings': [
            {'day': 1, 'reference': 'Mateo 1-4', 'title': 'Nacimiento y comienzo del ministerio'},
            {'day': 2, 'reference': 'Mateo 5-7', 'title': 'Sermón del Monte'},
            # ... continuaría con los 90 días
        ]
    },
    
    'plan_365_dias': {
        'name': 'Biblia Completa en 1 Año',
        'description': 'Lee toda la Biblia en un año',
        'duration': 365,
        'category': 'avanzado',
        'readings': [
            {'day': 1, 'reference': 'Génesis 1-3; Mateo 1', 'title': 'El principio'},
            {'day': 2, 'reference': 'Génesis 4-6; Mateo 2', 'title': 'La caída y sus consecuencias'},
            # ... continuaría con los 365 días
        ]
    }
}

# ============================================================================
# HERRAMIENTAS DE ESTUDIO
# ============================================================================

STUDY_TOOLS = {
    'hermeneutica': {
        'name': 'Hermenéutica',
        'description': 'Principios de interpretación bíblica',
        'tools': [
            {
                'name': 'Contexto Histórico',
                'description': 'Analizar el trasfondo histórico del pasaje',
                'icon': '🏛️',
                'questions': [
                    '¿Quién escribió este pasaje?',
                    '¿A quién fue dirigido?',
                    '¿Cuál era la situación histórica?',
                    '¿Qué propósito tenía el autor?'
                ]
            },
            {
                'name': 'Contexto Literario',
                'description': 'Examinar el contexto dentro del libro',
                'icon': '📖',
                'questions': [
                    '¿Qué viene antes y después?',
                    '¿Cómo se relaciona con el tema del libro?',
                    '¿Qué tipo de literatura es?',
                    '¿Hay figuras literarias?'
                ]
            },
            {
                'name': 'Análisis Gramatical',
                'description': 'Estudiar la gramática y sintaxis',
                'icon': '📝',
                'questions': [
                    '¿Cuáles son las palabras clave?',
                    '¿Qué significa en el idioma original?',
                    '¿Hay énfasis especiales?',
                    '¿Cómo se estructura el argumento?'
                ]
            }
        ]
    },
    
    'analisis_critico': {
        'name': 'Análisis Crítico',
        'description': 'Métodos de análisis textual y crítico',
        'tools': [
            {
                'name': 'Crítica Textual',
                'description': 'Examinar variantes textuales',
                'icon': '🔍',
                'questions': [
                    '¿Hay variantes en los manuscritos?',
                    '¿Cuál es la lectura más probable?',
                    '¿Cómo afecta la interpretación?'
                ]
            },
            {
                'name': 'Análisis de Fuentes',
                'description': 'Identificar fuentes y tradiciones',
                'icon': '📚',
                'questions': [
                    '¿Qué fuentes utilizó el autor?',
                    '¿Hay tradiciones orales detrás?',
                    '¿Se usan otras Escrituras?'
                ]
            }
        ]
    },
    
    'visualizacion': {
        'name': 'Visualización',
        'description': 'Herramientas visuales para el estudio',
        'tools': [
            {
                'name': 'Mapas Mentales',
                'description': 'Crear mapas conceptuales del pasaje',
                'icon': '🗺️',
                'features': ['Conexiones temáticas', 'Estructura visual', 'Relaciones']
            },
            {
                'name': 'Líneas de Tiempo',
                'description': 'Visualizar cronología bíblica',
                'icon': '⏰',
                'features': ['Eventos secuenciales', 'Contexto temporal', 'Paralelos']
            },
            {
                'name': 'Gráficos de Relaciones',
                'description': 'Mostrar relaciones entre personajes',
                'icon': '👥',
                'features': ['Genealogías', 'Redes sociales', 'Influencias']
            }
        ]
    }
}

# ============================================================================
# CONCORDANCIA BÁSICA
# ============================================================================

CONCORDANCE_SAMPLE = {
    'amor': [
        {'reference': 'Juan 3:16', 'context': 'Porque de tal manera amó Dios al mundo'},
        {'reference': '1 Juan 4:8', 'context': 'Dios es amor'},
        {'reference': '1 Corintios 13:4', 'context': 'El amor es sufrido, es benigno'},
        {'reference': 'Mateo 22:37', 'context': 'Amarás al Señor tu Dios'},
        {'reference': 'Romanos 5:8', 'context': 'Dios muestra su amor para con nosotros'}
    ],
    
    'fe': [
        {'reference': 'Hebreos 11:1', 'context': 'Es, pues, la fe la certeza de lo que se espera'},
        {'reference': 'Romanos 10:17', 'context': 'Así que la fe es por el oír'},
        {'reference': 'Efesios 2:8', 'context': 'Porque por gracia sois salvos por medio de la fe'},
        {'reference': 'Santiago 2:17', 'context': 'la fe, si no tiene obras, es muerta'},
        {'reference': 'Marcos 11:22', 'context': 'Tened fe en Dios'}
    ],
    
    'esperanza': [
        {'reference': 'Jeremías 29:11', 'context': 'para daros el fin que esperáis'},
        {'reference': 'Romanos 15:13', 'context': 'el Dios de esperanza os llene de todo gozo'},
        {'reference': '1 Pedro 1:3', 'context': 'una esperanza viva'},
        {'reference': 'Hebreos 6:19', 'context': 'esperanza que tenemos como segura y firme ancla'},
        {'reference': 'Salmos 42:5', 'context': 'Espera en Dios'}
    ]
}

# ============================================================================
# FUNCIONES DE UTILIDAD
# ============================================================================

def get_book_info(book_id):
    """Obtener información completa de un libro"""
    return BIBLE_BOOKS_COMPLETE.get(book_id, {})

def get_popular_verses(limit=10):
    """Obtener versículos populares"""
    return sorted(POPULAR_VERSES, key=lambda x: x['popularity'], reverse=True)[:limit]

def get_theme_verses(theme):
    """Obtener versículos de un tema específico"""
    theme_data = BIBLICAL_THEMES.get(theme, {})
    return theme_data.get('verses', [])

def get_reading_plan(plan_id):
    """Obtener plan de lectura específico"""
    return READING_PLANS.get(plan_id, {})

def get_study_tools_by_category(category):
    """Obtener herramientas de estudio por categoría"""
    return STUDY_TOOLS.get(category, {})

def search_concordance(word):
    """Buscar palabra en concordancia"""
    word_lower = word.lower()
    results = []
    
    for key, verses in CONCORDANCE_SAMPLE.items():
        if word_lower in key:
            results.extend(verses)
    
    return results

def get_all_themes():
    """Obtener todos los temas disponibles"""
    return list(BIBLICAL_THEMES.keys())

def get_all_books():
    """Obtener todos los libros bíblicos"""
    return BIBLE_BOOKS_COMPLETE

def get_testament_books(testament):
    """Obtener libros de un testamento específico"""
    return {
        book_id: book_data 
        for book_id, book_data in BIBLE_BOOKS_COMPLETE.items()
        if book_data['testament'] == testament
    }

# ============================================================================
# DATOS DE MUESTRA PARA DESARROLLO
# ============================================================================

SAMPLE_VERSES = [
    {
        'book': 'juan',
        'chapter': 3,
        'verse': 16,
        'text': 'Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito, para que todo aquel que en él cree, no se pierda, mas tenga vida eterna.'
    },
    {
        'book': 'filipenses',
        'chapter': 4,
        'verse': 13,
        'text': 'Todo lo puedo en Cristo que me fortalece.'
    },
    {
        'book': 'salmos',
        'chapter': 23,
        'verse': 1,
        'text': 'Jehová es mi pastor; nada me faltará.'
    },
    {
        'book': 'romanos',
        'chapter': 8,
        'verse': 28,
        'text': 'Y sabemos que a los que aman a Dios, todas las cosas les ayudan a bien, esto es, a los que conforme a su propósito son llamados.'
    },
    {
        'book': 'jeremias',
        'chapter': 29,
        'verse': 11,
        'text': 'Porque yo sé los pensamientos que tengo acerca de vosotros, dice Jehová, pensamientos de paz, y no de mal, para daros el fin que esperáis.'
    }
]

# Exportar todo
__all__ = [
    'BIBLE_BOOKS_COMPLETE',
    'POPULAR_VERSES',
    'BIBLICAL_THEMES',
    'READING_PLANS',
    'STUDY_TOOLS',
    'CONCORDANCE_SAMPLE',
    'SAMPLE_VERSES',
    'get_book_info',
    'get_popular_verses',
    'get_theme_verses',
    'get_reading_plan',
    'get_study_tools_by_category',
    'search_concordance',
    'get_all_themes',
    'get_all_books',
    'get_testament_books'
]
