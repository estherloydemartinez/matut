# 📱 Guía de Instalación - BibliaApp Pro v2.0.0

## 🚀 Instalación Rápida (Usuarios)

### Método 1: APK Directo (Recomendado)

1. **Descargar la aplicación**
   - Descarga `BibliaApp_Pro_v2.0.0_Android.apk`
   - Tamaño aproximado: ~50 MB

2. **Habilitar fuentes desconocidas**
   - Ve a **Configuración** → **Seguridad**
   - Activa **"Fuentes desconocidas"** o **"Instalar aplicaciones desconocidas"**
   - En Android 8+: Ve a **Configuración** → **Aplicaciones** → **Acceso especial** → **Instalar aplicaciones desconocidas**

3. **Instalar la aplicación**
   - Toca el archivo APK descargado
   - Sigue las instrucciones en pantalla
   - Acepta los permisos solicitados
   - Espera a que termine la instalación

4. **Primera configuración**
   - Abre BibliaApp Pro desde tu menú de aplicaciones
   - Acepta los términos y condiciones
   - Configura tus preferencias iniciales
   - ¡Comienza tu jornada de estudio bíblico!

### Método 2: Scripts Automáticos

#### Linux/macOS
```bash
# Hacer ejecutable
chmod +x instalar.sh

# Ejecutar instalador
./instalar.sh
```

#### Windows
```cmd
# Ejecutar instalador
instalar.bat
```

## 🔧 Instalación para Desarrolladores

### Prerrequisitos

- **Python**: 3.8 o superior
- **Sistema operativo**: Linux, macOS, o Windows
- **Memoria RAM**: 4 GB mínimo, 8 GB recomendado
- **Espacio en disco**: 10 GB libres
- **Conexión a internet**: Para descargar dependencias

### Configuración Automática

```bash
# Clonar repositorio
git clone https://github.com/bibliaapp/pro.git
cd pro/android-app

# Configurar entorno automáticamente
python setup_environment.py

# Compilar aplicación
python compile_android.py --type debug
```

### Configuración Manual

#### 1. Instalar Python y pip

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install python3 python3-pip python3-dev
```

**macOS:**
```bash
brew install python3
```

**Windows:**
- Descarga Python desde https://python.org
- Asegúrate de marcar "Add to PATH" durante la instalación

#### 2. Instalar dependencias del sistema

**Ubuntu/Debian:**
```bash
sudo apt install -y \
    build-essential \
    git \
    zip \
    unzip \
    openjdk-11-jdk \
    autoconf \
    libtool \
    pkg-config \
    zlib1g-dev \
    libncurses5-dev \
    libncursesw5-dev \
    libtinfo5 \
    cmake \
    libffi-dev \
    libssl-dev
```

**macOS:**
```bash
brew install git cmake autoconf automake libtool pkg-config openjdk@11
```

**Windows:**
- Instala Git for Windows
- Instala Microsoft Visual C++ Build Tools
- Instala OpenJDK 11

#### 3. Instalar dependencias de Python

```bash
pip install --upgrade pip
pip install buildozer cython
pip install kivy[base]>=2.1.0 kivymd>=1.1.1
pip install pillow requests plyer pyjnius
```

#### 4. Configurar Android SDK (Opcional)

Buildozer descargará automáticamente el SDK, pero puedes usar uno existente:

```bash
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$PATH:$ANDROID_HOME/platform-tools"
```

#### 5. Compilar la aplicación

```bash
# Debug (para desarrollo)
python compile_android.py --type debug

# Release (para distribución)
python compile_android.py --type release

# Compilar e instalar automáticamente
python compile_android.py --type debug --install
```

## 🛠️ Resolución de Problemas

### Problemas Comunes

#### Error: "buildozer command not found"
```bash
# Instalar buildozer
pip install buildozer

# Si persiste, agregar al PATH
export PATH="$HOME/.local/bin:$PATH"
```

#### Error: "Java not found"
```bash
# Ubuntu/Debian
sudo apt install openjdk-11-jdk

# Configurar JAVA_HOME
export JAVA_HOME="/usr/lib/jvm/java-11-openjdk-amd64"
```

#### Error: "NDK not found"
- Buildozer descargará automáticamente el NDK
- Si tienes problemas, limpia y recompila:
```bash
buildozer android clean
python compile_android.py --clean --type debug
```

#### Error de permisos en Linux
```bash
# Agregar usuario al grupo dialout (para ADB)
sudo usermod -a -G dialout $USER

# Reiniciar sesión o ejecutar:
newgrp dialout
```

### Depuración Avanzada

#### Logs detallados
```bash
# Compilación con logs verbosos
buildozer -v android debug

# Logs de ejecución en dispositivo
adb logcat | grep python
```

#### Limpiar cache
```bash
# Limpiar buildozer
buildozer android clean

# Limpiar Python cache
find . -name "*.pyc" -delete
find . -name "__pycache__" -type d -exec rm -rf {} +
```

## 📋 Permisos Requeridos

La aplicación solicita los siguientes permisos:

### Permisos Esenciales
- **INTERNET**: Sincronización y contenido online
- **WRITE_EXTERNAL_STORAGE**: Guardar datos de usuario
- **READ_EXTERNAL_STORAGE**: Leer configuraciones y cache

### Permisos Opcionales
- **CAMERA**: Escanear códigos QR de referencias
- **RECORD_AUDIO**: Notas de audio (opcional)
- **ACCESS_FINE_LOCATION**: Funciones comunitarias locales
- **VIBRATE**: Feedback háptico
- **WAKE_LOCK**: Mantener pantalla activa durante estudio

## 🔒 Seguridad y Privacidad

- **Datos offline**: Toda la funcionalidad principal funciona sin internet
- **Encriptación**: Datos sensibles encriptados localmente
- **Sin tracking**: No recopilamos datos personales sin consentimiento
- **Código abierto**: Puedes auditar el código fuente

## 📞 Soporte de Instalación

Si tienes problemas con la instalación:

1. **Consulta la documentación**: docs.bibliaapp.com
2. **Busca en Issues**: github.com/bibliaapp/pro/issues
3. **Contacta soporte**: soporte@bibliaapp.com
4. **Chat en Discord**: discord.gg/bibliaapp

---

¡Gracias por elegir BibliaApp Pro! Tu jornada de crecimiento espiritual está a punto de comenzar. 🙏

*"Lámpara es a mis pies tu palabra, y lumbrera a mi camino."* - Salmos 119:105
