#!/usr/bin/env python3
"""
Creador de distribución para BibliaApp Pro
Genera paquetes de distribución y documentación completa
"""

import os
import shutil
import zipfile
import json
from datetime import datetime
from pathlib import Path

class DistributionCreator:
    """Creador de distribución y documentación"""
    
    def __init__(self):
        self.project_dir = Path(__file__).parent
        self.dist_dir = self.project_dir / "distribution"
        self.docs_dir = self.dist_dir / "documentation"
        
        # Información del proyecto
        self.app_info = {
            'name': 'BibliaApp Pro',
            'version': '2.0.0',
            'build_date': datetime.now().isoformat(),
            'description': 'Aplicación de formación bíblica de clase mundial',
            'author': 'BibliaApp Team',
            'platform': 'Android',
            'min_android': '5.0 (API 21)',
            'target_android': '13 (API 33)'
        }
    
    def create_directories(self):
        """Crear estructura de directorios"""
        print("📁 Creando estructura de directorios...")
        
        directories = [
            self.dist_dir,
            self.docs_dir,
            self.dist_dir / "source_code",
            self.dist_dir / "builds",
            self.dist_dir / "tools",
            self.docs_dir / "developer",
            self.docs_dir / "user",
            self.docs_dir / "api"
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
        
        print("✅ Estructura de directorios creada")
    
    def create_readme(self):
        """Crear README principal"""
        print("📄 Creando README principal...")
        
        readme_content = f'''# {self.app_info['name']} v{self.app_info['version']}

## 🎯 Descripción

BibliaApp Pro es una aplicación móvil revolucionaria diseñada para transformar la experiencia del estudio bíblico. Combina tecnología de vanguardia con principios sólidos de hermenéutica para ofrecer una plataforma completa de formación bíblica.

## ✨ Características Principales

### 📚 **Teoría Bíblica Avanzada**
- **Modo Simple**: Lectura devocional con interfaz intuitiva
- **Modo Profundo**: 50+ herramientas de estudio académico
  - Hermenéutica avanzada
  - Análisis crítico textual
  - Lingüística bíblica
  - Historia y arqueología
  - Teología sistemática
  - Estadística bíblica
  - Filosofía e integración
  - Visualizaciones interactivas

### 🙏 **Práctica Cristiana Integral**
- **Guías de Oración**: 4 tipos principales (Adoración, Confesión, Gratitud, Petición)
- **Vida Cristiana**: Herramientas para relaciones, trabajo, servicio y mayordomía
- **Seguimiento**: Métricas de crecimiento espiritual

### 👥 **Sistema Social Completo**
- Comunidades de estudio
- Grupos de discusión
- Mentorías espirituales
- Eventos y actividades
- Compartir insights y revelaciones

### 🏆 **Gamificación Avanzada**
- Sistema de experiencia (XP) y niveles
- 50+ logros desbloqueables
- Rachas de lectura
- Desafíos personalizados
- Leaderboards comunitarios

### 🔧 **Herramientas de Estudio**
- Más de 50 herramientas categorizadas
- Concordancia interactiva
- Referencias cruzadas
- Comentarios contextuales
- Mapas y líneas de tiempo
- Análisis de palabras griegas/hebreas

## 🚀 Instalación Rápida

### Opción 1: Archivo APK (Recomendado)
1. Descarga `BibliaApp_Pro_v{self.app_info['version']}_Android.apk`
2. Habilita "Fuentes desconocidas" en tu dispositivo
3. Instala la aplicación
4. ¡Disfruta de tu nueva herramienta de estudio!

### Opción 2: Script Automático
```bash
# Linux/Mac
./instalar.sh

# Windows
instalar.bat
```

## 📱 Requisitos del Sistema

- **Android**: {self.app_info['min_android']} o superior
- **Almacenamiento**: 200 MB libres
- **RAM**: 2 GB recomendado
- **Conexión**: Opcional (funciona 100% offline)

## 🛠️ Para Desarrolladores

### Compilación desde Código Fuente

1. **Configurar entorno**:
   ```bash
   python setup_environment.py
   ```

2. **Compilar APK**:
   ```bash
   # Debug
   python compile_android.py --type debug
   
   # Release
   python compile_android.py --type release --install
   ```

### Arquitectura Técnica

- **Frontend**: Kivy + KivyMD (Python nativo)
- **Base de Datos**: SQLite con esquema optimizado
- **Persistencia**: JsonStore + archivos binarios
- **Networking**: Requests con manejo de errores robusto
- **Notificaciones**: Plyer con schedulers nativos

### Estructura del Proyecto

```
android-app/
├── src/
│   ├── main.py              # Aplicación principal
│   ├── config.py            # Configuraciones
│   ├── bible_data_full.py   # Datos bíblicos
│   └── modules/             # Módulos específicos
├── assets/                  # Recursos estáticos
├── buildozer.spec          # Configuración de compilación
└── requirements.txt        # Dependencias Python
```

## 🎨 Diseño UI/UX

### Paleta de Colores Pastel Profesional
- **Primario**: #4F46E5 (Indigo elegante)
- **Secundario**: #F59E0B (Ámbar cálido)
- **Acento**: #EC4899 (Rosa vibrante)
- **Fondos**: Gradientes suaves pastel
- **Tipografía**: Roboto optimizada para lectura

### Principios de Diseño
- **Minimalismo funcional**: Cada elemento tiene propósito
- **Accesibilidad universal**: Soporte para lectores de pantalla
- **Responsive design**: Adaptable a cualquier tamaño de pantalla
- **Micro-interacciones**: Feedback visual inmediato
- **Jerarquía visual clara**: Información organizada intuitivamente

## 📊 Herramientas de Pensamiento Profundo

### Categorías Académicas (50+ herramientas)

1. **Hermenéutica** (12 herramientas)
   - Contexto histórico-cultural
   - Análisis literario
   - Crítica textual
   - Método gramático-histórico

2. **Análisis Crítico** (10 herramientas)
   - Crítica de fuentes
   - Crítica de formas
   - Crítica de redacción
   - Análisis narrativo

3. **Lingüística** (10 herramientas)
   - Análisis léxico
   - Sintaxis griega/hebrea
   - Semántica bíblica
   - Pragmática textual

4. **Historia y Arqueología** (9 herramientas)
   - Cronología bíblica
   - Geografía histórica
   - Cultura del Antiguo Cercano Oriente
   - Evidencia arqueológica

5. **Teología Sistemática** (7 herramientas)
   - Doctrina bíblica
   - Teología bíblica
   - Teología histórica
   - Apologética

6. **Visualización** (6 herramientas)
   - Mapas mentales
   - Gráficos relacionales
   - Líneas de tiempo
   - Infografías interactivas

## 🌟 Características Únicas

### Sistema Social Jerárquico
- **Individual → Grupal**: Todo estudio personal puede compartirse
- **Mentorías estructuradas**: Conexión entre estudiantes y maestros
- **Eventos comunitarios**: Estudios en vivo y conferencias
- **Recursos colaborativos**: Creación conjunta de contenido

### Personalización Total
- **Interfaz adaptable**: Cada componente es configurable
- **Planes de estudio**: Personalizados según nivel y objetivos
- **Notificaciones inteligentes**: Adaptadas a rutinas personales
- **Progreso individualizado**: Métricas específicas por usuario

## 📈 Roadmap Futuro

### v2.1 (Q1 2025)
- [ ] Integración con IA para insights personalizados
- [ ] Reconocimiento de voz para búsquedas
- [ ] Realidad aumentada para mapas bíblicos
- [ ] Sincronización multi-dispositivo

### v2.2 (Q2 2025)
- [ ] Versiones en 10 idiomas adicionales
- [ ] Colaboración en tiempo real
- [ ] Exportación a formatos académicos
- [ ] API pública para desarrolladores

## 🤝 Contribuciones

Agradecemos contribuciones de la comunidad:

1. **Reportar bugs**: GitHub Issues
2. **Sugerir características**: GitHub Discussions
3. **Contribuir código**: Pull Requests
4. **Traducir contenido**: Crowdin
5. **Crear contenido**: Portal de creadores

## 📞 Soporte

- **Email**: soporte@bibliaapp.com
- **Documentación**: https://docs.bibliaapp.com
- **GitHub**: https://github.com/bibliaapp/pro
- **Discord**: https://discord.gg/bibliaapp
- **Telegram**: @BibliaAppSupport

## 📜 Licencia

Este proyecto está licenciado bajo MIT License - ver [LICENSE](LICENSE) para detalles.

## 🙏 Agradecimientos

- Comunidad de teólogos y desarrolladores
- Traductores de versiones bíblicas
- Beta testers y usuarios tempranos
- Bibliotecas de código abierto utilizadas

---

**"La suma de tu palabra es verdad, y eterno es todo juicio de tu justicia."** - Salmos 119:160

*BibliaApp Pro v{self.app_info['version']} - Transformando vidas a través del estudio bíblico profundo*

💡 **¿Sabías que...?** Esta aplicación incluye más de 50 herramientas de estudio que normalmente requieren múltiples aplicaciones y recursos físicos. Todo integrado en una experiencia fluida y hermosa.

🎯 **Objetivo**: Equipar a cada creyente con las mejores herramientas para comprender, aplicar y compartir la Palabra de Dios de manera efectiva y transformadora.
'''
        
        readme_path = self.dist_dir / "README.md"
        with open(readme_path, 'w', encoding='utf-8') as f:
            f.write(readme_content)
        
        print("✅ README principal creado")
    
    def create_installation_guide(self):
        """Crear guía de instalación detallada"""
        print("📖 Creando guía de instalación...")
        
        guide_content = f'''# 📱 Guía de Instalación - BibliaApp Pro v{self.app_info['version']}

## 🚀 Instalación Rápida (Usuarios)

### Método 1: APK Directo (Recomendado)

1. **Descargar la aplicación**
   - Descarga `BibliaApp_Pro_v{self.app_info['version']}_Android.apk`
   - Tamaño aproximado: ~50 MB

2. **Habilitar fuentes desconocidas**
   - Ve a **Configuración** → **Seguridad**
   - Activa **"Fuentes desconocidas"** o **"Instalar aplicaciones desconocidas"**
   - En Android 8+: Ve a **Configuración** → **Aplicaciones** → **Acceso especial** → **Instalar aplicaciones desconocidas**

3. **Instalar la aplicación**
   - Toca el archivo APK descargado
   - Sigue las instrucciones en pantalla
   - Acepta los permisos solicitados
   - Espera a que termine la instalación

4. **Primera configuración**
   - Abre BibliaApp Pro desde tu menú de aplicaciones
   - Acepta los términos y condiciones
   - Configura tus preferencias iniciales
   - ¡Comienza tu jornada de estudio bíblico!

### Método 2: Scripts Automáticos

#### Linux/macOS
```bash
# Hacer ejecutable
chmod +x instalar.sh

# Ejecutar instalador
./instalar.sh
```

#### Windows
```cmd
# Ejecutar instalador
instalar.bat
```

## 🔧 Instalación para Desarrolladores

### Prerrequisitos

- **Python**: 3.8 o superior
- **Sistema operativo**: Linux, macOS, o Windows
- **Memoria RAM**: 4 GB mínimo, 8 GB recomendado
- **Espacio en disco**: 10 GB libres
- **Conexión a internet**: Para descargar dependencias

### Configuración Automática

```bash
# Clonar repositorio
git clone https://github.com/bibliaapp/pro.git
cd pro/android-app

# Configurar entorno automáticamente
python setup_environment.py

# Compilar aplicación
python compile_android.py --type debug
```

### Configuración Manual

#### 1. Instalar Python y pip

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install python3 python3-pip python3-dev
```

**macOS:**
```bash
brew install python3
```

**Windows:**
- Descarga Python desde https://python.org
- Asegúrate de marcar "Add to PATH" durante la instalación

#### 2. Instalar dependencias del sistema

**Ubuntu/Debian:**
```bash
sudo apt install -y \\
    build-essential \\
    git \\
    zip \\
    unzip \\
    openjdk-11-jdk \\
    autoconf \\
    libtool \\
    pkg-config \\
    zlib1g-dev \\
    libncurses5-dev \\
    libncursesw5-dev \\
    libtinfo5 \\
    cmake \\
    libffi-dev \\
    libssl-dev
```

**macOS:**
```bash
brew install git cmake autoconf automake libtool pkg-config openjdk@11
```

**Windows:**
- Instala Git for Windows
- Instala Microsoft Visual C++ Build Tools
- Instala OpenJDK 11

#### 3. Instalar dependencias de Python

```bash
pip install --upgrade pip
pip install buildozer cython
pip install kivy[base]>=2.1.0 kivymd>=1.1.1
pip install pillow requests plyer pyjnius
```

#### 4. Configurar Android SDK (Opcional)

Buildozer descargará automáticamente el SDK, pero puedes usar uno existente:

```bash
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$PATH:$ANDROID_HOME/platform-tools"
```

#### 5. Compilar la aplicación

```bash
# Debug (para desarrollo)
python compile_android.py --type debug

# Release (para distribución)
python compile_android.py --type release

# Compilar e instalar automáticamente
python compile_android.py --type debug --install
```

## 🛠️ Resolución de Problemas

### Problemas Comunes

#### Error: "buildozer command not found"
```bash
# Instalar buildozer
pip install buildozer

# Si persiste, agregar al PATH
export PATH="$HOME/.local/bin:$PATH"
```

#### Error: "Java not found"
```bash
# Ubuntu/Debian
sudo apt install openjdk-11-jdk

# Configurar JAVA_HOME
export JAVA_HOME="/usr/lib/jvm/java-11-openjdk-amd64"
```

#### Error: "NDK not found"
- Buildozer descargará automáticamente el NDK
- Si tienes problemas, limpia y recompila:
```bash
buildozer android clean
python compile_android.py --clean --type debug
```

#### Error de permisos en Linux
```bash
# Agregar usuario al grupo dialout (para ADB)
sudo usermod -a -G dialout $USER

# Reiniciar sesión o ejecutar:
newgrp dialout
```

### Depuración Avanzada

#### Logs detallados
```bash
# Compilación con logs verbosos
buildozer -v android debug

# Logs de ejecución en dispositivo
adb logcat | grep python
```

#### Limpiar cache
```bash
# Limpiar buildozer
buildozer android clean

# Limpiar Python cache
find . -name "*.pyc" -delete
find . -name "__pycache__" -type d -exec rm -rf {{}} +
```

## 📋 Permisos Requeridos

La aplicación solicita los siguientes permisos:

### Permisos Esenciales
- **INTERNET**: Sincronización y contenido online
- **WRITE_EXTERNAL_STORAGE**: Guardar datos de usuario
- **READ_EXTERNAL_STORAGE**: Leer configuraciones y cache

### Permisos Opcionales
- **CAMERA**: Escanear códigos QR de referencias
- **RECORD_AUDIO**: Notas de audio (opcional)
- **ACCESS_FINE_LOCATION**: Funciones comunitarias locales
- **VIBRATE**: Feedback háptico
- **WAKE_LOCK**: Mantener pantalla activa durante estudio

## 🔒 Seguridad y Privacidad

- **Datos offline**: Toda la funcionalidad principal funciona sin internet
- **Encriptación**: Datos sensibles encriptados localmente
- **Sin tracking**: No recopilamos datos personales sin consentimiento
- **Código abierto**: Puedes auditar el código fuente

## 📞 Soporte de Instalación

Si tienes problemas con la instalación:

1. **Consulta la documentación**: docs.bibliaapp.com
2. **Busca en Issues**: github.com/bibliaapp/pro/issues
3. **Contacta soporte**: soporte@bibliaapp.com
4. **Chat en Discord**: discord.gg/bibliaapp

---

¡Gracias por elegir BibliaApp Pro! Tu jornada de crecimiento espiritual está a punto de comenzar. 🙏

*"Lámpara es a mis pies tu palabra, y lumbrera a mi camino."* - Salmos 119:105
'''
        
        guide_path = self.docs_dir / "INSTALLATION.md"
        with open(guide_path, 'w', encoding='utf-8') as f:
            f.write(guide_content)
        
        print("✅ Guía de instalación creada")
    
    def create_technical_docs(self):
        """Crear documentación técnica"""
        print("⚙️ Creando documentación técnica...")
        
        # Documentación de API
        api_doc = f'''# 📡 BibliaApp Pro - Documentación de API

## Arquitectura de la Aplicación

### Stack Tecnológico

- **Framework**: Kivy + KivyMD
- **Lenguaje**: Python 3.8+
- **Base de Datos**: SQLite
- **Almacenamiento**: JsonStore + archivos binarios
- **UI**: Material Design 3
- **Empaquetado**: Buildozer (Python-for-Android)

### Estructura Modular

```python
# Gestor de Base de Datos
class DatabaseManager:
    def __init__(self, db_path: str)
    def execute_query(self, query: str, params: tuple = None) -> List[Dict]
    def execute_command(self, query: str, params: tuple = None) -> bool

# Gestor de Datos Bíblicos
class BibleDataManager:
    def search_verses(self, query: str) -> List[Dict]
    def get_books(self, testament: str = None) -> List[Dict]
    def get_chapter(self, book_id: str, chapter: int) -> List[Dict]

# Gestor de Configuraciones
class SettingsManager:
    def get_setting(self, key: str, default: str = None) -> str
    def set_setting(self, key: str, value: str)
    def get_bool_setting(self, key: str, default: bool = False) -> bool

# Gestor de Progreso
class ProgressManager:
    def add_xp(self, amount: int, activity: str = "")
    def unlock_achievement(self, achievement_id: str, achievement_data: Dict)
    def calculate_streak(self)
```

### Pantallas Principales

```python
# Pantalla Base
class BaseScreen(MDScreen):
    def setup_ui(self)
    def show_loading(self, message: str = "Cargando...")
    def show_message(self, message: str, duration: int = 3)

# Pantalla de Inicio
class HomeScreen(BaseScreen):
    def create_header_card(self)
    def create_checkin_card(self)
    def create_progress_card(self)

# Pantalla de Teoría
class TheoryScreen(BaseScreen):
    def create_reading_modes(self)
    def create_study_tools(self)
    def create_memory_section(self)

# Pantalla de Práctica
class PracticeScreen(BaseScreen):
    def create_prayer_section(self)
    def create_life_section(self)
    def create_tracking_section(self)
```

## Base de Datos

### Esquema Principal

```sql
-- Libros bíblicos
CREATE TABLE bible_books (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    abbreviation TEXT NOT NULL,
    testament TEXT NOT NULL,
    order_num INTEGER NOT NULL,
    chapters INTEGER NOT NULL,
    category TEXT NOT NULL,
    author TEXT,
    theme TEXT,
    key_verse TEXT,
    summary TEXT
);

-- Versículos
CREATE TABLE bible_verses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id TEXT NOT NULL,
    chapter INTEGER NOT NULL,
    verse INTEGER NOT NULL,
    text TEXT NOT NULL,
    version TEXT DEFAULT 'RV1960',
    FOREIGN KEY (book_id) REFERENCES bible_books (id)
);

-- Progreso del usuario
CREATE TABLE user_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT DEFAULT 'default',
    activity_type TEXT NOT NULL,
    data TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Notas del usuario
CREATE TABLE notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL,
    title TEXT,
    content TEXT NOT NULL,
    tags TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### Consultas Comunes

```python
# Buscar versículos
def search_verses(query):
    return db.execute_query("""
        SELECT bv.*, bb.name as book_name, bb.abbreviation
        FROM bible_verses bv
        JOIN bible_books bb ON bv.book_id = bb.id
        WHERE bv.text LIKE ? OR bb.name LIKE ?
        ORDER BY bb.order_num, bv.chapter, bv.verse
        LIMIT 50
    """, (f'%{{query}}%', f'%{{query}}%'))

# Obtener progreso
def get_user_xp():
    result = db.execute_query("""
        SELECT data FROM user_progress 
        WHERE activity_type = 'xp_update' 
        ORDER BY timestamp DESC LIMIT 1
    """)
    if result:
        return json.loads(result[0]['data'])['xp']
    return 0
```

## Configuración

### Archivo config.py

```python
# Información de la aplicación
APP_INFO = {{
    'name': 'BibliaApp Pro',
    'version': '2.0.0',
    'package': 'com.bibliaapp.pro'
}}

# Configuración de UI
UI_CONFIG = {{
    'colors': {{
        'primary': '#4F46E5',
        'secondary': '#F59E0B',
        'accent': '#EC4899'
    }},
    'fonts': {{
        'primary': 'Roboto',
        'sizes': {{
            'body': '14sp',
            'title': '20sp'
        }}
    }}
}}

# Características habilitadas
FEATURES = {{
    'offline_mode': True,
    'notifications': True,
    'gamification': True,
    'social_features': True
}}
```

## Sistema de Gamificación

### Experiencia (XP)

```python
XP_VALUES = {{
    'daily_reading': 10,
    'chapter_complete': 25,
    'book_complete': 100,
    'verse_memorized': 15,
    'prayer_session': 5,
    'achievement_unlocked': 50
}}

# Cálculo de nivel
def calculate_level(xp):
    return int(math.sqrt(xp / 100)) + 1
```

### Logros

```python
ACHIEVEMENTS = {{
    'first_read': {{
        'name': 'Primer Paso',
        'description': 'Primera lectura bíblica',
        'xp': 50
    }},
    'week_streak': {{
        'name': 'Constante',
        'description': '7 días seguidos leyendo',
        'xp': 100
    }}
}}
```

## Herramientas de Estudio

### Categorías Principales

1. **Hermenéutica** (12 herramientas)
2. **Análisis Crítico** (10 herramientas)  
3. **Lingüística** (10 herramientas)
4. **Historia y Arqueología** (9 herramientas)
5. **Teología Sistemática** (7 herramientas)
6. **Visualización** (6 herramientas)

### Implementación

```python
class StudyTool:
    def __init__(self, name, category, description):
        self.name = name
        self.category = category
        self.description = description
    
    def analyze(self, passage):
        # Implementación específica de cada herramienta
        pass

# Herramienta de contexto histórico
class HistoricalContextTool(StudyTool):
    def analyze(self, passage):
        return {{
            'period': self.get_historical_period(passage),
            'culture': self.get_cultural_context(passage),
            'geography': self.get_geographical_context(passage)
        }}
```

## Notificaciones

### Sistema de Recordatorios

```python
NOTIFICATION_TYPES = {{
    'daily_reminder': {{
        'title': '📖 Tiempo de Lectura',
        'message': '¡Es hora de tu lectura bíblica diaria!',
        'time': '08:00'
    }},
    'prayer_reminder': {{
        'title': '🙏 Momento de Oración',
        'message': 'Dedica unos minutos para orar',
        'times': ['12:00', '18:00']
    }}
}}

def schedule_notification(notification_type, custom_time=None):
    if PLYER_AVAILABLE:
        notification.notify(
            title=notification_type['title'],
            message=notification_type['message'],
            timeout=10
        )
```

## Extensibilidad

### Plugin System (Futuro)

```python
class PluginInterface:
    def __init__(self):
        self.name = ""
        self.version = ""
    
    def initialize(self, app_context):
        pass
    
    def get_tools(self):
        return []
    
    def process_passage(self, passage):
        pass

# Registro de plugins
class PluginManager:
    def __init__(self):
        self.plugins = []
    
    def register_plugin(self, plugin):
        self.plugins.append(plugin)
    
    def get_available_tools(self):
        tools = []
        for plugin in self.plugins:
            tools.extend(plugin.get_tools())
        return tools
```

---

Esta documentación técnica permite a los desarrolladores entender y extender BibliaApp Pro eficientemente.
'''
        
        api_path = self.docs_dir / "api" / "API.md"
        api_path.parent.mkdir(exist_ok=True)
        with open(api_path, 'w', encoding='utf-8') as f:
            f.write(api_doc)
        
        print("✅ Documentación técnica creada")
    
    def create_user_manual(self):
        """Crear manual de usuario"""
        print("📚 Creando manual de usuario...")
        
        manual_content = f'''# 📖 Manual de Usuario - BibliaApp Pro v{self.app_info['version']}

## 🎯 Bienvenido a BibliaApp Pro

BibliaApp Pro es tu compañero completo para el estudio bíblico profundo. Esta guía te ayudará a aprovechar al máximo todas las características de la aplicación.

## 🚀 Primeros Pasos

### Pantalla de Inicio
Al abrir la aplicación, verás:
- **Saludo personalizado** según la hora del día
- **Check-in diario** con actividades espirituales
- **Progreso visual** de tu nivel y racha
- **Accesos rápidos** a funciones principales
- **Versículo del día** para inspiración

### Navegación Principal
La aplicación se organiza en 5 secciones principales:

1. **🏠 Inicio** - Dashboard personal
2. **📚 Teoría** - Estudio bíblico
3. **🙏 Práctica** - Vida cristiana
4. **👥 Social** - Comunidad
5. **⚙️ Ajustes** - Configuración

## 📚 Sección de Teoría

### Modos de Lectura

#### 🌱 Modo Simple
Perfecto para lectura devocional diaria:
- Interfaz limpia y sin distracciones
- Texto bíblico con formato optimizado
- Marcadores y notas rápidas
- Plan de lectura sugerido

#### 🔬 Modo Profundo
Para estudio académico serio con 50+ herramientas:

##### Hermenéutica (12 herramientas)
- **Contexto Histórico**: Trasfondo temporal y cultural
- **Análisis Literario**: Estructura y género
- **Crítica Textual**: Variantes manuscritas
- **Método Gramático-Histórico**: Interpretación clásica

##### Análisis Crítico (10 herramientas)
- **Crítica de Fuentes**: Identificación de tradiciones
- **Crítica de Formas**: Géneros literarios
- **Crítica de Redacción**: Propósito del autor
- **Análisis Narrativo**: Estructura de historias

##### Lingüística (10 herramientas)
- **Análisis Léxico**: Significado de palabras
- **Sintaxis**: Estructura gramatical
- **Semántica**: Significado en contexto
- **Palabras Clave**: Términos importantes

##### Historia y Arqueología (9 herramientas)
- **Cronología**: Líneas de tiempo
- **Geografía**: Mapas interactivos
- **Cultura ANE**: Antiguo Cercano Oriente
- **Evidencia Arqueológica**: Descubrimientos

##### Teología Sistemática (7 herramientas)
- **Doctrina Bíblica**: Enseñanzas fundamentales
- **Teología Bíblica**: Temas a través de la Escritura
- **Apologética**: Defensa de la fe
- **Eclesiología**: Doctrina de la iglesia

##### Visualización (6 herramientas)
- **Mapas Mentales**: Conexiones conceptuales
- **Gráficos**: Relaciones visuales
- **Líneas de Tiempo**: Secuencia histórica
- **Infografías**: Resúmenes visuales

### Herramientas de Memorización
Técnicas científicamente probadas:
- **Repetición Espaciada**: Algoritmo optimizado
- **Asociación Visual**: Imágenes mnemotécnicas
- **Chunking**: División en fragmentos
- **Rehearsal**: Práctica programada

## 🙏 Sección de Práctica

### ¿Qué es Orar?

#### Tipos de Oración
1. **💫 Adoración**
   - Alabanza por quién es Dios
   - Reconocimiento de sus atributos
   - Expresión de reverencia

2. **💔 Confesión**
   - Reconocimiento de pecados
   - Arrepentimiento genuino
   - Petición de perdón

3. **🎁 Gratitud**
   - Agradecimiento por bendiciones
   - Reconocimiento de provisión
   - Apreciación de la gracia

4. **🤲 Petición**
   - Solicitudes personales
   - Intercesión por otros
   - Necesidades específicas

#### Guías de Oración
- **Estructura ACTS**: Adoración, Confesión, Gratitud, Súplica
- **Oración del Señor**: Siguiendo Mateo 6:9-13
- **Oración Contemplativa**: Meditación profunda
- **Oración Intercesora**: Por otros

### ¿Qué es Dar/Vivir?

#### Áreas de Vida Cristiana

1. **❤️ Relaciones**
   - Matrimonio y familia
   - Amistades cristianas
   - Relaciones laborales
   - Testimonio personal

2. **💼 Trabajo**
   - Ética laboral
   - Testimonio profesional
   - Mayordomía de talentos
   - Servicio excelente

3. **🌍 Servicio**
   - Ministerio en la iglesia
   - Servicio comunitario
   - Misiones y evangelismo
   - Actos de bondad

4. **💰 Mayordomía**
   - Manejo de finanzas
   - Generosidad bíblica
   - Planificación financiera
   - Contentamiento

#### Seguimiento de Crecimiento
- **Métricas espirituales**: Actividades registradas
- **Reflexiones diarias**: Journaling guiado
- **Metas personales**: Objetivos de crecimiento
- **Evaluación periódica**: Progreso mensual

## 👥 Sección Social

### Comunidad BibliaApp

#### Funciones Principales
- **Grupos de Estudio**: Únete o crea grupos temáticos
- **Discusiones**: Participa en conversaciones bíblicas
- **Mentorías**: Conecta con mentores espirituales
- **Eventos**: Asiste a estudios en vivo

#### Compartir y Colaborar
- **Insights**: Comparte revelaciones personales
- **Notas**: Colabora en estudios grupales
- **Oraciones**: Comparte peticiones de oración
- **Testimonios**: Narra experiencias de fe

#### Características Avanzadas
- **Foros Temáticos**: Por libros o temas bíblicos
- **Salas de Estudio**: Sesiones en tiempo real
- **Biblioteca Comunitaria**: Recursos compartidos
- **Red de Mentores**: Sistema de discipulado

## 🏆 Sistema de Gamificación

### Experiencia (XP) y Niveles

#### Actividades que Dan XP
- **Lectura diaria**: 10 XP
- **Capítulo completado**: 25 XP
- **Libro completado**: 100 XP
- **Versículo memorizado**: 15 XP
- **Sesión de oración**: 5 XP
- **Nota creada**: 3 XP
- **Compartir insight**: 8 XP
- **Ayudar a otros**: 20 XP

#### Niveles de Progreso
1. **Principiante** (0 XP) - Comenzando el camino
2. **Buscador** (100 XP) - Explorando las Escrituras
3. **Discípulo** (500 XP) - Comprometido con el aprendizaje
4. **Estudiante** (1,500 XP) - Estudio sistemático
5. **Erudito** (3,500 XP) - Conocimiento profundo
6. **Maestro** (7,500 XP) - Enseñando a otros
7. **Sabio** (15,000 XP) - Sabiduría espiritual
8. **Anciano** (25,000 XP) - Liderazgo maduro
9. **Leyenda** (40,000 XP) - Impacto transformador

### Logros Desbloqueables

#### Logros de Lectura
- **Primer Paso**: Primera lectura bíblica
- **Constante**: 7 días consecutivos
- **Fiel**: 30 días consecutivos
- **Perseverante**: 365 días consecutivos
- **Completista**: Leyó toda la Biblia

#### Logros de Memorización
- **Memorizador Novato**: 10 versículos
- **Memorizador**: 50 versículos
- **Maestro de Memoria**: 100 versículos
- **Biblioteca Viviente**: 500 versículos

#### Logros Sociales
- **Ayudador**: Ayudó a 10 personas
- **Mentor**: Mentoró a 5 usuarios
- **Comunicador**: 100 posts en foros
- **Inspirador**: Sus posts recibieron 1000 likes

### Rachas y Desafíos
- **Racha de Lectura**: Días consecutivos leyendo
- **Desafío Semanal**: Metas específicas
- **Maratón Bíblico**: Eventos especiales
- **Competencias Amigables**: Con amigos

## ⚙️ Configuración y Personalización

### Ajustes de Lectura
- **Tamaño de fuente**: 12sp - 24sp
- **Interlineado**: Simple, 1.5x, Doble
- **Tema**: Claro, Oscuro, Sepia
- **Versión bíblica**: RV1960, NVI, LBLA, etc.

### Notificaciones
- **Recordatorio diario**: Hora personalizable
- **Recordatorios de oración**: Múltiples horarios
- **Logros**: Notificaciones de progreso
- **Social**: Mensajes y menciones

### Sincronización
- **Copia de seguridad**: Automática en la nube
- **Multi-dispositivo**: Sincronización entre dispositivos
- **Exportar datos**: JSON, PDF, txt
- **Importar datos**: Desde otras aplicaciones

### Privacidad
- **Perfil público/privado**: Control de visibilidad
- **Datos compartidos**: Qué información compartir
- **Historial**: Mantener o limpiar automáticamente
- **Ubicación**: Habilitar funciones locales

## 🔍 Funciones de Búsqueda

### Búsqueda Básica
- **Por palabra**: Busca términos específicos
- **Por referencia**: Ir directo a pasajes
- **Por tema**: Encuentra versículos temáticos
- **Por personaje**: Estudia personas bíblicas

### Búsqueda Avanzada
- **Operadores booleanos**: AND, OR, NOT
- **Búsqueda difusa**: Palabras similares
- **Rangos**: Buscar en libros específicos
- **Filtros**: Por testamento, género, autor

### Concordancia
- **Palabras clave**: Todas las apariciones
- **Contexto**: Versículos completos
- **Referencias cruzadas**: Pasajes relacionados
- **Temas conexos**: Conceptos similares

## 📝 Notas y Marcadores

### Sistema de Notas
- **Notas de versículo**: Asociadas a pasajes específicos
- **Notas generales**: Reflexiones libres
- **Notas de estudio**: Con herramientas académicas
- **Notas compartidas**: Colaborativas

### Organización
- **Etiquetas**: Categorización flexible
- **Colecciones**: Grupos temáticos
- **Búsqueda**: En todo el contenido
- **Exportación**: Múltiples formatos

### Marcadores
- **Favoritos**: Versículos especiales
- **Para estudiar**: Lista de pendientes
- **Compartidos**: Con la comunidad
- **Colecciones temáticas**: Agrupaciones

## 📊 Estadísticas y Reportes

### Progreso Personal
- **Tiempo de lectura**: Minutos diarios/semanales
- **Capítulos leídos**: Progreso por libro
- **Versículos memorizados**: Lista y fechas
- **Actividad de oración**: Frecuencia y duración

### Análisis de Hábitos
- **Mejores horarios**: Cuándo estudias más
- **Libros favoritos**: Más tiempo dedicado
- **Temas preferidos**: Intereses principales
- **Tendencias**: Crecimiento en el tiempo

### Reportes Detallados
- **Reporte mensual**: Resumen de actividades
- **Reporte anual**: Logros y crecimiento
- **Comparativo**: Con períodos anteriores
- **Exportable**: PDF, Excel, imagen

## 🆘 Ayuda y Soporte

### Centro de Ayuda
- **Tutoriales**: Videos paso a paso
- **FAQ**: Preguntas frecuentes
- **Guías**: Documentación detallada
- **Tips**: Consejos de uso avanzado

### Comunidad de Soporte
- **Foro de usuarios**: Ayuda entre usuarios
- **Chat en vivo**: Soporte inmediato
- **Videos tutoriales**: Canal de YouTube
- **Webinars**: Sesiones de entrenamiento

### Contacto Directo
- **Email**: soporte@bibliaapp.com
- **Discord**: Servidor oficial
- **Telegram**: Canal de soporte
- **GitHub**: Reportar bugs técnicos

---

¡Esperamos que este manual te ayude a aprovechar al máximo BibliaApp Pro! Tu crecimiento espiritual es nuestra prioridad.

*"Estudia para presentarte a Dios aprobado, como obrero que no tiene de qué avergonzarse, que maneja con precisión la palabra de verdad."* - 2 Timoteo 2:15
'''
        
        manual_path = self.docs_dir / "user" / "USER_MANUAL.md"
        manual_path.parent.mkdir(exist_ok=True)
        with open(manual_path, 'w', encoding='utf-8') as f:
            f.write(manual_content)
        
        print("✅ Manual de usuario creado")
    
    def copy_source_code(self):
        """Copiar código fuente a distribución"""
        print("📦 Copiando código fuente...")
        
        source_target = self.dist_dir / "source_code"
        
        # Copiar archivos principales
        files_to_copy = [
            "src/main.py",
            "src/config.py", 
            "src/bible_data_full.py",
            "buildozer.spec",
            "requirements.txt",
            "setup_environment.py",
            "compile_android.py"
        ]
        
        for file_path in files_to_copy:
            source_file = self.project_dir / file_path
            if source_file.exists():
                target_file = source_target / file_path
                target_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source_file, target_file)
        
        print("✅ Código fuente copiado")
    
    def create_build_info(self):
        """Crear información de compilación"""
        print("📋 Creando información de compilación...")
        
        build_info = {
            **self.app_info,
            'compilation_date': datetime.now().isoformat(),
            'python_version': '3.8+',
            'kivy_version': '2.1.0',
            'kivymd_version': '1.1.1',
            'target_platforms': ['Android'],
            'features': {
                'offline_mode': True,
                'bible_study_tools': 50,
                'gamification': True,
                'social_features': True,
                'notifications': True,
                'multilingual': True
            },
            'file_sizes': {
                'apk_estimated': '45-55 MB',
                'database': '15 MB',
                'assets': '10 MB'
            },
            'requirements': {
                'android_min': '5.0 (API 21)',
                'android_target': '13 (API 33)',
                'ram_min': '2 GB',
                'storage_min': '200 MB'
            }
        }
        
        info_path = self.dist_dir / "BUILD_INFO.json"
        with open(info_path, 'w', encoding='utf-8') as f:
            json.dump(build_info, f, indent=2, ensure_ascii=False)
        
        print("✅ Información de compilación creada")
    
    def create_package(self):
        """Crear paquete ZIP de distribución"""
        print("📦 Creando paquete de distribución...")
        
        package_name = f"BibliaApp_Pro_v{self.app_info['version']}_Complete_Package.zip"
        package_path = self.project_dir.parent / package_name
        
        with zipfile.ZipFile(package_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(self.dist_dir):
                for file in files:
                    file_path = Path(root) / file
                    arcname = file_path.relative_to(self.dist_dir)
                    zipf.write(file_path, arcname)
        
        print(f"✅ Paquete creado: {package_path}")
        return package_path
    
    def run_distribution(self):
        """Ejecutar creación completa de distribución"""
        print(f"🚀 Creando distribución completa de {self.app_info['name']} v{self.app_info['version']}")
        print("=" * 60)
        print()
        
        steps = [
            ("Crear directorios", self.create_directories),
            ("Crear README", self.create_readme),
            ("Crear guía de instalación", self.create_installation_guide),
            ("Crear documentación técnica", self.create_technical_docs),
            ("Crear manual de usuario", self.create_user_manual),
            ("Copiar código fuente", self.copy_source_code),
            ("Crear información de compilación", self.create_build_info),
            ("Crear paquete final", self.create_package)
        ]
        
        for step_name, step_func in steps:
            try:
                step_func()
            except Exception as e:
                print(f"❌ Error en {step_name}: {e}")
        
        print()
        print("🎉 ¡Distribución completa creada exitosamente!")
        print(f"📁 Archivos disponibles en: {self.dist_dir}")
        
        return True

def main():
    """Función principal"""
    creator = DistributionCreator()
    creator.run_distribution()

if __name__ == "__main__":
    main()
