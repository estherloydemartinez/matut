#!/usr/bin/env python3
"""
Script de configuración del entorno para BibliaApp Pro Android
Instala todas las dependencias necesarias para compilar la aplicación
"""

import os
import sys
import subprocess
import platform
from pathlib import Path

class EnvironmentSetup:
    """Configurador del entorno de desarrollo Android"""
    
    def __init__(self):
        self.system = platform.system().lower()
        self.project_dir = Path(__file__).parent
        
        # Colores para output
        self.GREEN = '\033[92m'
        self.RED = '\033[91m'
        self.YELLOW = '\033[93m'
        self.BLUE = '\033[94m'
        self.ENDC = '\033[0m'
        self.BOLD = '\033[1m'
    
    def log(self, message, color=None):
        """Log con colores"""
        if color:
            print(f"{color}{message}{self.ENDC}")
        else:
            print(message)
    
    def log_success(self, message):
        """Log de éxito"""
        self.log(f"✅ {message}", self.GREEN)
    
    def log_error(self, message):
        """Log de error"""
        self.log(f"❌ {message}", self.RED)
    
    def log_warning(self, message):
        """Log de advertencia"""
        self.log(f"⚠️ {message}", self.YELLOW)
    
    def log_info(self, message):
        """Log de información"""
        self.log(f"ℹ️ {message}", self.BLUE)
    
    def check_python(self):
        """Verificar versión de Python"""
        self.log_info("Verificando Python...")
        
        version = sys.version_info
        if version.major >= 3 and version.minor >= 8:
            self.log_success(f"Python {version.major}.{version.minor}.{version.micro} OK")
            return True
        else:
            self.log_error(f"Python {version.major}.{version.minor}.{version.micro} - Se requiere Python 3.8+")
            return False
    
    def install_pip(self):
        """Instalar pip si no está disponible"""
        try:
            subprocess.run([sys.executable, '-m', 'pip', '--version'], 
                         capture_output=True, check=True)
            self.log_success("pip ya está instalado")
            return True
        except subprocess.CalledProcessError:
            self.log_info("Instalando pip...")
            try:
                # Descargar get-pip.py
                import urllib.request
                get_pip_url = "https://bootstrap.pypa.io/get-pip.py"
                get_pip_path = self.project_dir / "get-pip.py"
                
                urllib.request.urlretrieve(get_pip_url, get_pip_path)
                
                # Instalar pip
                subprocess.run([sys.executable, str(get_pip_path)], check=True)
                
                # Limpiar
                get_pip_path.unlink()
                
                self.log_success("pip instalado correctamente")
                return True
            except Exception as e:
                self.log_error(f"Error instalando pip: {e}")
                return False
    
    def install_system_dependencies(self):
        """Instalar dependencias del sistema"""
        self.log_info("Verificando dependencias del sistema...")
        
        if self.system == "linux":
            return self.install_linux_dependencies()
        elif self.system == "darwin":  # macOS
            return self.install_macos_dependencies()
        elif self.system == "windows":
            return self.install_windows_dependencies()
        else:
            self.log_warning(f"Sistema {self.system} no soportado oficialmente")
            return False
    
    def install_linux_dependencies(self):
        """Instalar dependencias en Linux"""
        self.log_info("Instalando dependencias de Linux...")
        
        dependencies = [
            "python3-dev",
            "python3-pip",
            "build-essential",
            "git",
            "zip",
            "unzip",
            "openjdk-11-jdk",
            "autoconf",
            "libtool",
            "pkg-config",
            "zlib1g-dev",
            "libncurses5-dev",
            "libncursesw5-dev",
            "libtinfo5",
            "cmake",
            "libffi-dev",
            "libssl-dev"
        ]
        
        try:
            # Actualizar repositorios
            subprocess.run(["sudo", "apt", "update"], check=True)
            
            # Instalar dependencias
            cmd = ["sudo", "apt", "install", "-y"] + dependencies
            subprocess.run(cmd, check=True)
            
            self.log_success("Dependencias de Linux instaladas")
            return True
        except subprocess.CalledProcessError as e:
            self.log_error(f"Error instalando dependencias de Linux: {e}")
            self.log_info("Intenta instalar manualmente:")
            self.log(f"sudo apt update && sudo apt install -y {' '.join(dependencies)}")
            return False
    
    def install_macos_dependencies(self):
        """Instalar dependencias en macOS"""
        self.log_info("Instalando dependencias de macOS...")
        
        # Verificar si Homebrew está instalado
        try:
            subprocess.run(["brew", "--version"], capture_output=True, check=True)
            self.log_success("Homebrew encontrado")
        except subprocess.CalledProcessError:
            self.log_error("Homebrew no encontrado")
            self.log_info("Instala Homebrew desde: https://brew.sh")
            return False
        
        dependencies = [
            "python3",
            "git",
            "cmake",
            "autoconf",
            "automake",
            "libtool",
            "pkg-config",
            "openjdk@11"
        ]
        
        try:
            for dep in dependencies:
                subprocess.run(["brew", "install", dep], check=True)
            
            self.log_success("Dependencias de macOS instaladas")
            return True
        except subprocess.CalledProcessError as e:
            self.log_error(f"Error instalando dependencias de macOS: {e}")
            return False
    
    def install_windows_dependencies(self):
        """Instalar dependencias en Windows"""
        self.log_info("Configurando entorno Windows...")
        
        self.log_warning("En Windows necesitas instalar manualmente:")
        print("1. Git for Windows: https://git-scm.com/download/win")
        print("2. Microsoft Visual C++ Build Tools")
        print("3. OpenJDK 11: https://adoptopenjdk.net/")
        print("4. Android Studio (opcional): https://developer.android.com/studio")
        
        return True
    
    def install_python_dependencies(self):
        """Instalar dependencias de Python"""
        self.log_info("Instalando dependencias de Python...")
        
        try:
            # Actualizar pip
            subprocess.run([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'], 
                         check=True)
            
            # Instalar buildozer y dependencias principales
            dependencies = [
                "buildozer",
                "cython",
                "kivy[base]>=2.1.0",
                "kivymd>=1.1.1",
                "pillow",
                "requests",
                "plyer",
                "pyjnius"
            ]
            
            for dep in dependencies:
                self.log_info(f"Instalando {dep}...")
                subprocess.run([sys.executable, '-m', 'pip', 'install', dep], 
                             check=True)
            
            self.log_success("Dependencias de Python instaladas")
            return True
            
        except subprocess.CalledProcessError as e:
            self.log_error(f"Error instalando dependencias de Python: {e}")
            return False
    
    def setup_android_sdk(self):
        """Configurar Android SDK"""
        self.log_info("Configurando Android SDK...")
        
        # Directorios comunes del SDK
        sdk_paths = [
            Path.home() / "Android" / "Sdk",
            Path("/opt/android-sdk"),
            Path("C:\\Android\\sdk") if self.system == "windows" else None
        ]
        
        sdk_path = None
        for path in sdk_paths:
            if path and path.exists():
                sdk_path = path
                break
        
        if sdk_path:
            self.log_success(f"Android SDK encontrado en: {sdk_path}")
            
            # Configurar variables de entorno
            os.environ['ANDROID_HOME'] = str(sdk_path)
            os.environ['ANDROID_SDK_ROOT'] = str(sdk_path)
            
            # Agregar al PATH
            platform_tools = sdk_path / "platform-tools"
            if platform_tools.exists():
                current_path = os.environ.get('PATH', '')
                if str(platform_tools) not in current_path:
                    os.environ['PATH'] = f"{platform_tools}{os.pathsep}{current_path}"
            
            return True
        else:
            self.log_warning("Android SDK no encontrado")
            self.log_info("Buildozer descargará automáticamente el SDK")
            return True
    
    def create_buildozer_init(self):
        """Inicializar buildozer en el proyecto"""
        self.log_info("Inicializando buildozer...")
        
        try:
            os.chdir(self.project_dir)
            
            # Verificar si ya existe buildozer.spec
            if (self.project_dir / "buildozer.spec").exists():
                self.log_success("buildozer.spec ya existe")
                return True
            
            # Inicializar buildozer
            subprocess.run(["buildozer", "init"], check=True)
            self.log_success("Buildozer inicializado")
            return True
            
        except subprocess.CalledProcessError as e:
            self.log_error(f"Error inicializando buildozer: {e}")
            return False
    
    def run_setup(self):
        """Ejecutar configuración completa"""
        self.log(f"{self.BOLD}🔧 Configuración del Entorno BibliaApp Pro{self.ENDC}")
        self.log(f"{self.BOLD}==========================================={self.ENDC}")
        print()
        
        steps = [
            ("Verificar Python", self.check_python),
            ("Instalar pip", self.install_pip),
            ("Instalar dependencias del sistema", self.install_system_dependencies),
            ("Instalar dependencias de Python", self.install_python_dependencies),
            ("Configurar Android SDK", self.setup_android_sdk),
            ("Inicializar buildozer", self.create_buildozer_init)
        ]
        
        failed_steps = []
        
        for step_name, step_func in steps:
            self.log_info(f"Ejecutando: {step_name}")
            try:
                if not step_func():
                    failed_steps.append(step_name)
            except Exception as e:
                self.log_error(f"Error en {step_name}: {e}")
                failed_steps.append(step_name)
            print()
        
        # Resumen
        if failed_steps:
            self.log_warning("Configuración completada con advertencias")
            self.log("Pasos que fallaron:")
            for step in failed_steps:
                print(f"  ❌ {step}")
        else:
            self.log_success("¡Configuración completada exitosamente!")
        
        print()
        self.log_info("Próximos pasos:")
        print("1. Ejecuta: python compile_android.py --type debug")
        print("2. O para release: python compile_android.py --type release")
        print("3. Para instalar automáticamente: python compile_android.py --install")
        
        return len(failed_steps) == 0

def main():
    """Función principal"""
    setup = EnvironmentSetup()
    success = setup.run_setup()
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
