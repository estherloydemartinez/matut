/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: ['class'],
	content: [
		'./pages/**/*.{ts,tsx}',
		'./components/**/*.{ts,tsx}',
		'./app/**/*.{ts,tsx}',
		'./src/**/*.{ts,tsx}',
	],
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px',
			},
		},
		extend: {
			colors: {
				// Existing shadcn colors
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: '#2B5D3A',
					foreground: 'hsl(var(--primary-foreground))',
				},
				secondary: {
					DEFAULT: '#4A90E2',
					foreground: 'hsl(var(--secondary-foreground))',
				},
				accent: {
					DEFAULT: '#F5A623',
					foreground: 'hsl(var(--accent-foreground))',
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))',
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))',
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))',
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))',
				},
				
				// Discord theme colors
				discord: {
					primary: 'var(--bg-primary)',
					secondary: 'var(--bg-secondary)',
					tertiary: 'var(--bg-tertiary)',
					quaternary: 'var(--bg-quaternary)',
					input: 'var(--bg-input)',
					
					text: {
						primary: 'var(--text-primary)',
						secondary: 'var(--text-secondary)',
						muted: 'var(--text-muted)',
						link: 'var(--text-link)',
						positive: 'var(--text-positive)',
						warning: 'var(--text-warning)',
						danger: 'var(--text-danger)',
					},
					
					interactive: {
						normal: 'var(--interactive-normal)',
						hover: 'var(--interactive-hover)',
						active: 'var(--interactive-active)',
						muted: 'var(--interactive-muted)',
					},
					
					modifier: {
						hover: 'var(--bg-modifier-hover)',
						active: 'var(--bg-modifier-active)',
						selected: 'var(--bg-modifier-selected)',
					}
				}
			},
			
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)',
				discord: '8px',
				'discord-sm': '4px',
				'discord-lg': '12px',
			},
			
			boxShadow: {
				'elevation-low': 'var(--shadow-elevation-low)',
				'elevation-medium': 'var(--shadow-elevation-medium)',
				'elevation-high': 'var(--shadow-elevation-high)',
				'discord': '0 2px 10px 0 rgba(0, 0, 0, 0.2)',
				'discord-lg': '0 8px 16px rgba(0, 0, 0, 0.24)',
			},
			
			backdropBlur: {
				'discord': '20px',
			},
			
			fontSize: {
				'discord-xs': '0.75rem',
				'discord-sm': '0.875rem',
				'discord-base': '1rem',
				'discord-lg': '1.125rem',
				'discord-xl': '1.25rem',
			},
			
			spacing: {
				'discord': '0.5rem',
				'discord-lg': '1rem',
				'discord-xl': '1.5rem',
			},
			
			transitionDuration: {
				'fast': '150ms',
				'medium': '250ms',
				'slow': '350ms',
			},
			
			transitionTimingFunction: {
				'discord': 'cubic-bezier(0.4, 0, 0.2, 1)',
			},
			
			backgroundImage: {
				'gradient-primary': 'var(--gradient-primary)',
				'gradient-secondary': 'var(--gradient-secondary)',
			},
			
			keyframes: {
				// Existing shadcn animations
				'accordion-down': {
					from: { height: 0 },
					to: { height: 'var(--radix-accordion-content-height)' },
				},
				'accordion-up': {
					from: { height: 'var(--radix-accordion-content-height)' },
					to: { height: 0 },
				},
				
				// Discord-style animations
				'slide-up': {
					from: { 
						transform: 'translateY(20px)',
						opacity: '0' 
					},
					to: { 
						transform: 'translateY(0)',
						opacity: '1' 
					},
				},
				'slide-down': {
					from: { 
						transform: 'translateY(-20px)',
						opacity: '0' 
					},
					to: { 
						transform: 'translateY(0)',
						opacity: '1' 
					},
				},
				'scale-in': {
					from: { 
						transform: 'scale(0.95)',
						opacity: '0' 
					},
					to: { 
						transform: 'scale(1)',
						opacity: '1' 
					},
				},
				'fade-in': {
					from: { opacity: '0' },
					to: { opacity: '1' },
				},
				'bounce-subtle': {
					'0%, 100%': { 
						transform: 'translateY(0)' 
					},
					'50%': { 
						transform: 'translateY(-2px)' 
					},
				},
				shimmer: {
					'0%': { 
						backgroundPosition: '-200px 0' 
					},
					'100%': { 
						backgroundPosition: 'calc(200px + 100%) 0' 
					},
				}
			},
			
			animation: {
				// Existing shadcn animations
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				
				// Discord-style animations
				'slide-up': 'slide-up 0.25s ease-out',
				'slide-down': 'slide-down 0.25s ease-out',
				'scale-in': 'scale-in 0.2s ease-out',
				'fade-in': 'fade-in 0.3s ease-out',
				'bounce-subtle': 'bounce-subtle 0.6s ease-in-out',
				'shimmer': 'shimmer 1.5s ease-in-out infinite',
			},
		},
	},
	plugins: [
		require('tailwindcss-animate'),
		function({ addUtilities }) {
			const newUtilities = {
				'.discord-card': {
					backgroundColor: 'var(--bg-secondary)',
					borderRadius: '8px',
					boxShadow: 'var(--shadow-elevation-low)',
					transition: 'all var(--transition-fast)',
				},
				'.discord-card-hover': {
					'&:hover': {
						backgroundColor: 'var(--bg-modifier-hover)',
						boxShadow: 'var(--shadow-elevation-medium)',
					}
				},
				'.discord-button': {
					backgroundColor: 'var(--bg-input)',
					color: 'var(--text-primary)',
					borderRadius: '4px',
					padding: '0.5rem 1rem',
					fontSize: '0.875rem',
					fontWeight: '500',
					transition: 'all var(--transition-fast)',
					border: 'none',
					cursor: 'pointer',
					'&:hover': {
						backgroundColor: 'var(--bg-modifier-hover)',
					},
					'&:active': {
						backgroundColor: 'var(--bg-modifier-active)',
					},
					'&:focus': {
						outline: '2px solid var(--bg-primary)',
						outlineOffset: '2px',
					}
				},
				'.discord-button-primary': {
					backgroundColor: 'var(--bg-primary)',
					color: 'var(--text-primary)',
					'&:hover': {
						backgroundColor: '#4752c4',
					}
				},
				'.discord-input': {
					backgroundColor: 'var(--bg-input)',
					color: 'var(--text-primary)',
					border: 'none',
					borderRadius: '4px',
					padding: '0.5rem 0.75rem',
					fontSize: '0.875rem',
					transition: 'all var(--transition-fast)',
					'&:focus': {
						outline: '2px solid var(--bg-primary)',
						outlineOffset: '2px',
					}
				},
				'.scrollbar-discord': {
					'&::-webkit-scrollbar': {
						width: '8px',
						height: '8px',
					},
					'&::-webkit-scrollbar-thumb': {
						backgroundColor: 'var(--scrollbar-thin-thumb)',
						borderRadius: '4px',
					},
					'&::-webkit-scrollbar-track': {
						backgroundColor: 'var(--scrollbar-thin-track)',
					}
				}
			}
			
			addUtilities(newUtilities)
		}
	],
}