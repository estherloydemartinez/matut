import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig, splitVendorChunkPlugin } from "vite"

export default defineConfig({
  plugins: [
    react(),
    // Plugin para dividir chunks de vendor
    splitVendorChunkPlugin()
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  // Optimizaciones de desarrollo
  server: {
    hmr: {
      overlay: false
    },
    // Preload de módulos críticos
    warmup: {
      clientFiles: [
        './src/App.tsx',
        './src/components/Navigation.tsx',
        './src/components/Header.tsx',
        './src/components/BibleContainer.tsx'
      ]
    }
  },
  // Optimizaciones de build
  build: {
    // Target para navegadores modernos
    target: 'esnext',
    // Tamaño mínimo de chunk
    rollupOptions: {
      output: {
        // Estrategia de chunking manual
        manualChunks: {
          // Vendor chunks
          'react-vendor': ['react', 'react-dom'],
          'ui-vendor': ['framer-motion', 'lucide-react'],
          'chart-vendor': ['recharts'],
          'utils-vendor': ['clsx', 'tailwind-merge', 'class-variance-authority'],
          
          // Feature chunks
          'bible-features': [
            './src/components/BibleContainer.tsx',
            './src/components/StudyContainer.tsx'
          ],
          'advanced-features': [
            './src/components/AdvancedFeaturesHub.tsx',
            './src/components/PersonalizedStudySystem.tsx',
            './src/components/AdvancedStudyTools.tsx',
            './src/components/GamificationSystem.tsx',
            './src/components/MetricsDashboard.tsx'
          ],
          'social-features': [
            './src/components/SocialContainer.tsx'
          ]
        },
        // Nombres de archivo optimizados
        chunkFileNames: (chunkInfo) => {
          const facadeModuleId = chunkInfo.facadeModuleId
          if (facadeModuleId) {
            return `chunks/[name]-[hash].js`
          }
          return `chunks/[name]-[hash].js`
        },
        entryFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash].[ext]'
      },
      // Optimizaciones de dependencias externas
      external: () => {
        // No externalizar nada para PWA
        return false
      }
    },
    // Configuración de minificación
    minify: false,
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ['console.log', 'console.info'],
        unused: true,
        dead_code: true
      },
      mangle: {
        safari10: true
      },
      format: {
        comments: false
      }
    },
    // Configuración de CSS
    cssCodeSplit: true,
    cssMinify: true,
    // Configuración de sourcemaps
    sourcemap: process.env.NODE_ENV === 'development',
    // Configuración de reportes
    reportCompressedSize: true,
    chunkSizeWarningLimit: 1000
  },
  // Optimizaciones de dependencias
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      'framer-motion',
      'lucide-react',
      'recharts',
      'react-hot-toast',
      'react-hotkeys-hook'
    ],
    exclude: ['@vite/client', '@vite/env']
  },
  // Preview server config
  preview: {
    port: 3000,
    strictPort: true
  },
  // Configuración de assets
  assetsInclude: ['**/*.woff', '**/*.woff2'],
  // Variables de entorno
  define: {
    __BUILD_TIME__: JSON.stringify(new Date().toISOString()),
    __VERSION__: JSON.stringify(process.env.npm_package_version || '1.0.0')
  }
})

