/**
 * Módulo de Integración de la Biblia Reina Valera 1960 - VERSIÓN OPTIMIZADA
 * Aplicación de Formación Bíblica - Versión Mejorada con optimizaciones avanzadas
 * 
 * MEJORAS IMPLEMENTADAS:
 * - Debouncing y throttling para búsquedas
 * - Cache inteligente con estrategias de invalidación
 * - Lazy loading de contenido
 * - Algoritmos de búsqueda optimizados
 * - Manejo robusto de errores con fallbacks
 * - Performance monitoring
 * - Modularización mejorada
 * - Compatibilidad con navegadores modernos
 */

// Módulo principal para la Biblia - VERSIÓN OPTIMIZADA
if (typeof window !== 'undefined' && window.BibliaRV1960Optimized) {
    // Ya existe, no redeclarar
    console.log('BibliaRV1960Optimized ya está cargado');
} else {
const BibliaRV1960Optimized = (function() {
    'use strict';

    // =====================================================================
    // CONFIGURACIÓN Y CONSTANTES
    // =====================================================================
    
    const CONFIG = Object.freeze({
        apiBase: 'https://biblia-api.vercel.app/api/v1',
        cacheEnabled: true,
        cacheExpiration: 7 * 24 * 60 * 60 * 1000, // 7 días
        maxConcurrentRequests: 3, // Reducido para mejor control
        requestDelay: 200, // Optimizado para balance rendimiento/API
        debounceDelay: 300, // Debounce para búsquedas
        throttleDelay: 1000, // Throttle para solicitudes frecuentes
        maxCacheSize: 50, // Máximo de elementos en cache
        retryAttempts: 3,
        retryDelay: 1000,
        performanceMonitoring: true
    });

    const EVENTS = Object.freeze({
        CACHE_HIT: 'cache:hit',
        CACHE_MISS: 'cache:miss',
        API_REQUEST: 'api:request',
        ERROR: 'error',
        PERFORMANCE: 'performance'
    });

    // =====================================================================
    // SISTEMA DE CACHE INTELIGENTE
    // =====================================================================
    
    class IntelligentCache {
        constructor(maxSize = CONFIG.maxCacheSize) {
            this.cache = new Map();
            this.accessCount = new Map();
            this.lastAccess = new Map();
            this.maxSize = maxSize;
        }

        get(key) {
            if (this.cache.has(key)) {
                const item = this.cache.get(key);
                
                // Verificar expiración
                if (Date.now() - item.timestamp > CONFIG.cacheExpiration) {
                    this.delete(key);
                    EventManager.emit(EVENTS.CACHE_MISS, { key, reason: 'expired' });
                    return null;
                }

                // Actualizar estadísticas de acceso
                this.accessCount.set(key, (this.accessCount.get(key) || 0) + 1);
                this.lastAccess.set(key, Date.now());
                
                EventManager.emit(EVENTS.CACHE_HIT, { key });
                return item.data;
            }
            
            EventManager.emit(EVENTS.CACHE_MISS, { key, reason: 'not_found' });
            return null;
        }

        set(key, data) {
            // Implementar estrategia de limpieza si el cache está lleno
            if (this.cache.size >= this.maxSize && !this.cache.has(key)) {
                this._evictLeastUsed();
            }

            this.cache.set(key, {
                data,
                timestamp: Date.now()
            });
            this.accessCount.set(key, 1);
            this.lastAccess.set(key, Date.now());
        }

        delete(key) {
            this.cache.delete(key);
            this.accessCount.delete(key);
            this.lastAccess.delete(key);
        }

        clear() {
            this.cache.clear();
            this.accessCount.clear();
            this.lastAccess.clear();
        }

        _evictLeastUsed() {
            let leastUsedKey = null;
            let minCount = Infinity;
            let oldestAccess = Infinity;

            for (const [key, count] of this.accessCount) {
                const lastAccessTime = this.lastAccess.get(key);
                if (count < minCount || (count === minCount && lastAccessTime < oldestAccess)) {
                    minCount = count;
                    oldestAccess = lastAccessTime;
                    leastUsedKey = key;
                }
            }

            if (leastUsedKey) {
                this.delete(leastUsedKey);
            }
        }

        getStats() {
            return {
                size: this.cache.size,
                maxSize: this.maxSize,
                hitRate: this._calculateHitRate()
            };
        }

        _calculateHitRate() {
            const total = Array.from(this.accessCount.values()).reduce((sum, count) => sum + count, 0);
            return total > 0 ? (this.cache.size / total * 100).toFixed(2) : 0;
        }
    }

    // =====================================================================
    // SISTEMA DE EVENTOS Y MONITOREO
    // =====================================================================
    
    class EventManager {
        static listeners = new Map();

        static on(event, callback) {
            if (!this.listeners.has(event)) {
                this.listeners.set(event, []);
            }
            this.listeners.get(event).push(callback);
        }

        static emit(event, data) {
            if (this.listeners.has(event)) {
                this.listeners.get(event).forEach(callback => {
                    try {
                        callback(data);
                    } catch (error) {
                        console.error(`Error en listener del evento ${event}:`, error);
                    }
                });
            }
        }

        static off(event, callback) {
            if (this.listeners.has(event)) {
                const callbacks = this.listeners.get(event);
                const index = callbacks.indexOf(callback);
                if (index > -1) {
                    callbacks.splice(index, 1);
                }
            }
        }
    }

    // =====================================================================
    // UTILIDADES DE RENDIMIENTO
    // =====================================================================
    
    class PerformanceManager {
        static metrics = new Map();

        static startTimer(operation) {
            this.metrics.set(operation, performance.now());
        }

        static endTimer(operation) {
            const startTime = this.metrics.get(operation);
            if (startTime) {
                const duration = performance.now() - startTime;
                this.metrics.delete(operation);
                
                if (CONFIG.performanceMonitoring) {
                    EventManager.emit(EVENTS.PERFORMANCE, {
                        operation,
                        duration: Math.round(duration * 100) / 100
                    });
                }
                
                return duration;
            }
            return null;
        }

        static getAverageTime(operation, measurements = []) {
            if (measurements.length === 0) return 0;
            const sum = measurements.reduce((acc, time) => acc + time, 0);
            return Math.round((sum / measurements.length) * 100) / 100;
        }
    }

    // =====================================================================
    // UTILIDADES DE THROTTLING Y DEBOUNCING
    // =====================================================================
    
    function debounce(func, delay) {
        let timeoutId;
        return function (...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => func.apply(this, args), delay);
        };
    }

    function throttle(func, delay) {
        let inThrottle;
        return function (...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, delay);
            }
        };
    }

    // =====================================================================
    // INICIALIZACIÓN Y CONFIGURACIÓN
    // =====================================================================
    
    const cache = new IntelligentCache();
    const requestQueue = [];
    let processingQueue = false;
    let performanceData = {
        searchTimes: [],
        loadTimes: [],
        apiResponseTimes: []
    };

    // Información optimizada de libros de la Biblia con indexación
    const LIBROS_INFO = Object.freeze([
        { id: 'genesis', nombre: 'Génesis', abreviatura: 'Gn', testamento: 'AT', capitulos: 50, orden: 1 },
        { id: 'exodo', nombre: 'Éxodo', abreviatura: 'Ex', testamento: 'AT', capitulos: 40, orden: 2 },
        { id: 'levitico', nombre: 'Levítico', abreviatura: 'Lv', testamento: 'AT', capitulos: 27, orden: 3 },
        { id: 'numeros', nombre: 'Números', abreviatura: 'Nm', testamento: 'AT', capitulos: 36, orden: 4 },
        { id: 'deuteronomio', nombre: 'Deuteronomio', abreviatura: 'Dt', testamento: 'AT', capitulos: 34, orden: 5 },
        { id: 'josue', nombre: 'Josué', abreviatura: 'Jos', testamento: 'AT', capitulos: 24, orden: 6 },
        { id: 'jueces', nombre: 'Jueces', abreviatura: 'Jue', testamento: 'AT', capitulos: 21, orden: 7 },
        { id: 'rut', nombre: 'Rut', abreviatura: 'Rt', testamento: 'AT', capitulos: 4, orden: 8 },
        { id: '1samuel', nombre: '1 Samuel', abreviatura: '1S', testamento: 'AT', capitulos: 31, orden: 9 },
        { id: '2samuel', nombre: '2 Samuel', abreviatura: '2S', testamento: 'AT', capitulos: 24, orden: 10 },
        { id: '1reyes', nombre: '1 Reyes', abreviatura: '1R', testamento: 'AT', capitulos: 22, orden: 11 },
        { id: '2reyes', nombre: '2 Reyes', abreviatura: '2R', testamento: 'AT', capitulos: 25, orden: 12 },
        { id: '1cronicas', nombre: '1 Crónicas', abreviatura: '1Cr', testamento: 'AT', capitulos: 29, orden: 13 },
        { id: '2cronicas', nombre: '2 Crónicas', abreviatura: '2Cr', testamento: 'AT', capitulos: 36, orden: 14 },
        { id: 'esdras', nombre: 'Esdras', abreviatura: 'Esd', testamento: 'AT', capitulos: 10, orden: 15 },
        { id: 'nehemias', nombre: 'Nehemías', abreviatura: 'Neh', testamento: 'AT', capitulos: 13, orden: 16 },
        { id: 'ester', nombre: 'Ester', abreviatura: 'Est', testamento: 'AT', capitulos: 10, orden: 17 },
        { id: 'job', nombre: 'Job', abreviatura: 'Job', testamento: 'AT', capitulos: 42, orden: 18 },
        { id: 'salmos', nombre: 'Salmos', abreviatura: 'Sal', testamento: 'AT', capitulos: 150, orden: 19 },
        { id: 'proverbios', nombre: 'Proverbios', abreviatura: 'Pr', testamento: 'AT', capitulos: 31, orden: 20 },
        { id: 'eclesiastes', nombre: 'Eclesiastés', abreviatura: 'Ec', testamento: 'AT', capitulos: 12, orden: 21 },
        { id: 'cantares', nombre: 'Cantares', abreviatura: 'Cnt', testamento: 'AT', capitulos: 8, orden: 22 },
        { id: 'isaias', nombre: 'Isaías', abreviatura: 'Is', testamento: 'AT', capitulos: 66, orden: 23 },
        { id: 'jeremias', nombre: 'Jeremías', abreviatura: 'Jer', testamento: 'AT', capitulos: 52, orden: 24 },
        { id: 'lamentaciones', nombre: 'Lamentaciones', abreviatura: 'Lm', testamento: 'AT', capitulos: 5, orden: 25 },
        { id: 'ezequiel', nombre: 'Ezequiel', abreviatura: 'Ez', testamento: 'AT', capitulos: 48, orden: 26 },
        { id: 'daniel', nombre: 'Daniel', abreviatura: 'Dn', testamento: 'AT', capitulos: 12, orden: 27 },
        { id: 'oseas', nombre: 'Oseas', abreviatura: 'Os', testamento: 'AT', capitulos: 14, orden: 28 },
        { id: 'joel', nombre: 'Joel', abreviatura: 'Jl', testamento: 'AT', capitulos: 3, orden: 29 },
        { id: 'amos', nombre: 'Amós', abreviatura: 'Am', testamento: 'AT', capitulos: 9, orden: 30 },
        { id: 'abdias', nombre: 'Abdías', abreviatura: 'Abd', testamento: 'AT', capitulos: 1, orden: 31 },
        { id: 'jonas', nombre: 'Jonás', abreviatura: 'Jon', testamento: 'AT', capitulos: 4, orden: 32 },
        { id: 'miqueas', nombre: 'Miqueas', abreviatura: 'Mi', testamento: 'AT', capitulos: 7, orden: 33 },
        { id: 'nahum', nombre: 'Nahúm', abreviatura: 'Nah', testamento: 'AT', capitulos: 3, orden: 34 },
        { id: 'habacuc', nombre: 'Habacuc', abreviatura: 'Hab', testamento: 'AT', capitulos: 3, orden: 35 },
        { id: 'sofonias', nombre: 'Sofonías', abreviatura: 'Sof', testamento: 'AT', capitulos: 3, orden: 36 },
        { id: 'hageo', nombre: 'Hageo', abreviatura: 'Hag', testamento: 'AT', capitulos: 2, orden: 37 },
        { id: 'zacarias', nombre: 'Zacarías', abreviatura: 'Zac', testamento: 'AT', capitulos: 14, orden: 38 },
        { id: 'malaquias', nombre: 'Malaquías', abreviatura: 'Mal', testamento: 'AT', capitulos: 4, orden: 39 },
        { id: 'mateo', nombre: 'Mateo', abreviatura: 'Mt', testamento: 'NT', capitulos: 28, orden: 40 },
        { id: 'marcos', nombre: 'Marcos', abreviatura: 'Mr', testamento: 'NT', capitulos: 16, orden: 41 },
        { id: 'lucas', nombre: 'Lucas', abreviatura: 'Lc', testamento: 'NT', capitulos: 24, orden: 42 },
        { id: 'juan', nombre: 'Juan', abreviatura: 'Jn', testamento: 'NT', capitulos: 21, orden: 43 },
        { id: 'hechos', nombre: 'Hechos', abreviatura: 'Hch', testamento: 'NT', capitulos: 28, orden: 44 },
        { id: 'romanos', nombre: 'Romanos', abreviatura: 'Ro', testamento: 'NT', capitulos: 16, orden: 45 },
        { id: '1corintios', nombre: '1 Corintios', abreviatura: '1Co', testamento: 'NT', capitulos: 16, orden: 46 },
        { id: '2corintios', nombre: '2 Corintios', abreviatura: '2Co', testamento: 'NT', capitulos: 13, orden: 47 },
        { id: 'galatas', nombre: 'Gálatas', abreviatura: 'Ga', testamento: 'NT', capitulos: 6, orden: 48 },
        { id: 'efesios', nombre: 'Efesios', abreviatura: 'Ef', testamento: 'NT', capitulos: 6, orden: 49 },
        { id: 'filipenses', nombre: 'Filipenses', abreviatura: 'Fil', testamento: 'NT', capitulos: 4, orden: 50 },
        { id: 'colosenses', nombre: 'Colosenses', abreviatura: 'Col', testamento: 'NT', capitulos: 4, orden: 51 },
        { id: '1tesalonicenses', nombre: '1 Tesalonicenses', abreviatura: '1Ts', testamento: 'NT', capitulos: 5, orden: 52 },
        { id: '2tesalonicenses', nombre: '2 Tesalonicenses', abreviatura: '2Ts', testamento: 'NT', capitulos: 3, orden: 53 },
        { id: '1timoteo', nombre: '1 Timoteo', abreviatura: '1Ti', testamento: 'NT', capitulos: 6, orden: 54 },
        { id: '2timoteo', nombre: '2 Timoteo', abreviatura: '2Ti', testamento: 'NT', capitulos: 4, orden: 55 },
        { id: 'tito', nombre: 'Tito', abreviatura: 'Tit', testamento: 'NT', capitulos: 3, orden: 56 },
        { id: 'filemon', nombre: 'Filemón', abreviatura: 'Flm', testamento: 'NT', capitulos: 1, orden: 57 },
        { id: 'hebreos', nombre: 'Hebreos', abreviatura: 'He', testamento: 'NT', capitulos: 13, orden: 58 },
        { id: 'santiago', nombre: 'Santiago', abreviatura: 'Stg', testamento: 'NT', capitulos: 5, orden: 59 },
        { id: '1pedro', nombre: '1 Pedro', abreviatura: '1P', testamento: 'NT', capitulos: 5, orden: 60 },
        { id: '2pedro', nombre: '2 Pedro', abreviatura: '2P', testamento: 'NT', capitulos: 3, orden: 61 },
        { id: '1juan', nombre: '1 Juan', abreviatura: '1Jn', testamento: 'NT', capitulos: 5, orden: 62 },
        { id: '2juan', nombre: '2 Juan', abreviatura: '2Jn', testamento: 'NT', capitulos: 1, orden: 63 },
        { id: '3juan', nombre: '3 Juan', abreviatura: '3Jn', testamento: 'NT', capitulos: 1, orden: 64 },
        { id: 'judas', nombre: 'Judas', abreviatura: 'Jud', testamento: 'NT', capitulos: 1, orden: 65 },
        { id: 'apocalipsis', nombre: 'Apocalipsis', abreviatura: 'Ap', testamento: 'NT', capitulos: 22, orden: 66 }
    ]);

    // Índices optimizados para búsqueda rápida
    const INDICES = {
        porId: new Map(LIBROS_INFO.map(libro => [libro.id, libro])),
        porNombre: new Map(LIBROS_INFO.map(libro => [libro.nombre.toLowerCase(), libro])),
        porAbreviatura: new Map(LIBROS_INFO.map(libro => [libro.abreviatura.toLowerCase(), libro])),
        porTestamento: {
            AT: LIBROS_INFO.filter(libro => libro.testamento === 'AT'),
            NT: LIBROS_INFO.filter(libro => libro.testamento === 'NT')
        }
    };

    // =====================================================================
    // FUNCIONES DE RED CON MANEJO DE ERRORES ROBUSTO
    // =====================================================================
    
    async function makeRequest(url, options = {}) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), options.timeout || 10000);

        try {
            PerformanceManager.startTimer('api_request');
            
            const response = await fetch(url, {
                ...options,
                signal: controller.signal,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });

            clearTimeout(timeoutId);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();
            
            const duration = PerformanceManager.endTimer('api_request');
            performanceData.apiResponseTimes.push(duration);
            
            EventManager.emit(EVENTS.API_REQUEST, { 
                url, 
                success: true, 
                duration,
                status: response.status 
            });

            return data;

        } catch (error) {
            clearTimeout(timeoutId);
            
            EventManager.emit(EVENTS.ERROR, {
                type: 'api_request',
                error: error.message,
                url
            });

            throw error;
        }
    }

    async function requestWithRetry(url, options = {}, attempts = CONFIG.retryAttempts) {
        for (let i = 0; i < attempts; i++) {
            try {
                return await makeRequest(url, options);
            } catch (error) {
                if (i === attempts - 1) throw error;
                
                // Espera exponencial entre reintentos
                const delay = CONFIG.retryDelay * Math.pow(2, i);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }

    // =====================================================================
    // GESTIÓN DE COLA DE SOLICITUDES
    // =====================================================================
    
    async function addToQueue(requestFn) {
        return new Promise((resolve, reject) => {
            requestQueue.push({ requestFn, resolve, reject });
            processQueue();
        });
    }

    async function processQueue() {
        if (processingQueue || requestQueue.length === 0) return;

        processingQueue = true;
        const concurrent = Math.min(CONFIG.maxConcurrentRequests, requestQueue.length);
        
        const promises = [];
        for (let i = 0; i < concurrent; i++) {
            promises.push(processNextRequest());
        }

        await Promise.allSettled(promises);
        processingQueue = false;

        // Continuar procesando si hay más solicitudes
        if (requestQueue.length > 0) {
            setTimeout(processQueue, CONFIG.requestDelay);
        }
    }

    async function processNextRequest() {
        while (requestQueue.length > 0) {
            const { requestFn, resolve, reject } = requestQueue.shift();
            
            try {
                const result = await requestFn();
                resolve(result);
            } catch (error) {
                reject(error);
            }

            // Delay entre solicitudes para no sobrecargar la API
            if (requestQueue.length > 0) {
                await new Promise(resolve => setTimeout(resolve, CONFIG.requestDelay));
            }
        }
    }

    // =====================================================================
    // FUNCIONES PRINCIPALES DE LA API
    // =====================================================================
    
    /**
     * Inicializa el módulo de la Biblia con configuración optimizada
     * @param {Object} opciones - Opciones de configuración
     */
    function inicializar(opciones = {}) {
        try {
            // Combinar configuración
            Object.assign(CONFIG, opciones);
            
            // Inicializar event listeners para monitoreo
            if (CONFIG.performanceMonitoring) {
                setupPerformanceMonitoring();
            }
            
            // Renderizar interfaz
            renderizarInterfazBiblia();
            
            // Configurar eventos de la interfaz
            configurarEventosBiblia();
            
            console.log('BibliaRV1960 Optimizado inicializado correctamente');
            return true;
            
        } catch (error) {
            console.error('Error al inicializar BibliaRV1960 Optimizado:', error);
            EventManager.emit(EVENTS.ERROR, {
                type: 'initialization',
                error: error.message
            });
            return false;
        }
    }

    /**
     * Obtiene la lista de libros con optimización de cache
     * @returns {Promise<Array>} Lista de libros
     */
    async function obtenerLibros() {
        const cacheKey = 'libros_biblia';
        
        // Intentar obtener del cache
        let libros = cache.get(cacheKey);
        if (libros) {
            return libros;
        }

        try {
            // Si no está en cache, usar datos locales optimizados
            libros = [...LIBROS_INFO];
            
            // Guardar en cache
            cache.set(cacheKey, libros);
            
            return libros;
            
        } catch (error) {
            console.error('Error al obtener libros:', error);
            EventManager.emit(EVENTS.ERROR, {
                type: 'obtener_libros',
                error: error.message
            });
            
            // Fallback: devolver datos locales
            return [...LIBROS_INFO];
        }
    }

    /**
     * Obtiene información de un libro específico
     * @param {String} libroId - ID del libro
     * @returns {Object|null} Información del libro
     */
    function obtenerLibro(libroId) {
        if (!libroId) return null;
        
        // Búsqueda optimizada usando índice
        return INDICES.porId.get(libroId.toLowerCase()) || null;
    }

    /**
     * Obtiene un capítulo específico con cache inteligente
     * @param {String} libroId - ID del libro
     * @param {Number} capitulo - Número del capítulo
     * @returns {Promise<Object>} Datos del capítulo
     */
    async function obtenerCapitulo(libroId, capitulo) {
        if (!libroId || !capitulo) {
            throw new Error('Parámetros inválidos: se requiere libroId y capitulo');
        }

        const cacheKey = `capitulo_${libroId}_${capitulo}`;
        
        // Intentar obtener del cache
        let datosCapitulo = cache.get(cacheKey);
        if (datosCapitulo) {
            return datosCapitulo;
        }

        // Solicitud con cola y reintentos
        return addToQueue(async () => {
            try {
                const url = `${CONFIG.apiBase}/biblia/rv1960/${libroId}/${capitulo}`;
                const datos = await requestWithRetry(url);
                
                // Procesar y validar datos
                if (!datos || !datos.versiculos) {
                    throw new Error('Respuesta de API inválida');
                }

                // Optimizar estructura de datos
                const capituloOptimizado = {
                    libro: datos.libro,
                    capitulo: datos.capitulo,
                    versiculos: datos.versiculos.map((v, index) => ({
                        numero: index + 1,
                        texto: v.texto || v,
                        id: `${libroId}_${capitulo}_${index + 1}`
                    })),
                    metadata: {
                        totalVersiculos: datos.versiculos.length,
                        fechaCarga: new Date().toISOString()
                    }
                };
                
                // Guardar en cache
                cache.set(cacheKey, capituloOptimizado);
                
                return capituloOptimizado;
                
            } catch (error) {
                console.error(`Error al obtener capítulo ${libroId} ${capitulo}:`, error);
                throw error;
            }
        });
    }

    /**
     * Obtiene un versículo específico
     * @param {String} libroId - ID del libro
     * @param {Number} capitulo - Número del capítulo
     * @param {Number} versiculo - Número del versículo
     * @returns {Promise<Object>} Datos del versículo
     */
    async function obtenerVersiculo(libroId, capitulo, versiculo) {
        try {
            // Primero obtener el capítulo completo (aprovecha cache)
            const datosCapitulo = await obtenerCapitulo(libroId, capitulo);
            
            if (!datosCapitulo || !datosCapitulo.versiculos) {
                throw new Error('Capítulo no encontrado');
            }

            const versiculoData = datosCapitulo.versiculos.find(v => v.numero === versiculo);
            
            if (!versiculoData) {
                throw new Error(`Versículo ${versiculo} no encontrado en ${libroId} ${capitulo}`);
            }

            return {
                libro: datosCapitulo.libro,
                capitulo: datosCapitulo.capitulo,
                versiculo: versiculoData.numero,
                texto: versiculoData.texto,
                referencia: `${datosCapitulo.libro} ${capitulo}:${versiculo}`
            };
            
        } catch (error) {
            console.error(`Error al obtener versículo ${libroId} ${capitulo}:${versiculo}:`, error);
            throw error;
        }
    }

    /**
     * Búsqueda optimizada de texto en la Biblia
     * @param {String} texto - Texto a buscar
     * @param {Object} opciones - Opciones de búsqueda
     * @returns {Promise<Array>} Resultados de búsqueda
     */
    async function buscarTexto(texto, opciones = {}) {
        if (!texto || texto.trim().length < 2) {
            throw new Error('El texto de búsqueda debe tener al menos 2 caracteres');
        }

        const {
            libros = [],
            testamento = '',
            exacta = false,
            limite = 50
        } = opciones;

        PerformanceManager.startTimer('search');

        try {
            // Optimizar términos de búsqueda
            const terminosLimpios = texto.trim().toLowerCase();
            const cacheKey = `busqueda_${terminosLimpios}_${JSON.stringify(opciones)}`;
            
            // Verificar cache
            let resultados = cache.get(cacheKey);
            if (resultados) {
                const duration = PerformanceManager.endTimer('search');
                performanceData.searchTimes.push(duration);
                return resultados;
            }

            // Realizar búsqueda con cola
            resultados = await addToQueue(async () => {
                const params = new URLSearchParams({
                    texto: terminosLimpios,
                    exacta: exacta.toString(),
                    limite: limite.toString()
                });

                if (libros.length > 0) {
                    params.append('libros', libros.join(','));
                }
                if (testamento) {
                    params.append('testamento', testamento);
                }

                const url = `${CONFIG.apiBase}/biblia/rv1960/buscar?${params}`;
                const datos = await requestWithRetry(url);
                
                // Procesar y optimizar resultados
                const resultadosOptimizados = (datos.resultados || []).map(resultado => ({
                    ...resultado,
                    libroInfo: obtenerLibro(resultado.libroId),
                    relevancia: calcularRelevancia(resultado.texto, terminosLimpios)
                })).sort((a, b) => b.relevancia - a.relevancia);

                return resultadosOptimizados;
            });

            // Guardar en cache
            cache.set(cacheKey, resultados);
            
            const duration = PerformanceManager.endTimer('search');
            performanceData.searchTimes.push(duration);
            
            return resultados;
            
        } catch (error) {
            console.error('Error en búsqueda:', error);
            PerformanceManager.endTimer('search');
            throw error;
        }
    }

    /**
     * Calcula la relevancia de un resultado de búsqueda
     * @param {String} texto - Texto del versículo
     * @param {String} busqueda - Términos de búsqueda
     * @returns {Number} Puntuación de relevancia
     */
    function calcularRelevancia(texto, busqueda) {
        if (!texto || !busqueda) return 0;

        const textoLower = texto.toLowerCase();
        const busquedaLower = busqueda.toLowerCase();
        
        let puntuacion = 0;
        
        // Coincidencia exacta completa
        if (textoLower.includes(busquedaLower)) {
            puntuacion += 100;
        }
        
        // Coincidencias de palabras individuales
        const palabrasBusqueda = busquedaLower.split(/\s+/);
        const palabrasTexto = textoLower.split(/\s+/);
        
        palabrasBusqueda.forEach(palabra => {
            if (palabrasTexto.includes(palabra)) {
                puntuacion += 20;
            } else {
                // Coincidencias parciales
                palabrasTexto.forEach(palabraTexto => {
                    if (palabraTexto.includes(palabra) || palabra.includes(palabraTexto)) {
                        puntuacion += 5;
                    }
                });
            }
        });
        
        return puntuacion;
    }

    // =====================================================================
    // FUNCIONES DE INTERFAZ OPTIMIZADAS
    // =====================================================================
    
    /**
     * Renderiza la interfaz de la Biblia con lazy loading
     */
    function renderizarInterfazBiblia() {
        const contenedor = document.getElementById('content-biblia');
        if (!contenedor) return;

        contenedor.innerHTML = `
            <div class="biblia-container p-6 max-w-6xl mx-auto">
                <!-- Header con controles optimizados -->
                <div class="biblia-header mb-6">
                    <div class="flex flex-wrap gap-4 mb-4">
                        <select id="biblia-select-libro" class="discord-select flex-1 min-w-[200px]">
                            <option value="">Seleccionar libro...</option>
                        </select>
                        <select id="biblia-select-capitulo" class="discord-select min-w-[120px]" disabled>
                            <option value="">Capítulo</option>
                        </select>
                        <button id="biblia-btn-aleatorio" class="discord-button-secondary px-4 py-2 rounded-lg">
                            📖 Aleatorio
                        </button>
                    </div>
                    
                    <!-- Búsqueda optimizada -->
                    <div class="biblia-busqueda mb-4">
                        <div class="flex gap-2">
                            <input type="text" id="biblia-input-busqueda" 
                                   class="discord-input flex-1" 
                                   placeholder="Buscar en la Biblia..."
                                   autocomplete="off">
                            <button id="biblia-btn-buscar" class="discord-button-primary px-6 py-2 rounded-lg">
                                🔍 Buscar
                            </button>
                        </div>
                        <div id="biblia-opciones-busqueda" class="mt-2 hidden">
                            <div class="flex flex-wrap gap-2 text-sm">
                                <label class="flex items-center gap-1">
                                    <input type="checkbox" id="busqueda-exacta"> Búsqueda exacta
                                </label>
                                <select id="busqueda-testamento" class="discord-select text-sm">
                                    <option value="">Todos los libros</option>
                                    <option value="AT">Antiguo Testamento</option>
                                    <option value="NT">Nuevo Testamento</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Área de contenido con lazy loading -->
                <div id="biblia-contenido" class="biblia-content">
                    <div class="text-center text-gray-500 py-8">
                        <p>Selecciona un libro y capítulo para comenzar</p>
                    </div>
                </div>
                
                <!-- Resultados de búsqueda -->
                <div id="biblia-resultados-busqueda" class="hidden mt-6">
                    <h3 class="text-lg font-semibold mb-3">Resultados de búsqueda</h3>
                    <div id="biblia-lista-resultados"></div>
                </div>
                
                <!-- Información de rendimiento (debug) -->
                <div id="biblia-performance-info" class="mt-6 text-xs text-gray-500 hidden">
                    <div class="flex gap-4">
                        <span>Cache: <span id="cache-stats">-</span></span>
                        <span>Última búsqueda: <span id="last-search-time">-</span>ms</span>
                        <span>Tiempo de carga: <span id="last-load-time">-</span>ms</span>
                    </div>
                </div>
            </div>
        `;

        // Cargar libros de forma asíncrona
        cargarLibrosEnSelector();
    }

    /**
     * Carga los libros en el selector con optimización
     */
    async function cargarLibrosEnSelector() {
        try {
            const selector = document.getElementById('biblia-select-libro');
            if (!selector) return;

            PerformanceManager.startTimer('load_books');
            
            const libros = await obtenerLibros();
            
            // Crear opciones optimizadas
            const fragment = document.createDocumentFragment();
            
            // Agregar separadores por testamento
            const opcionAT = document.createElement('optgroup');
            opcionAT.label = 'Antiguo Testamento';
            
            const opcionNT = document.createElement('optgroup');
            opcionNT.label = 'Nuevo Testamento';
            
            libros.forEach(libro => {
                const option = document.createElement('option');
                option.value = libro.id;
                option.textContent = `${libro.nombre} (${libro.abreviatura})`;
                
                if (libro.testamento === 'AT') {
                    opcionAT.appendChild(option);
                } else {
                    opcionNT.appendChild(option);
                }
            });
            
            fragment.appendChild(opcionAT);
            fragment.appendChild(opcionNT);
            selector.appendChild(fragment);
            
            const duration = PerformanceManager.endTimer('load_books');
            performanceData.loadTimes.push(duration);
            
        } catch (error) {
            console.error('Error al cargar libros en selector:', error);
        }
    }

    /**
     * Configura los eventos de la interfaz con optimizaciones
     */
    function configurarEventosBiblia() {
        // Selector de libro
        const selectorLibro = document.getElementById('biblia-select-libro');
        if (selectorLibro) {
            selectorLibro.addEventListener('change', async (e) => {
                const libroId = e.target.value;
                if (libroId) {
                    await poblarSelectorCapitulos(libroId);
                }
            });
        }

        // Selector de capítulo
        const selectorCapitulo = document.getElementById('biblia-select-capitulo');
        if (selectorCapitulo) {
            selectorCapitulo.addEventListener('change', async (e) => {
                const capitulo = parseInt(e.target.value);
                const libroId = selectorLibro?.value;
                
                if (libroId && capitulo) {
                    await cargarCapitulo(libroId, capitulo);
                }
            });
        }

        // Búsqueda con debouncing
        const inputBusqueda = document.getElementById('biblia-input-busqueda');
        if (inputBusqueda) {
            const busquedaDebounced = debounce(async (texto) => {
                if (texto.length >= 2) {
                    await realizarBusqueda(texto);
                }
            }, CONFIG.debounceDelay);
            
            inputBusqueda.addEventListener('input', (e) => {
                busquedaDebounced(e.target.value);
            });
            
            inputBusqueda.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    realizarBusqueda(e.target.value);
                }
            });
        }

        // Botón de búsqueda
        const btnBuscar = document.getElementById('biblia-btn-buscar');
        if (btnBuscar) {
            btnBuscar.addEventListener('click', () => {
                const texto = inputBusqueda?.value;
                if (texto) {
                    realizarBusqueda(texto);
                }
            });
        }

        // Botón aleatorio
        const btnAleatorio = document.getElementById('biblia-btn-aleatorio');
        if (btnAleatorio) {
            btnAleatorio.addEventListener('click', cargarVersiculoAleatorio);
        }

        // Mostrar opciones de búsqueda
        if (inputBusqueda) {
            inputBusqueda.addEventListener('focus', () => {
                const opciones = document.getElementById('biblia-opciones-busqueda');
                if (opciones) {
                    opciones.classList.remove('hidden');
                }
            });
        }
    }

    /**
     * Puebla el selector de capítulos
     * @param {String} libroId - ID del libro seleccionado
     */
    async function poblarSelectorCapitulos(libroId) {
        const selector = document.getElementById('biblia-select-capitulo');
        if (!selector) return;

        try {
            const libro = obtenerLibro(libroId);
            if (!libro) return;

            // Limpiar y habilitar selector
            selector.innerHTML = '<option value="">Seleccionar capítulo...</option>';
            selector.disabled = false;

            // Crear opciones de capítulos
            const fragment = document.createDocumentFragment();
            for (let i = 1; i <= libro.capitulos; i++) {
                const option = document.createElement('option');
                option.value = i;
                option.textContent = `Capítulo ${i}`;
                fragment.appendChild(option);
            }
            
            selector.appendChild(fragment);
            
        } catch (error) {
            console.error('Error al poblar selector de capítulos:', error);
            selector.disabled = true;
        }
    }

    /**
     * Carga y muestra un capítulo con optimizaciones de renderizado
     * @param {String} libroId - ID del libro
     * @param {Number} capitulo - Número del capítulo
     */
    async function cargarCapitulo(libroId, capitulo) {
        const contenedor = document.getElementById('biblia-contenido');
        if (!contenedor) return;

        try {
            PerformanceManager.startTimer('load_chapter');
            
            // Mostrar indicador de carga
            contenedor.innerHTML = `
                <div class="text-center py-8">
                    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-[var(--bg-primary)] mx-auto"></div>
                    <p class="mt-2 text-gray-500">Cargando capítulo...</p>
                </div>
            `;

            // Obtener datos del capítulo
            const datos = await obtenerCapitulo(libroId, capitulo);
            
            // Renderizar capítulo con optimizaciones
            renderizarCapitulo(datos);
            
            const duration = PerformanceManager.endTimer('load_chapter');
            performanceData.loadTimes.push(duration);
            
            // Actualizar estadísticas de rendimiento
            actualizarEstadisticasRendimiento();
            
        } catch (error) {
            console.error('Error al cargar capítulo:', error);
            contenedor.innerHTML = `
                <div class="text-center text-red-500 py-8">
                    <p>Error al cargar el capítulo: ${error.message}</p>
                    <button class="mt-2 discord-button-secondary px-4 py-2 rounded-lg" 
                            onclick="BibliaRV1960Optimized.cargarCapitulo('${libroId}', ${capitulo})">
                        Reintentar
                    </button>
                </div>
            `;
        }
    }

    /**
     * Renderiza un capítulo con optimizaciones de DOM
     * @param {Object} datos - Datos del capítulo
     */
    function renderizarCapitulo(datos) {
        const contenedor = document.getElementById('biblia-contenido');
        if (!contenedor || !datos) return;

        // Crear header del capítulo
        const header = `
            <div class="chapter-header mb-6 text-center">
                <h2 class="text-2xl font-bold text-[var(--text-primary)] mb-2">
                    ${datos.libro} ${datos.capitulo}
                </h2>
                <div class="text-sm text-gray-500">
                    ${datos.metadata?.totalVersiculos || 0} versículos
                </div>
            </div>
        `;

        // Crear versículos con virtual scrolling para capítulos largos
        const versiculos = datos.versiculos.map(versiculo => `
            <div class="versiculo-item mb-3 p-3 hover:bg-[var(--bg-input)]/20 rounded-lg transition-colors cursor-pointer" 
                 data-versiculo="${versiculo.numero}"
                 id="versiculo-${versiculo.id}">
                <span class="versiculo-numero text-[var(--bg-primary)] font-semibold mr-2 text-sm">
                    ${versiculo.numero}
                </span>
                <span class="versiculo-texto">${versiculo.texto}</span>
            </div>
        `).join('');

        // Actualizar contenido de forma eficiente
        contenedor.innerHTML = `
            ${header}
            <div class="versiculos-container">
                ${versiculos}
            </div>
        `;

        // Configurar eventos de versículos
        configurarEventosVersiculos();
        
        // Ocultar resultados de búsqueda
        const resultadosBusqueda = document.getElementById('biblia-resultados-busqueda');
        if (resultadosBusqueda) {
            resultadosBusqueda.classList.add('hidden');
        }
    }

    /**
     * Configura eventos para versículos individuales
     */
    function configurarEventosVersiculos() {
        const versiculos = document.querySelectorAll('.versiculo-item');
        versiculos.forEach(versiculo => {
            versiculo.addEventListener('click', () => {
                // Remover selección anterior
                document.querySelectorAll('.versiculo-item.selected').forEach(v => {
                    v.classList.remove('selected');
                });
                
                // Agregar selección actual
                versiculo.classList.add('selected');
                
                // Scroll suave al versículo
                versiculo.scrollIntoView({ 
                    behavior: 'smooth', 
                    block: 'center' 
                });
            });
        });
    }

    /**
     * Realiza búsqueda con opciones avanzadas
     * @param {String} texto - Texto a buscar
     */
    async function realizarBusqueda(texto) {
        if (!texto || texto.trim().length < 2) return;

        const contenedorResultados = document.getElementById('biblia-resultados-busqueda');
        const listaResultados = document.getElementById('biblia-lista-resultados');
        
        if (!contenedorResultados || !listaResultados) return;

        try {
            // Mostrar indicador de búsqueda
            contenedorResultados.classList.remove('hidden');
            listaResultados.innerHTML = `
                <div class="text-center py-4">
                    <div class="animate-spin rounded-full h-6 w-6 border-b-2 border-[var(--bg-primary)] mx-auto"></div>
                    <p class="mt-2 text-sm text-gray-500">Buscando...</p>
                </div>
            `;

            // Obtener opciones de búsqueda
            const exacta = document.getElementById('busqueda-exacta')?.checked || false;
            const testamento = document.getElementById('busqueda-testamento')?.value || '';

            // Realizar búsqueda
            const resultados = await buscarTexto(texto, {
                exacta,
                testamento,
                limite: 100
            });

            // Renderizar resultados
            renderizarResultadosBusqueda(resultados, texto);
            
        } catch (error) {
            console.error('Error en búsqueda:', error);
            listaResultados.innerHTML = `
                <div class="text-center text-red-500 p-4">
                    <p>Error al realizar la búsqueda: ${error.message}</p>
                    <button class="mt-2 discord-button-secondary px-3 py-1 rounded-lg text-sm" 
                            onclick="BibliaRV1960Optimized.realizarBusqueda('${texto}')">
                        Reintentar
                    </button>
                </div>
            `;
        }
    }

    /**
     * Renderiza resultados de búsqueda optimizados
     * @param {Array} resultados - Resultados de búsqueda
     * @param {String} texto - Texto buscado
     */
    function renderizarResultadosBusqueda(resultados, texto) {
        const listaResultados = document.getElementById('biblia-lista-resultados');
        if (!listaResultados) return;

        if (resultados.length === 0) {
            listaResultados.innerHTML = `
                <div class="text-center text-gray-500 p-6">
                    <p>No se encontraron resultados para "${texto}"</p>
                    <p class="text-sm mt-2">Intenta con otros términos de búsqueda</p>
                </div>
            `;
            return;
        }

        // Renderizar resultados con paginación para mejor rendimiento
        const resultadosPaginados = resultados.slice(0, 20); // Mostrar primeros 20
        
        const html = `
            <div class="mb-3 text-sm text-gray-600">
                Se encontraron ${resultados.length} resultados para "${texto}"
                ${resultados.length > 20 ? ' (mostrando los primeros 20)' : ''}
            </div>
            <div class="space-y-3">
                ${resultadosPaginados.map((resultado, index) => `
                    <div class="resultado-item p-4 bg-[var(--bg-input)]/30 rounded-lg hover:bg-[var(--bg-input)]/50 transition-colors">
                        <div class="flex justify-between items-start mb-2">
                            <p class="font-semibold text-[var(--bg-primary)]">
                                ${resultado.referencia}
                                ${resultado.libroInfo ? `(${resultado.libroInfo.testamento})` : ''}
                            </p>
                            <span class="text-xs text-gray-500">
                                Relevancia: ${Math.round(resultado.relevancia || 0)}%
                            </span>
                        </div>
                        <p class="text-sm mb-3 leading-relaxed">
                            ${resaltarTexto(resultado.texto, texto)}
                        </p>
                        <button class="ir-a-resultado text-xs discord-button-secondary px-3 py-1 rounded" 
                            data-libro="${resultado.libroId}" 
                            data-capitulo="${resultado.capitulo}" 
                            data-versiculo="${resultado.versiculo}">
                            📖 Ir al versículo
                        </button>
                    </div>
                `).join('')}
            </div>
            ${resultados.length > 20 ? `
                <div class="text-center mt-4">
                    <button class="discord-button-secondary px-4 py-2 rounded-lg text-sm"
                            onclick="cargarMasResultados(${resultados.length})">
                        Cargar más resultados (${resultados.length - 20} restantes)
                    </button>
                </div>
            ` : ''}
        `;

        listaResultados.innerHTML = html;
        
        // Configurar eventos para botones de navegación
        configurarEventosResultados();
    }

    /**
     * Configura eventos para los resultados de búsqueda
     */
    function configurarEventosResultados() {
        document.querySelectorAll('.ir-a-resultado').forEach(boton => {
            boton.addEventListener('click', async (e) => {
                const libroId = e.target.dataset.libro;
                const capitulo = parseInt(e.target.dataset.capitulo);
                const versiculo = parseInt(e.target.dataset.versiculo);
                
                try {
                    // Actualizar selectores
                    const selectorLibro = document.getElementById('biblia-select-libro');
                    const selectorCapitulo = document.getElementById('biblia-select-capitulo');
                    
                    if (selectorLibro) {
                        selectorLibro.value = libroId;
                        await poblarSelectorCapitulos(libroId);
                        
                        if (selectorCapitulo) {
                            selectorCapitulo.value = capitulo;
                            await cargarCapitulo(libroId, capitulo);
                            
                            // Seleccionar y hacer scroll al versículo
                            setTimeout(() => {
                                seleccionarVersiculo(libroId, capitulo, versiculo);
                            }, 500);
                        }
                    }
                } catch (error) {
                    console.error('Error al navegar al versículo:', error);
                }
            });
        });
    }

    /**
     * Selecciona y resalta un versículo específico
     * @param {String} libroId - ID del libro
     * @param {Number} capitulo - Número del capítulo
     * @param {Number} versiculo - Número del versículo
     */
    function seleccionarVersiculo(libroId, capitulo, versiculo) {
        const elementoVersiculo = document.querySelector(`[data-versiculo="${versiculo}"]`);
        if (elementoVersiculo) {
            // Remover selecciones anteriores
            document.querySelectorAll('.versiculo-item.selected').forEach(v => {
                v.classList.remove('selected');
            });
            
            // Seleccionar versículo actual
            elementoVersiculo.classList.add('selected');
            
            // Scroll suave y centrado
            elementoVersiculo.scrollIntoView({ 
                behavior: 'smooth', 
                block: 'center' 
            });
            
            // Efecto de resaltado temporal
            elementoVersiculo.style.animation = 'highlight 2s ease-in-out';
            setTimeout(() => {
                elementoVersiculo.style.animation = '';
            }, 2000);
        }
    }

    /**
     * Carga un versículo aleatorio
     */
    async function cargarVersiculoAleatorio() {
        try {
            const libros = await obtenerLibros();
            const libroAleatorio = libros[Math.floor(Math.random() * libros.length)];
            const capituloAleatorio = Math.floor(Math.random() * libroAleatorio.capitulos) + 1;
            
            // Actualizar selectores
            const selectorLibro = document.getElementById('biblia-select-libro');
            const selectorCapitulo = document.getElementById('biblia-select-capitulo');
            
            if (selectorLibro) {
                selectorLibro.value = libroAleatorio.id;
                await poblarSelectorCapitulos(libroAleatorio.id);
                
                if (selectorCapitulo) {
                    selectorCapitulo.value = capituloAleatorio;
                    await cargarCapitulo(libroAleatorio.id, capituloAleatorio);
                }
            }
            
        } catch (error) {
            console.error('Error al cargar versículo aleatorio:', error);
        }
    }

    /**
     * Resalta texto en resultados de búsqueda
     * @param {String} texto - Texto completo
     * @param {String} busqueda - Texto a resaltar
     * @returns {String} Texto con resaltado HTML
     */
    function resaltarTexto(texto, busqueda) {
        if (!busqueda || busqueda.trim().length === 0) return texto;
        
        const palabras = busqueda.trim().split(/\s+/);
        let resultado = texto;
        
        palabras.forEach(palabra => {
            const regex = new RegExp(`(${palabra})`, 'gi');
            resultado = resultado.replace(regex, 
                '<mark class="bg-[var(--bg-primary)]/30 text-[var(--text-primary)] font-semibold px-1 rounded">$1</mark>'
            );
        });
        
        return resultado;
    }

    /**
     * Configura monitoreo de rendimiento
     */
    function setupPerformanceMonitoring() {
        // Listener para eventos de cache
        EventManager.on(EVENTS.CACHE_HIT, (data) => {
            console.debug('Cache hit:', data.key);
        });
        
        EventManager.on(EVENTS.CACHE_MISS, (data) => {
            console.debug('Cache miss:', data.key, 'Reason:', data.reason);
        });
        
        // Listener para eventos de rendimiento
        EventManager.on(EVENTS.PERFORMANCE, (data) => {
            console.debug(`Performance - ${data.operation}: ${data.duration}ms`);
        });
        
        // Listener para errores
        EventManager.on(EVENTS.ERROR, (data) => {
            console.warn('Error event:', data);
        });
        
        // Mostrar información de rendimiento en la interfaz
        if (CONFIG.modoDebug) {
            const perfInfo = document.getElementById('biblia-performance-info');
            if (perfInfo) {
                perfInfo.classList.remove('hidden');
                setInterval(actualizarEstadisticasRendimiento, 5000);
            }
        }
    }

    /**
     * Actualiza las estadísticas de rendimiento en la interfaz
     */
    function actualizarEstadisticasRendimiento() {
        const cacheStats = document.getElementById('cache-stats');
        const lastSearchTime = document.getElementById('last-search-time');
        const lastLoadTime = document.getElementById('last-load-time');
        
        if (cacheStats) {
            const stats = cache.getStats();
            cacheStats.textContent = `${stats.size}/${stats.maxSize} (${stats.hitRate}% hit rate)`;
        }
        
        if (lastSearchTime && performanceData.searchTimes.length > 0) {
            const lastTime = performanceData.searchTimes[performanceData.searchTimes.length - 1];
            lastSearchTime.textContent = Math.round(lastTime);
        }
        
        if (lastLoadTime && performanceData.loadTimes.length > 0) {
            const lastTime = performanceData.loadTimes[performanceData.loadTimes.length - 1];
            lastLoadTime.textContent = Math.round(lastTime);
        }
    }

    /**
     * Limpia el cache y reinicia métricas
     */
    function limpiarCache() {
        cache.clear();
        performanceData = {
            searchTimes: [],
            loadTimes: [],
            apiResponseTimes: []
        };
        console.log('Cache y métricas de rendimiento limpiados');
    }

    /**
     * Obtiene estadísticas del módulo
     * @returns {Object} Estadísticas completas
     */
    function obtenerEstadisticas() {
        return {
            cache: cache.getStats(),
            performance: {
                averageSearchTime: PerformanceManager.getAverageTime('search', performanceData.searchTimes),
                averageLoadTime: PerformanceManager.getAverageTime('load', performanceData.loadTimes),
                averageApiTime: PerformanceManager.getAverageTime('api', performanceData.apiResponseTimes),
                totalSearches: performanceData.searchTimes.length,
                totalLoads: performanceData.loadTimes.length,
                totalApiCalls: performanceData.apiResponseTimes.length
            },
            config: { ...CONFIG }
        };
    }

    // =====================================================================
    // API PÚBLICA DEL MÓDULO
    // =====================================================================
    
    return Object.freeze({
        // Funciones principales
        inicializar,
        obtenerLibros,
        obtenerLibro,
        obtenerCapitulo,
        obtenerVersiculo,
        buscarTexto,
        
        // Funciones de interfaz
        cargarCapitulo,
        seleccionarVersiculo,
        realizarBusqueda,
        cargarVersiculoAleatorio,
        
        // Funciones de utilidad
        limpiarCache,
        obtenerEstadisticas,
        
        // Acceso a componentes internos (para testing)
        cache: CONFIG.modoDebug ? cache : undefined,
        eventos: CONFIG.modoDebug ? EventManager : undefined
    });

})();

// =====================================================================
// CSS OPTIMIZADO PARA ANIMACIONES Y TRANSICIONES
// =====================================================================

const estilosOptimizados = `
<style>
    /* Animaciones optimizadas */
    @keyframes highlight {
        0% { background-color: var(--bg-primary); opacity: 0.3; }
        50% { background-color: var(--bg-primary); opacity: 0.6; }
        100% { background-color: transparent; opacity: 1; }
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Clases optimizadas */
    .versiculo-item.selected {
        background-color: var(--bg-primary) !important;
        color: white !important;
        transform: scale(1.02);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        transition: all 0.3s ease;
    }
    
    .resultado-item {
        animation: fadeIn 0.3s ease-out;
    }
    
    .biblia-container {
        animation: fadeIn 0.5s ease-out;
    }
    
    /* Optimizaciones de performance */
    .versiculo-item {
        will-change: transform, background-color;
    }
    
    .resultado-item:hover {
        transform: translateY(-1px);
        transition: transform 0.2s ease;
    }
    
    /* Responsive improvements */
    @media (max-width: 768px) {
        .biblia-header .flex {
            flex-direction: column;
        }
        
        .biblia-header .flex > * {
            min-width: 100%;
        }
    }
</style>
`;

// =====================================================================
// INICIALIZACIÓN AUTOMÁTICA OPTIMIZADA
// =====================================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Inicializando BibliaRV1960 Optimizado...');
    
    // Inyectar estilos
    document.head.insertAdjacentHTML('beforeend', estilosOptimizados);
    
    // Inicializar módulo si está disponible
    if (typeof BibliaRV1960Optimized !== 'undefined') {
        BibliaRV1960Optimized.inicializar({
            cacheEnabled: true,
            performanceMonitoring: true,
            modoDebug: false // Cambiar a true para debugging
        });
    }
    
    console.log('BibliaRV1960 Optimizado inicializado correctamente');
});

// Hacer disponible globalmente para compatibilidad
if (typeof window !== 'undefined') {
    window.BibliaRV1960Optimized = BibliaRV1960Optimized;
    
    // Exponer datos bíblicos simplificados para la aplicación React
    window.bibliaRV1960 = {
        books: [
            { name: 'Génesis', chapters: 50, testament: 'old' },
            { name: 'Éxodo', chapters: 40, testament: 'old' },
            { name: 'Levítico', chapters: 27, testament: 'old' },
            { name: 'Números', chapters: 36, testament: 'old' },
            { name: 'Deuteronomio', chapters: 34, testament: 'old' },
            { name: 'Josué', chapters: 24, testament: 'old' },
            { name: 'Jueces', chapters: 21, testament: 'old' },
            { name: 'Rut', chapters: 4, testament: 'old' },
            { name: '1 Samuel', chapters: 31, testament: 'old' },
            { name: '2 Samuel', chapters: 24, testament: 'old' },
            { name: '1 Reyes', chapters: 22, testament: 'old' },
            { name: '2 Reyes', chapters: 25, testament: 'old' },
            { name: '1 Crónicas', chapters: 29, testament: 'old' },
            { name: '2 Crónicas', chapters: 36, testament: 'old' },
            { name: 'Esdras', chapters: 10, testament: 'old' },
            { name: 'Nehemías', chapters: 13, testament: 'old' },
            { name: 'Ester', chapters: 10, testament: 'old' },
            { name: 'Job', chapters: 42, testament: 'old' },
            { name: 'Salmos', chapters: 150, testament: 'old' },
            { name: 'Proverbios', chapters: 31, testament: 'old' },
            { name: 'Eclesiastés', chapters: 12, testament: 'old' },
            { name: 'Cantares', chapters: 8, testament: 'old' },
            { name: 'Isaías', chapters: 66, testament: 'old' },
            { name: 'Jeremías', chapters: 52, testament: 'old' },
            { name: 'Lamentaciones', chapters: 5, testament: 'old' },
            { name: 'Ezequiel', chapters: 48, testament: 'old' },
            { name: 'Daniel', chapters: 12, testament: 'old' },
            { name: 'Oseas', chapters: 14, testament: 'old' },
            { name: 'Joel', chapters: 3, testament: 'old' },
            { name: 'Amós', chapters: 9, testament: 'old' },
            { name: 'Abdías', chapters: 1, testament: 'old' },
            { name: 'Jonás', chapters: 4, testament: 'old' },
            { name: 'Miqueas', chapters: 7, testament: 'old' },
            { name: 'Nahúm', chapters: 3, testament: 'old' },
            { name: 'Habacuc', chapters: 3, testament: 'old' },
            { name: 'Sofonías', chapters: 3, testament: 'old' },
            { name: 'Hageo', chapters: 2, testament: 'old' },
            { name: 'Zacarías', chapters: 14, testament: 'old' },
            { name: 'Malaquías', chapters: 4, testament: 'old' },
            { name: 'Mateo', chapters: 28, testament: 'new' },
            { name: 'Marcos', chapters: 16, testament: 'new' },
            { name: 'Lucas', chapters: 24, testament: 'new' },
            { name: 'Juan', chapters: 21, testament: 'new' },
            { name: 'Hechos', chapters: 28, testament: 'new' },
            { name: 'Romanos', chapters: 16, testament: 'new' },
            { name: '1 Corintios', chapters: 16, testament: 'new' },
            { name: '2 Corintios', chapters: 13, testament: 'new' },
            { name: 'Gálatas', chapters: 6, testament: 'new' },
            { name: 'Efesios', chapters: 6, testament: 'new' },
            { name: 'Filipenses', chapters: 4, testament: 'new' },
            { name: 'Colosenses', chapters: 4, testament: 'new' },
            { name: '1 Tesalonicenses', chapters: 5, testament: 'new' },
            { name: '2 Tesalonicenses', chapters: 3, testament: 'new' },
            { name: '1 Timoteo', chapters: 6, testament: 'new' },
            { name: '2 Timoteo', chapters: 4, testament: 'new' },
            { name: 'Tito', chapters: 3, testament: 'new' },
            { name: 'Filemón', chapters: 1, testament: 'new' },
            { name: 'Hebreos', chapters: 13, testament: 'new' },
            { name: 'Santiago', chapters: 5, testament: 'new' },
            { name: '1 Pedro', chapters: 5, testament: 'new' },
            { name: '2 Pedro', chapters: 3, testament: 'new' },
            { name: '1 Juan', chapters: 5, testament: 'new' },
            { name: '2 Juan', chapters: 1, testament: 'new' },
            { name: '3 Juan', chapters: 1, testament: 'new' },
            { name: 'Judas', chapters: 1, testament: 'new' },
            { name: 'Apocalipsis', chapters: 22, testament: 'new' }
        ],
        verses: {
            'Génesis': {
                1: {
                    1: 'En el principio creó Dios los cielos y la tierra.',
                    2: 'Y la tierra estaba desordenada y vacía, y las tinieblas estaban sobre la faz del abismo, y el Espíritu de Dios se movía sobre la faz de las aguas.',
                    3: 'Y dijo Dios: Sea la luz; y fue la luz.',
                    4: 'Y vio Dios que la luz era buena; y separó Dios la luz de las tinieblas.',
                    5: 'Y llamó Dios a la luz Día, y a las tinieblas llamó Noche. Y fue la tarde y la mañana un día.',
                    6: 'Luego dijo Dios: Haya expansión en medio de las aguas, y separe las aguas de las aguas.',
                    7: 'E hizo Dios la expansión, y separó las aguas que estaban debajo de la expansión, de las aguas que estaban sobre la expansión. Y fue así.',
                    8: 'Y llamó Dios a la expansión Cielos. Y fue la tarde y la mañana el día segundo.',
                    9: 'Dijo también Dios: Júntense las aguas que están debajo de los cielos en un lugar, y descúbrase lo seco. Y fue así.',
                    10: 'Y llamó Dios a lo seco Tierra, y a la reunión de las aguas llamó Mares. Y vio Dios que era bueno.',
                    11: 'Después dijo Dios: Produzca la tierra hierba verde, hierba que dé semilla; árbol de fruto que dé fruto según su género, que su semilla esté en él, sobre la tierra. Y fue así.',
                    12: 'Produjo, pues, la tierra hierba verde, hierba que da semilla según su naturaleza, y árbol que da fruto, cuya semilla está en él, según su género. Y vio Dios que era bueno.',
                    13: 'Y fue la tarde y la mañana el día tercero.',
                    14: 'Dijo luego Dios: Haya lumbreras en la expansión de los cielos para separar el día de la noche; y sirvan de señales para las estaciones, para días y años,',
                    15: 'y sean por lumbreras en la expansión de los cielos para alumbrar sobre la tierra. Y fue así.',
                    16: 'E hizo Dios las dos grandes lumbreras; la lumbrera mayor para que señorease en el día, y la lumbrera menor para que señorease en la noche; hizo también las estrellas.',
                    17: 'Y las puso Dios en la expansión de los cielos para alumbrar sobre la tierra,',
                    18: 'y para señorear en el día y en la noche, y para separar la luz de las tinieblas. Y vio Dios que era bueno.',
                    19: 'Y fue la tarde y la mañana el día cuarto.',
                    20: 'Dijo Dios: Produzcan las aguas seres vivientes, y aves que vuelen sobre la tierra, en la abierta expansión de los cielos.',
                    21: 'Y creó Dios los grandes monstruos marinos, y todo ser viviente que se mueve, que las aguas produjeron según su género, y toda ave alada según su especie. Y vio Dios que era bueno.',
                    22: 'Y Dios los bendijo, diciendo: Fructificad y multiplicaos, y llenad las aguas en los mares, y multiplíquense las aves en la tierra.',
                    23: 'Y fue la tarde y la mañana el día quinto.',
                    24: 'Luego dijo Dios: Produzca la tierra seres vivientes según su género, bestias y serpientes y animales de la tierra según su especie. Y fue así.',
                    25: 'E hizo Dios animales de la tierra según su género, y ganado según su género, y todo animal que se arrastra sobre la tierra según su especie. Y vio Dios que era bueno.',
                    26: 'Entonces dijo Dios: Hagamos al hombre a nuestra imagen, conforme a nuestra semejanza; y señoree en los peces del mar, en las aves de los cielos, en las bestias, en toda la tierra, y en todo animal que se arrastra sobre la tierra.',
                    27: 'Y creó Dios al hombre a su imagen, a imagen de Dios lo creó; varón y hembra los creó.',
                    28: 'Y los bendijo Dios, y les dijo: Fructificad y multiplicaos; llenad la tierra, y sojuzgadla, y señoread en los peces del mar, en las aves de los cielos, y en todas las bestias que se mueven sobre la tierra.',
                    29: 'Y dijo Dios: He aquí que os he dado toda planta que da semilla, que está sobre toda la tierra, y todo árbol en que hay fruto y que da semilla; os serán para comer.',
                    30: 'Y a toda bestia de la tierra, y a todas las aves de los cielos, y a todo lo que se arrastra sobre la tierra, en que hay vida, toda planta verde les será para comer. Y fue así.',
                    31: 'Y vio Dios todo lo que había hecho, y he aquí que era bueno en gran manera. Y fue la tarde y la mañana el día sexto.'
                },
                4: {
                    1: 'Conoció Adán a su mujer Eva, la cual concibió y dio a luz a Caín, y dijo: Por voluntad de Jehová he adquirido varón.',
                    2: 'Después dio a luz a su hermano Abel. Y Abel fue pastor de ovejas, y Caín fue labrador de la tierra.',
                    3: 'Y aconteció andando el tiempo, que Caín trajo del fruto de la tierra una ofrenda a Jehová.',
                    4: 'Y Abel trajo también de los primogénitos de sus ovejas, de lo más gordo de ellas. Y miró Jehová con agrado a Abel y a su ofrenda;',
                    5: 'pero no miró con agrado a Caín y a la ofrenda suya. Y se ensañó Caín en gran manera, y decayó su semblante.',
                    6: 'Entonces Jehová dijo a Caín: ¿Por qué te has ensañado, y por qué ha decaído tu semblante?',
                    7: 'Si bien hicieres, ¿no serás enaltecido? y si no hicieres bien, el pecado está a la puerta; con todo esto, a ti será su deseo, y tú te enseñorearás de él.',
                    8: 'Y dijo Caín a su hermano Abel: Salgamos al campo. Y aconteció que estando ellos en el campo, Caín se levantó contra su hermano Abel, y lo mató.',
                    9: 'Y Jehová dijo a Caín: ¿Dónde está Abel tu hermano? Y él respondió: No sé. ¿Soy yo acaso guarda de mi hermano?',
                    10: 'Y él le dijo: ¿Qué has hecho? La voz de la sangre de tu hermano clama a mí desde la tierra.',
                    11: 'Ahora, pues, maldito seas tú de la tierra, que abrió su boca para recibir de tu mano la sangre de tu hermano.',
                    12: 'Cuando labres la tierra, no te volverá a dar su fuerza; errante y extranjero serás en la tierra.',
                    13: 'Y dijo Caín a Jehová: Grande es mi castigo para ser soportado.',
                    14: 'He aquí me echas hoy de la tierra, y de tu presencia me esconderé, y seré errante y extranjero en la tierra; y sucederá que cualquiera que me hallare, me matará.',
                    15: 'Y le respondió Jehová: Ciertamente cualquiera que matare a Caín, siete veces será castigado. Entonces Jehová puso señal en Caín, para que no lo matase cualquiera que le hallara.',
                    16: 'Salió, pues, Caín de delante de Jehová, y habitó en tierra de Nod, al oriente de Edén.'
                }
            },
            'Éxodo': {
                1: {
                    1: 'Estos son los nombres de los hijos de Israel que entraron en Egipto con Jacob; cada uno entró con su familia:',
                    2: 'Rubén, Simeón, Leví y Judá,',
                    3: 'Isacar, Zabulón y Benjamín,',
                    4: 'Dan y Neftalí, Gad y Aser.',
                    5: 'Todas las personas que le nacieron a Jacob fueron setenta, y José estaba en Egipto.',
                    6: 'Y murió José, y todos sus hermanos, y toda aquella generación.',
                    7: 'Y los hijos de Israel fructificaron y se multiplicaron, y fueron aumentados y fortalecidos en extremo, y se llenó de ellos la tierra.',
                    8: 'Entretanto, se levantó sobre Egipto un nuevo rey que no conocía a José; y dijo a su pueblo:',
                    9: 'He aquí, el pueblo de los hijos de Israel es mayor y más fuerte que nosotros.',
                    10: 'Ahora, pues, seamos sabios para con él, para que no se multiplique, y acontezca que viniendo guerra, él también se una a nuestros enemigos y pelee contra nosotros, y se vaya de la tierra.',
                    11: 'Entonces pusieron sobre ellos comisarios de tributos que los molestasen con sus cargas; y edificaron para Faraón las ciudades de almacenaje, Pitón y Ramesés.',
                    12: 'Pero cuanto más los oprimían, tanto más se multiplicaban y crecían, de manera que los egipcios temían a los hijos de Israel.',
                    13: 'Y los egipcios hicieron servir a los hijos de Israel con dureza,',
                    14: 'y amargaron su vida con dura servidumbre, en hacer barro y ladrillo, y en toda labor del campo y en todo su servicio, al cual los obligaban con rigor.',
                    15: 'Y habló el rey de Egipto a las parteras de las hebreas, una de las cuales se llamaba Sifra, y otra Fúa, y les dijo:',
                    16: 'Cuando asistáis a las hebreas en sus partos, y veáis el sexo, si es hijo, matadlo; y si es hija, entonces viva.',
                    17: 'Pero las parteras temieron a Dios, y no hicieron como les mandó el rey de Egipto, sino que preservaron la vida a los niños.',
                    18: 'Y el rey de Egipto hizo llamar a las parteras y les dijo: ¿Por qué habéis hecho esto, que habéis preservado la vida a los niños?',
                    19: 'Y las parteras respondieron a Faraón: Porque las mujeres hebreas no son como las egipcias; pues son robustas, y dan a luz antes que la partera venga a ellas.',
                    20: 'Y Dios hizo bien a las parteras; y el pueblo se multiplicó y se fortaleció en gran manera.',
                    21: 'Y por haber las parteras temido a Dios, él prosperó sus familias.',
                    22: 'Entonces Faraón mandó a todo su pueblo, diciendo: Echad al río a todo hijo que nazca, y a toda hija preservad la vida.'
                }
            },
            'Mateo': {
                1: {
                    1: 'Libro de la genealogía de Jesucristo, hijo de David, hijo de Abraham.',
                    2: 'Abraham engendró a Isaac, Isaac a Jacob, y Jacob a Judá y a sus hermanos.',
                    3: 'Judá engendró de Tamar a Fares y a Zara, Fares a Esrom, y Esrom a Aram.',
                    4: 'Aram engendró a Aminadab, Aminadab a Naasón, y Naasón a Salmón.',
                    5: 'Salmón engendró de Rahab a Booz, Booz engendró de Rut a Obed, y Obed a Isaí.',
                    6: 'Isaí engendró al rey David, y el rey David engendró a Salomón de la que fue mujer de Urías.',
                    7: 'Salomón engendró a Roboam, Roboam a Abías, y Abías a Asa.',
                    8: 'Asa engendró a Josafat, Josafat a Joram, y Joram a Uzías.',
                    9: 'Uzías engendró a Jotam, Jotam a Acaz, y Acaz a Ezequías.',
                    10: 'Ezequías engendró a Manasés, Manasés a Amón, y Amón a Josías.',
                    11: 'Josías engendró a Jeconías y a sus hermanos, en el tiempo de la deportación a Babilonia.',
                    12: 'Después de la deportación a Babilonia, Jeconías engendró a Salatiel, y Salatiel a Zorobabel.',
                    13: 'Zorobabel engendró a Abiud, Abiud a Eliaquim, y Eliaquim a Azor.',
                    14: 'Azor engendró a Sadoc, Sadoc a Aquim, y Aquim a Eliud.',
                    15: 'Eliud engendró a Eleazar, Eleazar a Matán, Matán a Jacob.',
                    16: 'Y Jacob engendró a José, marido de María, de la cual nació Jesús, llamado el Cristo.',
                    17: 'De manera que todas las generaciones desde Abraham hasta David son catorce; desde David hasta la deportación a Babilonia, catorce; y desde la deportación a Babilonia hasta Cristo, catorce.',
                    18: 'El nacimiento de Jesucristo fue así: Estando desposada María su madre con José, antes que se juntasen, se halló que había concebido del Espíritu Santo.',
                    19: 'José su marido, como era justo, y no quería infamarla, quiso dejarla secretamente.',
                    20: 'Y pensando él en esto, he aquí un ángel del Señor le apareció en sueños y le dijo: José, hijo de David, no temas recibir a María tu mujer, porque lo que en ella es engendrado, del Espíritu Santo es.',
                    21: 'Y dará a luz un hijo, y llamarás su nombre JESÚS, porque él salvará a su pueblo de sus pecados.',
                    22: 'Todo esto aconteció para que se cumpliese lo dicho por el Señor por medio del profeta, cuando dijo:',
                    23: 'He aquí, una virgen concebirá y dará a luz un hijo, Y llamarás su nombre Emanuel, que traducido es: Dios con nosotros.',
                    24: 'Y despertando José del sueño, hizo como el ángel del Señor le había mandado, y recibió a su mujer.',
                    25: 'Pero no la conoció hasta que dio a luz a su hijo primogénito; y le puso por nombre JESÚS.'
                }
            },
            'Juan': {
                3: {
                    16: 'Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito, para que todo aquel que en él cree, no se pierda, mas tenga vida eterna.',
                    17: 'Porque no envió Dios a su Hijo al mundo para condenar al mundo, sino para que el mundo sea salvo por él.',
                    18: 'El que en él cree, no es condenado; pero el que no cree, ya ha sido condenado, porque no ha creído en el nombre del unigénito Hijo de Dios.'
                }
            },
            'Salmos': {
                23: {
                    1: 'Jehová es mi pastor; nada me faltará.',
                    2: 'En lugares de delicados pastos me hará descansar; Junto a aguas de reposo me pastoreará.',
                    3: 'Confortará mi alma; Me guiará por sendas de justicia por amor de su nombre.',
                    4: 'Aunque ande en valle de sombra de muerte, No temeré mal alguno, porque tú estarás conmigo; Tu vara y tu cayado me infundirán aliento.',
                    5: 'Aderezas mesa delante de mí en presencia de mis angustiadores; Unges mi cabeza con aceite; mi copa está rebosando.',
                    6: 'Ciertamente el bien y la misericordia me seguirán todos los días de mi vida, Y en la casa de Jehová moraré por largos días.'
                }
            },
            'Romanos': {
                8: {
                    28: 'Y sabemos que a los que aman a Dios, todas las cosas les ayudan a bien, esto es, a los que conforme a su propósito son llamados.',
                    29: 'Porque a los que antes conoció, también los predestinó para que fuesen hechos conformes a la imagen de su Hijo, para que él sea el primogénito entre muchos hermanos.',
                    30: 'Y a los que predestinó, a éstos también llamó; y a los que llamó, a éstos también justificó; y a los que justificó, a éstos también glorificó.'
                }
            },
            'Proverbios': {
                3: {
                    5: 'Fíate de Jehová de todo tu corazón, Y no te apoyes en tu propia prudencia.',
                    6: 'Reconócelo en todos tus caminos, Y él enderezará tus veredas.',
                    7: 'No seas sabio en tu propia opinión; Teme a Jehová, y apártate del mal.',
                    8: 'Porque será medicina a tu cuerpo, Y refrigerio para tus huesos.'
                }
            },
            'Filipenses': {
                4: {
                    13: 'Todo lo puedo en Cristo que me fortalece.',
                    19: 'Mi Dios, pues, suplirá todo lo que os falta conforme a sus riquezas en gloria en Cristo Jesús.'
                }
            },
            'Apocalipsis': {
                21: {
                    4: 'Enjugará Dios toda lágrima de los ojos de ellos; y ya no habrá muerte, ni habrá más llanto, ni clamor, ni dolor; porque las primeras cosas pasaron.',
                    5: 'Y el que estaba sentado en el trono dijo: He aquí, yo hago nuevas todas las cosas. Y me dijo: Escribe; porque estas palabras son fieles y verdaderas.'
                }
            }
        }
    };
}

// Soporte para módulos ES6
if (typeof module !== 'undefined' && module.exports) {
    module.exports = BibliaRV1960Optimized;
}

} // Cerrar la condición if inicial
