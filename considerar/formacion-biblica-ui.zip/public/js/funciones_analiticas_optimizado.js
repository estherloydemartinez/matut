/**
 * Funciones Analíticas y Estadísticas - VERSIÓN OPTIMIZADA
 * Aplicación de Formación Bíblica - Filtros de Sangre y Agua
 * 
 * MEJORAS IMPLEMENTADAS:
 * - Algoritmos optimizados para análisis estadísticos
 * - Web Workers para procesamiento en segundo plano
 * - Cache inteligente para resultados de análisis
 * - Throttling para operaciones intensivas
 * - Lazy loading de visualizaciones
 * - Manejo robusto de errores
 * - Performance monitoring avanzado
 * - Modularización mejorada
 * - Algoritmos de machine learning básicos
 */

'use strict';

// =====================================================================
// MÓDULO PRINCIPAL DE ANÁLISIS - VERSIÓN OPTIMIZADA
// =====================================================================

const AnalisisAvanzadoOptimizado = (function() {
    
    // =====================================================================
    // CONFIGURACIÓN Y CONSTANTES
    // =====================================================================
    
    const CONFIG = Object.freeze({
        modoDebug: false,
        nivelPrecision: 3, // Incrementado para mayor precisión
        umbralCorrelacion: 0.65, // Optimizado
        maxElementosVisualizacion: 200, // Incrementado
        useWebWorkers: true,
        cacheEnabled: true,
        cacheExpiration: 30 * 60 * 1000, // 30 minutos
        maxCacheSize: 100,
        batchSize: 1000, // Para procesamiento por lotes
        throttleDelay: 500,
        performanceMonitoring: true,
        optimizacionesML: true
    });

    const ALGORITMOS = Object.freeze({
        CORRELACION_PEARSON: 'pearson',
        CORRELACION_SPEARMAN: 'spearman',
        CLUSTERING_KMEANS: 'kmeans',
        PATRON_FRECUENCIA: 'frequency',
        PATRON_SECUENCIAL: 'sequential',
        ANALISIS_SENTIMENT: 'sentiment'
    });

    // =====================================================================
    // SISTEMA DE CACHE AVANZADO
    // =====================================================================
    
    class AnalyticsCache {
        constructor(maxSize = CONFIG.maxCacheSize) {
            this.cache = new Map();
            this.metadata = new Map();
            this.maxSize = maxSize;
            this.hits = 0;
            this.misses = 0;
        }

        generateKey(operation, params) {
            return `${operation}_${JSON.stringify(params)}`;
        }

        get(key) {
            if (this.cache.has(key)) {
                const item = this.cache.get(key);
                const meta = this.metadata.get(key);
                
                // Verificar expiración
                if (Date.now() - meta.timestamp > CONFIG.cacheExpiration) {
                    this.delete(key);
                    this.misses++;
                    return null;
                }
                
                meta.accessCount++;
                meta.lastAccess = Date.now();
                this.hits++;
                return item;
            }
            
            this.misses++;
            return null;
        }

        set(key, value) {
            if (this.cache.size >= this.maxSize && !this.cache.has(key)) {
                this._evictLRU();
            }

            this.cache.set(key, value);
            this.metadata.set(key, {
                timestamp: Date.now(),
                lastAccess: Date.now(),
                accessCount: 1,
                size: this._estimateSize(value)
            });
        }

        delete(key) {
            this.cache.delete(key);
            this.metadata.delete(key);
        }

        _evictLRU() {
            let oldestKey = null;
            let oldestTime = Infinity;

            for (const [key, meta] of this.metadata) {
                if (meta.lastAccess < oldestTime) {
                    oldestTime = meta.lastAccess;
                    oldestKey = key;
                }
            }

            if (oldestKey) {
                this.delete(oldestKey);
            }
        }

        _estimateSize(obj) {
            return JSON.stringify(obj).length;
        }

        getStats() {
            const total = this.hits + this.misses;
            return {
                size: this.cache.size,
                maxSize: this.maxSize,
                hitRate: total > 0 ? ((this.hits / total) * 100).toFixed(2) : 0,
                hits: this.hits,
                misses: this.misses
            };
        }

        clear() {
            this.cache.clear();
            this.metadata.clear();
            this.hits = 0;
            this.misses = 0;
        }
    }

    // =====================================================================
    // WEB WORKERS PARA PROCESAMIENTO PARALELO
    // =====================================================================
    
    class WorkerManager {
        constructor() {
            this.workers = new Map();
            this.workerPool = [];
            this.maxWorkers = navigator.hardwareConcurrency || 4;
        }

        async createWorker(type) {
            if (this.workers.has(type)) {
                return this.workers.get(type);
            }

            const workerCode = this._getWorkerCode(type);
            const blob = new Blob([workerCode], { type: 'application/javascript' });
            const worker = new Worker(URL.createObjectURL(blob));
            
            this.workers.set(type, worker);
            return worker;
        }

        async executeInWorker(type, data) {
            if (!CONFIG.useWebWorkers) {
                return this._executeSynchronously(type, data);
            }

            const worker = await this.createWorker(type);
            
            return new Promise((resolve, reject) => {
                const timeout = setTimeout(() => {
                    reject(new Error('Worker timeout'));
                }, 30000);

                worker.onmessage = (e) => {
                    clearTimeout(timeout);
                    if (e.data.error) {
                        reject(new Error(e.data.error));
                    } else {
                        resolve(e.data.result);
                    }
                };

                worker.onerror = (error) => {
                    clearTimeout(timeout);
                    reject(error);
                };

                worker.postMessage({ type, data });
            });
        }

        _getWorkerCode(type) {
            switch (type) {
                case 'correlation':
                    return `
                        self.onmessage = function(e) {
                            try {
                                const { data } = e.data;
                                const result = calculateCorrelationMatrix(data);
                                self.postMessage({ result });
                            } catch (error) {
                                self.postMessage({ error: error.message });
                            }
                        };

                        function calculateCorrelationMatrix(data) {
                            const { series, method } = data;
                            const n = series.length;
                            const matrix = Array(n).fill().map(() => Array(n).fill(0));
                            
                            for (let i = 0; i < n; i++) {
                                for (let j = 0; j < n; j++) {
                                    if (i === j) {
                                        matrix[i][j] = 1;
                                    } else {
                                        matrix[i][j] = calculatePearsonCorrelation(series[i], series[j]);
                                    }
                                }
                            }
                            
                            return matrix;
                        }

                        function calculatePearsonCorrelation(x, y) {
                            const n = Math.min(x.length, y.length);
                            if (n === 0) return 0;
                            
                            const sumX = x.slice(0, n).reduce((a, b) => a + b, 0);
                            const sumY = y.slice(0, n).reduce((a, b) => a + b, 0);
                            const sumXY = x.slice(0, n).reduce((sum, xi, i) => sum + xi * y[i], 0);
                            const sumX2 = x.slice(0, n).reduce((sum, xi) => sum + xi * xi, 0);
                            const sumY2 = y.slice(0, n).reduce((sum, yi) => sum + yi * yi, 0);
                            
                            const numerator = n * sumXY - sumX * sumY;
                            const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
                            
                            return denominator === 0 ? 0 : numerator / denominator;
                        }
                    `;

                case 'pattern':
                    return `
                        self.onmessage = function(e) {
                            try {
                                const { data } = e.data;
                                const result = detectPatterns(data);
                                self.postMessage({ result });
                            } catch (error) {
                                self.postMessage({ error: error.message });
                            }
                        };

                        function detectPatterns(data) {
                            const { texto, opciones } = data;
                            const patterns = [];
                            
                            // Implementar algoritmo de detección de patrones optimizado
                            const words = texto.toLowerCase().split(/\\s+/).filter(w => w.length > 2);
                            const ngramCounts = {};
                            
                            // Generar n-gramas
                            for (let n = 2; n <= Math.min(5, words.length); n++) {
                                for (let i = 0; i <= words.length - n; i++) {
                                    const ngram = words.slice(i, i + n).join(' ');
                                    ngramCounts[ngram] = (ngramCounts[ngram] || 0) + 1;
                                }
                            }
                            
                            // Filtrar y ordenar patrones
                            Object.entries(ngramCounts)
                                .filter(([_, count]) => count >= (opciones.umbralFrecuencia || 2))
                                .sort((a, b) => b[1] - a[1])
                                .slice(0, opciones.maxPatrones || 20)
                                .forEach(([pattern, frequency]) => {
                                    patterns.push({
                                        texto: pattern,
                                        frecuencia: frequency,
                                        palabras: pattern.split(' ').length,
                                        relevancia: frequency * pattern.split(' ').length
                                    });
                                });
                            
                            return patterns;
                        }
                    `;

                case 'clustering':
                    return `
                        self.onmessage = function(e) {
                            try {
                                const { data } = e.data;
                                const result = performKMeans(data);
                                self.postMessage({ result });
                            } catch (error) {
                                self.postMessage({ error: error.message });
                            }
                        };

                        function performKMeans(data) {
                            const { points, k, maxIterations = 100 } = data;
                            
                            // Inicializar centroides aleatoriamente
                            const centroids = [];
                            for (let i = 0; i < k; i++) {
                                const randomPoint = points[Math.floor(Math.random() * points.length)];
                                centroids.push([...randomPoint]);
                            }
                            
                            let assignments = new Array(points.length);
                            let converged = false;
                            let iteration = 0;
                            
                            while (!converged && iteration < maxIterations) {
                                const newAssignments = new Array(points.length);
                                
                                // Asignar puntos a centroides más cercanos
                                for (let i = 0; i < points.length; i++) {
                                    let minDistance = Infinity;
                                    let bestCentroid = 0;
                                    
                                    for (let j = 0; j < centroids.length; j++) {
                                        const distance = euclideanDistance(points[i], centroids[j]);
                                        if (distance < minDistance) {
                                            minDistance = distance;
                                            bestCentroid = j;
                                        }
                                    }
                                    
                                    newAssignments[i] = bestCentroid;
                                }
                                
                                // Verificar convergencia
                                converged = JSON.stringify(assignments) === JSON.stringify(newAssignments);
                                assignments = newAssignments;
                                
                                // Actualizar centroides
                                for (let j = 0; j < k; j++) {
                                    const clusterPoints = points.filter((_, i) => assignments[i] === j);
                                    if (clusterPoints.length > 0) {
                                        const dimensions = clusterPoints[0].length;
                                        for (let d = 0; d < dimensions; d++) {
                                            centroids[j][d] = clusterPoints.reduce((sum, point) => sum + point[d], 0) / clusterPoints.length;
                                        }
                                    }
                                }
                                
                                iteration++;
                            }
                            
                            return {
                                assignments,
                                centroids,
                                iterations: iteration,
                                converged
                            };
                        }

                        function euclideanDistance(point1, point2) {
                            return Math.sqrt(point1.reduce((sum, val, i) => sum + Math.pow(val - point2[i], 2), 0));
                        }
                    `;

                default:
                    return `
                        self.onmessage = function(e) {
                            self.postMessage({ error: 'Worker type not implemented' });
                        };
                    `;
            }
        }

        _executeSynchronously(type, data) {
            // Fallback para cuando los Web Workers no están disponibles
            switch (type) {
                case 'correlation':
                    return this._calculateCorrelationSync(data);
                case 'pattern':
                    return this._detectPatternsSync(data);
                case 'clustering':
                    return this._performClusteringSync(data);
                default:
                    throw new Error(`Synchronous execution not implemented for type: ${type}`);
            }
        }

        _calculateCorrelationSync(data) {
            // Implementación síncrona de correlación
            const { series, method } = data;
            const n = series.length;
            const matrix = Array(n).fill().map(() => Array(n).fill(0));
            
            for (let i = 0; i < n; i++) {
                for (let j = 0; j < n; j++) {
                    if (i === j) {
                        matrix[i][j] = 1;
                    } else {
                        matrix[i][j] = this._pearsonCorrelation(series[i], series[j]);
                    }
                }
            }
            
            return matrix;
        }

        _pearsonCorrelation(x, y) {
            const n = Math.min(x.length, y.length);
            if (n === 0) return 0;
            
            const sumX = x.slice(0, n).reduce((a, b) => a + b, 0);
            const sumY = y.slice(0, n).reduce((a, b) => a + b, 0);
            const sumXY = x.slice(0, n).reduce((sum, xi, i) => sum + xi * y[i], 0);
            const sumX2 = x.slice(0, n).reduce((sum, xi) => sum + xi * xi, 0);
            const sumY2 = y.slice(0, n).reduce((sum, yi) => sum + yi * yi, 0);
            
            const numerator = n * sumXY - sumX * sumY;
            const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
            
            return denominator === 0 ? 0 : numerator / denominator;
        }

        destroy() {
            for (const worker of this.workers.values()) {
                worker.terminate();
            }
            this.workers.clear();
        }
    }

    // =====================================================================
    // UTILIDADES DE PERFORMANCE
    // =====================================================================
    
    class PerformanceTracker {
        constructor() {
            this.metrics = new Map();
            this.operationCounts = new Map();
        }

        startTimer(operation) {
            this.metrics.set(operation, performance.now());
        }

        endTimer(operation) {
            const startTime = this.metrics.get(operation);
            if (startTime) {
                const duration = performance.now() - startTime;
                this.metrics.delete(operation);
                
                // Incrementar contador de operaciones
                const count = this.operationCounts.get(operation) || 0;
                this.operationCounts.set(operation, count + 1);
                
                if (CONFIG.performanceMonitoring) {
                    console.debug(`Performance - ${operation}: ${duration.toFixed(2)}ms`);
                }
                
                return duration;
            }
            return null;
        }

        getAverageTime(operation, measurements = []) {
            if (measurements.length === 0) return 0;
            const sum = measurements.reduce((acc, time) => acc + time, 0);
            return (sum / measurements.length).toFixed(2);
        }

        getOperationCount(operation) {
            return this.operationCounts.get(operation) || 0;
        }

        getStats() {
            const stats = {};
            for (const [operation, count] of this.operationCounts) {
                stats[operation] = { count };
            }
            return stats;
        }
    }

    // =====================================================================
    // INICIALIZACIÓN DE COMPONENTES
    // =====================================================================
    
    const cache = new AnalyticsCache();
    const workerManager = new WorkerManager();
    const performanceTracker = new PerformanceTracker();
    
    // Estructura optimizada de datos para análisis
    let datosAnalisis = {
        sangre: {
            categorias: new Map(),
            frecuencias: new Map(),
            correlaciones: new Map(),
            patrones: [],
            clusters: []
        },
        agua: {
            elementos: new Map(),
            conexiones: new Map(),
            flujos: new Map(),
            patrones: [],
            redes: []
        },
        estadisticas: {
            global: {},
            porLibro: new Map(),
            porCategoria: new Map(),
            temporal: [],
            distribucion: {}
        },
        metadatos: {
            ultimaActualizacion: null,
            version: '2.0.0',
            operacionesRealizadas: 0
        }
    };

    // =====================================================================
    // FUNCIONES DE ANÁLISIS OPTIMIZADAS
    // =====================================================================
    
    /**
     * Análisis de frecuencia optimizado con algoritmos avanzados
     * @param {String|Array} texto - Texto a analizar o array de textos
     * @param {Array} categorias - Categorías para clasificación
     * @param {Object} opciones - Opciones avanzadas
     * @returns {Promise<Object>} Resultados del análisis de frecuencia
     */
    async function analizarFrecuenciaOptimizado(texto, categorias, opciones = {}) {
        const cacheKey = cache.generateKey('frecuencia', { texto: typeof texto === 'string' ? texto.substring(0, 100) : texto.length, categorias: categorias.map(c => c.id) });
        
        // Verificar cache
        let resultado = cache.get(cacheKey);
        if (resultado) {
            return resultado;
        }

        performanceTracker.startTimer('analisis_frecuencia');

        try {
            const {
                algoritmo = ALGORITMOS.PATRON_FRECUENCIA,
                incluirBigramas = true,
                incluirTrigramas = false,
                normalizacion = 'tf-idf',
                filtrosPalabras = []
            } = opciones;

            // Procesar texto de entrada
            const textos = Array.isArray(texto) ? texto : [texto];
            const textoCombinado = textos.join(' ').toLowerCase();
            
            // Preprocesamiento optimizado
            const palabras = textoCombinado
                .replace(/[^\w\sáéíóúüñ]/g, ' ')
                .split(/\s+/)
                .filter(p => p.length > 2 && !filtrosPalabras.includes(p));

            resultado = {
                totalPalabras: palabras.length,
                totalTextos: textos.length,
                frecuenciaCategorias: new Map(),
                densidadPorTexto: [],
                terminosDestacados: [],
                ngramas: {
                    unigramas: new Map(),
                    bigramas: new Map(),
                    trigramas: new Map()
                },
                estadisticas: {
                    entropia: 0,
                    diversidadLexica: 0,
                    complejidad: 0
                },
                metadatos: {
                    algoritmo,
                    normalizacion,
                    tiempoAnalisis: null
                }
            };

            // Análisis por categorías con optimización
            const promesasCategorias = categorias.map(async (categoria) => {
                const terminos = categoria.terminos || [];
                let contador = 0;
                const coincidencias = new Map();

                // Análisis paralelo de términos
                for (const termino of terminos) {
                    const regex = new RegExp(`\\b${termino}\\b`, 'gi');
                    const matches = (textoCombinado.match(regex) || []).length;
                    contador += matches;
                    if (matches > 0) {
                        coincidencias.set(termino, matches);
                    }
                }

                return {
                    categoriaId: categoria.id,
                    total: contador,
                    porcentaje: (contador / resultado.totalPalabras * 100).toFixed(CONFIG.nivelPrecision),
                    coincidencias,
                    densidad: contador / resultado.totalTextos
                };
            });

            const resultadosCategorias = await Promise.all(promesasCategorias);
            resultadosCategorias.forEach(res => {
                resultado.frecuenciaCategorias.set(res.categoriaId, res);
            });

            // Análisis de n-gramas si está habilitado
            if (incluirBigramas || incluirTrigramas) {
                await this._analizarNgramas(palabras, resultado, incluirBigramas, incluirTrigramas);
            }

            // Calcular estadísticas avanzadas
            resultado.estadisticas = await this._calcularEstadisticasAvanzadas(palabras, resultado);

            // Detectar términos destacados usando TF-IDF
            if (normalizacion === 'tf-idf') {
                resultado.terminosDestacados = await this._calcularTFIDF(textos, categorias);
            }

            const duracion = performanceTracker.endTimer('analisis_frecuencia');
            resultado.metadatos.tiempoAnalisis = duracion;

            // Guardar en cache
            cache.set(cacheKey, resultado);
            
            return resultado;

        } catch (error) {
            performanceTracker.endTimer('analisis_frecuencia');
            console.error('Error en análisis de frecuencia optimizado:', error);
            throw new Error(`Error en análisis de frecuencia: ${error.message}`);
        }
    }

    /**
     * Análisis de correlaciones usando Web Workers
     * @param {Object} datosFrecuencia - Datos de frecuencia
     * @param {Array} categorias - Categorías para análisis
     * @param {String} metodo - Método de correlación (pearson, spearman)
     * @returns {Promise<Object>} Matriz de correlación
     */
    async function analizarCorrelacionesOptimizado(datosFrecuencia, categorias, metodo = ALGORITMOS.CORRELACION_PEARSON) {
        const cacheKey = cache.generateKey('correlaciones', { categorias: categorias.map(c => c.id), metodo });
        
        let resultado = cache.get(cacheKey);
        if (resultado) {
            return resultado;
        }

        performanceTracker.startTimer('analisis_correlaciones');

        try {
            // Preparar series de datos para análisis
            const series = categorias.map(categoria => {
                const datosCategoria = datosFrecuencia.frecuenciaCategorias.get(categoria.id);
                if (!datosCategoria) return [];
                
                // Convertir densidad por texto a serie numérica
                return datosFrecuencia.densidadPorTexto.map(texto => 
                    parseFloat(texto.densidad[categoria.id]) || 0
                );
            });

            // Ejecutar análisis en Web Worker
            const matrizCorrelacion = await workerManager.executeInWorker('correlation', {
                series,
                method: metodo
            });

            // Procesar resultados
            resultado = {
                matriz: matrizCorrelacion,
                metodo,
                categorias: categorias.map(c => c.id),
                estadisticas: {
                    correlacionesSignificativas: 0,
                    correlacionMaxima: 0,
                    correlacionMinima: 0,
                    promedioCorrelacion: 0
                },
                grupos: [],
                redCorrelaciones: [],
                metadatos: {
                    tiempoAnalisis: null,
                    algoritmo: metodo
                }
            };

            // Calcular estadísticas de la matriz
            this._calcularEstadisticasCorrelacion(resultado);

            // Detectar grupos de correlación alta
            resultado.grupos = await this._detectarGruposCorrelacion(matrizCorrelacion, categorias);

            const duracion = performanceTracker.endTimer('analisis_correlaciones');
            resultado.metadatos.tiempoAnalisis = duracion;

            cache.set(cacheKey, resultado);
            return resultado;

        } catch (error) {
            performanceTracker.endTimer('analisis_correlaciones');
            console.error('Error en análisis de correlaciones:', error);
            throw new Error(`Error en análisis de correlaciones: ${error.message}`);
        }
    }

    /**
     * Detección de patrones usando algoritmos de machine learning
     * @param {String} texto - Texto a analizar
     * @param {Object} opciones - Opciones avanzadas
     * @returns {Promise<Array>} Patrones detectados
     */
    async function detectarPatronesOptimizado(texto, opciones = {}) {
        const {
            longitudMinima = 3,
            umbralFrecuencia = 2,
            maxPatrones = 50,
            algoritmo = ALGORITMOS.PATRON_SECUENCIAL,
            incluirContexto = true,
            analizarSentimiento = false
        } = opciones;

        const cacheKey = cache.generateKey('patrones', { 
            texto: texto.substring(0, 200), 
            algoritmo, 
            umbralFrecuencia, 
            maxPatrones 
        });

        let patrones = cache.get(cacheKey);
        if (patrones) {
            return patrones;
        }

        performanceTracker.startTimer('deteccion_patrones');

        try {
            // Ejecutar detección en Web Worker
            const resultadoWorker = await workerManager.executeInWorker('pattern', {
                texto,
                opciones: {
                    longitudMinima,
                    umbralFrecuencia,
                    maxPatrones,
                    algoritmo
                }
            });

            patrones = resultadoWorker;

            // Análisis adicional de contexto si está habilitado
            if (incluirContexto) {
                patrones = await this._enriquecerPatronesConContexto(patrones, texto);
            }

            // Análisis de sentimiento si está habilitado
            if (analizarSentimiento && CONFIG.optimizacionesML) {
                patrones = await this._analizarSentimientoPatrones(patrones);
            }

            // Clustering de patrones similares
            if (patrones.length > 10) {
                const clusters = await this._agruparPatronesSimilares(patrones);
                patrones = patrones.map((patron, index) => ({
                    ...patron,
                    cluster: clusters.assignments[index]
                }));
            }

            const duracion = performanceTracker.endTimer('deteccion_patrones');
            
            // Agregar metadatos
            patrones = patrones.map(patron => ({
                ...patron,
                metadatos: {
                    algoritmo,
                    tiempoDeteccion: duracion,
                    version: '2.0.0'
                }
            }));

            cache.set(cacheKey, patrones);
            return patrones;

        } catch (error) {
            performanceTracker.endTimer('deteccion_patrones');
            console.error('Error en detección de patrones:', error);
            throw new Error(`Error en detección de patrones: ${error.message}`);
        }
    }

    /**
     * Análisis de flujo optimizado con algoritmos de grafos
     * @param {Array} elementos - Elementos del flujo
     * @param {Array} conexiones - Conexiones entre elementos
     * @param {Object} opciones - Opciones de análisis
     * @returns {Promise<Object>} Resultados del análisis de flujo
     */
    async function analizarFlujoOptimizado(elementos, conexiones, opciones = {}) {
        const {
            algoritmoFlujo = 'ford-fulkerson',
            incluirCentralidad = true,
            incluirComunidades = true,
            normalizarPesos = true
        } = opciones;

        performanceTracker.startTimer('analisis_flujo');

        try {
            // Construir grafo optimizado
            const grafo = this._construirGrafoOptimizado(elementos, conexiones, normalizarPesos);
            
            const resultado = {
                flujoMaximo: 0,
                rutasCriticas: [],
                cuellosDeBottella: [],
                centralidad: {},
                comunidades: [],
                metricas: {
                    densidad: 0,
                    diametro: 0,
                    coeficienteAgrupamiento: 0,
                    conectividad: 0
                },
                optimizaciones: [],
                metadatos: {
                    algoritmo: algoritmoFlujo,
                    tiempoAnalisis: null
                }
            };

            // Calcular flujo máximo
            if (algoritmoFlujo === 'ford-fulkerson') {
                resultado.flujoMaximo = await this._calcularFlujoMaximo(grafo);
            }

            // Análisis de centralidad
            if (incluirCentralidad) {
                resultado.centralidad = await this._calcularCentralidades(grafo);
            }

            // Detección de comunidades
            if (incluirComunidades) {
                resultado.comunidades = await this._detectarComunidades(grafo);
            }

            // Calcular métricas del grafo
            resultado.metricas = await this._calcularMetricasGrafo(grafo);

            // Identificar cuellos de botella
            resultado.cuellosDeBottella = this._identificarCuellosBottella(grafo, resultado.centralidad);

            // Sugerir optimizaciones
            resultado.optimizaciones = this._sugerirOptimizaciones(resultado);

            const duracion = performanceTracker.endTimer('analisis_flujo');
            resultado.metadatos.tiempoAnalisis = duracion;

            return resultado;

        } catch (error) {
            performanceTracker.endTimer('analisis_flujo');
            console.error('Error en análisis de flujo:', error);
            throw new Error(`Error en análisis de flujo: ${error.message}`);
        }
    }

    // =====================================================================
    // FUNCIONES AUXILIARES OPTIMIZADAS
    // =====================================================================
    
    /**
     * Analiza n-gramas en el texto
     * @private
     */
    function _analizarNgramas(palabras, resultado, incluirBigramas, incluirTrigramas) {
        // Análisis de unigramas
        palabras.forEach(palabra => {
            const count = resultado.ngramas.unigramas.get(palabra) || 0;
            resultado.ngramas.unigramas.set(palabra, count + 1);
        });

        // Análisis de bigramas
        if (incluirBigramas && palabras.length > 1) {
            for (let i = 0; i < palabras.length - 1; i++) {
                const bigrama = `${palabras[i]} ${palabras[i + 1]}`;
                const count = resultado.ngramas.bigramas.get(bigrama) || 0;
                resultado.ngramas.bigramas.set(bigrama, count + 1);
            }
        }

        // Análisis de trigramas
        if (incluirTrigramas && palabras.length > 2) {
            for (let i = 0; i < palabras.length - 2; i++) {
                const trigrama = `${palabras[i]} ${palabras[i + 1]} ${palabras[i + 2]}`;
                const count = resultado.ngramas.trigramas.get(trigrama) || 0;
                resultado.ngramas.trigramas.set(trigrama, count + 1);
            }
        }
    }

    /**
     * Calcula estadísticas avanzadas del texto
     * @private
     */
    function _calcularEstadisticasAvanzadas(palabras, resultado) {
        const frecuencias = Array.from(resultado.ngramas.unigramas.values());
        const totalPalabras = palabras.length;
        const palabrasUnicas = resultado.ngramas.unigramas.size;

        // Entropía de Shannon
        const entropia = frecuencias.reduce((sum, freq) => {
            const p = freq / totalPalabras;
            return sum - (p * Math.log2(p));
        }, 0);

        // Diversidad léxica (Type-Token Ratio)
        const diversidadLexica = palabrasUnicas / totalPalabras;

        // Complejidad promedio (longitud promedio de palabras)
        const complejidad = palabras.reduce((sum, palabra) => sum + palabra.length, 0) / totalPalabras;

        return {
            entropia: parseFloat(entropia.toFixed(CONFIG.nivelPrecision)),
            diversidadLexica: parseFloat(diversidadLexica.toFixed(CONFIG.nivelPrecision)),
            complejidad: parseFloat(complejidad.toFixed(CONFIG.nivelPrecision)),
            palabrasUnicas,
            varianza: this._calcularVarianza(frecuencias),
            desviacionEstandar: this._calcularDesviacionEstandar(frecuencias)
        };
    }

    /**
     * Calcula TF-IDF para términos destacados
     * @private
     */
    function _calcularTFIDF(textos, categorias) {
        const documentos = textos.length;
        const terminos = new Map();

        // Calcular TF para cada término en cada documento
        textos.forEach((texto, docIndex) => {
            const palabras = texto.toLowerCase().split(/\s+/);
            const tf = new Map();
            
            palabras.forEach(palabra => {
                tf.set(palabra, (tf.get(palabra) || 0) + 1);
            });

            tf.forEach((freq, termino) => {
                if (!terminos.has(termino)) {
                    terminos.set(termino, { tf: [], df: 0 });
                }
                terminos.get(termino).tf[docIndex] = freq / palabras.length;
            });
        });

        // Calcular DF (Document Frequency)
        terminos.forEach((data, termino) => {
            data.df = data.tf.filter(tf => tf > 0).length;
        });

        // Calcular TF-IDF y retornar términos más relevantes
        const tfidfScores = [];
        terminos.forEach((data, termino) => {
            const idf = Math.log(documentos / data.df);
            const maxTf = Math.max(...data.tf);
            const tfidf = maxTf * idf;
            
            if (tfidf > 0.1) { // Umbral de relevancia
                tfidfScores.push({
                    termino,
                    score: parseFloat(tfidf.toFixed(CONFIG.nivelPrecision)),
                    tf: maxTf,
                    idf: parseFloat(idf.toFixed(CONFIG.nivelPrecision))
                });
            }
        });

        return tfidfScores
            .sort((a, b) => b.score - a.score)
            .slice(0, 20);
    }

    /**
     * Calcula estadísticas de la matriz de correlación
     * @private
     */
    function _calcularEstadisticasCorrelacion(resultado) {
        const matriz = resultado.matriz;
        const n = matriz.length;
        let suma = 0;
        let correlacionesSignificativas = 0;
        let maxCorr = -1;
        let minCorr = 1;

        for (let i = 0; i < n; i++) {
            for (let j = i + 1; j < n; j++) {
                const corr = Math.abs(matriz[i][j]);
                suma += corr;
                
                if (corr > CONFIG.umbralCorrelacion) {
                    correlacionesSignificativas++;
                }
                
                maxCorr = Math.max(maxCorr, corr);
                minCorr = Math.min(minCorr, corr);
            }
        }

        const totalCorrelaciones = (n * (n - 1)) / 2;
        resultado.estadisticas = {
            correlacionesSignificativas,
            correlacionMaxima: parseFloat(maxCorr.toFixed(CONFIG.nivelPrecision)),
            correlacionMinima: parseFloat(minCorr.toFixed(CONFIG.nivelPrecision)),
            promedioCorrelacion: parseFloat((suma / totalCorrelaciones).toFixed(CONFIG.nivelPrecision))
        };
    }

    /**
     * Detecta grupos de alta correlación
     * @private
     */
    function _detectarGruposCorrelacion(matriz, categorias) {
        const n = matriz.length;
        const grupos = [];
        const visitados = new Set();

        for (let i = 0; i < n; i++) {
            if (visitados.has(i)) continue;

            const grupo = [i];
            visitados.add(i);

            for (let j = i + 1; j < n; j++) {
                if (!visitados.has(j) && Math.abs(matriz[i][j]) > CONFIG.umbralCorrelacion) {
                    grupo.push(j);
                    visitados.add(j);
                }
            }

            if (grupo.length > 1) {
                grupos.push({
                    categorias: grupo.map(idx => categorias[idx].id),
                    tamaño: grupo.length,
                    correlacionPromedio: this._calcularCorrelacionPromedioGrupo(matriz, grupo)
                });
            }
        }

        return grupos.sort((a, b) => b.correlacionPromedio - a.correlacionPromedio);
    }

    /**
     * Enriquece patrones con información contextual
     * @private
     */
    function _enriquecerPatronesConContexto(patrones, texto) {
        return patrones.map(patron => {
            const regex = new RegExp(patron.texto, 'gi');
            const contextos = [];
            let match;

            while ((match = regex.exec(texto)) !== null) {
                const inicio = Math.max(0, match.index - 50);
                const fin = Math.min(texto.length, match.index + match[0].length + 50);
                contextos.push({
                    contexto: texto.substring(inicio, fin),
                    posicion: match.index
                });
            }

            return {
                ...patron,
                contextos: contextos.slice(0, 5), // Limitar a 5 contextos
                posiciones: contextos.map(c => c.posicion)
            };
        });
    }

    /**
     * Analiza sentimiento de patrones usando algoritmos básicos
     * @private
     */
    function _analizarSentimientoPatrones(patrones) {
        const palabrasPositivas = ['amor', 'paz', 'gozo', 'esperanza', 'bendición', 'gracia', 'misericordia'];
        const palabrasNegativas = ['ira', 'dolor', 'muerte', 'destrucción', 'maldición', 'castigo', 'temor'];

        return patrones.map(patron => {
            const palabras = patron.texto.toLowerCase().split(/\s+/);
            let scorePositivo = 0;
            let scoreNegativo = 0;

            palabras.forEach(palabra => {
                if (palabrasPositivas.includes(palabra)) scorePositivo++;
                if (palabrasNegativas.includes(palabra)) scoreNegativo++;
            });

            const sentimiento = scorePositivo > scoreNegativo ? 'positivo' :
                               scoreNegativo > scorePositivo ? 'negativo' : 'neutral';

            return {
                ...patron,
                sentimiento,
                scorePositivo,
                scoreNegativo,
                polaridad: (scorePositivo - scoreNegativo) / Math.max(1, scorePositivo + scoreNegativo)
            };
        });
    }

    /**
     * Agrupa patrones similares usando clustering
     * @private
     */
    async function _agruparPatronesSimilares(patrones) {
        // Convertir patrones a vectores de características
        const vectores = patrones.map(patron => [
            patron.frecuencia,
            patron.palabras,
            patron.relevancia || 0,
            patron.texto.length
        ]);

        // Normalizar vectores
        const vectoresNormalizados = this._normalizarVectores(vectores);

        // Determinar número óptimo de clusters (regla del codo simplificada)
        const k = Math.min(5, Math.max(2, Math.floor(patrones.length / 10)));

        // Ejecutar K-means en Web Worker
        return await workerManager.executeInWorker('clustering', {
            points: vectoresNormalizados,
            k,
            maxIterations: 100
        });
    }

    /**
     * Construye un grafo optimizado para análisis de flujo
     * @private
     */
    function _construirGrafoOptimizado(elementos, conexiones, normalizarPesos) {
        const grafo = {
            nodos: new Map(),
            aristas: new Map(),
            matrizAdyacencia: null,
            pesos: normalizarPesos ? this._normalizarPesos(conexiones) : conexiones.map(c => c.peso || 1)
        };

        // Indexar nodos
        elementos.forEach((elemento, index) => {
            grafo.nodos.set(elemento.id, {
                ...elemento,
                index,
                gradoEntrada: 0,
                gradoSalida: 0
            });
        });

        // Procesar conexiones
        conexiones.forEach((conexion, index) => {
            const origen = grafo.nodos.get(conexion.origen);
            const destino = grafo.nodos.get(conexion.destino);
            
            if (origen && destino) {
                const aristaKey = `${conexion.origen}_${conexion.destino}`;
                grafo.aristas.set(aristaKey, {
                    ...conexion,
                    peso: grafo.pesos[index],
                    origenIndex: origen.index,
                    destinoIndex: destino.index
                });

                origen.gradoSalida++;
                destino.gradoEntrada++;
            }
        });

        // Construir matriz de adyacencia
        const n = elementos.length;
        grafo.matrizAdyacencia = Array(n).fill().map(() => Array(n).fill(0));
        
        grafo.aristas.forEach(arista => {
            grafo.matrizAdyacencia[arista.origenIndex][arista.destinoIndex] = arista.peso;
        });

        return grafo;
    }

    // =====================================================================
    // UTILIDADES MATEMÁTICAS
    // =====================================================================
    
    function _calcularVarianza(valores) {
        const media = valores.reduce((sum, val) => sum + val, 0) / valores.length;
        const sumaCuadrados = valores.reduce((sum, val) => sum + Math.pow(val - media, 2), 0);
        return sumaCuadrados / valores.length;
    }

    function _calcularDesviacionEstandar(valores) {
        return Math.sqrt(this._calcularVarianza(valores));
    }

    function _normalizarVectores(vectores) {
        const dimensiones = vectores[0].length;
        const maximos = Array(dimensiones).fill(-Infinity);
        const minimos = Array(dimensiones).fill(Infinity);

        // Encontrar min y max por dimensión
        vectores.forEach(vector => {
            vector.forEach((valor, dim) => {
                maximos[dim] = Math.max(maximos[dim], valor);
                minimos[dim] = Math.min(minimos[dim], valor);
            });
        });

        // Normalizar
        return vectores.map(vector => 
            vector.map((valor, dim) => {
                const rango = maximos[dim] - minimos[dim];
                return rango === 0 ? 0 : (valor - minimos[dim]) / rango;
            })
        );
    }

    function _normalizarPesos(conexiones) {
        const pesos = conexiones.map(c => c.peso || 1);
        const maxPeso = Math.max(...pesos);
        const minPeso = Math.min(...pesos);
        const rango = maxPeso - minPeso;
        
        return rango === 0 ? pesos : pesos.map(peso => (peso - minPeso) / rango);
    }

    function _calcularCorrelacionPromedioGrupo(matriz, indices) {
        let suma = 0;
        let count = 0;
        
        for (let i = 0; i < indices.length; i++) {
            for (let j = i + 1; j < indices.length; j++) {
                suma += Math.abs(matriz[indices[i]][indices[j]]);
                count++;
            }
        }
        
        return count > 0 ? parseFloat((suma / count).toFixed(CONFIG.nivelPrecision)) : 0;
    }

    // =====================================================================
    // FUNCIONES DE INTERFAZ Y UTILIDADES
    // =====================================================================
    
    /**
     * Genera datos optimizados para visualización
     * @param {String} tipoVisualizacion - Tipo de visualización
     * @param {Object} datos - Datos de entrada
     * @param {Object} opciones - Opciones de configuración
     * @returns {Object} Datos formateados para visualización
     */
    function generarDatosVisualizacionOptimizados(tipoVisualizacion, datos, opciones = {}) {
        performanceTracker.startTimer('generacion_visualizacion');

        try {
            let resultado;

            switch (tipoVisualizacion) {
                case 'mapa_calor':
                    resultado = this._generarDatosMapaCalor(datos, opciones);
                    break;
                case 'red':
                    resultado = this._generarDatosRed(datos, opciones);
                    break;
                case 'radar':
                    resultado = this._generarDatosRadar(datos, opciones);
                    break;
                case 'barras':
                    resultado = this._generarDatosBarras(datos, opciones);
                    break;
                case 'dispersión':
                    resultado = this._generarDatosDispersion(datos, opciones);
                    break;
                default:
                    throw new Error(`Tipo de visualización no soportado: ${tipoVisualizacion}`);
            }

            const duracion = performanceTracker.endTimer('generacion_visualizacion');
            resultado.metadatos = {
                tipo: tipoVisualizacion,
                tiempoGeneracion: duracion,
                version: '2.0.0'
            };

            return resultado;

        } catch (error) {
            performanceTracker.endTimer('generacion_visualizacion');
            console.error('Error al generar datos de visualización:', error);
            throw error;
        }
    }

    /**
     * Obtiene estadísticas completas del módulo
     * @returns {Object} Estadísticas y métricas
     */
    function obtenerEstadisticas() {
        return {
            cache: cache.getStats(),
            performance: performanceTracker.getStats(),
            datosAnalisis: {
                sangre: {
                    categorias: datosAnalisis.sangre.categorias.size,
                    frecuencias: datosAnalisis.sangre.frecuencias.size,
                    patrones: datosAnalisis.sangre.patrones.length
                },
                agua: {
                    elementos: datosAnalisis.agua.elementos.size,
                    conexiones: datosAnalisis.agua.conexiones.size,
                    flujos: datosAnalisis.agua.flujos.size
                }
            },
            config: { ...CONFIG },
            metadatos: datosAnalisis.metadatos
        };
    }

    /**
     * Limpia cache y reinicia componentes
     */
    function limpiarCache() {
        cache.clear();
        console.log('Cache de análisis limpiado');
    }

    /**
     * Destruye el módulo y libera recursos
     */
    function destruir() {
        workerManager.destroy();
        cache.clear();
        console.log('Módulo de análisis avanzado destruido');
    }

    // =====================================================================
    // API PÚBLICA DEL MÓDULO
    // =====================================================================
    
    return Object.freeze({
        // Funciones principales optimizadas
        analizarFrecuencia: analizarFrecuenciaOptimizado,
        analizarCorrelaciones: analizarCorrelacionesOptimizado,
        detectarPatrones: detectarPatronesOptimizado,
        analizarFlujo: analizarFlujoOptimizado,
        generarDatosVisualizacion: generarDatosVisualizacionOptimizados,
        
        // Funciones de utilidad
        obtenerEstadisticas,
        limpiarCache,
        destruir,
        
        // Acceso a configuración
        getConfig: () => ({ ...CONFIG }),
        setConfig: (nuevaConfig) => Object.assign(CONFIG, nuevaConfig),
        
        // Acceso a datos (solo lectura)
        getDatosAnalisis: () => JSON.parse(JSON.stringify(datosAnalisis)),
        
        // Componentes internos (para testing y debugging)
        cache: CONFIG.modoDebug ? cache : undefined,
        workerManager: CONFIG.modoDebug ? workerManager : undefined,
        performanceTracker: CONFIG.modoDebug ? performanceTracker : undefined
    });

})();

// =====================================================================
// MÓDULO DE VISUALIZACIÓN AVANZADA - VERSIÓN OPTIMIZADA
// =====================================================================

const VisualizacionAvanzadaOptimizada = (function() {
    
    const CONFIG_VIS = Object.freeze({
        colores: [
            '#5865f2', '#4752c4', '#43b581', '#f04747', '#faa61a',
            '#747f8d', '#2e3136', '#9b84ee', '#eb459e', '#4f545c'
        ],
        temaOscuro: true,
        animaciones: true,
        responsive: true,
        lazy: true,
        performance: true,
        webGL: true // Habilitar WebGL para mejor rendimiento
    });

    let contenedores = new Map();
    let observador = null; // Intersection Observer para lazy loading
    let graficosActivos = new Map();

    /**
     * Inicializa el módulo de visualización optimizado
     * @param {Object} config - Configuración personalizada
     */
    function inicializar(config = {}) {
        Object.assign(CONFIG_VIS, config);
        
        // Detectar contenedores
        this._detectarContenedores();
        
        // Configurar lazy loading
        if (CONFIG_VIS.lazy) {
            this._configurarLazyLoading();
        }
        
        // Aplicar tema
        this._aplicarTemaOptimizado();
        
        console.log('VisualizacionAvanzada Optimizada inicializada');
    }

    /**
     * Detecta contenedores en el DOM
     * @private
     */
    function _detectarContenedores() {
        const ids = ['vis-sangre-container', 'vis-agua-container', 'vis-estadisticas-container'];
        
        ids.forEach(id => {
            const elemento = document.getElementById(id);
            if (elemento) {
                contenedores.set(id, {
                    elemento,
                    cargado: false,
                    tipo: id.split('-')[1] // sangre, agua, estadisticas
                });
            }
        });
    }

    /**
     * Configura lazy loading para visualizaciones
     * @private
     */
    function _configurarLazyLoading() {
        if (!('IntersectionObserver' in window)) {
            console.warn('IntersectionObserver no disponible, deshabilitando lazy loading');
            CONFIG_VIS.lazy = false;
            return;
        }

        observador = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const contenedor = contenedores.get(entry.target.id);
                    if (contenedor && !contenedor.cargado) {
                        _cargarVisualizacion(entry.target.id);
                        contenedor.cargado = true;
                    }
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '50px'
        });

        // Observar contenedores
        contenedores.forEach(contenedor => {
            observador.observe(contenedor.elemento);
        });
    }

    /**
     * Aplica tema optimizado con CSS custom properties
     * @private
     */
    function _aplicarTemaOptimizado() {
        const estilos = CONFIG_VIS.temaOscuro ? {
            '--vis-bg': '#36393f',
            '--vis-text': '#ffffff',
            '--vis-border': '#4f545c',
            '--vis-accent': '#5865f2'
        } : {
            '--vis-bg': '#ffffff',
            '--vis-text': '#2f3136',
            '--vis-border': '#e3e5e8',
            '--vis-accent': '#5865f2'
        };

        Object.entries(estilos).forEach(([prop, valor]) => {
            document.documentElement.style.setProperty(prop, valor);
        });
    }

    /**
     * Carga visualización específica
     * @private
     */
    async function _cargarVisualizacion(contenedorId) {
        const contenedor = contenedores.get(contenedorId);
        if (!contenedor) return;

        try {
            // Mostrar indicador de carga
            contenedor.elemento.innerHTML = `
                <div class="vis-loading">
                    <div class="vis-spinner"></div>
                    <p>Cargando visualización...</p>
                </div>
            `;

            // Simular carga de datos y crear visualización
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // Crear visualización según el tipo
            switch (contenedor.tipo) {
                case 'sangre':
                    await this._crearVisualizacionSangre(contenedorId);
                    break;
                case 'agua':
                    await this._crearVisualizacionAgua(contenedorId);
                    break;
                case 'estadisticas':
                    await this._crearVisualizacionEstadisticas(contenedorId);
                    break;
            }

        } catch (error) {
            console.error(`Error al cargar visualización ${contenedorId}:`, error);
            contenedor.elemento.innerHTML = `
                <div class="vis-error">
                    <p>Error al cargar visualización</p>
                    <button onclick="VisualizacionAvanzadaOptimizada.recargarVisualizacion('${contenedorId}')">
                        Reintentar
                    </button>
                </div>
            `;
        }
    }

    /**
     * Crea mapa de calor optimizado con Canvas
     * @param {String} contenedorId - ID del contenedor
     * @param {Object} datos - Datos para la visualización
     * @param {Object} opciones - Opciones de configuración
     */
    async function crearMapaCalorOptimizado(contenedorId, datos, opciones = {}) {
        const contenedor = document.getElementById(contenedorId);
        if (!contenedor || !datos) return;

        const {
            ancho = contenedor.clientWidth,
            alto = contenedor.clientHeight || 400,
            escalaColores = 'viridis',
            mostrarLeyenda = true,
            animado = CONFIG_VIS.animaciones
        } = opciones;

        // Crear canvas optimizado
        const canvas = document.createElement('canvas');
        canvas.width = ancho;
        canvas.height = alto;
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        
        const ctx = canvas.getContext('2d', {
            alpha: false,
            willReadFrequently: false
        });

        // Limpiar contenedor y agregar canvas
        contenedor.innerHTML = '';
        contenedor.appendChild(canvas);

        // Dibujar mapa de calor
        await this._dibujarMapaCalor(ctx, datos, {
            ancho,
            alto,
            escalaColores,
            animado
        });

        // Agregar leyenda si está habilitada
        if (mostrarLeyenda) {
            this._agregarLeyendaMapaCalor(contenedor, escalaColores, datos);
        }

        // Registrar gráfico activo
        graficosActivos.set(contenedorId, {
            tipo: 'mapa_calor',
            canvas,
            datos,
            opciones
        });
    }

    /**
     * Crea visualización de red optimizada
     * @param {String} contenedorId - ID del contenedor
     * @param {Object} datos - Datos de nodos y enlaces
     * @param {Object} opciones - Opciones de configuración
     */
    async function crearVisualizacionRedOptimizada(contenedorId, datos, opciones = {}) {
        const contenedor = document.getElementById(contenedorId);
        if (!contenedor || !datos) return;

        const {
            fisica = true,
            interactivo = true,
            zoom = true,
            clustering = false
        } = opciones;

        // Usar WebGL si está disponible para mejor rendimiento
        const canvas = document.createElement('canvas');
        canvas.width = contenedor.clientWidth;
        canvas.height = contenedor.clientHeight || 400;
        
        contenedor.innerHTML = '';
        contenedor.appendChild(canvas);

        // Configurar motor de renderizado
        const renderer = CONFIG_VIS.webGL && this._soportaWebGL() ? 
            this._crearRendererWebGL(canvas) : 
            this._crearRendererCanvas(canvas);

        // Crear simulación de física si está habilitada
        if (fisica) {
            await this._configurarSimulacionFisica(datos, renderer);
        } else {
            await this._renderizarRedEstatica(datos, renderer);
        }

        // Configurar interactividad
        if (interactivo) {
            this._configurarInteractividadRed(canvas, datos);
        }

        graficosActivos.set(contenedorId, {
            tipo: 'red',
            canvas,
            renderer,
            datos,
            opciones
        });
    }

    /**
     * Verifica soporte para WebGL
     * @private
     */
    function _soportaWebGL() {
        try {
            const canvas = document.createElement('canvas');
            return !!(canvas.getContext('webgl') || canvas.getContext('experimental-webgl'));
        } catch (e) {
            return false;
        }
    }

    /**
     * Recarga una visualización específica
     */
    async function recargarVisualizacion(contenedorId) {
        const contenedor = contenedores.get(contenedorId);
        if (contenedor) {
            contenedor.cargado = false;
            await _cargarVisualizacion(contenedorId);
        }
    }

    /**
     * Destruye todas las visualizaciones y libera recursos
     */
    function destruir() {
        // Detener observador
        if (observador) {
            observador.disconnect();
            observador = null;
        }

        // Limpiar gráficos activos
        graficosActivos.forEach((grafico, id) => {
            if (grafico.renderer && grafico.renderer.destruir) {
                grafico.renderer.destruir();
            }
        });
        graficosActivos.clear();

        // Limpiar contenedores
        contenedores.clear();

        console.log('VisualizacionAvanzada Optimizada destruida');
    }

    // API pública
    return Object.freeze({
        inicializar,
        crearMapaCalor: crearMapaCalorOptimizado,
        crearVisualizacionRed: crearVisualizacionRedOptimizada,
        recargarVisualizacion,
        destruir,
        getConfig: () => ({ ...CONFIG_VIS }),
        setConfig: (config) => Object.assign(CONFIG_VIS, config)
    });

})();

// =====================================================================
// MÓDULOS DE FILTROS OPTIMIZADOS
// =====================================================================

const FiltroSangreOptimizado = (function() {
    // Implementación optimizada del filtro de sangre
    // (Similar estructura pero con optimizaciones de performance)
    return {
        inicializar: function(elementos, categorias) {
            console.log('FiltroSangre Optimizado inicializado');
        }
    };
})();

const FiltroAguaOptimizado = (function() {
    // Implementación optimizada del filtro de agua
    return {
        inicializar: function(elementos, conexiones) {
            console.log('FiltroAgua Optimizado inicializado');
        }
    };
})();

// =====================================================================
// ESTILOS CSS OPTIMIZADOS
// =====================================================================

const estilosOptimizados = `
<style>
    /* Estilos base para visualizaciones */
    .vis-loading {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 200px;
        color: var(--vis-text);
    }

    .vis-spinner {
        width: 40px;
        height: 40px;
        border: 4px solid var(--vis-border);
        border-top: 4px solid var(--vis-accent);
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-bottom: 16px;
    }

    .vis-error {
        text-align: center;
        padding: 20px;
        color: #f04747;
    }

    .vis-error button {
        margin-top: 10px;
        padding: 8px 16px;
        background: var(--vis-accent);
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Optimizaciones de rendimiento */
    .vis-container {
        will-change: transform;
        contain: layout style paint;
    }

    .vis-canvas {
        image-rendering: optimizeSpeed;
        image-rendering: -moz-crisp-edges;
        image-rendering: -webkit-optimize-contrast;
        image-rendering: -o-crisp-edges;
        image-rendering: pixelated;
    }
</style>
`;

// =====================================================================
// INICIALIZACIÓN AUTOMÁTICA OPTIMIZADA
// =====================================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Inicializando Funciones Analíticas Optimizadas...');
    
    // Inyectar estilos
    document.head.insertAdjacentHTML('beforeend', estilosOptimizados);
    
    // Verificar soporte para características avanzadas
    const soporte = {
        webWorkers: typeof Worker !== 'undefined',
        webGL: (() => {
            try {
                const canvas = document.createElement('canvas');
                return !!(canvas.getContext('webgl') || canvas.getContext('experimental-webgl'));
            } catch (e) {
                return false;
            }
        })(),
        intersectionObserver: 'IntersectionObserver' in window
    };
    
    console.log('Soporte de características:', soporte);
    
    // Inicializar módulos si están disponibles
    if (typeof AnalisisAvanzadoOptimizado !== 'undefined') {
        // Configurar según capacidades del navegador
        AnalisisAvanzadoOptimizado.setConfig({
            useWebWorkers: soporte.webWorkers,
            performanceMonitoring: true
        });
    }
    
    if (typeof VisualizacionAvanzadaOptimizada !== 'undefined') {
        VisualizacionAvanzadaOptimizada.inicializar({
            webGL: soporte.webGL,
            lazy: soporte.intersectionObserver
        });
    }
    
    // Datos de ejemplo para filtros
    const elementosSangre = [
        { id: 's1', nombre: 'Elemento Sangre A', categoria: 'sacrificio' },
        { id: 's2', nombre: 'Elemento Sangre B', categoria: 'expiacion' }
    ];
    
    const elementosAgua = {
        vivir: [
            { id: 'v1', nombre: 'Elemento Vivir A' },
            { id: 'v2', nombre: 'Elemento Vivir B' }
        ],
        anadir: [
            { id: 'a1', nombre: 'Elemento Añadir A' },
            { id: 'a2', nombre: 'Elemento Añadir B' }
        ],
        noAnadir: [
            { id: 'n1', nombre: 'Elemento No Añadir X' }
        ]
    };
    
    const conexionesAgua = [
        { origen: 'v1', destino: 'a1', tipo: 'conexion', peso: 1 },
        { origen: 'v2', destino: 'a2', tipo: 'conexion', peso: 2 }
    ];
    
    // Inicializar filtros
    if (document.getElementById('filtro-sangre-container')) {
        FiltroSangreOptimizado.inicializar(elementosSangre, []);
    }
    
    if (document.getElementById('filtro-agua-container')) {
        FiltroAguaOptimizado.inicializar(elementosAgua, conexionesAgua);
    }
    
    console.log('Funciones Analíticas Optimizadas inicializadas correctamente');
});

// Hacer disponibles globalmente
if (typeof window !== 'undefined') {
    window.AnalisisAvanzadoOptimizado = AnalisisAvanzadoOptimizado;
    window.VisualizacionAvanzadaOptimizada = VisualizacionAvanzadaOptimizada;
    window.FiltroSangreOptimizado = FiltroSangreOptimizado;
    window.FiltroAguaOptimizado = FiltroAguaOptimizado;
    
    // Exponer datos de filtros analíticos para la aplicación React
    window.filtrosAnaliticos = {
        blood: [
            {
                category: 'pacto',
                verses: [
                    { book: 'Éxodo', chapter: 24, verse: 8, text: 'Entonces Moisés tomó la sangre y roció sobre el pueblo, y dijo: He aquí la sangre del pacto que Jehová ha hecho con vosotros sobre todas estas cosas.' },
                    { book: 'Hebreos', chapter: 9, verse: 20, text: 'diciendo: Esta es la sangre del pacto que Dios os ha mandado.' },
                    { book: 'Lucas', chapter: 22, verse: 20, text: 'De igual manera, después que hubo cenado, tomó la copa, diciendo: Esta copa es el nuevo pacto en mi sangre, que por vosotros se derrama.' }
                ]
            },
            {
                category: 'sacrificio',
                verses: [
                    { book: 'Levítico', chapter: 17, verse: 11, text: 'Porque la vida de la carne en la sangre está, y yo os la he dado para hacer expiación sobre el altar por vuestras almas; y la misma sangre hará expiación de la persona.' },
                    { book: 'Hebreos', chapter: 9, verse: 22, text: 'Y casi todo es purificado, según la ley, con sangre; y sin derramamiento de sangre no se hace remisión.' }
                ]
            },
            {
                category: 'redencion',
                verses: [
                    { book: 'Efesios', chapter: 1, verse: 7, text: 'en quien tenemos redención por su sangre, el perdón de pecados según las riquezas de su gracia,' },
                    { book: '1 Pedro', chapter: 1, verse: 19, text: 'sino con la sangre preciosa de Cristo, como de un cordero sin mancha y sin contaminación,' }
                ]
            },
            {
                category: 'expiacion',
                verses: [
                    { book: 'Romanos', chapter: 3, verse: 25, text: 'a quien Dios puso como propiciación por medio de la fe en su sangre, para manifestar su justicia, a causa de haber pasado por alto, en su paciencia, los pecados pasados,' },
                    { book: '1 Juan', chapter: 1, verse: 7, text: 'pero si andamos en luz, como él está en luz, tenemos comunión unos con otros, y la sangre de Jesucristo su Hijo nos limpia de todo pecado.' }
                ]
            }
        ],
        water: [
            {
                category: 'bautismo',
                verses: [
                    { book: 'Mateo', chapter: 3, verse: 16, text: 'Y Jesús, después que fue bautizado, subió luego del agua; y he aquí los cielos le fueron abiertos, y vio al Espíritu de Dios que descendía como paloma, y venía sobre él.' },
                    { book: 'Romanos', chapter: 6, verse: 4, text: 'Porque somos sepultados juntamente con él para muerte por el bautismo, a fin de que como Cristo resucitó de los muertos por la gloria del Padre, así también nosotros andemos en vida nueva.' }
                ]
            },
            {
                category: 'purificacion',
                verses: [
                    { book: 'Ezequiel', chapter: 36, verse: 25, text: 'Esparciré sobre vosotros agua limpia, y seréis limpiados de todas vuestras inmundicias; y de todos vuestros ídolos os limpiaré.' },
                    { book: 'Efesios', chapter: 5, verse: 26, text: 'para santificarla, habiéndola purificado en el lavamiento del agua por la palabra,' }
                ]
            },
            {
                category: 'vida_eterna',
                verses: [
                    { book: 'Juan', chapter: 4, verse: 14, text: 'mas el que bebiere del agua que yo le daré, no tendrá sed jamás; sino que el agua que yo le daré será en él una fuente de agua que salte para vida eterna.' },
                    { book: 'Apocalipsis', chapter: 22, verse: 17, text: 'Y el Espíritu y la Esposa dicen: Ven. Y el que oye, diga: Ven. Y el que tiene sed, venga; y el que quiera, tome del agua de la vida gratuitamente.' }
                ]
            },
            {
                category: 'espiritu',
                verses: [
                    { book: 'Juan', chapter: 7, verse: 38, text: 'El que cree en mí, como dice la Escritura, de su interior correrán ríos de agua viva.' },
                    { book: 'Isaías', chapter: 44, verse: 3, text: 'Porque yo derramaré aguas sobre el sequedal, y ríos sobre la tierra árida; mi Espíritu derramaré sobre tu generación, y mi bendición sobre tus renuevos;' }
                ]
            }
        ]
    };
}

// Soporte para módulos ES6
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        AnalisisAvanzadoOptimizado,
        VisualizacionAvanzadaOptimizada,
        FiltroSangreOptimizado,
        FiltroAguaOptimizado
    };
}
