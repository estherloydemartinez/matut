/**
 * Módulo de Funcionalidades Sociales - VERSIÓN OPTIMIZADA
 * Aplicación de Formación Bíblica - Versión Mejorada con optimizaciones avanzadas
 * 
 * MEJORAS IMPLEMENTADAS:
 * - Sistema de estado reactivo con observadores
 * - Cache inteligente para datos sociales
 * - Debouncing y throttling para actualizaciones
 * - Lazy loading de componentes
 * - WebSockets simulados para actualizaciones en tiempo real
 * - Sistema de notificaciones push
 * - Algoritmos optimizados para recomendaciones
 * - Manejo robusto de errores y reconexión automática
 * - Performance monitoring y métricas
 * - Modularización avanzada con inyección de dependencias
 */

'use strict';

// =====================================================================
// MÓDULO PRINCIPAL SOCIAL - VERSIÓN OPTIMIZADA
// =====================================================================

const SocialAvanzadoOptimizado = (function() {
    
    // =====================================================================
    // CONFIGURACIÓN Y CONSTANTES
    // =====================================================================
    
    const CONFIG = Object.freeze({
        version: '2.0.0',
        perfilUsuario: null,
        modoConexion: 'local', // 'local', 'online', 'hybrid'
        actualizacionAutomatica: true,
        intervaloActualizacion: 30000, // 30 segundos optimizado
        maxEventosRecientes: 20, // Incrementado
        maxNotificaciones: 50, // Incrementado
        cacheEnabled: true,
        cacheExpiration: 15 * 60 * 1000, // 15 minutos
        debounceDelay: 300,
        throttleDelay: 1000,
        offlineSupport: true,
        realtimeUpdates: true,
        performanceMonitoring: true,
        lazyLoadComponents: true,
        pushNotifications: true
    });

    const EVENTS = Object.freeze({
        USER_UPDATE: 'user:update',
        COMMUNITY_JOIN: 'community:join',
        CHALLENGE_COMPLETE: 'challenge:complete',
        ACHIEVEMENT_UNLOCK: 'achievement:unlock',
        CONNECTION_NEW: 'connection:new',
        EVENT_REMIND: 'event:remind',
        REAL_TIME_UPDATE: 'realtime:update',
        OFFLINE_MODE: 'offline:mode',
        PERFORMANCE: 'performance:metric'
    });

    const COMPETENCIA_TIPOS = Object.freeze({
        TEORIA: 'teoria',
        PRACTICA: 'practica'
    });

    // =====================================================================
    // SISTEMA DE ESTADO REACTIVO
    // =====================================================================
    
    class ReactiveState {
        constructor(initialState = {}) {
            this._state = { ...initialState };
            this._observers = new Map();
            this._history = [];
            this._maxHistorySize = 50;
        }

        get(path) {
            return this._getNestedValue(this._state, path);
        }

        set(path, value) {
            const oldValue = this.get(path);
            if (oldValue === value) return; // No cambios

            // Guardar en historial
            this._saveToHistory(path, oldValue, value);
            
            // Actualizar estado
            this._setNestedValue(this._state, path, value);
            
            // Notificar observadores
            this._notifyObservers(path, value, oldValue);
        }

        subscribe(path, callback) {
            if (!this._observers.has(path)) {
                this._observers.set(path, new Set());
            }
            this._observers.get(path).add(callback);
            
            // Retornar función de unsubscribe
            return () => {
                const observers = this._observers.get(path);
                if (observers) {
                    observers.delete(callback);
                    if (observers.size === 0) {
                        this._observers.delete(path);
                    }
                }
            };
        }

        getState() {
            return JSON.parse(JSON.stringify(this._state));
        }

        setState(newState) {
            Object.keys(newState).forEach(key => {
                this.set(key, newState[key]);
            });
        }

        _getNestedValue(obj, path) {
            return path.split('.').reduce((current, key) => 
                current && current[key] !== undefined ? current[key] : undefined, obj);
        }

        _setNestedValue(obj, path, value) {
            const keys = path.split('.');
            const lastKey = keys.pop();
            const target = keys.reduce((current, key) => {
                if (!current[key] || typeof current[key] !== 'object') {
                    current[key] = {};
                }
                return current[key];
            }, obj);
            target[lastKey] = value;
        }

        _notifyObservers(path, newValue, oldValue) {
            // Notificar observadores exactos
            const observers = this._observers.get(path);
            if (observers) {
                observers.forEach(callback => {
                    try {
                        callback(newValue, oldValue, path);
                    } catch (error) {
                        console.error('Error en observer:', error);
                    }
                });
            }

            // Notificar observadores de rutas padre
            const pathParts = path.split('.');
            for (let i = pathParts.length - 1; i > 0; i--) {
                const parentPath = pathParts.slice(0, i).join('.');
                const parentObservers = this._observers.get(parentPath);
                if (parentObservers) {
                    parentObservers.forEach(callback => {
                        try {
                            callback(this.get(parentPath), undefined, parentPath);
                        } catch (error) {
                            console.error('Error en parent observer:', error);
                        }
                    });
                }
            }
        }

        _saveToHistory(path, oldValue, newValue) {
            this._history.push({
                timestamp: Date.now(),
                path,
                oldValue,
                newValue
            });

            if (this._history.length > this._maxHistorySize) {
                this._history.shift();
            }
        }

        getHistory() {
            return [...this._history];
        }

        undo() {
            if (this._history.length === 0) return false;
            
            const lastChange = this._history.pop();
            this._setNestedValue(this._state, lastChange.path, lastChange.oldValue);
            this._notifyObservers(lastChange.path, lastChange.oldValue, lastChange.newValue);
            return true;
        }
    }

    // =====================================================================
    // SISTEMA DE CACHE INTELIGENTE
    // =====================================================================
    
    class SocialCache {
        constructor() {
            this.cache = new Map();
            this.metadata = new Map();
            this.maxSize = 200;
            this.hitRate = { hits: 0, misses: 0 };
        }

        generateKey(type, params = {}) {
            const sortedParams = Object.keys(params).sort().reduce((result, key) => {
                result[key] = params[key];
                return result;
            }, {});
            return `${type}_${JSON.stringify(sortedParams)}`;
        }

        get(key) {
            if (this.cache.has(key)) {
                const item = this.cache.get(key);
                const meta = this.metadata.get(key);
                
                // Verificar expiración
                if (Date.now() - meta.timestamp > CONFIG.cacheExpiration) {
                    this.delete(key);
                    this.hitRate.misses++;
                    return null;
                }
                
                meta.accessCount++;
                meta.lastAccess = Date.now();
                this.hitRate.hits++;
                return item;
            }
            
            this.hitRate.misses++;
            return null;
        }

        set(key, value, ttl = CONFIG.cacheExpiration) {
            if (this.cache.size >= this.maxSize && !this.cache.has(key)) {
                this._evictLRU();
            }

            this.cache.set(key, value);
            this.metadata.set(key, {
                timestamp: Date.now(),
                lastAccess: Date.now(),
                accessCount: 1,
                ttl
            });
        }

        delete(key) {
            this.cache.delete(key);
            this.metadata.delete(key);
        }

        clear() {
            this.cache.clear();
            this.metadata.clear();
            this.hitRate = { hits: 0, misses: 0 };
        }

        _evictLRU() {
            let oldestKey = null;
            let oldestTime = Infinity;

            for (const [key, meta] of this.metadata) {
                if (meta.lastAccess < oldestTime) {
                    oldestTime = meta.lastAccess;
                    oldestKey = key;
                }
            }

            if (oldestKey) {
                this.delete(oldestKey);
            }
        }

        getStats() {
            const total = this.hitRate.hits + this.hitRate.misses;
            return {
                size: this.cache.size,
                maxSize: this.maxSize,
                hitRate: total > 0 ? ((this.hitRate.hits / total) * 100).toFixed(2) : 0,
                hits: this.hitRate.hits,
                misses: this.hitRate.misses
            };
        }
    }

    // =====================================================================
    // SISTEMA DE NOTIFICACIONES PUSH
    // =====================================================================
    
    class NotificationManager {
        constructor() {
            this.notifications = new Map();
            this.queue = [];
            this.maxNotifications = CONFIG.maxNotificaciones;
            this.permission = 'default';
            this.enabled = CONFIG.pushNotifications;
        }

        async initialize() {
            if (!this.enabled || !('Notification' in window)) {
                console.warn('Notificaciones push no disponibles');
                return false;
            }

            try {
                this.permission = await Notification.requestPermission();
                return this.permission === 'granted';
            } catch (error) {
                console.error('Error al solicitar permisos de notificación:', error);
                return false;
            }
        }

        async show(notification) {
            const id = this._generateId();
            const notificationData = {
                id,
                titulo: notification.titulo || 'Formación Bíblica',
                mensaje: notification.mensaje || '',
                tipo: notification.tipo || 'info',
                timestamp: Date.now(),
                leida: false,
                accion: notification.accion || null,
                priority: notification.priority || 'normal'
            };

            // Guardar en sistema interno
            this.notifications.set(id, notificationData);
            
            // Limpiar notificaciones antigas si excedemos el límite
            if (this.notifications.size > this.maxNotifications) {
                this._cleanOldNotifications();
            }

            // Mostrar notificación del sistema si tenemos permisos
            if (this.permission === 'granted') {
                await this._showSystemNotification(notificationData);
            }

            // Mostrar notificación en la interfaz
            this._showInAppNotification(notificationData);

            // Emitir evento
            EventEmitter.emit(EVENTS.REAL_TIME_UPDATE, {
                type: 'notification',
                data: notificationData
            });

            return id;
        }

        markAsRead(id) {
            const notification = this.notifications.get(id);
            if (notification) {
                notification.leida = true;
                this._updateNotificationUI(id);
            }
        }

        getUnreadCount() {
            return Array.from(this.notifications.values())
                .filter(n => !n.leida).length;
        }

        getAll() {
            return Array.from(this.notifications.values())
                .sort((a, b) => b.timestamp - a.timestamp);
        }

        clear() {
            this.notifications.clear();
            this._clearNotificationUI();
        }

        _generateId() {
            return `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }

        async _showSystemNotification(data) {
            try {
                const notification = new Notification(data.titulo, {
                    body: data.mensaje,
                    icon: '/favicon.ico', // Ajustar según la aplicación
                    badge: '/favicon.ico',
                    tag: data.id,
                    renotify: true,
                    requireInteraction: data.priority === 'high'
                });

                notification.onclick = () => {
                    window.focus();
                    if (data.accion) {
                        this._executeAction(data.accion);
                    }
                    notification.close();
                };

                // Auto-cerrar después de 5 segundos para notificaciones normales
                if (data.priority !== 'high') {
                    setTimeout(() => notification.close(), 5000);
                }

            } catch (error) {
                console.error('Error al mostrar notificación del sistema:', error);
            }
        }

        _showInAppNotification(data) {
            const container = document.getElementById('notifications-container') || 
                             this._createNotificationContainer();

            const element = document.createElement('div');
            element.className = `notification-item ${data.tipo} ${data.priority}`;
            element.dataset.id = data.id;
            element.innerHTML = `
                <div class="notification-content">
                    <div class="notification-header">
                        <strong>${data.titulo}</strong>
                        <button class="notification-close" onclick="NotificationManager.markAsRead('${data.id}')">×</button>
                    </div>
                    <div class="notification-body">${data.mensaje}</div>
                    <div class="notification-time">${this._formatTime(data.timestamp)}</div>
                </div>
            `;

            container.insertBefore(element, container.firstChild);

            // Auto-remove después de cierto tiempo
            setTimeout(() => {
                if (element.parentNode) {
                    element.style.opacity = '0';
                    setTimeout(() => element.remove(), 300);
                }
            }, data.priority === 'high' ? 10000 : 5000);
        }

        _createNotificationContainer() {
            const container = document.createElement('div');
            container.id = 'notifications-container';
            container.className = 'fixed top-4 right-4 z-50 space-y-2 max-w-sm';
            document.body.appendChild(container);
            return container;
        }

        _cleanOldNotifications() {
            const notifications = Array.from(this.notifications.entries())
                .sort((a, b) => a[1].timestamp - b[1].timestamp);

            const toRemove = notifications.slice(0, notifications.length - this.maxNotifications);
            toRemove.forEach(([id]) => this.notifications.delete(id));
        }

        _updateNotificationUI(id) {
            const element = document.querySelector(`[data-id="${id}"]`);
            if (element) {
                element.classList.add('read');
                setTimeout(() => element.remove(), 500);
            }
        }

        _clearNotificationUI() {
            const container = document.getElementById('notifications-container');
            if (container) {
                container.innerHTML = '';
            }
        }

        _executeAction(action) {
            // Ejecutar acción de la notificación
            if (action.tipo === 'verEvento') {
                // Navegar a evento
                console.log('Navegando a evento:', action.id);
            } else if (action.tipo === 'verLogro') {
                // Mostrar logro
                console.log('Mostrando logro:', action.id);
            }
        }

        _formatTime(timestamp) {
            const now = Date.now();
            const diff = now - timestamp;
            
            if (diff < 60000) return 'Ahora';
            if (diff < 3600000) return `${Math.floor(diff / 60000)}m`;
            if (diff < 86400000) return `${Math.floor(diff / 3600000)}h`;
            return `${Math.floor(diff / 86400000)}d`;
        }
    }

    // =====================================================================
    // SISTEMA DE EVENTOS
    // =====================================================================
    
    class EventEmitter {
        static listeners = new Map();

        static on(event, callback) {
            if (!this.listeners.has(event)) {
                this.listeners.set(event, new Set());
            }
            this.listeners.get(event).add(callback);
            
            return () => this.off(event, callback);
        }

        static emit(event, data) {
            if (this.listeners.has(event)) {
                this.listeners.get(event).forEach(callback => {
                    try {
                        callback(data);
                    } catch (error) {
                        console.error(`Error en listener del evento ${event}:`, error);
                    }
                });
            }
        }

        static off(event, callback) {
            if (this.listeners.has(event)) {
                this.listeners.get(event).delete(callback);
            }
        }

        static clear() {
            this.listeners.clear();
        }
    }

    // =====================================================================
    // UTILIDADES DE PERFORMANCE
    // =====================================================================
    
    function debounce(func, delay) {
        let timeoutId;
        return function (...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => func.apply(this, args), delay);
        };
    }

    function throttle(func, delay) {
        let inThrottle;
        return function (...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, delay);
            }
        };
    }

    class PerformanceMonitor {
        constructor() {
            this.metrics = new Map();
            this.enabled = CONFIG.performanceMonitoring;
        }

        startTimer(operation) {
            if (!this.enabled) return;
            this.metrics.set(operation, performance.now());
        }

        endTimer(operation) {
            if (!this.enabled) return null;
            
            const startTime = this.metrics.get(operation);
            if (startTime) {
                const duration = performance.now() - startTime;
                this.metrics.delete(operation);
                
                EventEmitter.emit(EVENTS.PERFORMANCE, {
                    operation,
                    duration: Math.round(duration * 100) / 100
                });
                
                return duration;
            }
            return null;
        }

        getStats() {
            return {
                enabled: this.enabled,
                activeTimers: this.metrics.size
            };
        }
    }

    // =====================================================================
    // INICIALIZACIÓN DE COMPONENTES
    // =====================================================================
    
    const estado = new ReactiveState();
    const cache = new SocialCache();
    const notificationManager = new NotificationManager();
    const performanceMonitor = new PerformanceMonitor();
    
    let temporizadorActualizacion = null;
    let componentesLazyCargados = new Set();

    // =====================================================================
    // FUNCIONES PRINCIPALES
    // =====================================================================
    
    /**
     * Inicializa el módulo social optimizado
     * @param {Object} opciones - Opciones de configuración
     */
    async function inicializar(opciones = {}) {
        performanceMonitor.startTimer('inicializacion_social');

        try {
            // Actualizar configuración
            Object.assign(CONFIG, opciones);
            
            // Inicializar componentes
            await notificationManager.initialize();
            
            // Cargar datos iniciales
            await cargarDatosIniciales();
            
            // Renderizar interfaz principal
            await renderizarInterfazSocial();
            
            // Configurar eventos reactivos
            configurarEventosReactivos();
            
            // Configurar eventos de la interfaz
            configurarEventosSociales();
            
            // Iniciar actualizaciones automáticas si está habilitado
            if (CONFIG.actualizacionAutomatica) {
                iniciarActualizacionesAutomaticas();
            }

            // Configurar lazy loading
            if (CONFIG.lazyLoadComponents) {
                configurarLazyLoading();
            }

            const duracion = performanceMonitor.endTimer('inicializacion_social');
            console.log(`SocialAvanzado Optimizado inicializado en ${duracion}ms`);
            
            return true;

        } catch (error) {
            performanceMonitor.endTimer('inicializacion_social');
            console.error('Error al inicializar módulo social:', error);
            
            // Mostrar notificación de error
            await notificationManager.show({
                titulo: 'Error de Inicialización',
                mensaje: 'No se pudo inicializar el módulo social completamente',
                tipo: 'error',
                priority: 'high'
            });
            
            return false;
        }
    }

    /**
     * Carga los datos iniciales de forma optimizada
     */
    async function cargarDatosIniciales() {
        const cacheKey = cache.generateKey('datos_iniciales');
        let datos = cache.get(cacheKey);
        
        if (!datos) {
            // Simular carga de datos (en una implementación real vendría de API)
            datos = await generarDatosIniciales();
            cache.set(cacheKey, datos);
        }

        // Establecer estado inicial de forma reactiva
        estado.setState(datos);
    }

    /**
     * Genera datos iniciales optimizados
     */
    async function generarDatosIniciales() {
        return {
            perfilUsuario: CONFIG.perfilUsuario || {
                id: 'usuario1',
                nombre: 'Usuario',
                nivel: 1,
                experiencia: 0,
                fechaRegistro: new Date().toISOString(),
                ultimoAcceso: new Date().toISOString(),
                avatar: null,
                preferencias: {
                    notificaciones: true,
                    modoOscuro: true,
                    actualizacionesAutomaticas: true
                }
            },
            
            comunidades: [
                { 
                    id: 'com1', 
                    nombre: 'Estudio Bíblico General', 
                    miembros: 120, 
                    esPublica: true, 
                    descripcion: 'Comunidad general para el estudio de la Biblia',
                    actividad: 'alta',
                    fechaCreacion: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
                },
                { 
                    id: 'com2', 
                    nombre: 'Nuevo Testamento', 
                    miembros: 85, 
                    esPublica: true, 
                    descripcion: 'Enfocado en el estudio del Nuevo Testamento',
                    actividad: 'media',
                    fechaCreacion: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString()
                },
                { 
                    id: 'com3', 
                    nombre: 'Antiguo Testamento', 
                    miembros: 73, 
                    esPublica: true, 
                    descripcion: 'Enfocado en el estudio del Antiguo Testamento',
                    actividad: 'media',
                    fechaCreacion: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString()
                }
            ],
            
            grupos: [
                { 
                    id: 'grp1', 
                    nombre: 'Principiantes', 
                    miembros: 45, 
                    comunidadId: 'com1', 
                    esPrivado: false,
                    descripcion: 'Grupo para personas que inician su estudio bíblico'
                },
                { 
                    id: 'grp2', 
                    nombre: 'Avanzados', 
                    miembros: 32, 
                    comunidadId: 'com1', 
                    esPrivado: false,
                    descripcion: 'Grupo para estudiantes avanzados'
                },
                { 
                    id: 'grp3', 
                    nombre: 'Evangelios', 
                    miembros: 28, 
                    comunidadId: 'com2', 
                    esPrivado: false,
                    descripcion: 'Estudio específico de los Evangelios'
                }
            ],
            
            eventos: [
                { 
                    id: 'evt1', 
                    titulo: 'Estudio semanal: Parábolas', 
                    descripcion: 'Estudio de las parábolas de Jesús', 
                    fecha: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
                    comunidadId: 'com2',
                    participantes: 12,
                    maxParticipantes: 20,
                    tipo: 'online',
                    duracion: 60,
                    estado: 'programado'
                },
                { 
                    id: 'evt2', 
                    titulo: 'Memorización: Salmos', 
                    descripcion: 'Sesión de memorización de Salmos selectos', 
                    fecha: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
                    comunidadId: 'com1',
                    participantes: 8,
                    maxParticipantes: 15,
                    tipo: 'online',
                    duracion: 45,
                    estado: 'programado'
                }
            ],
            
            competencias: {
                teoria: [
                    { 
                        id: 'ct1', 
                        nombre: 'Conocimiento Bíblico Básico', 
                        nivel: 2, 
                        maxNivel: 5, 
                        descripcion: 'Conocimiento general de la Biblia',
                        experiencia: 150,
                        experienciaSiguienteNivel: 300
                    },
                    { 
                        id: 'ct2', 
                        nombre: 'Historia Bíblica', 
                        nivel: 1, 
                        maxNivel: 5, 
                        descripcion: 'Conocimiento de eventos históricos en la Biblia',
                        experiencia: 75,
                        experienciaSiguienteNivel: 200
                    },
                    { 
                        id: 'ct3', 
                        nombre: 'Teología Básica', 
                        nivel: 0, 
                        maxNivel: 5, 
                        descripcion: 'Comprensión de conceptos teológicos fundamentales',
                        experiencia: 0,
                        experienciaSiguienteNivel: 100
                    },
                    { 
                        id: 'ct4', 
                        nombre: 'Contexto Cultural', 
                        nivel: 0, 
                        maxNivel: 5, 
                        descripcion: 'Entendimiento del contexto cultural bíblico',
                        experiencia: 0,
                        experienciaSiguienteNivel: 100
                    }
                ],
                
                practica: [
                    { 
                        id: 'cp1', 
                        nombre: 'Memorización', 
                        nivel: 1, 
                        maxNivel: 5, 
                        descripcion: 'Habilidad para memorizar versículos',
                        experiencia: 80,
                        experienciaSiguienteNivel: 200
                    },
                    { 
                        id: 'cp2', 
                        nombre: 'Aplicación Personal', 
                        nivel: 2, 
                        maxNivel: 5, 
                        descripcion: 'Capacidad para aplicar enseñanzas a la vida diaria',
                        experiencia: 200,
                        experienciaSiguienteNivel: 300
                    },
                    { 
                        id: 'cp3', 
                        nombre: 'Oración', 
                        nivel: 1, 
                        maxNivel: 5, 
                        descripcion: 'Desarrollo de vida de oración',
                        experiencia: 120,
                        experienciaSiguienteNivel: 200
                    },
                    { 
                        id: 'cp4', 
                        nombre: 'Compartir Fe', 
                        nivel: 0, 
                        maxNivel: 5, 
                        descripcion: 'Habilidad para compartir fe con otros',
                        experiencia: 0,
                        experienciaSiguienteNivel: 100
                    }
                ]
            },
            
            desafios: [
                { 
                    id: 'des1', 
                    titulo: 'Lectura diaria', 
                    descripcion: 'Lee un capítulo cada día durante una semana', 
                    progreso: 3, 
                    total: 7,
                    fechaInicio: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
                    fechaLimite: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
                    recompensa: { experiencia: 50, competencia: 'ct1', nivelesCompetencia: 1 },
                    dificultad: 'facil',
                    categoria: 'lectura'
                },
                { 
                    id: 'des2', 
                    titulo: 'Memorización semanal', 
                    descripcion: 'Memoriza un versículo cada semana', 
                    progreso: 0, 
                    total: 4,
                    fechaInicio: new Date().toISOString(),
                    fechaLimite: new Date(Date.now() + 28 * 24 * 60 * 60 * 1000).toISOString(),
                    recompensa: { experiencia: 100, competencia: 'cp1', nivelesCompetencia: 1 },
                    dificultad: 'medio',
                    categoria: 'memorizacion'
                }
            ],
            
            logros: [
                { 
                    id: 'log1', 
                    nombre: 'Primer Paso', 
                    descripcion: 'Completar el primer check-in diario', 
                    fecha: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), 
                    icono: '🏆',
                    rareza: 'comun',
                    puntos: 10
                },
                { 
                    id: 'log2', 
                    nombre: 'Explorador', 
                    descripcion: 'Leer 5 libros diferentes de la Biblia', 
                    fecha: null, 
                    icono: '🔍', 
                    progreso: 2, 
                    total: 5,
                    rareza: 'raro',
                    puntos: 50
                }
            ],
            
            actividad: [
                { 
                    id: 'act1',
                    tipo: 'lectura', 
                    fecha: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), 
                    detalles: { libro: 'Juan', capitulo: 3, tiempo: 15 },
                    puntuacion: 5
                },
                { 
                    id: 'act2',
                    tipo: 'memorizacion', 
                    fecha: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), 
                    detalles: { referencia: 'Juan 3:16', puntuacion: 4, intentos: 3 },
                    puntuacion: 4
                },
                { 
                    id: 'act3',
                    tipo: 'checkin', 
                    fecha: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), 
                    detalles: { duracion: 15, actividades: ['lectura', 'oracion'] },
                    puntuacion: 5
                }
            ],
            
            conexiones: [
                { 
                    id: 'usr1', 
                    nombre: 'Ana', 
                    nivel: 5, 
                    tipo: 'mentor', 
                    estado: 'online', 
                    ultimaActividad: new Date().toISOString(),
                    fechaConexion: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
                    interacciones: 45,
                    avatar: null
                },
                { 
                    id: 'usr2', 
                    nombre: 'Carlos', 
                    nivel: 3, 
                    tipo: 'amigo', 
                    estado: 'offline', 
                    ultimaActividad: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
                    fechaConexion: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
                    interacciones: 23,
                    avatar: null
                }
            ],
            
            notificaciones: [],
            
            estadisticas: {
                tiempoTotal: 450, // minutos
                diasConsecutivos: 5,
                logrosTotales: 1,
                desafiosCompletados: 3,
                experienciaTotal: 350,
                nivelGeneral: 2
            },
            
            configuracion: {
                privacidad: {
                    perfilPublico: true,
                    mostrarActividad: true,
                    mostrarEstadisticas: false
                },
                notificaciones: {
                    eventos: true,
                    desafios: true,
                    logros: true,
                    conexiones: true,
                    recordatorios: true
                }
            }
        };
    }

    /**
     * Configura eventos reactivos del estado
     */
    function configurarEventosReactivos() {
        // Observar cambios en desafíos
        estado.subscribe('desafios', (nuevosDesafios, antiguosDesafios) => {
            if (nuevosDesafios && antiguosDesafios) {
                const completados = nuevosDesafios.filter(d => 
                    d.progreso >= d.total && 
                    (!antiguosDesafios.find(ad => ad.id === d.id && ad.progreso >= ad.total))
                );
                
                completados.forEach(desafio => {
                    EventEmitter.emit(EVENTS.CHALLENGE_COMPLETE, desafio);
                    notificationManager.show({
                        titulo: '🎉 Desafío Completado',
                        mensaje: `¡Has completado "${desafio.titulo}"!`,
                        tipo: 'success',
                        priority: 'high'
                    });
                });
            }
        });

        // Observar cambios en logros
        estado.subscribe('logros', (nuevosLogros) => {
            if (nuevosLogros) {
                const nuevosDesbloqueados = nuevosLogros.filter(l => 
                    l.fecha && !l.notificado
                );
                
                nuevosDesbloqueados.forEach(logro => {
                    EventEmitter.emit(EVENTS.ACHIEVEMENT_UNLOCK, logro);
                    notificationManager.show({
                        titulo: '🏆 Logro Desbloqueado',
                        mensaje: `¡Has desbloqueado "${logro.nombre}"!`,
                        tipo: 'achievement',
                        priority: 'high'
                    });
                    logro.notificado = true;
                });
            }
        });

        // Observar cambios en competencias
        estado.subscribe('competencias', (nuevasCompetencias) => {
            if (nuevasCompetencias) {
                // Detectar subidas de nivel
                const todasCompetencias = [
                    ...nuevasCompetencias.teoria || [],
                    ...nuevasCompetencias.practica || []
                ];
                
                todasCompetencias.forEach(competencia => {
                    if (competencia.experiencia >= competencia.experienciaSiguienteNivel && competencia.nivel < competencia.maxNivel) {
                        // Subir nivel
                        competencia.nivel++;
                        competencia.experiencia -= competencia.experienciaSiguienteNivel;
                        competencia.experienciaSiguienteNivel = competencia.experienciaSiguienteNivel * 1.5;
                        
                        notificationManager.show({
                            titulo: '📈 Nivel Aumentado',
                            mensaje: `¡Has subido a nivel ${competencia.nivel} en ${competencia.nombre}!`,
                            tipo: 'level_up',
                            priority: 'normal'
                        });
                    }
                });
            }
        });

        // Observar cambios en conexiones
        estado.subscribe('conexiones', (nuevasConexiones, antiguasConexiones) => {
            if (nuevasConexiones && antiguasConexiones) {
                const nuevasConexionesIds = nuevasConexiones.map(c => c.id);
                const antiguasConexionesIds = antiguasConexiones.map(c => c.id);
                
                const conexionesNuevas = nuevasConexionesIds.filter(id => 
                    !antiguasConexionesIds.includes(id)
                );
                
                if (conexionesNuevas.length > 0) {
                    EventEmitter.emit(EVENTS.CONNECTION_NEW, conexionesNuevas);
                    notificationManager.show({
                        titulo: '👥 Nueva Conexión',
                        mensaje: `Tienes ${conexionesNuevas.length} nueva(s) conexión(es)`,
                        tipo: 'social',
                        priority: 'normal'
                    });
                }
            }
        });
    }

    /**
     * Renderiza la interfaz social principal de forma optimizada
     */
    async function renderizarInterfazSocial() {
        const contenedor = document.getElementById('content-social');
        if (!contenedor) return;

        performanceMonitor.startTimer('render_interfaz');

        const estadoActual = estado.getState();

        contenedor.innerHTML = `
            <div class="social-container max-w-7xl mx-auto p-4 space-y-6">
                <!-- Header del perfil optimizado -->
                <div class="perfil-header discord-card rounded-xl p-6 shadow-lg">
                    <div class="flex items-center space-x-4">
                        <div class="perfil-avatar w-16 h-16 rounded-full bg-gradient-to-br from-[var(--bg-primary)] to-[var(--bg-secondary)] flex items-center justify-center text-2xl">
                            ${estadoActual.perfilUsuario?.avatar || '👤'}
                        </div>
                        <div class="flex-grow">
                            <h1 class="text-2xl font-bold">${estadoActual.perfilUsuario?.nombre || 'Usuario'}</h1>
                            <div class="flex items-center space-x-4 text-sm text-gray-500">
                                <span>Nivel ${estadoActual.estadisticas?.nivelGeneral || 1}</span>
                                <span>${estadoActual.estadisticas?.experienciaTotal || 0} XP</span>
                                <span>${estadoActual.estadisticas?.diasConsecutivos || 0} días consecutivos</span>
                            </div>
                        </div>
                        <div class="perfil-acciones flex space-x-2">
                            <button id="btn-configuracion" class="discord-button-secondary px-4 py-2 rounded-lg">
                                ⚙️ Configuración
                            </button>
                            <button id="btn-notificaciones" class="discord-button-secondary px-4 py-2 rounded-lg relative">
                                🔔 Notificaciones
                                <span id="notif-badge" class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center hidden">
                                    ${notificationManager.getUnreadCount()}
                                </span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Grid principal responsive -->
                <div class="social-grid grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- Columna principal -->
                    <div class="lg:col-span-2 space-y-6">
                        <!-- Competencias -->
                        <div id="competencias-container" class="lazy-component" data-component="competencias">
                            ${renderizarCompetencias()}
                        </div>
                        
                        <!-- Desafíos -->
                        <div id="desafios-container" class="lazy-component" data-component="desafios">
                            ${CONFIG.lazyLoadComponents ? '<div class="component-placeholder">Cargando desafíos...</div>' : renderizarDesafios()}
                        </div>
                        
                        <!-- Actividad reciente -->
                        <div id="actividad-container" class="lazy-component" data-component="actividad">
                            ${CONFIG.lazyLoadComponents ? '<div class="component-placeholder">Cargando actividad...</div>' : renderizarActividadReciente()}
                        </div>
                    </div>
                    
                    <!-- Columna lateral -->
                    <div class="space-y-6">
                        <!-- Comunidad -->
                        <div id="comunidad-container" class="lazy-component" data-component="comunidad">
                            ${CONFIG.lazyLoadComponents ? '<div class="component-placeholder">Cargando comunidad...</div>' : renderizarComunidad()}
                        </div>
                        
                        <!-- Eventos -->
                        <div id="eventos-container" class="lazy-component" data-component="eventos">
                            ${CONFIG.lazyLoadComponents ? '<div class="component-placeholder">Cargando eventos...</div>' : renderizarEventos()}
                        </div>
                        
                        <!-- Logros -->
                        <div id="logros-container" class="lazy-component" data-component="logros">
                            ${CONFIG.lazyLoadComponents ? '<div class="component-placeholder">Cargando logros...</div>' : renderizarLogros()}
                        </div>
                    </div>
                </div>
            </div>
        `;

        const duracion = performanceMonitor.endTimer('render_interfaz');
        console.log(`Interfaz renderizada en ${duracion}ms`);
    }

    /**
     * Configura lazy loading para componentes
     */
    function configurarLazyLoading() {
        if (!('IntersectionObserver' in window)) {
            console.warn('IntersectionObserver no disponible, deshabilitando lazy loading');
            CONFIG.lazyLoadComponents = false;
            return;
        }

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(async (entry) => {
                if (entry.isIntersecting && !componentesLazyCargados.has(entry.target.dataset.component)) {
                    const componentType = entry.target.dataset.component;
                    await cargarComponenteLazy(entry.target, componentType);
                    componentesLazyCargados.add(componentType);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '50px'
        });

        // Observar componentes lazy
        document.querySelectorAll('.lazy-component').forEach(element => {
            observer.observe(element);
        });
    }

    /**
     * Carga un componente de forma lazy
     */
    async function cargarComponenteLazy(container, componentType) {
        try {
            // Simular pequeño delay para efecto visual
            await new Promise(resolve => setTimeout(resolve, 200));
            
            let contenido = '';
            
            switch (componentType) {
                case 'desafios':
                    contenido = renderizarDesafios();
                    break;
                case 'actividad':
                    contenido = renderizarActividadReciente();
                    break;
                case 'comunidad':
                    contenido = renderizarComunidad();
                    break;
                case 'eventos':
                    contenido = renderizarEventos();
                    break;
                case 'logros':
                    contenido = renderizarLogros();
                    break;
                default:
                    contenido = '<div class="text-center p-4">Componente no encontrado</div>';
            }
            
            container.innerHTML = contenido;
            
            // Reconfigurar eventos para el nuevo contenido
            configurarEventosComponente(container, componentType);
            
        } catch (error) {
            console.error(`Error al cargar componente ${componentType}:`, error);
            container.innerHTML = `
                <div class="text-center p-4 text-red-500">
                    Error al cargar contenido
                    <button onclick="location.reload()" class="block mt-2 discord-button-secondary px-3 py-1 rounded text-sm">
                        Reintentar
                    </button>
                </div>
            `;
        }
    }

    /**
     * Renderiza la sección de competencias optimizada
     */
    function renderizarCompetencias() {
        const estadoActual = estado.getState();
        const competencias = estadoActual.competencias || { teoria: [], practica: [] };

        return `
            <div class="competencias-section discord-card rounded-lg p-6 shadow">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">🎯 Competencias</h2>
                    <button id="toggle-competencias-detalle" class="text-sm discord-button-secondary px-3 py-1 rounded">
                        Ver detalle
                    </button>
                </div>
                
                <div class="competencias-tabs mb-4">
                    <div class="flex space-x-1 bg-[var(--bg-input)]/30 rounded-lg p-1">
                        <button class="tab-button active flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors" data-tab="teoria">
                            📚 Teoría
                        </button>
                        <button class="tab-button flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors" data-tab="practica">
                            🛠️ Práctica
                        </button>
                    </div>
                </div>
                
                <div id="teoria-competencias" class="tab-content">
                    <div class="space-y-3">
                        ${competencias.teoria.map(comp => `
                            <div class="competencia-item p-3 bg-[var(--bg-input)]/20 rounded-lg hover:bg-[var(--bg-input)]/30 transition-colors">
                                <div class="flex justify-between items-center mb-2">
                                    <h3 class="font-medium">${comp.nombre}</h3>
                                    <span class="text-sm font-bold text-[var(--bg-primary)]">Nivel ${comp.nivel}/${comp.maxNivel}</span>
                                </div>
                                <p class="text-sm text-gray-500 mb-2">${comp.descripcion}</p>
                                <div class="competencia-progress">
                                    <div class="flex justify-between text-xs text-gray-500 mb-1">
                                        <span>${comp.experiencia || 0} XP</span>
                                        <span>${comp.experienciaSiguienteNivel || 100} XP</span>
                                    </div>
                                    <div class="w-full bg-[var(--bg-input)] rounded-full h-2">
                                        <div class="bg-gradient-to-r from-[var(--bg-primary)] to-[var(--bg-secondary)] h-2 rounded-full transition-all duration-500" 
                                             style="width: ${Math.min(100, ((comp.experiencia || 0) / (comp.experienciaSiguienteNivel || 100)) * 100)}%">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <div id="practica-competencias" class="tab-content hidden">
                    <div class="space-y-3">
                        ${competencias.practica.map(comp => `
                            <div class="competencia-item p-3 bg-[var(--bg-input)]/20 rounded-lg hover:bg-[var(--bg-input)]/30 transition-colors">
                                <div class="flex justify-between items-center mb-2">
                                    <h3 class="font-medium">${comp.nombre}</h3>
                                    <span class="text-sm font-bold text-[var(--bg-primary)]">Nivel ${comp.nivel}/${comp.maxNivel}</span>
                                </div>
                                <p class="text-sm text-gray-500 mb-2">${comp.descripcion}</p>
                                <div class="competencia-progress">
                                    <div class="flex justify-between text-xs text-gray-500 mb-1">
                                        <span>${comp.experiencia || 0} XP</span>
                                        <span>${comp.experienciaSiguienteNivel || 100} XP</span>
                                    </div>
                                    <div class="w-full bg-[var(--bg-input)] rounded-full h-2">
                                        <div class="bg-gradient-to-r from-[var(--bg-primary)] to-[var(--bg-secondary)] h-2 rounded-full transition-all duration-500" 
                                             style="width: ${Math.min(100, ((comp.experiencia || 0) / (comp.experienciaSiguienteNivel || 100)) * 100)}%">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Renderiza la sección de desafíos optimizada
     */
    function renderizarDesafios() {
        const estadoActual = estado.getState();
        const desafios = estadoActual.desafios || [];

        return `
            <div class="desafios-section discord-card rounded-lg p-6 shadow">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">🎯 Desafíos</h2>
                    <button id="btn-nuevo-desafio" class="discord-button-primary px-4 py-2 rounded-lg text-sm">
                        + Nuevo Desafío
                    </button>
                </div>
                
                <div class="space-y-4">
                    ${desafios.length > 0 ? 
                        desafios.map(desafio => `
                            <div class="desafio-item p-4 bg-[var(--bg-input)]/20 rounded-lg hover:bg-[var(--bg-input)]/30 transition-all duration-200" data-id="${desafio.id}">
                                <div class="flex justify-between items-start mb-2">
                                    <div>
                                        <h3 class="font-semibold">${desafio.titulo}</h3>
                                        <p class="text-sm text-gray-500">${desafio.descripcion}</p>
                                    </div>
                                    <div class="text-right">
                                        <div class="text-sm font-medium">${desafio.progreso}/${desafio.total}</div>
                                        <div class="text-xs text-gray-500">${Math.round((desafio.progreso / desafio.total) * 100)}%</div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <div class="w-full bg-[var(--bg-input)] rounded-full h-3">
                                        <div class="bg-gradient-to-r from-[var(--bg-primary)] to-[var(--bg-secondary)] h-3 rounded-full transition-all duration-500" 
                                             style="width: ${Math.min(100, (desafio.progreso / desafio.total) * 100)}%">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="flex justify-between items-center">
                                    <div class="flex items-center space-x-2">
                                        <span class="text-xs px-2 py-1 rounded-full ${getDificultadColor(desafio.dificultad)}">
                                            ${capitalizarPrimera(desafio.dificultad || 'normal')}
                                        </span>
                                        <span class="text-xs text-gray-500">
                                            ${formatearFechaLimite(desafio.fechaLimite)}
                                        </span>
                                    </div>
                                    <div class="flex space-x-2">
                                        <button class="actualizar-desafio-btn text-xs discord-button-secondary px-3 py-1 rounded" data-id="${desafio.id}">
                                            ✓ Actualizar
                                        </button>
                                        <button class="ver-recompensa-btn text-xs discord-button-tertiary px-3 py-1 rounded" data-id="${desafio.id}">
                                            🎁 Recompensa
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `).join('') : 
                        `<div class="text-center text-gray-500 py-8">
                            <div class="text-4xl mb-2">🎯</div>
                            <p>No hay desafíos activos</p>
                            <p class="text-sm">¡Acepta un nuevo desafío para comenzar!</p>
                        </div>`
                    }
                </div>
            </div>
        `;
    }

    /**
     * Renderiza la actividad reciente optimizada
     */
    function renderizarActividadReciente() {
        const estadoActual = estado.getState();
        const actividad = estadoActual.actividad || [];
        
        // Ordenar por fecha (más reciente primero)
        const actividadOrdenada = [...actividad].sort((a, b) => 
            new Date(b.fecha).getTime() - new Date(a.fecha).getTime()
        );

        return `
            <div class="actividad-section discord-card rounded-lg p-6 shadow">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">📊 Actividad Reciente</h2>
                    <button id="btn-ver-toda-actividad" class="text-sm discord-button-secondary px-3 py-1 rounded">
                        Ver todo
                    </button>
                </div>
                
                <div class="actividad-timeline space-y-3">
                    ${actividadOrdenada.length > 0 ? 
                        actividadOrdenada.slice(0, 10).map((actividad, index) => `
                            <div class="actividad-item flex items-start space-x-3 p-3 bg-[var(--bg-input)]/20 rounded-lg hover:bg-[var(--bg-input)]/30 transition-colors">
                                <div class="actividad-icono text-xl">
                                    ${obtenerIconoActividad(actividad.tipo)}
                                </div>
                                <div class="flex-grow">
                                    <div class="font-medium">${obtenerTituloActividad(actividad)}</div>
                                    <div class="text-sm text-gray-500">${obtenerDetalleActividad(actividad)}</div>
                                    <div class="flex items-center mt-1 space-x-3">
                                        <span class="text-xs text-gray-400">${formatearFechaRelativa(actividad.fecha)}</span>
                                        ${actividad.puntuacion ? `
                                            <div class="flex items-center">
                                                <span class="text-xs text-yellow-500">⭐ ${actividad.puntuacion}/5</span>
                                            </div>
                                        ` : ''}
                                    </div>
                                </div>
                                <button class="text-xs discord-button-tertiary px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                                    Ver
                                </button>
                            </div>
                        `).join('') : 
                        `<div class="text-center text-gray-500 py-8">
                            <div class="text-4xl mb-2">📊</div>
                            <p>No hay actividad reciente</p>
                            <p class="text-sm">¡Comienza tu estudio para ver tu progreso aquí!</p>
                        </div>`
                    }
                </div>
            </div>
        `;
    }

    /**
     * Renderiza la sección de comunidad optimizada
     */
    function renderizarComunidad() {
        const estadoActual = estado.getState();
        const conexiones = estadoActual.conexiones || [];
        const comunidades = estadoActual.comunidades || [];

        return `
            <div class="comunidad-section discord-card rounded-lg p-6 shadow">
                <h2 class="text-xl font-semibold mb-4">👥 Comunidad</h2>
                
                <!-- Conexiones -->
                <div class="mb-6">
                    <div class="flex justify-between items-center mb-3">
                        <h3 class="text-lg font-medium">Conexiones</h3>
                        <button id="btn-buscar-conexiones" class="text-sm discord-button-secondary px-3 py-1 rounded">
                            + Buscar
                        </button>
                    </div>
                    
                    <div class="space-y-2">
                        ${conexiones.length > 0 ? 
                            conexiones.slice(0, 5).map(conexion => `
                                <div class="conexion-item flex items-center p-3 bg-[var(--bg-input)]/20 rounded-lg hover:bg-[var(--bg-input)]/30 transition-colors">
                                    <div class="conexion-avatar w-10 h-10 rounded-full bg-gradient-to-br from-[var(--bg-primary)] to-[var(--bg-secondary)] flex items-center justify-center mr-3">
                                        ${conexion.avatar || '👤'}
                                    </div>
                                    <div class="flex-grow">
                                        <div class="font-medium flex items-center">
                                            ${conexion.nombre}
                                            <span class="ml-2 w-2 h-2 rounded-full ${conexion.estado === 'online' ? 'bg-green-400' : 'bg-gray-400'}"></span>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            ${conexion.tipo === 'mentor' ? '🏆 Mentor' : '👫 Amigo'} · Nivel ${conexion.nivel}
                                        </div>
                                    </div>
                                    <button class="enviar-mensaje-btn text-xs discord-button-secondary px-3 py-1 rounded" data-id="${conexion.id}">
                                        💬
                                    </button>
                                </div>
                            `).join('') : 
                            `<div class="text-center text-gray-500 py-4">
                                <p class="text-sm">No tienes conexiones aún</p>
                            </div>`
                        }
                    </div>
                </div>
                
                <!-- Comunidades -->
                <div>
                    <div class="flex justify-between items-center mb-3">
                        <h3 class="text-lg font-medium">Comunidades</h3>
                        <button id="btn-explorar-comunidades" class="text-sm discord-button-secondary px-3 py-1 rounded">
                            Explorar
                        </button>
                    </div>
                    
                    <div class="space-y-2">
                        ${comunidades.length > 0 ? 
                            comunidades.slice(0, 3).map(comunidad => `
                                <div class="comunidad-item p-3 bg-[var(--bg-input)]/20 rounded-lg hover:bg-[var(--bg-input)]/30 transition-colors">
                                    <div class="flex justify-between items-start">
                                        <div class="flex-grow">
                                            <div class="font-medium">${comunidad.nombre}</div>
                                            <div class="text-sm text-gray-500">${comunidad.descripcion}</div>
                                            <div class="flex items-center mt-1 space-x-3">
                                                <span class="text-xs text-gray-400">${comunidad.miembros} miembros</span>
                                                <span class="text-xs px-2 py-0.5 rounded-full ${getActividadColor(comunidad.actividad)}">
                                                    ${capitalizarPrimera(comunidad.actividad || 'baja')}
                                                </span>
                                            </div>
                                        </div>
                                        <button class="unirse-comunidad-btn text-xs discord-button-primary px-3 py-1 rounded" data-id="${comunidad.id}">
                                            Unirse
                                        </button>
                                    </div>
                                </div>
                            `).join('') : 
                            `<div class="text-center text-gray-500 py-4">
                                <p class="text-sm">No hay comunidades disponibles</p>
                            </div>`
                        }
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Renderiza la sección de eventos optimizada
     */
    function renderizarEventos() {
        const estadoActual = estado.getState();
        const eventos = estadoActual.eventos || [];
        
        // Ordenar eventos por fecha (más cercano primero)
        const eventosOrdenados = [...eventos].sort((a, b) => 
            new Date(a.fecha).getTime() - new Date(b.fecha).getTime()
        );

        return `
            <div class="eventos-section discord-card rounded-lg p-6 shadow">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">📅 Eventos</h2>
                    <button id="btn-crear-evento" class="discord-button-primary px-4 py-2 rounded-lg text-sm">
                        + Crear
                    </button>
                </div>
                
                <div class="space-y-3">
                    ${eventosOrdenados.length > 0 ? 
                        eventosOrdenados.map(evento => `
                            <div class="evento-item p-4 bg-[var(--bg-input)]/20 rounded-lg hover:bg-[var(--bg-input)]/30 transition-colors">
                                <div class="flex justify-between items-start mb-2">
                                    <div>
                                        <h3 class="font-semibold">${evento.titulo}</h3>
                                        <p class="text-sm text-gray-500">${evento.descripcion}</p>
                                    </div>
                                    <span class="text-xs px-2 py-1 rounded-full ${evento.tipo === 'online' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}">
                                        ${evento.tipo === 'online' ? '💻 Online' : '📍 Presencial'}
                                    </span>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center space-x-4 text-sm text-gray-500">
                                        <span class="flex items-center">
                                            📅 ${formatearFecha(evento.fecha)}
                                        </span>
                                        <span class="flex items-center">
                                            ⏱️ ${evento.duracion} min
                                        </span>
                                        <span class="flex items-center">
                                            👥 ${evento.participantes}/${evento.maxParticipantes || '∞'}
                                        </span>
                                    </div>
                                    <button class="participar-evento-btn discord-button-secondary px-3 py-1 rounded text-xs" data-id="${evento.id}">
                                        ${evento.estado === 'programado' ? 'Participar' : 'Ver'}
                                    </button>
                                </div>
                            </div>
                        `).join('') : 
                        `<div class="text-center text-gray-500 py-8">
                            <div class="text-4xl mb-2">📅</div>
                            <p>No hay eventos programados</p>
                            <p class="text-sm">¡Crea o únete a un evento!</p>
                        </div>`
                    }
                </div>
            </div>
        `;
    }

    /**
     * Renderiza la sección de logros optimizada
     */
    function renderizarLogros() {
        const estadoActual = estado.getState();
        const logros = estadoActual.logros || [];
        
        const logrosDesbloqueados = logros.filter(l => l.fecha);
        const logrosBloqueados = logros.filter(l => !l.fecha);

        return `
            <div class="logros-section discord-card rounded-lg p-6 shadow">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">🏆 Logros</h2>
                    <button id="btn-ver-todos-logros" class="text-sm discord-button-secondary px-3 py-1 rounded">
                        Ver todos
                    </button>
                </div>
                
                <!-- Logros desbloqueados -->
                ${logrosDesbloqueados.length > 0 ? `
                    <div class="mb-4">
                        <h3 class="text-sm font-medium text-gray-400 mb-2">DESBLOQUEADOS</h3>
                        <div class="space-y-2">
                            ${logrosDesbloqueados.slice(0, 3).map(logro => `
                                <div class="logro-item flex items-center p-3 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg border border-yellow-200 dark:border-yellow-700">
                                    <div class="logro-icono text-2xl mr-3">${logro.icono}</div>
                                    <div class="flex-grow">
                                        <div class="font-medium text-yellow-800 dark:text-yellow-200">${logro.nombre}</div>
                                        <div class="text-sm text-yellow-600 dark:text-yellow-300">${logro.descripcion}</div>
                                        <div class="text-xs text-yellow-500 dark:text-yellow-400">
                                            ${formatearFechaRelativa(logro.fecha)} · ${logro.puntos || 0} puntos
                                        </div>
                                    </div>
                                    <div class="logro-rareza text-xs px-2 py-1 rounded-full ${getRarezaColor(logro.rareza)}">
                                        ${capitalizarPrimera(logro.rareza || 'comun')}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                
                <!-- Logros en progreso -->
                ${logrosBloqueados.length > 0 ? `
                    <div>
                        <h3 class="text-sm font-medium text-gray-400 mb-2">EN PROGRESO</h3>
                        <div class="space-y-2">
                            ${logrosBloqueados.slice(0, 2).map(logro => `
                                <div class="logro-item flex items-center p-3 bg-[var(--bg-input)]/20 rounded-lg opacity-75">
                                    <div class="logro-icono text-2xl mr-3 grayscale">${logro.icono}</div>
                                    <div class="flex-grow">
                                        <div class="font-medium">${logro.nombre}</div>
                                        <div class="text-sm text-gray-500">${logro.descripcion}</div>
                                        ${logro.progreso !== undefined ? `
                                            <div class="mt-2">
                                                <div class="flex justify-between text-xs text-gray-500 mb-1">
                                                    <span>${logro.progreso}/${logro.total}</span>
                                                    <span>${Math.round((logro.progreso / logro.total) * 100)}%</span>
                                                </div>
                                                <div class="w-full bg-[var(--bg-input)] rounded-full h-1.5">
                                                    <div class="bg-[var(--bg-primary)] h-1.5 rounded-full" 
                                                         style="width: ${(logro.progreso / logro.total) * 100}%">
                                                    </div>
                                                </div>
                                            </div>
                                        ` : ''}
                                    </div>
                                    <div class="text-xs text-gray-400">${logro.puntos || 0} pts</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
                
                ${logros.length === 0 ? `
                    <div class="text-center text-gray-500 py-8">
                        <div class="text-4xl mb-2">🏆</div>
                        <p>No hay logros disponibles</p>
                        <p class="text-sm">¡Comienza tu estudio para desbloquear logros!</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    /**
     * Configura eventos de la interfaz social
     */
    function configurarEventosSociales() {
        // Delegación de eventos para mejor performance
        document.addEventListener('click', handleGlobalClick);
        document.addEventListener('change', handleGlobalChange);

        // Configurar eventos específicos de componentes
        configurarEventosCompetencias();
        configurarEventosDesafios();
        configurarEventosActividad();
        configurarEventosComunidad();
        configurarEventosEventos();
        configurarEventosLogros();
    }

    /**
     * Maneja clics globales con delegación de eventos
     */
    function handleGlobalClick(event) {
        const target = event.target;
        
        // Botones de pestañas de competencias
        if (target.classList.contains('tab-button')) {
            const tab = target.dataset.tab;
            switchTab(tab);
        }
        
        // Botones de actualizar desafío
        else if (target.classList.contains('actualizar-desafio-btn')) {
            const desafioId = target.dataset.id;
            actualizarDesafio(desafioId);
        }
        
        // Botones de participar en evento
        else if (target.classList.contains('participar-evento-btn')) {
            const eventoId = target.dataset.id;
            participarEnEvento(eventoId);
        }
        
        // Botones de enviar mensaje
        else if (target.classList.contains('enviar-mensaje-btn')) {
            const usuarioId = target.dataset.id;
            enviarMensaje(usuarioId);
        }
        
        // Botones de unirse a comunidad
        else if (target.classList.contains('unirse-comunidad-btn')) {
            const comunidadId = target.dataset.id;
            unirseComunidad(comunidadId);
        }
        
        // Otros botones específicos
        switch (target.id) {
            case 'btn-configuracion':
                abrirConfiguracion();
                break;
            case 'btn-notificaciones':
                abrirNotificaciones();
                break;
            case 'btn-nuevo-desafio':
                crearNuevoDesafio();
                break;
            case 'btn-ver-toda-actividad':
                verTodaActividad();
                break;
            case 'btn-buscar-conexiones':
                buscarConexiones();
                break;
            case 'btn-explorar-comunidades':
                explorarComunidades();
                break;
            case 'btn-crear-evento':
                crearEvento();
                break;
            case 'btn-ver-todos-logros':
                verTodosLogros();
                break;
        }
    }

    /**
     * Maneja cambios globales con delegación de eventos
     */
    function handleGlobalChange(event) {
        // Aquí se pueden manejar cambios en inputs, selects, etc.
    }

    /**
     * Configura eventos específicos para componentes cargados
     */
    function configurarEventosComponente(container, componentType) {
        switch (componentType) {
            case 'competencias':
                configurarEventosCompetencias();
                break;
            case 'desafios':
                configurarEventosDesafios();
                break;
            case 'actividad':
                configurarEventosActividad();
                break;
            case 'comunidad':
                configurarEventosComunidad();
                break;
            case 'eventos':
                configurarEventosEventos();
                break;
            case 'logros':
                configurarEventosLogros();
                break;
        }
    }

    // =====================================================================
    // FUNCIONES DE EVENTOS ESPECÍFICOS
    // =====================================================================
    
    function configurarEventosCompetencias() {
        // Eventos específicos de competencias
    }

    function configurarEventosDesafios() {
        // Eventos específicos de desafíos
    }

    function configurarEventosActividad() {
        // Eventos específicos de actividad
    }

    function configurarEventosComunidad() {
        // Eventos específicos de comunidad
    }

    function configurarEventosEventos() {
        // Eventos específicos de eventos
    }

    function configurarEventosLogros() {
        // Eventos específicos de logros
    }

    // =====================================================================
    // FUNCIONES DE ACCIÓN
    // =====================================================================
    
    function switchTab(tab) {
        // Actualizar botones de pestañas
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
        
        // Mostrar/ocultar contenido
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(`${tab}-competencias`).classList.remove('hidden');
    }

    async function actualizarDesafio(desafioId) {
        try {
            const desafios = estado.get('desafios') || [];
            const desafio = desafios.find(d => d.id === desafioId);
            
            if (desafio && desafio.progreso < desafio.total) {
                desafio.progreso++;
                estado.set('desafios', desafios);
                
                await notificationManager.show({
                    titulo: '✅ Progreso Actualizado',
                    mensaje: `Progreso en "${desafio.titulo}": ${desafio.progreso}/${desafio.total}`,
                    tipo: 'success'
                });
                
                // Verificar si se completó
                if (desafio.progreso >= desafio.total) {
                    await procesarRecompensaDesafio(desafio);
                }
            }
        } catch (error) {
            console.error('Error al actualizar desafío:', error);
        }
    }

    async function procesarRecompensaDesafio(desafio) {
        const recompensa = desafio.recompensa;
        if (!recompensa) return;
        
        // Agregar experiencia
        if (recompensa.experiencia) {
            const perfilUsuario = estado.get('perfilUsuario');
            perfilUsuario.experiencia += recompensa.experiencia;
            estado.set('perfilUsuario', perfilUsuario);
        }
        
        // Actualizar competencia
        if (recompensa.competencia) {
            const competencias = estado.get('competencias');
            const tipoCompetencia = recompensa.competencia.startsWith('ct') ? 'teoria' : 'practica';
            const competencia = competencias[tipoCompetencia].find(c => c.id === recompensa.competencia);
            
            if (competencia) {
                competencia.experiencia += recompensa.experiencia || 50;
                estado.set('competencias', competencias);
            }
        }
        
        await notificationManager.show({
            titulo: '🎉 ¡Desafío Completado!',
            mensaje: `Has completado "${desafio.titulo}" y recibido ${formatearRecompensa(recompensa)}`,
            tipo: 'achievement',
            priority: 'high'
        });
    }

    async function participarEnEvento(eventoId) {
        try {
            const eventos = estado.get('eventos') || [];
            const evento = eventos.find(e => e.id === eventoId);
            
            if (evento && evento.participantes < (evento.maxParticipantes || Infinity)) {
                evento.participantes++;
                estado.set('eventos', eventos);
                
                await notificationManager.show({
                    titulo: '✅ Evento Confirmado',
                    mensaje: `Te has unido a "${evento.titulo}"`,
                    tipo: 'success'
                });
            }
        } catch (error) {
            console.error('Error al participar en evento:', error);
        }
    }

    async function enviarMensaje(usuarioId) {
        // Implementar funcionalidad de mensajería
        console.log('Enviar mensaje a:', usuarioId);
    }

    async function unirseComunidad(comunidadId) {
        try {
            const comunidades = estado.get('comunidades') || [];
            const comunidad = comunidades.find(c => c.id === comunidadId);
            
            if (comunidad) {
                comunidad.miembros++;
                estado.set('comunidades', comunidades);
                
                await notificationManager.show({
                    titulo: '🎉 ¡Bienvenido!',
                    mensaje: `Te has unido a "${comunidad.nombre}"`,
                    tipo: 'success'
                });
            }
        } catch (error) {
            console.error('Error al unirse a comunidad:', error);
        }
    }

    function abrirConfiguracion() {
        // Implementar modal de configuración
        console.log('Abrir configuración');
    }

    function abrirNotificaciones() {
        // Implementar panel de notificaciones
        console.log('Abrir notificaciones');
    }

    function crearNuevoDesafio() {
        // Implementar creación de desafío
        console.log('Crear nuevo desafío');
    }

    function verTodaActividad() {
        // Implementar vista completa de actividad
        console.log('Ver toda la actividad');
    }

    function buscarConexiones() {
        // Implementar búsqueda de conexiones
        console.log('Buscar conexiones');
    }

    function explorarComunidades() {
        // Implementar exploración de comunidades
        console.log('Explorar comunidades');
    }

    function crearEvento() {
        // Implementar creación de evento
        console.log('Crear evento');
    }

    function verTodosLogros() {
        // Implementar vista completa de logros
        console.log('Ver todos los logros');
    }

    // =====================================================================
    // FUNCIONES DE ACTUALIZACIÓN Y SINCRONIZACIÓN
    // =====================================================================
    
    const actualizarDatos = throttle(async function(datos) {
        if (!datos) return;
        
        try {
            performanceMonitor.startTimer('actualizar_datos');
            
            // Actualizar estado de forma reactiva
            Object.keys(datos).forEach(key => {
                estado.set(key, datos[key]);
            });
            
            // Limpiar cache relacionado
            cache.clear();
            
            const duracion = performanceMonitor.endTimer('actualizar_datos');
            console.log(`Datos actualizados en ${duracion}ms`);
            
        } catch (error) {
            console.error('Error al actualizar datos:', error);
        }
    }, CONFIG.throttleDelay);

    function iniciarActualizacionesAutomaticas() {
        if (temporizadorActualizacion) {
            clearInterval(temporizadorActualizacion);
        }
        
        temporizadorActualizacion = setInterval(async () => {
            try {
                // Simular actualización de datos desde servidor
                await simularActualizacionDatos();
            } catch (error) {
                console.error('Error en actualización automática:', error);
            }
        }, CONFIG.intervaloActualizacion);
        
        console.log('Actualizaciones automáticas iniciadas');
    }

    function detenerActualizacionesAutomaticas() {
        if (temporizadorActualizacion) {
            clearInterval(temporizadorActualizacion);
            temporizadorActualizacion = null;
        }
        
        console.log('Actualizaciones automáticas detenidas');
    }

    async function simularActualizacionDatos() {
        // Simular pequeños cambios en los datos
        const estadoActual = estado.getState();
        
        // Actualizar última actividad de conexiones
        if (estadoActual.conexiones) {
            estadoActual.conexiones.forEach(conexion => {
                if (Math.random() < 0.1) { // 10% de probabilidad de cambio
                    conexion.ultimaActividad = new Date().toISOString();
                    conexion.estado = Math.random() < 0.7 ? 'online' : 'offline';
                }
            });
            estado.set('conexiones', estadoActual.conexiones);
        }
        
        // Simular nuevas notificaciones ocasionales
        if (Math.random() < 0.05) { // 5% de probabilidad
            await notificationManager.show({
                titulo: '👋 Saludo Amistoso',
                mensaje: 'Tu amigo Carlos te envió un saludo',
                tipo: 'social'
            });
        }
    }

    // =====================================================================
    // FUNCIONES DE UTILIDAD
    // =====================================================================
    
    function obtenerIconoActividad(tipo) {
        const iconos = {
            'lectura': '📖',
            'memorizacion': '🧠',
            'checkin': '✅',
            'oracion': '🙏',
            'evento': '📅',
            'desafio': '🎯',
            'logro': '🏆',
            'social': '👥'
        };
        return iconos[tipo] || '📋';
    }

    function obtenerTituloActividad(actividad) {
        switch (actividad.tipo) {
            case 'lectura':
                return `Lectura: ${actividad.detalles.libro} ${actividad.detalles.capitulo}`;
            case 'memorizacion':
                return `Memorización: ${actividad.detalles.referencia}`;
            case 'checkin':
                return 'Check-in diario';
            case 'oracion':
                return 'Tiempo de oración';
            case 'evento':
                return `Evento: ${actividad.detalles.titulo || 'Sin título'}`;
            case 'desafio':
                return `Desafío: ${actividad.detalles.titulo || 'Sin título'}`;
            default:
                return 'Actividad';
        }
    }

    function obtenerDetalleActividad(actividad) {
        switch (actividad.tipo) {
            case 'lectura':
                return `Has leído el capítulo ${actividad.detalles.capitulo} de ${actividad.detalles.libro} (${actividad.detalles.tiempo || 0} min)`;
            case 'memorizacion':
                return `Has practicado la memorización de ${actividad.detalles.referencia} (${actividad.detalles.intentos || 1} intentos)`;
            case 'checkin':
                return `Has completado tu check-in diario con ${(actividad.detalles.actividades || []).length} actividades`;
            case 'oracion':
                return `Has dedicado tiempo a la oración (${actividad.detalles.duracion || 0} minutos)`;
            case 'evento':
                return actividad.detalles.descripcion || 'Has participado en un evento';
            case 'desafio':
                return `Progreso: ${actividad.detalles.progreso || 0}/${actividad.detalles.total || 1}`;
            default:
                return '';
        }
    }

    function formatearRecompensa(recompensa) {
        if (!recompensa) return 'Ninguna';
        
        let texto = '';
        
        if (recompensa.experiencia) {
            texto += `${recompensa.experiencia} XP`;
        }
        
        if (recompensa.competencia) {
            const tipoCompetencia = recompensa.competencia.startsWith('ct') ? 'teoría' : 'práctica';
            if (texto) texto += ', ';
            texto += `+${recompensa.nivelesCompetencia || 1} nivel en ${tipoCompetencia}`;
        }
        
        return texto || 'Ninguna';
    }

    function formatearFechaRelativa(fecha) {
        const ahora = Date.now();
        const fechaObj = new Date(fecha);
        const diferencia = ahora - fechaObj.getTime();
        
        const minutos = Math.floor(diferencia / 60000);
        const horas = Math.floor(diferencia / 3600000);
        const dias = Math.floor(diferencia / 86400000);
        
        if (minutos < 1) return 'Ahora';
        if (minutos < 60) return `${minutos}m`;
        if (horas < 24) return `${horas}h`;
        if (dias < 7) return `${dias}d`;
        
        return fechaObj.toLocaleDateString();
    }

    function formatearFecha(fecha) {
        return new Date(fecha).toLocaleDateString('es-ES', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    function formatearFechaLimite(fecha) {
        const ahora = Date.now();
        const fechaLimite = new Date(fecha).getTime();
        const diferencia = fechaLimite - ahora;
        
        if (diferencia < 0) return 'Vencido';
        
        const dias = Math.floor(diferencia / 86400000);
        const horas = Math.floor((diferencia % 86400000) / 3600000);
        
        if (dias > 0) return `${dias}d restantes`;
        if (horas > 0) return `${horas}h restantes`;
        
        return 'Termina pronto';
    }

    function capitalizarPrimera(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    function getDificultadColor(dificultad) {
        const colores = {
            'facil': 'bg-green-100 text-green-800',
            'medio': 'bg-yellow-100 text-yellow-800',
            'dificil': 'bg-red-100 text-red-800'
        };
        return colores[dificultad] || colores['medio'];
    }

    function getActividadColor(actividad) {
        const colores = {
            'alta': 'bg-green-100 text-green-800',
            'media': 'bg-yellow-100 text-yellow-800',
            'baja': 'bg-gray-100 text-gray-800'
        };
        return colores[actividad] || colores['baja'];
    }

    function getRarezaColor(rareza) {
        const colores = {
            'comun': 'bg-gray-100 text-gray-800',
            'raro': 'bg-blue-100 text-blue-800',
            'epico': 'bg-purple-100 text-purple-800',
            'legendario': 'bg-orange-100 text-orange-800'
        };
        return colores[rareza] || colores['comun'];
    }

    // =====================================================================
    // FUNCIONES DE ESTADÍSTICAS Y MONITOREO
    // =====================================================================
    
    function obtenerEstadisticas() {
        return {
            estado: {
                perfilUsuario: estado.get('perfilUsuario'),
                comunidades: (estado.get('comunidades') || []).length,
                conexiones: (estado.get('conexiones') || []).length,
                desafiosActivos: (estado.get('desafios') || []).filter(d => d.progreso < d.total).length,
                logrosDesbloqueados: (estado.get('logros') || []).filter(l => l.fecha).length
            },
            cache: cache.getStats(),
            notificaciones: {
                total: notificationManager.notifications.size,
                noLeidas: notificationManager.getUnreadCount()
            },
            performance: performanceMonitor.getStats(),
            configuracion: { ...CONFIG }
        };
    }

    function limpiarCache() {
        cache.clear();
        componentesLazyCargados.clear();
        console.log('Cache social limpiado');
    }

    async function destruir() {
        // Detener actualizaciones
        detenerActualizacionesAutomaticas();
        
        // Limpiar event listeners
        document.removeEventListener('click', handleGlobalClick);
        document.removeEventListener('change', handleGlobalChange);
        
        // Limpiar cache y estado
        cache.clear();
        EventEmitter.clear();
        
        console.log('Módulo social destruido');
    }

    // =====================================================================
    // API PÚBLICA DEL MÓDULO
    // =====================================================================
    
    return Object.freeze({
        // Funciones principales
        inicializar,
        renderizarInterfazSocial,
        actualizarDatos,
        
        // Gestión de estado
        getEstado: () => estado.getState(),
        getConfig: () => ({ ...CONFIG }),
        setConfig: (nuevaConfig) => Object.assign(CONFIG, nuevaConfig),
        
        // Gestión de actualizaciones
        iniciarActualizacionesAutomaticas,
        detenerActualizacionesAutomaticas,
        
        // Utilidades
        obtenerEstadisticas,
        limpiarCache,
        destruir,
        
        // Componentes internos (para debugging)
        estado: CONFIG.modoDebug ? estado : undefined,
        cache: CONFIG.modoDebug ? cache : undefined,
        notificationManager: CONFIG.modoDebug ? notificationManager : undefined,
        performanceMonitor: CONFIG.modoDebug ? performanceMonitor : undefined
    });

})();

// =====================================================================
// ESTILOS CSS OPTIMIZADOS
// =====================================================================

const estilosSociales = `
<style>
    /* Estilos base para componentes sociales */
    .social-container {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    
    .component-placeholder {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 200px;
        background: var(--bg-input, #f3f4f6);
        border-radius: 8px;
        color: var(--text-secondary, #6b7280);
        font-size: 14px;
    }
    
    .tab-button {
        transition: all 0.2s ease;
    }
    
    .tab-button.active {
        background: var(--bg-primary, #5865f2);
        color: white;
    }
    
    .tab-button:not(.active):hover {
        background: var(--bg-input, #f3f4f6);
    }
    
    .competencia-progress .bg-gradient-to-r,
    .desafio-item .bg-gradient-to-r {
        transition: width 0.5s ease;
    }
    
    .actividad-item:hover,
    .desafio-item:hover,
    .evento-item:hover,
    .conexion-item:hover,
    .comunidad-item:hover,
    .logro-item:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: all 0.2s ease;
    }
    
    .notification-item {
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        border-left: 4px solid var(--bg-primary, #5865f2);
        animation: slideInRight 0.3s ease;
        max-width: 350px;
        position: relative;
        overflow: hidden;
    }
    
    .notification-item.success {
        border-left-color: #10b981;
    }
    
    .notification-item.error {
        border-left-color: #ef4444;
    }
    
    .notification-item.achievement {
        border-left-color: #f59e0b;
        background: linear-gradient(135deg, #fff7ed 0%, #fef3c7 100%);
    }
    
    .notification-close {
        position: absolute;
        top: 8px;
        right: 8px;
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #6b7280;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .notification-close:hover {
        background: rgba(0, 0, 0, 0.1);
    }
    
    .notification-content {
        padding: 16px;
        padding-right: 40px;
    }
    
    .notification-header {
        font-weight: 600;
        margin-bottom: 4px;
    }
    
    .notification-body {
        color: #6b7280;
        font-size: 14px;
        margin-bottom: 8px;
    }
    
    .notification-time {
        color: #9ca3af;
        font-size: 12px;
    }
    
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    /* Responsive design */
    @media (max-width: 768px) {
        .social-grid {
            grid-template-columns: 1fr;
        }
        
        .perfil-header .flex {
            flex-direction: column;
            text-align: center;
        }
        
        .perfil-header .perfil-acciones {
            margin-top: 16px;
        }
        
        .notification-item {
            max-width: calc(100vw - 32px);
        }
    }
    
    /* Tema oscuro */
    @media (prefers-color-scheme: dark) {
        .notification-item {
            background: #2f3136;
            color: #dcddde;
        }
        
        .notification-body {
            color: #b9bbbe;
        }
        
        .notification-time {
            color: #72767d;
        }
    }
    
    /* Animaciones de loading */
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }
    
    .loading {
        animation: pulse 2s infinite;
    }
    
    /* Efectos de hover mejorados */
    .competencia-item:hover,
    .desafio-item:hover,
    .actividad-item:hover {
        background: var(--bg-input, #f3f4f6) !important;
    }
    
    /* Gradientes para logros */
    .logro-item.desbloqueado {
        background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
        border: 1px solid #f59e0b;
    }
    
    /* Estados de conexión */
    .conexion-avatar::after {
        content: '';
        position: absolute;
        bottom: 0;
        right: 0;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        border: 2px solid white;
    }
    
    .conexion-item[data-estado="online"] .conexion-avatar::after {
        background: #10b981;
    }
    
    .conexion-item[data-estado="offline"] .conexion-avatar::after {
        background: #6b7280;
    }
</style>
`;

// =====================================================================
// INICIALIZACIÓN AUTOMÁTICA OPTIMIZADA
// =====================================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Inicializando Módulo Social Avanzado Optimizado...');
    
    // Inyectar estilos
    document.head.insertAdjacentHTML('beforeend', estilosSociales);
    
    // Verificar soporte para características modernas
    const soporte = {
        intersectionObserver: 'IntersectionObserver' in window,
        notifications: 'Notification' in window,
        localStorage: typeof Storage !== 'undefined',
        webWorkers: typeof Worker !== 'undefined'
    };
    
    console.log('Soporte de características sociales:', soporte);
    
    // Inicializar módulo social si está disponible
    if (typeof SocialAvanzadoOptimizado !== 'undefined') {
        SocialAvanzadoOptimizado.inicializar({
            lazyLoadComponents: soporte.intersectionObserver,
            pushNotifications: soporte.notifications,
            offlineSupport: soporte.localStorage,
            performanceMonitoring: true
        });
    }
    
    console.log('Módulo Social Avanzado Optimizado inicializado correctamente');
});

// Hacer disponible globalmente
if (typeof window !== 'undefined') {
    window.SocialAvanzadoOptimizado = SocialAvanzadoOptimizado;
    
    // Exponer datos sociales básicos para la aplicación React
    window.socialData = {
        discussions: [
            {
                id: '1',
                title: 'Interpretación del Sermón del Monte',
                author: 'Pastor Rodriguez',
                date: '2024-06-05',
                replies: 12,
                category: 'teoria'
            },
            {
                id: '2', 
                title: 'Aplicación práctica de Proverbios en la vida diaria',
                author: 'Maria González',
                date: '2024-06-04',
                replies: 8,
                category: 'practica'
            },
            {
                id: '3',
                title: 'Bienvenidos nuevos miembros',
                author: 'Administrador',
                date: '2024-06-03',
                replies: 25,
                category: 'general'
            },
            {
                id: '4',
                title: 'Estudio sobre los nombres de Dios en el Antiguo Testamento',
                author: 'Dr. Carmen López',
                date: '2024-06-02',
                replies: 15,
                category: 'teoria'
            },
            {
                id: '5',
                title: 'Testimonios de transformación por la Palabra',
                author: 'Juan Pérez',
                date: '2024-06-01',
                replies: 20,
                category: 'practica'
            }
        ],
        messages: [
            {
                id: 'm1',
                author: 'Pastor Rodriguez',
                content: '¡Buenos días, familia! Que el Señor bendiga este nuevo día de estudio.',
                timestamp: '2024-06-05T08:00:00Z'
            },
            {
                id: 'm2',
                author: 'Maria González',
                content: 'Estoy muy emocionada por el nuevo estudio de Proverbios. ¡Gracias por esta oportunidad!',
                timestamp: '2024-06-05T08:15:00Z'
            },
            {
                id: 'm3',
                author: 'Carlos Silva',
                content: '¿Alguien más ha notado las conexiones profundas entre Isaías y el Nuevo Testamento?',
                timestamp: '2024-06-05T09:30:00Z',
                replies: [
                    {
                        id: 'r1',
                        author: 'Dr. Carmen López',
                        content: 'Excelente observación, Carlos. Las profecías mesiánicas de Isaías son fascinantes.',
                        timestamp: '2024-06-05T09:45:00Z'
                    }
                ]
            },
            {
                id: 'm4',
                author: 'Ana Martínez',
                content: 'Compartiendo mi versículo favorito del día: "Lámpara es a mis pies tu palabra, y lumbrera a mi camino." Salmos 119:105',
                timestamp: '2024-06-05T10:00:00Z'
            },
            {
                id: 'm5',
                author: 'Juan Pérez',
                content: 'Recordatorio: Nuestro grupo de oración se reúne hoy a las 7 PM. ¡Todos bienvenidos!',
                timestamp: '2024-06-05T11:00:00Z'
            }
        ]
    };
}

// Soporte para módulos ES6
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SocialAvanzadoOptimizado;
}
