/**
 * Módulo de Funcionalidades Avanzadas
 * Aplicación de Formación Bíblica - Nuevas Características Integradas
 * 
 * FUNCIONALIDADES IMPLEMENTADAS:
 * - Sistema de Estudios Personalizados
 * - Herramientas de Estudio Avanzadas
 * - Análisis Textual con IA
 * - Sistema de Gamificación
 * - Funcionalidades Multimedia
 * - Colaboración y Grupos de Estudio
 * - Herramientas de Predicación
 * - Dashboard de Métricas
 */

'use strict';

// =====================================================================
// MÓDULO PRINCIPAL DE FUNCIONALIDADES AVANZADAS
// =====================================================================

const AdvancedFeaturesModule = (function() {
    
    // =====================================================================
    // CONFIGURACIÓN GLOBAL
    // =====================================================================
    
    const CONFIG = Object.freeze({
        version: '1.0.0',
        apiBaseUrl: 'https://api.bible-formation.com',
        enableAI: true,
        enableOfflineMode: true,
        enableRealTimeSync: true,
        maxCacheSize: 500,
        syncInterval: 30000, // 30 segundos
        performanceMonitoring: true,
        debugMode: false
    });

    // =====================================================================
    // SISTEMA DE ESTUDIOS PERSONALIZADOS
    // =====================================================================
    
    const PersonalizedStudySystem = (function() {
        
        let currentPlan = null;
        let studyProgress = new Map();
        let reminders = new Map();
        let studySession = null;

        /**
         * Crea un nuevo plan de lectura personalizado
         */
        async function createReadingPlan(planData) {
            try {
                const plan = {
                    id: generateId(),
                    name: planData.name,
                    description: planData.description,
                    type: planData.type || 'sequential',
                    duration: planData.duration,
                    books: planData.books || [],
                    dailyReadings: [],
                    difficulty: planData.difficulty || 'intermediate',
                    tags: planData.tags || [],
                    createdBy: getCurrentUserId(),
                    isPublic: planData.isPublic || false,
                    createdAt: new Date(),
                    updatedAt: new Date()
                };

                // Generar lecturas diarias
                plan.dailyReadings = await generateDailyReadings(plan);
                
                // Guardar en storage
                await savePlan(plan);
                
                // Emitir evento
                EventManager.emit('plan:created', plan);
                
                return plan;
                
            } catch (error) {
                console.error('Error creating reading plan:', error);
                throw error;
            }
        }

        /**
         * Genera lecturas diarias basadas en el tipo de plan
         */
        async function generateDailyReadings(plan) {
            const readings = [];
            
            switch (plan.type) {
                case 'sequential':
                    return generateSequentialReadings(plan);
                case 'thematic':
                    return generateThematicReadings(plan);
                case 'chronological':
                    return generateChronologicalReadings(plan);
                case 'custom':
                    return plan.customReadings || [];
                default:
                    return generateSequentialReadings(plan);
            }
        }

        /**
         * Genera lecturas secuenciales
         */
        function generateSequentialReadings(plan) {
            const readings = [];
            const booksData = getBooksData();
            let currentDay = 1;
            
            plan.books.forEach(bookId => {
                const book = booksData.find(b => b.id === bookId);
                if (!book) return;
                
                for (let chapter = 1; chapter <= book.chapters; chapter++) {
                    readings.push({
                        day: currentDay++,
                        readings: [{
                            book: bookId,
                            chapter: chapter,
                            focus: `Capítulo ${chapter} de ${book.name}`
                        }],
                        estimatedTime: estimateReadingTime(bookId, chapter)
                    });
                }
            });
            
            return readings;
        }

        /**
         * Genera lecturas temáticas
         */
        function generateThematicReadings(plan) {
            const themes = getThematicReadings();
            const readings = [];
            let currentDay = 1;
            
            plan.tags.forEach(theme => {
                const themeReadings = themes[theme];
                if (themeReadings) {
                    themeReadings.forEach(reading => {
                        readings.push({
                            day: currentDay++,
                            readings: [reading],
                            reflection: `Reflexión sobre: ${theme}`,
                            questions: generateThematicQuestions(theme),
                            estimatedTime: estimateReadingTime(reading.book, reading.chapter)
                        });
                    });
                }
            });
            
            return readings;
        }

        /**
         * Inicia una sesión de estudio
         */
        async function startStudySession(planId, day) {
            try {
                const plan = await getPlan(planId);
                if (!plan) throw new Error('Plan not found');
                
                const dayReading = plan.dailyReadings.find(r => r.day === day);
                if (!dayReading) throw new Error('Day reading not found');
                
                studySession = {
                    id: generateId(),
                    planId: planId,
                    day: day,
                    startTime: new Date(),
                    activities: [],
                    notes: [],
                    progress: {
                        readingsCompleted: 0,
                        totalReadings: dayReading.readings.length,
                        timeSpent: 0
                    }
                };
                
                // Emitir evento
                EventManager.emit('study:session_started', studySession);
                
                return studySession;
                
            } catch (error) {
                console.error('Error starting study session:', error);
                throw error;
            }
        }

        /**
         * Marca una lectura como completada
         */
        async function completeReading(sessionId, readingIndex) {
            if (!studySession || studySession.id !== sessionId) {
                throw new Error('Invalid study session');
            }
            
            studySession.activities.push({
                type: 'reading',
                timestamp: new Date(),
                readingIndex: readingIndex,
                completed: true
            });
            
            studySession.progress.readingsCompleted++;
            
            // Verificar si se completó el día
            if (studySession.progress.readingsCompleted >= studySession.progress.totalReadings) {
                await completeDayStudy(studySession.planId, studySession.day);
            }
            
            EventManager.emit('study:reading_completed', {
                sessionId: sessionId,
                readingIndex: readingIndex,
                progress: studySession.progress
            });
        }

        /**
         * Completa el estudio del día
         */
        async function completeDayStudy(planId, day) {
            let progress = studyProgress.get(planId);
            if (!progress) {
                progress = {
                    planId: planId,
                    userId: getCurrentUserId(),
                    currentDay: 1,
                    completedDays: [],
                    totalDays: 0,
                    startDate: new Date(),
                    notes: [],
                    timeSpent: 0,
                    completed: false
                };
            }
            
            // Agregar día completado
            if (!progress.completedDays.includes(day)) {
                progress.completedDays.push(day);
                progress.lastReadDate = new Date();
                
                // Calcular tiempo gastado
                if (studySession) {
                    const sessionTime = Date.now() - studySession.startTime.getTime();
                    progress.timeSpent += Math.floor(sessionTime / 60000); // minutos
                }
                
                // Actualizar día actual
                progress.currentDay = Math.max(progress.currentDay, day + 1);
                
                // Verificar si se completó el plan
                const plan = await getPlan(planId);
                if (plan && progress.completedDays.length >= plan.dailyReadings.length) {
                    progress.completed = true;
                    await awardPlanCompletion(planId);
                }
                
                studyProgress.set(planId, progress);
                await saveProgress(progress);
                
                // Emitir eventos
                EventManager.emit('study:day_completed', { planId, day, progress });
                
                if (progress.completed) {
                    EventManager.emit('study:plan_completed', { planId, progress });
                }
            }
        }

        /**
         * Añade una nota de estudio
         */
        async function addStudyNote(planId, day, noteData) {
            const note = {
                id: generateId(),
                day: day,
                reading: noteData.reading,
                content: noteData.content,
                type: noteData.type || 'note',
                tags: noteData.tags || [],
                createdAt: new Date(),
                isPrivate: noteData.isPrivate !== false
            };
            
            let progress = studyProgress.get(planId);
            if (progress) {
                progress.notes.push(note);
                studyProgress.set(planId, progress);
                await saveProgress(progress);
            }
            
            EventManager.emit('study:note_added', { planId, note });
            return note;
        }

        /**
         * Configura recordatorios de estudio
         */
        async function setStudyReminder(planId, reminderData) {
            const reminder = {
                id: generateId(),
                userId: getCurrentUserId(),
                planId: planId,
                time: reminderData.time,
                days: reminderData.days || [1, 2, 3, 4, 5], // Lun-Vie por defecto
                enabled: true,
                message: reminderData.message || 'Es hora de tu estudio bíblico'
            };
            
            reminders.set(reminder.id, reminder);
            await saveReminder(reminder);
            
            // Configurar notificación del navegador
            if ('Notification' in window && Notification.permission === 'granted') {
                scheduleNotification(reminder);
            }
            
            EventManager.emit('reminder:set', reminder);
            return reminder;
        }

        /**
         * Obtiene el progreso de un plan
         */
        function getStudyProgress(planId) {
            return studyProgress.get(planId) || null;
        }

        /**
         * Obtiene estadísticas de estudio
         */
        async function getStudyStats(userId) {
            const allProgress = Array.from(studyProgress.values())
                .filter(p => p.userId === userId);
            
            return {
                totalPlans: allProgress.length,
                completedPlans: allProgress.filter(p => p.completed).length,
                activePlans: allProgress.filter(p => !p.completed).length,
                totalStudyTime: allProgress.reduce((sum, p) => sum + p.timeSpent, 0),
                totalDaysStudied: allProgress.reduce((sum, p) => sum + p.completedDays.length, 0),
                currentStreak: calculateStudyStreak(allProgress),
                averageSessionTime: calculateAverageSessionTime(allProgress)
            };
        }

        // API pública
        return {
            createReadingPlan,
            startStudySession,
            completeReading,
            addStudyNote,
            setStudyReminder,
            getStudyProgress,
            getStudyStats,
            getCurrentSession: () => studySession,
            getAllPlans: () => getAllPlans()
        };
    })();

    // =====================================================================
    // HERRAMIENTAS DE ESTUDIO AVANZADAS
    // =====================================================================
    
    const AdvancedStudyTools = (function() {
        
        let bibleVersions = new Map();
        let personalNotes = new Map();
        let highlights = new Map();
        let concordanceData = new Map();

        /**
         * Inicializa las herramientas de estudio
         */
        async function initialize() {
            await loadBibleVersions();
            await loadPersonalNotes();
            await loadHighlights();
            await loadConcordanceData();
        }

        /**
         * Compara versiones bíblicas
         */
        async function compareVersions(reference, versionIds) {
            try {
                const comparison = {
                    reference: reference,
                    versions: []
                };
                
                for (const versionId of versionIds) {
                    const text = await getVerseText(reference, versionId);
                    comparison.versions.push({
                        versionId: versionId,
                        text: text,
                        differences: []
                    });
                }
                
                // Calcular diferencias
                if (comparison.versions.length > 1) {
                    for (let i = 1; i < comparison.versions.length; i++) {
                        comparison.versions[i].differences = 
                            calculateTextDifferences(
                                comparison.versions[0].text,
                                comparison.versions[i].text
                            );
                    }
                }
                
                return comparison;
                
            } catch (error) {
                console.error('Error comparing versions:', error);
                throw error;
            }
        }

        /**
         * Añade una nota personal
         */
        async function addPersonalNote(noteData) {
            const note = {
                id: generateId(),
                userId: getCurrentUserId(),
                reference: noteData.reference,
                content: noteData.content,
                type: noteData.type || 'note',
                tags: noteData.tags || [],
                color: noteData.color || '#ffeb3b',
                isPrivate: noteData.isPrivate !== false,
                createdAt: new Date(),
                updatedAt: new Date(),
                linkedNotes: []
            };
            
            personalNotes.set(note.id, note);
            await savePersonalNote(note);
            
            EventManager.emit('note:added', note);
            return note;
        }

        /**
         * Actualiza una nota personal
         */
        async function updatePersonalNote(noteId, updates) {
            const note = personalNotes.get(noteId);
            if (!note) throw new Error('Note not found');
            
            Object.assign(note, updates, { updatedAt: new Date() });
            personalNotes.set(noteId, note);
            await savePersonalNote(note);
            
            EventManager.emit('note:updated', note);
            return note;
        }

        /**
         * Resalta texto con tema específico
         */
        async function highlightText(highlightData) {
            const highlight = {
                id: generateId(),
                userId: getCurrentUserId(),
                reference: highlightData.reference,
                startWord: highlightData.startWord,
                endWord: highlightData.endWord,
                themeId: highlightData.themeId,
                text: highlightData.text,
                createdAt: new Date()
            };
            
            highlights.set(highlight.id, highlight);
            await saveHighlight(highlight);
            
            EventManager.emit('highlight:added', highlight);
            return highlight;
        }

        /**
         * Busca en la concordancia
         */
        async function searchConcordance(word) {
            try {
                // Buscar en cache local primero
                let concordance = concordanceData.get(word.toLowerCase());
                
                if (!concordance) {
                    // Buscar en API
                    concordance = await fetchConcordanceData(word);
                    if (concordance) {
                        concordanceData.set(word.toLowerCase(), concordance);
                    }
                }
                
                return concordance;
                
            } catch (error) {
                console.error('Error searching concordance:', error);
                throw error;
            }
        }

        /**
         * Obtiene notas para una referencia
         */
        function getNotesForReference(reference) {
            return Array.from(personalNotes.values())
                .filter(note => note.reference === reference)
                .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        }

        /**
         * Obtiene highlights para una referencia
         */
        function getHighlightsForReference(reference) {
            return Array.from(highlights.values())
                .filter(highlight => highlight.reference === reference);
        }

        /**
         * Busca en notas personales
         */
        function searchPersonalNotes(query) {
            const results = [];
            const queryLower = query.toLowerCase();
            
            for (const note of personalNotes.values()) {
                if (note.content.toLowerCase().includes(queryLower) ||
                    note.tags.some(tag => tag.toLowerCase().includes(queryLower))) {
                    results.push(note);
                }
            }
            
            return results.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
        }

        // API pública
        return {
            initialize,
            compareVersions,
            addPersonalNote,
            updatePersonalNote,
            highlightText,
            searchConcordance,
            getNotesForReference,
            getHighlightsForReference,
            searchPersonalNotes
        };
    })();

    // =====================================================================
    // ANÁLISIS TEXTUAL CON IA
    // =====================================================================
    
    const AITextAnalysis = (function() {
        
        let analysisCache = new Map();
        let aiInsights = new Map();

        /**
         * Analiza semánticamente un pasaje
         */
        async function analyzePassage(reference) {
            try {
                // Verificar cache
                let analysis = analysisCache.get(reference);
                if (analysis) {
                    return analysis;
                }
                
                // Obtener texto del pasaje
                const text = await getPassageText(reference);
                
                // Realizar análisis con IA simulada
                analysis = await performSemanticAnalysis(text, reference);
                
                // Guardar en cache
                analysisCache.set(reference, analysis);
                
                EventManager.emit('ai:analysis_completed', { reference, analysis });
                return analysis;
                
            } catch (error) {
                console.error('Error analyzing passage:', error);
                throw error;
            }
        }

        /**
         * Realiza análisis semántico simulado
         */
        async function performSemanticAnalysis(text, reference) {
            // Simulación de análisis de IA
            const analysis = {
                reference: reference,
                themes: await identifyThemes(text),
                emotions: await identifyEmotions(text),
                characters: await identifyCharacters(text, reference),
                literaryDevices: await identifyLiteraryDevices(text),
                historicalContext: await getHistoricalContext(reference),
                theologicalConcepts: await identifyTheologicalConcepts(text),
                summary: await generateSummary(text),
                keyVerses: await identifyKeyVerses(text, reference),
                relatedPassages: await findRelatedPassages(text, reference)
            };
            
            return analysis;
        }

        /**
         * Identifica temas principales
         */
        async function identifyThemes(text) {
            const themeKeywords = {
                'amor': ['amor', 'amado', 'amar', 'caridad', 'afecto'],
                'fe': ['fe', 'creer', 'confianza', 'esperanza'],
                'salvación': ['salvación', 'salvar', 'redentor', 'liberación'],
                'perdón': ['perdón', 'perdonar', 'misericordia', 'gracia'],
                'justicia': ['justicia', 'justo', 'rectitud', 'derecho'],
                'paz': ['paz', 'tranquilo', 'sosiego', 'calma'],
                'oración': ['oración', 'orar', 'súplica', 'ruego'],
                'sabiduría': ['sabiduría', 'sabio', 'entendimiento', 'prudencia']
            };
            
            const themes = [];
            const textLower = text.toLowerCase();
            
            for (const [theme, keywords] of Object.entries(themeKeywords)) {
                let relevance = 0;
                const verses = [];
                
                keywords.forEach(keyword => {
                    const matches = (textLower.match(new RegExp(keyword, 'g')) || []).length;
                    relevance += matches * 0.1;
                });
                
                if (relevance > 0) {
                    themes.push({
                        id: theme,
                        name: theme.charAt(0).toUpperCase() + theme.slice(1),
                        description: `Tema relacionado con ${theme}`,
                        relevance: Math.min(relevance, 1),
                        verses: verses,
                        relatedThemes: []
                    });
                }
            }
            
            return themes.sort((a, b) => b.relevance - a.relevance);
        }

        /**
         * Identifica emociones en el texto
         */
        async function identifyEmotions(text) {
            const emotionKeywords = {
                'gozo': ['gozo', 'alegría', 'regocijo', 'contento', 'feliz'],
                'tristeza': ['tristeza', 'llanto', 'dolor', 'pena', 'lamento'],
                'temor': ['temor', 'miedo', 'espanto', 'terror'],
                'ira': ['ira', 'enojo', 'cólera', 'furor'],
                'esperanza': ['esperanza', 'esperar', 'confianza'],
                'gratitud': ['gracias', 'agradecido', 'alabanza']
            };
            
            const emotions = [];
            const textLower = text.toLowerCase();
            
            for (const [emotion, keywords] of Object.entries(emotionKeywords)) {
                let intensity = 0;
                const verses = [];
                
                keywords.forEach(keyword => {
                    const matches = (textLower.match(new RegExp(keyword, 'g')) || []).length;
                    intensity += matches * 0.2;
                });
                
                if (intensity > 0) {
                    emotions.push({
                        type: emotion,
                        intensity: Math.min(intensity, 1),
                        context: `Emoción de ${emotion} identificada en el texto`,
                        verses: verses
                    });
                }
            }
            
            return emotions.sort((a, b) => b.intensity - a.intensity);
        }

        /**
         * Genera resumen del pasaje
         */
        async function generateSummary(text) {
            // Simulación de generación de resumen
            const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 10);
            const maxSentences = Math.min(3, Math.ceil(sentences.length * 0.3));
            
            return sentences.slice(0, maxSentences).join('. ') + '.';
        }

        /**
         * Encuentra pasajes relacionados
         */
        async function findRelatedPassages(text, reference) {
            // Simulación de búsqueda de pasajes relacionados
            const relatedPassages = [
                {
                    reference: "Juan 3:16",
                    relationship: "parallel",
                    description: "Pasaje paralelo que habla del mismo tema",
                    relevance: 0.9
                },
                {
                    reference: "Romanos 8:28",
                    relationship: "background",
                    description: "Contexto teológico relacionado",
                    relevance: 0.7
                }
            ];
            
            return relatedPassages;
        }

        /**
         * Genera insights con IA
         */
        async function generateAIInsights(reference) {
            const insights = [
                {
                    id: generateId(),
                    reference: reference,
                    type: 'theme',
                    title: 'Tema Principal Identificado',
                    content: 'Este pasaje trata principalmente sobre el amor de Dios hacia la humanidad.',
                    confidence: 0.85,
                    sources: ['Análisis semántico', 'Contexto bíblico'],
                    createdAt: new Date()
                },
                {
                    id: generateId(),
                    reference: reference,
                    type: 'application',
                    title: 'Aplicación Práctica',
                    content: 'Este pasaje nos enseña a mostrar amor incondicional hacia otros.',
                    confidence: 0.78,
                    sources: ['Análisis contextual'],
                    createdAt: new Date()
                }
            ];
            
            insights.forEach(insight => {
                aiInsights.set(insight.id, insight);
            });
            
            return insights;
        }

        // API pública
        return {
            analyzePassage,
            generateAIInsights,
            getInsights: (reference) => {
                return Array.from(aiInsights.values())
                    .filter(insight => insight.reference === reference);
            }
        };
    })();

    // =====================================================================
    // SISTEMA DE GAMIFICACIÓN
    // =====================================================================
    
    const GamificationSystem = (function() {
        
        let userLevel = 1;
        let userXP = 0;
        let achievements = new Map();
        let challenges = new Map();
        let leaderboards = new Map();

        /**
         * Inicializa el sistema de gamificación
         */
        async function initialize() {
            await loadUserProgress();
            await loadAchievements();
            await loadChallenges();
            await loadLeaderboards();
            
            // Configurar eventos
            EventManager.on('study:day_completed', handleDayCompleted);
            EventManager.on('study:plan_completed', handlePlanCompleted);
            EventManager.on('note:added', handleNoteAdded);
        }

        /**
         * Otorga experiencia al usuario
         */
        async function awardXP(amount, reason) {
            const oldLevel = userLevel;
            userXP += amount;
            
            // Calcular nuevo nivel
            const newLevel = calculateLevel(userXP);
            if (newLevel > userLevel) {
                userLevel = newLevel;
                await handleLevelUp(oldLevel, newLevel);
            }
            
            await saveUserProgress();
            
            EventManager.emit('gamification:xp_awarded', {
                amount: amount,
                total: userXP,
                reason: reason,
                levelUp: newLevel > oldLevel
            });
        }

        /**
         * Maneja subida de nivel
         */
        async function handleLevelUp(oldLevel, newLevel) {
            const levelData = getLevelData(newLevel);
            
            // Mostrar notificación
            NotificationManager.show({
                title: '🎉 ¡Nivel Aumentado!',
                message: `¡Has alcanzado el nivel ${newLevel}: ${levelData.title}!`,
                type: 'level_up',
                priority: 'high'
            });
            
            // Verificar logros de nivel
            await checkLevelAchievements(newLevel);
            
            EventManager.emit('gamification:level_up', {
                oldLevel: oldLevel,
                newLevel: newLevel,
                levelData: levelData
            });
        }

        /**
         * Verifica y otorga logros
         */
        async function checkAchievements(context) {
            const availableAchievements = getAvailableAchievements();
            
            for (const achievement of availableAchievements) {
                if (await meetsRequirements(achievement, context)) {
                    await awardAchievement(achievement.id);
                }
            }
        }

        /**
         * Otorga un logro
         */
        async function awardAchievement(achievementId) {
            const achievement = getAchievementData(achievementId);
            if (!achievement) return;
            
            const userAchievement = {
                achievementId: achievementId,
                userId: getCurrentUserId(),
                unlockedAt: new Date(),
                progress: 1,
                notified: false
            };
            
            achievements.set(achievementId, userAchievement);
            await saveAchievement(userAchievement);
            
            // Otorgar XP
            await awardXP(achievement.points, `Logro: ${achievement.name}`);
            
            // Mostrar notificación
            NotificationManager.show({
                title: '🏆 ¡Logro Desbloqueado!',
                message: `Has desbloqueado "${achievement.name}"`,
                type: 'achievement',
                priority: 'high'
            });
            
            EventManager.emit('gamification:achievement_unlocked', {
                achievement: achievement,
                userAchievement: userAchievement
            });
        }

        /**
         * Crea un nuevo desafío
         */
        async function createChallenge(challengeData) {
            const challenge = {
                id: generateId(),
                name: challengeData.name,
                description: challengeData.description,
                type: challengeData.type,
                category: challengeData.category,
                startDate: new Date(challengeData.startDate),
                endDate: new Date(challengeData.endDate),
                requirements: challengeData.requirements,
                rewards: challengeData.rewards,
                difficulty: challengeData.difficulty,
                participants: 0,
                maxParticipants: challengeData.maxParticipants,
                isActive: true
            };
            
            challenges.set(challenge.id, challenge);
            await saveChallenge(challenge);
            
            EventManager.emit('gamification:challenge_created', challenge);
            return challenge;
        }

        /**
         * Participa en un desafío
         */
        async function joinChallenge(challengeId) {
            const challenge = challenges.get(challengeId);
            if (!challenge) throw new Error('Challenge not found');
            
            if (challenge.maxParticipants && challenge.participants >= challenge.maxParticipants) {
                throw new Error('Challenge is full');
            }
            
            challenge.participants++;
            challenges.set(challengeId, challenge);
            await saveChallenge(challenge);
            
            // Crear progreso del usuario
            const userProgress = {
                challengeId: challengeId,
                userId: getCurrentUserId(),
                progress: 0,
                requirements: challenge.requirements.map(req => ({
                    ...req,
                    currentProgress: 0
                })),
                joinedAt: new Date(),
                completed: false
            };
            
            await saveChallengeProgress(userProgress);
            
            EventManager.emit('gamification:challenge_joined', {
                challenge: challenge,
                userProgress: userProgress
            });
        }

        /**
         * Actualiza el leaderboard
         */
        async function updateLeaderboard(type, userId, score) {
            let leaderboard = leaderboards.get(type);
            if (!leaderboard) {
                leaderboard = {
                    id: type,
                    name: getLeaderboardName(type),
                    type: 'global',
                    period: 'all_time',
                    metric: type,
                    entries: [],
                    lastUpdated: new Date()
                };
            }
            
            // Buscar entrada existente
            let entry = leaderboard.entries.find(e => e.userId === userId);
            if (entry) {
                const oldScore = entry.score;
                entry.score = score;
                entry.change = score - oldScore;
            } else {
                entry = {
                    rank: 0,
                    userId: userId,
                    userName: getUserName(userId),
                    avatar: getUserAvatar(userId),
                    score: score,
                    change: 0
                };
                leaderboard.entries.push(entry);
            }
            
            // Ordenar y actualizar ranks
            leaderboard.entries.sort((a, b) => b.score - a.score);
            leaderboard.entries.forEach((entry, index) => {
                entry.rank = index + 1;
            });
            
            leaderboard.lastUpdated = new Date();
            leaderboards.set(type, leaderboard);
            await saveLeaderboard(leaderboard);
            
            EventManager.emit('gamification:leaderboard_updated', {
                type: type,
                leaderboard: leaderboard
            });
        }

        /**
         * Maneja eventos de progreso
         */
        function handleDayCompleted(data) {
            awardXP(10, 'Día de estudio completado');
            checkAchievements({ type: 'study_day', data: data });
        }

        function handlePlanCompleted(data) {
            awardXP(100, 'Plan de lectura completado');
            checkAchievements({ type: 'plan_completed', data: data });
        }

        function handleNoteAdded(data) {
            awardXP(5, 'Nota añadida');
            checkAchievements({ type: 'note_added', data: data });
        }

        // API pública
        return {
            initialize,
            awardXP,
            checkAchievements,
            createChallenge,
            joinChallenge,
            getUserLevel: () => userLevel,
            getUserXP: () => userXP,
            getUserAchievements: () => Array.from(achievements.values()),
            getLeaderboard: (type) => leaderboards.get(type),
            updateLeaderboard
        };
    })();

    // =====================================================================
    // FUNCIONALIDADES MULTIMEDIA
    // =====================================================================
    
    const MultimediaFeatures = (function() {
        
        let audioSettings = {
            voice: 'es-ES-Standard-A',
            speed: 1.0,
            volume: 0.8,
            autoplay: false,
            language: 'es'
        };
        
        let contextualImages = new Map();
        let bibleMaps = new Map();
        let timelines = new Map();

        /**
         * Inicializa funcionalidades multimedia
         */
        async function initialize() {
            await loadAudioSettings();
            await loadContextualImages();
            await loadBibleMaps();
            await loadTimelines();
        }

        /**
         * Convierte texto a audio
         */
        async function textToSpeech(text, reference) {
            try {
                if (!('speechSynthesis' in window)) {
                    throw new Error('Text-to-speech not supported');
                }
                
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.lang = audioSettings.language;
                utterance.rate = audioSettings.speed;
                utterance.volume = audioSettings.volume;
                
                // Buscar voz específica
                const voices = speechSynthesis.getVoices();
                const selectedVoice = voices.find(voice => 
                    voice.name === audioSettings.voice || 
                    voice.lang.startsWith(audioSettings.language)
                );
                
                if (selectedVoice) {
                    utterance.voice = selectedVoice;
                }
                
                // Configurar eventos
                utterance.onstart = () => {
                    EventManager.emit('audio:started', { reference, text });
                };
                
                utterance.onend = () => {
                    EventManager.emit('audio:ended', { reference, text });
                };
                
                utterance.onerror = (error) => {
                    EventManager.emit('audio:error', { reference, error });
                };
                
                speechSynthesis.speak(utterance);
                
                return utterance;
                
            } catch (error) {
                console.error('Error in text-to-speech:', error);
                throw error;
            }
        }

        /**
         * Obtiene imágenes contextuales para una referencia
         */
        async function getContextualImages(reference) {
            try {
                let images = contextualImages.get(reference);
                
                if (!images) {
                    // Buscar imágenes relevantes
                    images = await searchRelevantImages(reference);
                    contextualImages.set(reference, images);
                }
                
                return images;
                
            } catch (error) {
                console.error('Error getting contextual images:', error);
                return [];
            }
        }

        /**
         * Busca imágenes relevantes para una referencia
         */
        async function searchRelevantImages(reference) {
            // Simulación de búsqueda de imágenes
            const sampleImages = [
                {
                    id: 'img1',
                    reference: reference,
                    url: 'https://example.com/biblical-image-1.jpg',
                    title: 'Ilustración bíblica',
                    description: 'Imagen relacionada con el pasaje',
                    type: 'illustration',
                    source: 'Biblioteca Digital Bíblica',
                    license: 'Creative Commons',
                    relevance: 0.9
                }
            ];
            
            return sampleImages;
        }

        /**
         * Obtiene mapas bíblicos relevantes
         */
        async function getBibleMaps(reference) {
            try {
                // Extraer ubicaciones del texto
                const locations = await extractLocations(reference);
                const relevantMaps = [];
                
                for (const map of bibleMaps.values()) {
                    const hasRelevantLocation = map.interactiveData.some(location =>
                        locations.includes(location.name.toLowerCase())
                    );
                    
                    if (hasRelevantLocation || map.relatedPassages.includes(reference)) {
                        relevantMaps.push(map);
                    }
                }
                
                return relevantMaps;
                
            } catch (error) {
                console.error('Error getting bible maps:', error);
                return [];
            }
        }

        /**
         * Obtiene timeline relevante
         */
        async function getTimeline(reference) {
            try {
                // Determinar período histórico
                const period = await determineHistoricalPeriod(reference);
                
                for (const timeline of timelines.values()) {
                    const hasRelevantEvents = timeline.events.some(event =>
                        event.references.includes(reference) ||
                        isInPeriod(event.date, period)
                    );
                    
                    if (hasRelevantEvents) {
                        return timeline;
                    }
                }
                
                return null;
                
            } catch (error) {
                console.error('Error getting timeline:', error);
                return null;
            }
        }

        /**
         * Actualiza configuración de audio
         */
        function updateAudioSettings(newSettings) {
            Object.assign(audioSettings, newSettings);
            saveAudioSettings();
            
            EventManager.emit('audio:settings_updated', audioSettings);
        }

        /**
         * Pausa audio actual
         */
        function pauseAudio() {
            if ('speechSynthesis' in window) {
                speechSynthesis.pause();
                EventManager.emit('audio:paused');
            }
        }

        /**
         * Reanuda audio
         */
        function resumeAudio() {
            if ('speechSynthesis' in window) {
                speechSynthesis.resume();
                EventManager.emit('audio:resumed');
            }
        }

        /**
         * Detiene audio
         */
        function stopAudio() {
            if ('speechSynthesis' in window) {
                speechSynthesis.cancel();
                EventManager.emit('audio:stopped');
            }
        }

        // API pública
        return {
            initialize,
            textToSpeech,
            getContextualImages,
            getBibleMaps,
            getTimeline,
            updateAudioSettings,
            pauseAudio,
            resumeAudio,
            stopAudio,
            getAudioSettings: () => ({ ...audioSettings })
        };
    })();

    // =====================================================================
    // COLABORACIÓN Y GRUPOS DE ESTUDIO
    // =====================================================================
    
    const CollaborationSystem = (function() {
        
        let studyGroups = new Map();
        let discussions = new Map();
        let liveSessions = new Map();
        let groupMembers = new Map();

        /**
         * Inicializa el sistema de colaboración
         */
        async function initialize() {
            await loadStudyGroups();
            await loadDiscussions();
            await loadLiveSessions();
            await loadGroupMembers();
        }

        /**
         * Crea un nuevo grupo de estudio
         */
        async function createStudyGroup(groupData) {
            const group = {
                id: generateId(),
                name: groupData.name,
                description: groupData.description,
                type: groupData.type || 'public',
                category: groupData.category || 'general',
                memberCount: 1,
                maxMembers: groupData.maxMembers,
                createdBy: getCurrentUserId(),
                moderators: [getCurrentUserId()],
                currentStudy: groupData.currentStudy,
                meetingSchedule: groupData.meetingSchedule,
                rules: groupData.rules || [],
                tags: groupData.tags || [],
                createdAt: new Date(),
                isActive: true
            };
            
            studyGroups.set(group.id, group);
            await saveStudyGroup(group);
            
            // Añadir creador como miembro
            await joinGroup(group.id, getCurrentUserId(), 'leader');
            
            EventManager.emit('collaboration:group_created', group);
            return group;
        }

        /**
         * Une a un usuario a un grupo
         */
        async function joinGroup(groupId, userId, role = 'member') {
            const group = studyGroups.get(groupId);
            if (!group) throw new Error('Group not found');
            
            if (group.maxMembers && group.memberCount >= group.maxMembers) {
                throw new Error('Group is full');
            }
            
            const member = {
                userId: userId,
                groupId: groupId,
                role: role,
                joinedAt: new Date(),
                lastActivity: new Date(),
                permissions: getDefaultPermissions(role),
                isActive: true
            };
            
            const memberKey = `${groupId}_${userId}`;
            groupMembers.set(memberKey, member);
            await saveGroupMember(member);
            
            // Actualizar contador de miembros
            group.memberCount++;
            studyGroups.set(groupId, group);
            await saveStudyGroup(group);
            
            EventManager.emit('collaboration:member_joined', {
                group: group,
                member: member
            });
        }

        /**
         * Crea una nueva discusión
         */
        async function createDiscussion(groupId, discussionData) {
            const discussion = {
                id: generateId(),
                groupId: groupId,
                authorId: getCurrentUserId(),
                reference: discussionData.reference,
                title: discussionData.title,
                content: discussionData.content,
                type: discussionData.type || 'question',
                tags: discussionData.tags || [],
                isPinned: false,
                replies: [],
                reactions: [],
                createdAt: new Date(),
                updatedAt: new Date()
            };
            
            discussions.set(discussion.id, discussion);
            await saveDiscussion(discussion);
            
            EventManager.emit('collaboration:discussion_created', discussion);
            return discussion;
        }

        /**
         * Añade una respuesta a una discusión
         */
        async function addReply(discussionId, replyData) {
            const discussion = discussions.get(discussionId);
            if (!discussion) throw new Error('Discussion not found');
            
            const reply = {
                id: generateId(),
                authorId: getCurrentUserId(),
                content: replyData.content,
                parentReplyId: replyData.parentReplyId,
                reactions: [],
                createdAt: new Date(),
                updatedAt: new Date()
            };
            
            discussion.replies.push(reply);
            discussion.updatedAt = new Date();
            
            discussions.set(discussionId, discussion);
            await saveDiscussion(discussion);
            
            EventManager.emit('collaboration:reply_added', {
                discussion: discussion,
                reply: reply
            });
            
            return reply;
        }

        /**
         * Añade una reacción
         */
        async function addReaction(targetType, targetId, reactionType) {
            const reaction = {
                userId: getCurrentUserId(),
                type: reactionType,
                createdAt: new Date()
            };
            
            if (targetType === 'discussion') {
                const discussion = discussions.get(targetId);
                if (discussion) {
                    // Remover reacción existente del mismo usuario
                    discussion.reactions = discussion.reactions.filter(r => r.userId !== getCurrentUserId());
                    discussion.reactions.push(reaction);
                    
                    discussions.set(targetId, discussion);
                    await saveDiscussion(discussion);
                    
                    EventManager.emit('collaboration:reaction_added', {
                        targetType: 'discussion',
                        targetId: targetId,
                        reaction: reaction
                    });
                }
            }
            
            return reaction;
        }

        /**
         * Programa una sesión en vivo
         */
        async function scheduleLiveSession(groupId, sessionData) {
            const session = {
                id: generateId(),
                groupId: groupId,
                hostId: getCurrentUserId(),
                title: sessionData.title,
                description: sessionData.description,
                scheduledAt: new Date(sessionData.scheduledAt),
                status: 'scheduled',
                participants: [],
                maxParticipants: sessionData.maxParticipants,
                isRecorded: sessionData.isRecorded || false,
                agenda: sessionData.agenda || []
            };
            
            liveSessions.set(session.id, session);
            await saveLiveSession(session);
            
            EventManager.emit('collaboration:session_scheduled', session);
            return session;
        }

        /**
         * Inicia una sesión en vivo
         */
        async function startLiveSession(sessionId) {
            const session = liveSessions.get(sessionId);
            if (!session) throw new Error('Session not found');
            
            session.status = 'live';
            session.startedAt = new Date();
            
            // Añadir host como participante
            session.participants.push({
                userId: getCurrentUserId(),
                joinedAt: new Date(),
                role: 'host',
                permissions: getAllPermissions()
            });
            
            liveSessions.set(sessionId, session);
            await saveLiveSession(session);
            
            EventManager.emit('collaboration:session_started', session);
            return session;
        }

        /**
         * Une a una sesión en vivo
         */
        async function joinLiveSession(sessionId, userId) {
            const session = liveSessions.get(sessionId);
            if (!session) throw new Error('Session not found');
            
            if (session.status !== 'live') {
                throw new Error('Session is not live');
            }
            
            if (session.maxParticipants && session.participants.length >= session.maxParticipants) {
                throw new Error('Session is full');
            }
            
            const participant = {
                userId: userId,
                joinedAt: new Date(),
                role: 'participant',
                permissions: getBasicPermissions()
            };
            
            session.participants.push(participant);
            liveSessions.set(sessionId, session);
            await saveLiveSession(session);
            
            EventManager.emit('collaboration:session_joined', {
                session: session,
                participant: participant
            });
        }

        /**
         * Obtiene grupos del usuario
         */
        function getUserGroups(userId) {
            const userGroups = [];
            
            for (const [key, member] of groupMembers) {
                if (member.userId === userId && member.isActive) {
                    const group = studyGroups.get(member.groupId);
                    if (group) {
                        userGroups.push({
                            ...group,
                            memberRole: member.role,
                            joinedAt: member.joinedAt
                        });
                    }
                }
            }
            
            return userGroups;
        }

        /**
         * Obtiene discusiones de un grupo
         */
        function getGroupDiscussions(groupId, limit = 20) {
            return Array.from(discussions.values())
                .filter(d => d.groupId === groupId)
                .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
                .slice(0, limit);
        }

        // API pública
        return {
            initialize,
            createStudyGroup,
            joinGroup,
            createDiscussion,
            addReply,
            addReaction,
            scheduleLiveSession,
            startLiveSession,
            joinLiveSession,
            getUserGroups,
            getGroupDiscussions,
            getStudyGroup: (id) => studyGroups.get(id),
            getLiveSession: (id) => liveSessions.get(id)
        };
    })();

    // =====================================================================
    // HERRAMIENTAS DE PREDICACIÓN
    // =====================================================================
    
    const PreachingTools = (function() {
        
        let sermonOutlines = new Map();
        let illustrations = new Map();
        let sermonSeries = new Map();

        /**
         * Inicializa las herramientas de predicación
         */
        async function initialize() {
            await loadSermonOutlines();
            await loadIllustrations();
            await loadSermonSeries();
        }

        /**
         * Crea un nuevo bosquejo de sermón
         */
        async function createSermonOutline(outlineData) {
            const outline = {
                id: generateId(),
                title: outlineData.title,
                mainText: outlineData.mainText,
                theme: outlineData.theme,
                type: outlineData.type || 'expository',
                occasion: outlineData.occasion,
                audience: outlineData.audience,
                duration: outlineData.duration || 30,
                points: outlineData.points || [],
                introduction: outlineData.introduction || { content: '', duration: 5, notes: [], transitions: [] },
                conclusion: outlineData.conclusion || { content: '', duration: 5, notes: [], transitions: [] },
                illustrations: [],
                applications: [],
                crossReferences: [],
                tags: outlineData.tags || [],
                createdBy: getCurrentUserId(),
                createdAt: new Date(),
                updatedAt: new Date(),
                isPublic: outlineData.isPublic || false
            };
            
            sermonOutlines.set(outline.id, outline);
            await saveSermonOutline(outline);
            
            EventManager.emit('preaching:outline_created', outline);
            return outline;
        }

        /**
         * Añade un punto al sermón
         */
        async function addSermonPoint(outlineId, pointData) {
            const outline = sermonOutlines.get(outlineId);
            if (!outline) throw new Error('Outline not found');
            
            const point = {
                id: generateId(),
                order: pointData.order || outline.points.length + 1,
                title: pointData.title,
                mainIdea: pointData.mainIdea,
                subPoints: pointData.subPoints || [],
                supportingTexts: pointData.supportingTexts || [],
                explanation: pointData.explanation || '',
                illustration: pointData.illustration,
                application: pointData.application
            };
            
            outline.points.push(point);
            outline.updatedAt = new Date();
            
            sermonOutlines.set(outlineId, outline);
            await saveSermonOutline(outline);
            
            EventManager.emit('preaching:point_added', {
                outline: outline,
                point: point
            });
            
            return point;
        }

        /**
         * Busca ilustraciones
         */
        async function searchIllustrations(query, filters = {}) {
            try {
                const results = [];
                const queryLower = query.toLowerCase();
                
                for (const illustration of illustrations.values()) {
                    // Verificar coincidencias en título, contenido o tags
                    const matches = 
                        illustration.title.toLowerCase().includes(queryLower) ||
                        illustration.content.toLowerCase().includes(queryLower) ||
                        illustration.topic.toLowerCase().includes(queryLower) ||
                        illustration.tags.some(tag => tag.toLowerCase().includes(queryLower));
                    
                    if (matches) {
                        // Aplicar filtros
                        if (filters.type && illustration.type !== filters.type) continue;
                        if (filters.topic && illustration.topic !== filters.topic) continue;
                        if (filters.ageGroup && !illustration.ageGroup.includes(filters.ageGroup)) continue;
                        
                        results.push(illustration);
                    }
                }
                
                // Ordenar por efectividad
                return results.sort((a, b) => b.effectiveness - a.effectiveness);
                
            } catch (error) {
                console.error('Error searching illustrations:', error);
                return [];
            }
        }

        /**
         * Añade una nueva ilustración
         */
        async function addIllustration(illustrationData) {
            const illustration = {
                id: generateId(),
                title: illustrationData.title,
                content: illustrationData.content,
                type: illustrationData.type || 'story',
                source: illustrationData.source,
                topic: illustrationData.topic,
                tags: illustrationData.tags || [],
                effectiveness: illustrationData.effectiveness || 3,
                ageGroup: illustrationData.ageGroup || ['adult'],
                context: illustrationData.context || []
            };
            
            illustrations.set(illustration.id, illustration);
            await saveIllustration(illustration);
            
            EventManager.emit('preaching:illustration_added', illustration);
            return illustration;
        }

        /**
         * Genera referencias cruzadas automáticamente
         */
        async function generateCrossReferences(mainText) {
            try {
                // Obtener análisis del texto principal
                const analysis = await AITextAnalysis.analyzePassage(mainText);
                const crossReferences = [];
                
                // Añadir pasajes relacionados del análisis de IA
                if (analysis.relatedPassages) {
                    analysis.relatedPassages.forEach(passage => {
                        crossReferences.push({
                            reference: passage.reference,
                            relationship: passage.relationship,
                            description: passage.description,
                            relevance: passage.relevance
                        });
                    });
                }
                
                // Buscar referencias temáticas
                if (analysis.themes) {
                    for (const theme of analysis.themes) {
                        const thematicRefs = await findThematicReferences(theme.name, mainText);
                        crossReferences.push(...thematicRefs);
                    }
                }
                
                // Ordenar por relevancia
                return crossReferences.sort((a, b) => b.relevance - a.relevance);
                
            } catch (error) {
                console.error('Error generating cross references:', error);
                return [];
            }
        }

        /**
         * Exporta sermón a PDF
         */
        async function exportToPDF(outlineId) {
            try {
                const outline = sermonOutlines.get(outlineId);
                if (!outline) throw new Error('Outline not found');
                
                // Crear contenido del PDF
                const pdfContent = formatSermonForPDF(outline);
                
                // Generar PDF (requiere biblioteca PDF)
                if (typeof window.jsPDF !== 'undefined') {
                    const doc = new window.jsPDF();
                    doc.text(pdfContent, 10, 10);
                    doc.save(`${outline.title}.pdf`);
                } else {
                    // Fallback: crear blob de texto
                    const blob = new Blob([pdfContent], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `${outline.title}.txt`;
                    a.click();
                    
                    URL.revokeObjectURL(url);
                }
                
                EventManager.emit('preaching:sermon_exported', {
                    outline: outline,
                    format: 'pdf'
                });
                
            } catch (error) {
                console.error('Error exporting to PDF:', error);
                throw error;
            }
        }

        /**
         * Crea una serie de sermones
         */
        async function createSermonSeries(seriesData) {
            const series = {
                id: generateId(),
                title: seriesData.title,
                description: seriesData.description,
                theme: seriesData.theme,
                duration: seriesData.duration,
                sermons: seriesData.sermons || [],
                createdBy: getCurrentUserId(),
                isComplete: false,
                tags: seriesData.tags || []
            };
            
            sermonSeries.set(series.id, series);
            await saveSermonSeries(series);
            
            EventManager.emit('preaching:series_created', series);
            return series;
        }

        // API pública
        return {
            initialize,
            createSermonOutline,
            addSermonPoint,
            searchIllustrations,
            addIllustration,
            generateCrossReferences,
            exportToPDF,
            createSermonSeries,
            getSermonOutline: (id) => sermonOutlines.get(id),
            getAllOutlines: () => Array.from(sermonOutlines.values()),
            getSermonSeries: (id) => sermonSeries.get(id)
        };
    })();

    // =====================================================================
    // DASHBOARD DE MÉTRICAS
    // =====================================================================
    
    const MetricsDashboard = (function() {
        
        let userMetrics = new Map();
        let analytics = {
            pageViews: [],
            userEngagement: [],
            featureAdoption: [],
            performanceMetrics: []
        };

        /**
         * Inicializa el dashboard de métricas
         */
        async function initialize() {
            await loadUserMetrics();
            await loadAnalytics();
            
            // Configurar tracking automático
            setupAutoTracking();
        }

        /**
         * Actualiza métricas del usuario
         */
        async function updateUserMetrics(userId, activity) {
            let metrics = userMetrics.get(userId);
            if (!metrics) {
                metrics = initializeUserMetrics(userId);
            }
            
            // Actualizar según el tipo de actividad
            switch (activity.type) {
                case 'reading':
                    updateReadingStats(metrics, activity);
                    break;
                case 'study':
                    updateStudyStats(metrics, activity);
                    break;
                case 'social':
                    updateSocialStats(metrics, activity);
                    break;
                case 'gamification':
                    updateGamificationStats(metrics, activity);
                    break;
            }
            
            metrics.lastUpdated = new Date();
            userMetrics.set(userId, metrics);
            await saveUserMetrics(metrics);
            
            EventManager.emit('metrics:updated', {
                userId: userId,
                activity: activity,
                metrics: metrics
            });
        }

        /**
         * Inicializa métricas de usuario
         */
        function initializeUserMetrics(userId) {
            return {
                userId: userId,
                period: 'all_time',
                readingStats: {
                    booksRead: 0,
                    chaptersRead: 0,
                    versesRead: 0,
                    timeSpent: 0,
                    averageSessionDuration: 0,
                    readingStreak: 0,
                    favoriteBooks: [],
                    readingPattern: [],
                    completion: {
                        oldTestament: 0,
                        newTestament: 0,
                        total: 0
                    }
                },
                studyStats: {
                    plansCompleted: 0,
                    currentPlans: 0,
                    totalStudyTime: 0,
                    notesCreated: 0,
                    reflectionsWritten: 0,
                    questionsAnswered: 0,
                    averageStudySession: 0,
                    favoriteTopics: []
                },
                socialStats: {
                    groupsJoined: 0,
                    discussionsStarted: 0,
                    repliesPosted: 0,
                    reactionsGiven: 0,
                    reactionsReceived: 0,
                    friendsCount: 0,
                    mentorshipSessions: 0
                },
                gamificationStats: {
                    totalXP: 0,
                    currentLevel: 1,
                    achievementsUnlocked: 0,
                    challengesCompleted: 0,
                    streakDays: 0,
                    leaderboardRank: 0,
                    badgesEarned: []
                },
                generalStats: {
                    accountAge: 0,
                    loginStreak: 0,
                    totalSessions: 0,
                    averageSessionTime: 0,
                    featuresUsed: [],
                    goals: []
                },
                lastUpdated: new Date()
            };
        }

        /**
         * Actualiza estadísticas de lectura
         */
        function updateReadingStats(metrics, activity) {
            const stats = metrics.readingStats;
            
            switch (activity.action) {
                case 'chapter_read':
                    stats.chaptersRead++;
                    stats.timeSpent += activity.duration || 0;
                    updateReadingPattern(stats, activity);
                    updateBookStats(stats, activity.book);
                    break;
                case 'verse_read':
                    stats.versesRead++;
                    break;
                case 'book_completed':
                    stats.booksRead++;
                    updateCompletion(stats, activity.book);
                    break;
            }
            
            // Recalcular promedios
            if (stats.chaptersRead > 0) {
                stats.averageSessionDuration = stats.timeSpent / stats.chaptersRead;
            }
        }

        /**
         * Actualiza estadísticas de estudio
         */
        function updateStudyStats(metrics, activity) {
            const stats = metrics.studyStats;
            
            switch (activity.action) {
                case 'plan_completed':
                    stats.plansCompleted++;
                    stats.currentPlans = Math.max(0, stats.currentPlans - 1);
                    break;
                case 'plan_started':
                    stats.currentPlans++;
                    break;
                case 'note_added':
                    stats.notesCreated++;
                    break;
                case 'reflection_written':
                    stats.reflectionsWritten++;
                    break;
                case 'study_session':
                    stats.totalStudyTime += activity.duration || 0;
                    updateAverageStudySession(stats);
                    break;
            }
        }

        /**
         * Genera reporte de progreso
         */
        async function generateProgressReport(userId, period = 'monthly') {
            const metrics = userMetrics.get(userId);
            if (!metrics) return null;
            
            const report = {
                userId: userId,
                period: period,
                generatedAt: new Date(),
                summary: {
                    totalReadingTime: metrics.readingStats.timeSpent,
                    chaptersRead: metrics.readingStats.chaptersRead,
                    studySessionsCompleted: metrics.studyStats.totalStudyTime / (metrics.studyStats.averageStudySession || 1),
                    currentLevel: metrics.gamificationStats.currentLevel,
                    xpEarned: metrics.gamificationStats.totalXP
                },
                insights: await generateInsights(metrics),
                recommendations: await generateRecommendations(metrics),
                goals: generateGoalSuggestions(metrics),
                charts: await generateChartData(metrics)
            };
            
            return report;
        }

        /**
         * Genera insights basados en métricas
         */
        async function generateInsights(metrics) {
            const insights = [];
            
            // Insight sobre consistencia de lectura
            if (metrics.readingStats.readingStreak > 7) {
                insights.push({
                    type: 'positive',
                    title: 'Excelente consistencia',
                    description: `Has mantenido una racha de lectura de ${metrics.readingStats.readingStreak} días`,
                    icon: '🔥'
                });
            }
            
            // Insight sobre tiempo de estudio
            const avgStudyTime = metrics.studyStats.averageStudySession;
            if (avgStudyTime > 30) {
                insights.push({
                    type: 'positive',
                    title: 'Sesiones profundas',
                    description: `Tu tiempo promedio de estudio es de ${avgStudyTime} minutos`,
                    icon: '⏰'
                });
            }
            
            // Insight sobre participación social
            if (metrics.socialStats.groupsJoined > 3) {
                insights.push({
                    type: 'social',
                    title: 'Participación activa',
                    description: `Participas en ${metrics.socialStats.groupsJoined} grupos de estudio`,
                    icon: '👥'
                });
            }
            
            return insights;
        }

        /**
         * Configura tracking automático
         */
        function setupAutoTracking() {
            // Track page views
            EventManager.on('page:view', (data) => {
                trackPageView(data.page, data.userId);
            });
            
            // Track feature usage
            EventManager.on('feature:used', (data) => {
                trackFeatureUsage(data.feature, data.userId);
            });
            
            // Track engagement metrics
            EventManager.on('user:interaction', (data) => {
                trackUserEngagement(data.type, data.userId);
            });
        }

        /**
         * Rastrea vista de página
         */
        function trackPageView(page, userId) {
            analytics.pageViews.push({
                page: page,
                userId: userId,
                timestamp: new Date(),
                sessionId: getSessionId()
            });
            
            // Mantener solo últimas 1000 vistas
            if (analytics.pageViews.length > 1000) {
                analytics.pageViews = analytics.pageViews.slice(-1000);
            }
        }

        /**
         * Obtiene estadísticas globales
         */
        function getGlobalStats() {
            const allMetrics = Array.from(userMetrics.values());
            
            return {
                totalUsers: allMetrics.length,
                totalReadingTime: allMetrics.reduce((sum, m) => sum + m.readingStats.timeSpent, 0),
                totalChaptersRead: allMetrics.reduce((sum, m) => sum + m.readingStats.chaptersRead, 0),
                totalNotesCreated: allMetrics.reduce((sum, m) => sum + m.studyStats.notesCreated, 0),
                activeUsers: allMetrics.filter(m => {
                    const daysSinceLastUpdate = (Date.now() - new Date(m.lastUpdated).getTime()) / (1000 * 60 * 60 * 24);
                    return daysSinceLastUpdate <= 7;
                }).length,
                averageLevel: allMetrics.reduce((sum, m) => sum + m.gamificationStats.currentLevel, 0) / allMetrics.length
            };
        }

        // API pública
        return {
            initialize,
            updateUserMetrics,
            generateProgressReport,
            getGlobalStats,
            getUserMetrics: (userId) => userMetrics.get(userId),
            getAnalytics: () => ({ ...analytics })
        };
    })();

    // =====================================================================
    // UTILIDADES Y FUNCIONES AUXILIARES
    // =====================================================================
    
    /**
     * Genera un ID único
     */
    function generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    /**
     * Obtiene el ID del usuario actual
     */
    function getCurrentUserId() {
        return localStorage.getItem('currentUserId') || 'user_default';
    }

    /**
     * Obtiene datos de libros bíblicos
     */
    function getBooksData() {
        // Retornar datos de libros desde BibliaRV1960Optimized si está disponible
        if (typeof BibliaRV1960Optimized !== 'undefined') {
            return BibliaRV1960Optimized.obtenerLibros();
        }
        
        // Fallback con datos básicos
        return [
            { id: 'genesis', name: 'Génesis', chapters: 50, testament: 'AT' },
            { id: 'exodo', name: 'Éxodo', chapters: 40, testament: 'AT' },
            // ... más libros
        ];
    }

    /**
     * Calcula tiempo estimado de lectura
     */
    function estimateReadingTime(book, chapter) {
        // Estimación básica: 3-5 minutos por capítulo
        const baseTime = 4; // minutos
        const bookFactors = {
            'salmos': 0.5, // Capítulos más cortos
            'proverbios': 0.7,
            'genesis': 1.2, // Capítulos más largos
            'exodo': 1.1
        };
        
        const factor = bookFactors[book] || 1;
        return Math.round(baseTime * factor);
    }

    /**
     * Sistema de eventos global
     */
    const EventManager = {
        listeners: new Map(),
        
        on(event, callback) {
            if (!this.listeners.has(event)) {
                this.listeners.set(event, []);
            }
            this.listeners.get(event).push(callback);
        },
        
        emit(event, data) {
            if (this.listeners.has(event)) {
                this.listeners.get(event).forEach(callback => {
                    try {
                        callback(data);
                    } catch (error) {
                        console.error(`Error in event listener for ${event}:`, error);
                    }
                });
            }
        },
        
        off(event, callback) {
            if (this.listeners.has(event)) {
                const callbacks = this.listeners.get(event);
                const index = callbacks.indexOf(callback);
                if (index > -1) {
                    callbacks.splice(index, 1);
                }
            }
        }
    };

    /**
     * Sistema de notificaciones mejorado
     */
    const NotificationManager = {
        show(notification) {
            // Integrar con sistema de notificaciones existente
            if (typeof SocialAvanzadoOptimizado !== 'undefined' && SocialAvanzadoOptimizado.notificationManager) {
                return SocialAvanzadoOptimizado.notificationManager.show(notification);
            }
            
            // Fallback a notificaciones del navegador
            if ('Notification' in window && Notification.permission === 'granted') {
                new Notification(notification.title, {
                    body: notification.message,
                    icon: '/favicon.ico'
                });
            }
            
            // Fallback a console
            console.log('Notification:', notification.title, notification.message);
        }
    };

    // =====================================================================
    // FUNCIONES DE PERSISTENCIA (SIMULADAS)
    // =====================================================================
    
    async function savePlan(plan) {
        localStorage.setItem(`plan_${plan.id}`, JSON.stringify(plan));
    }

    async function getPlan(planId) {
        const data = localStorage.getItem(`plan_${planId}`);
        return data ? JSON.parse(data) : null;
    }

    async function getAllPlans() {
        const plans = [];
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key.startsWith('plan_')) {
                const data = localStorage.getItem(key);
                if (data) {
                    plans.push(JSON.parse(data));
                }
            }
        }
        return plans;
    }

    async function saveProgress(progress) {
        localStorage.setItem(`progress_${progress.planId}`, JSON.stringify(progress));
    }

    // =====================================================================
    // API PÚBLICA DEL MÓDULO
    // =====================================================================
    
    return Object.freeze({
        // Configuración
        CONFIG,
        
        // Módulos principales
        PersonalizedStudySystem,
        AdvancedStudyTools,
        AITextAnalysis,
        GamificationSystem,
        MultimediaFeatures,
        CollaborationSystem,
        PreachingTools,
        MetricsDashboard,
        
        // Utilidades
        EventManager,
        NotificationManager,
        generateId,
        getCurrentUserId,
        
        // Inicialización global
        async initialize() {
            console.log('Inicializando funcionalidades avanzadas...');
            
            try {
                await PersonalizedStudySystem.initialize?.();
                await AdvancedStudyTools.initialize();
                await GamificationSystem.initialize();
                await MultimediaFeatures.initialize();
                await CollaborationSystem.initialize();
                await PreachingTools.initialize();
                await MetricsDashboard.initialize();
                
                console.log('Funcionalidades avanzadas inicializadas correctamente');
                EventManager.emit('advanced_features:initialized');
                
            } catch (error) {
                console.error('Error inicializando funcionalidades avanzadas:', error);
                throw error;
            }
        }
    });
})();

// =====================================================================
// INICIALIZACIÓN AUTOMÁTICA
// =====================================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('Cargando funcionalidades avanzadas...');
    
    // Verificar dependencias
    const dependencies = [
        'BibliaRV1960Optimized',
        'AnalisisAvanzadoOptimizado',
        'SocialAvanzadoOptimizado'
    ];
    
    const missingDeps = dependencies.filter(dep => typeof window[dep] === 'undefined');
    if (missingDeps.length > 0) {
        console.warn('Dependencias faltantes:', missingDeps);
    }
    
    // Inicializar funcionalidades avanzadas
    AdvancedFeaturesModule.initialize().then(() => {
        console.log('Todas las funcionalidades avanzadas están listas');
        
        // Emitir evento global
        window.dispatchEvent(new CustomEvent('advancedFeaturesReady', {
            detail: { module: AdvancedFeaturesModule }
        }));
        
    }).catch(error => {
        console.error('Error en inicialización de funcionalidades avanzadas:', error);
    });
});

// Hacer disponible globalmente
if (typeof window !== 'undefined') {
    window.AdvancedFeaturesModule = AdvancedFeaturesModule;
}

// Soporte para módulos ES6
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AdvancedFeaturesModule;
}
