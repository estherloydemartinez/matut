/**
 * Service Worker Avanzado con Estrategias de Cache Inteligentes
 * Implementa múltiples estrategias de cache para máximo rendimiento
 */

// =====================================================================
// CONFIGURACIÓN
// =====================================================================

const SW_VERSION = '2.0.0';
const CACHE_PREFIX = 'formacion-biblica';
const CACHE_NAMES = {
  static: `${CACHE_PREFIX}-static-v${SW_VERSION}`,
  dynamic: `${CACHE_PREFIX}-dynamic-v${SW_VERSION}`,
  api: `${CACHE_PREFIX}-api-v${SW_VERSION}`,
  images: `${CACHE_PREFIX}-images-v${SW_VERSION}`,
  fonts: `${CACHE_PREFIX}-fonts-v${SW_VERSION}`
};

const CACHE_STRATEGIES = {
  CACHE_FIRST: 'cache-first',
  NETWORK_FIRST: 'network-first',
  STALE_WHILE_REVALIDATE: 'stale-while-revalidate',
  NETWORK_ONLY: 'network-only',
  CACHE_ONLY: 'cache-only'
};

// Recursos críticos para precargar
const CRITICAL_RESOURCES = [
  '/',
  '/manifest.json',
  '/js/biblia_rv1960_optimizado.js',
  '/js/advanced-features.js'
];

// TTL para diferentes tipos de recursos (en segundos)
const CACHE_TTL = {
  static: 86400 * 7, // 7 días
  dynamic: 86400, // 1 día
  api: 1800, // 30 minutos
  images: 86400 * 30, // 30 días
  fonts: 86400 * 365 // 1 año
};

// =====================================================================
// INSTALACIÓN Y ACTIVACIÓN
// =====================================================================

self.addEventListener('install', (event) => {
  console.log(`Service Worker ${SW_VERSION} installing...`);
  
  event.waitUntil(
    (async () => {
      try {
        // Precargar recursos críticos
        const staticCache = await caches.open(CACHE_NAMES.static);
        await staticCache.addAll(CRITICAL_RESOURCES);
        
        // Inicializar otros caches
        await Promise.all([
          caches.open(CACHE_NAMES.dynamic),
          caches.open(CACHE_NAMES.api),
          caches.open(CACHE_NAMES.images),
          caches.open(CACHE_NAMES.fonts)
        ]);
        
        console.log('Service Worker installation completed');
        
        // Forzar activación inmediata
        self.skipWaiting();
      } catch (error) {
        console.error('Service Worker installation failed:', error);
      }
    })()
  );
});

self.addEventListener('activate', (event) => {
  console.log(`Service Worker ${SW_VERSION} activating...`);
  
  event.waitUntil(
    (async () => {
      try {
        // Limpiar caches antiguos
        const cacheNames = await caches.keys();
        const oldCaches = cacheNames.filter(name => 
          name.startsWith(CACHE_PREFIX) && !Object.values(CACHE_NAMES).includes(name)
        );
        
        await Promise.all(
          oldCaches.map(name => caches.delete(name))
        );
        
        console.log(`Deleted ${oldCaches.length} old caches`);
        
        // Tomar control de todas las páginas
        await self.clients.claim();
        
        console.log('Service Worker activation completed');
      } catch (error) {
        console.error('Service Worker activation failed:', error);
      }
    })()
  );
});

// =====================================================================
// ESTRATEGIAS DE CACHE
// =====================================================================

class CacheStrategy {
  static async cacheFirst(request, cacheName, ttl) {
    try {
      const cache = await caches.open(cacheName);
      const cachedResponse = await cache.match(request);
      
      if (cachedResponse) {
        // Verificar TTL si está disponible
        const cacheTime = cachedResponse.headers.get('sw-cache-time');
        if (cacheTime && ttl) {
          const age = Date.now() - parseInt(cacheTime);
          if (age > ttl * 1000) {
            // Cache expirado, intentar actualizar en background
            this.updateCacheInBackground(request, cache);
          }
        }
        return cachedResponse;
      }
      
      // No en cache, obtener de red
      const response = await fetch(request);
      if (response.status === 200) {
        await this.putInCache(cache, request, response.clone(), ttl);
      }
      return response;
    } catch (error) {
      console.error('Cache first strategy failed:', error);
      throw error;
    }
  }

  static async networkFirst(request, cacheName, ttl) {
    try {
      const cache = await caches.open(cacheName);
      
      try {
        // Intentar red primero
        const response = await fetch(request);
        if (response.status === 200) {
          await this.putInCache(cache, request, response.clone(), ttl);
        }
        return response;
      } catch (networkError) {
        // Red falló, intentar cache
        const cachedResponse = await cache.match(request);
        if (cachedResponse) {
          return cachedResponse;
        }
        throw networkError;
      }
    } catch (error) {
      console.error('Network first strategy failed:', error);
      throw error;
    }
  }

  static async staleWhileRevalidate(request, cacheName, ttl) {
    try {
      const cache = await caches.open(cacheName);
      const cachedResponse = await cache.match(request);
      
      // Actualizar cache en background
      const fetchPromise = fetch(request).then(response => {
        if (response.status === 200) {
          this.putInCache(cache, request, response.clone(), ttl);
        }
        return response;
      });
      
      // Retornar cache si está disponible, sino esperar red
      return cachedResponse || await fetchPromise;
    } catch (error) {
      console.error('Stale while revalidate strategy failed:', error);
      throw error;
    }
  }

  static async putInCache(cache, request, response, ttl) {
    if (ttl) {
      // Agregar timestamp para TTL
      const headers = new Headers(response.headers);
      headers.set('sw-cache-time', Date.now().toString());
      
      const responseWithTTL = new Response(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers: headers
      });
      
      await cache.put(request, responseWithTTL);
    } else {
      await cache.put(request, response);
    }
  }

  static async updateCacheInBackground(request, cache) {
    try {
      const response = await fetch(request);
      if (response.status === 200) {
        await cache.put(request, response);
      }
    } catch (error) {
      console.warn('Background cache update failed:', error);
    }
  }
}

// =====================================================================
// ROUTING DE REQUESTS
// =====================================================================

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Solo manejar requests HTTP/HTTPS
  if (!url.protocol.startsWith('http')) {
    return;
  }

  event.respondWith(handleRequest(request));
});

async function handleRequest(request) {
  const url = new URL(request.url);
  const pathname = url.pathname;
  
  try {
    // Determinar estrategia basada en el tipo de recurso
    if (isStaticAsset(pathname)) {
      return await CacheStrategy.cacheFirst(request, CACHE_NAMES.static, CACHE_TTL.static);
    }
    
    if (isImageAsset(pathname)) {
      return await CacheStrategy.cacheFirst(request, CACHE_NAMES.images, CACHE_TTL.images);
    }
    
    if (isFontAsset(pathname)) {
      return await CacheStrategy.cacheFirst(request, CACHE_NAMES.fonts, CACHE_TTL.fonts);
    }
    
    if (isAPIRequest(url)) {
      return await CacheStrategy.networkFirst(request, CACHE_NAMES.api, CACHE_TTL.api);
    }
    
    if (isHTMLRequest(request)) {
      return await CacheStrategy.networkFirst(request, CACHE_NAMES.dynamic, CACHE_TTL.dynamic);
    }
    
    // Estrategia por defecto para recursos dinámicos
    return await CacheStrategy.staleWhileRevalidate(request, CACHE_NAMES.dynamic, CACHE_TTL.dynamic);
    
  } catch (error) {
    console.error('Request handling failed:', error);
    
    // Fallback a offline page si está disponible
    if (request.destination === 'document') {
      const cache = await caches.open(CACHE_NAMES.static);
      const offlinePage = await cache.match('/offline.html');
      if (offlinePage) {
        return offlinePage;
      }
    }
    
    // Retornar error
    return new Response('Network error', { 
      status: 408,
      headers: { 'Content-Type': 'text/plain' }
    });
  }
}

// =====================================================================
// UTILIDADES DE CLASIFICACIÓN
// =====================================================================

function isStaticAsset(pathname) {
  return /\.(js|css|json)$/.test(pathname) || 
         pathname === '/' || 
         pathname === '/manifest.json';
}

function isImageAsset(pathname) {
  return /\.(png|jpg|jpeg|gif|webp|svg|ico)$/.test(pathname);
}

function isFontAsset(pathname) {
  return /\.(woff|woff2|ttf|otf|eot)$/.test(pathname);
}

function isAPIRequest(url) {
  return url.pathname.startsWith('/api/') || 
         url.hostname !== self.location.hostname;
}

function isHTMLRequest(request) {
  return request.destination === 'document' ||
         request.headers.get('Accept')?.includes('text/html');
}

// =====================================================================
// BACKGROUND SYNC Y NOTIFICACIONES
// =====================================================================

self.addEventListener('sync', (event) => {
  console.log('Background sync triggered:', event.tag);
  
  if (event.tag === 'background-sync') {
    event.waitUntil(performBackgroundSync());
  }
});

async function performBackgroundSync() {
  try {
    // Sincronizar datos offline
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
      client.postMessage({
        type: 'BACKGROUND_SYNC',
        payload: { status: 'started' }
      });
    });
    
    // Aquí iría la lógica de sincronización
    console.log('Background sync completed');
    
  } catch (error) {
    console.error('Background sync failed:', error);
  }
}

// Push notification handling
self.addEventListener('push', function(event) {
  if (!event.data) return;

  const options = {
    body: event.data.text(),
    icon: '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Abrir',
        icon: '/icons/action-explore.png'
      },
      {
        action: 'close',
        title: 'Cerrar',
        icon: '/icons/action-close.png'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Formación Bíblica', options)
  );
});

// Notification click handling
self.addEventListener('notificationclick', function(event) {
  event.notification.close();

  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/')
    );
  } else if (event.action === 'close') {
    return;
  } else {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// =====================================================================
// MANEJO DE MENSAJES
// =====================================================================

self.addEventListener('message', (event) => {
  const { type, payload } = event.data;
  
  switch (type) {
    case 'SKIP_WAITING':
      self.skipWaiting();
      break;
      
    case 'GET_CACHE_STATS':
      getCacheStats().then(stats => {
        event.ports[0].postMessage({ type: 'CACHE_STATS', payload: stats });
      });
      break;
      
    case 'CLEAR_CACHE':
      clearCache(payload.cacheName).then(() => {
        event.ports[0].postMessage({ type: 'CACHE_CLEARED' });
      });
      break;
      
    case 'PRECACHE_RESOURCES':
      precacheResources(payload.urls).then(() => {
        event.ports[0].postMessage({ type: 'PRECACHE_COMPLETED' });
      });
      break;
  }
});

// =====================================================================
// UTILIDADES DE GESTIÓN DE CACHE
// =====================================================================

async function getCacheStats() {
  try {
    const cacheNames = await caches.keys();
    const stats = {};
    
    for (const cacheName of cacheNames) {
      if (cacheName.startsWith(CACHE_PREFIX)) {
        const cache = await caches.open(cacheName);
        const keys = await cache.keys();
        stats[cacheName] = {
          size: keys.length,
          keys: keys.map(req => req.url)
        };
      }
    }
    
    return stats;
  } catch (error) {
    console.error('Error getting cache stats:', error);
    return {};
  }
}

async function clearCache(cacheName) {
  try {
    if (cacheName === 'all') {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames
          .filter(name => name.startsWith(CACHE_PREFIX))
          .map(name => caches.delete(name))
      );
    } else {
      await caches.delete(cacheName);
    }
    console.log(`Cache ${cacheName} cleared`);
  } catch (error) {
    console.error('Error clearing cache:', error);
  }
}

async function precacheResources(urls) {
  try {
    const cache = await caches.open(CACHE_NAMES.static);
    await cache.addAll(urls);
    console.log(`Precached ${urls.length} resources`);
  } catch (error) {
    console.error('Error precaching resources:', error);
  }
}

// =====================================================================
// LIMPIEZA AUTOMÁTICA
// =====================================================================

setInterval(async () => {
  try {
    await cleanupExpiredCache();
  } catch (error) {
    console.error('Cache cleanup failed:', error);
  }
}, 3600000); // Cada hora

async function cleanupExpiredCache() {
  const cacheNames = Object.values(CACHE_NAMES);
  
  for (const cacheName of cacheNames) {
    try {
      const cache = await caches.open(cacheName);
      const requests = await cache.keys();
      
      for (const request of requests) {
        const response = await cache.match(request);
        if (response) {
          const cacheTime = response.headers.get('sw-cache-time');
          if (cacheTime) {
            const age = Date.now() - parseInt(cacheTime);
            const ttl = getCacheTTL(cacheName) * 1000;
            
            if (age > ttl) {
              await cache.delete(request);
            }
          }
        }
      }
    } catch (error) {
      console.warn(`Cleanup failed for cache ${cacheName}:`, error);
    }
  }
}

function getCacheTTL(cacheName) {
  if (cacheName.includes('static')) return CACHE_TTL.static;
  if (cacheName.includes('api')) return CACHE_TTL.api;
  if (cacheName.includes('images')) return CACHE_TTL.images;
  if (cacheName.includes('fonts')) return CACHE_TTL.fonts;
  return CACHE_TTL.dynamic;
}

// =====================================================================
// LOGGING Y DEBUGGING
// =====================================================================

console.log(`Service Worker ${SW_VERSION} loaded`);
console.log('Cache names:', CACHE_NAMES);
console.log('Cache TTLs:', CACHE_TTL);
