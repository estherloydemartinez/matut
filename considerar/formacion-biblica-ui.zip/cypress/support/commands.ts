// Custom Cypress Commands

// Comando para login (si fuera necesario en el futuro)
Cypress.Commands.add('login', (email?: string, password?: string) => {
  const userEmail = email || Cypress.env('testUser').email;
  const userPassword = password || Cypress.env('testUser').password;
  
  cy.visit('/login');
  cy.get('[data-testid="email-input"]').type(userEmail);
  cy.get('[data-testid="password-input"]').type(userPassword);
  cy.get('[data-testid="login-button"]').click();
  
  // Verificar que el login fue exitoso
  cy.url().should('not.include', '/login');
  cy.get('[data-testid="user-menu"]').should('be.visible');
});

// Comando para navegar a secciones específicas
Cypress.Commands.add('navigateToSection', (section: string) => {
  cy.get(`[data-testid="nav-${section}"]`).click();
  cy.url().should('include', `/${section}`);
  cy.get(`[data-testid="${section}-container"]`).should('be.visible');
});

// Comando para crear una comunidad (usado en múltiples tests)
Cypress.Commands.add('createCommunity', (communityData: {
  name: string;
  description: string;
  category?: string;
  privacy?: string;
}) => {
  cy.navigateToSection('social');
  
  // Asegurar que estamos en la tab de comunidades
  cy.get('[data-testid="tab-communities"]').click();
  
  // Abrir modal de creación
  cy.get('[data-testid="create-community-button"]').click();
  cy.get('[data-testid="community-modal"]').should('be.visible');
  
  // Llenar formulario
  cy.get('[data-testid="community-name-input"]').type(communityData.name);
  cy.get('[data-testid="community-description-input"]').type(communityData.description);
  
  if (communityData.category) {
    cy.get('[data-testid="community-category-select"]').click();
    cy.get(`[data-value="${communityData.category}"]`).click();
  }
  
  if (communityData.privacy) {
    cy.get('[data-testid="community-privacy-select"]').click();
    cy.get(`[data-value="${communityData.privacy}"]`).click();
  }
  
  // Enviar formulario
  cy.get('[data-testid="submit-community-button"]').click();
  
  // Verificar creación exitosa
  cy.get('[data-testid="success-toast"]').should('contain', 'Comunidad creada');
  cy.get('[data-testid="community-modal"]').should('not.exist');
  
  // Verificar que aparece en la lista
  cy.contains('[data-testid="community-card"]', communityData.name).should('be.visible');
});

// Comando para crear grupo de estudio
Cypress.Commands.add('createStudyGroup', (groupData: {
  name: string;
  book: string;
  schedule?: string;
  maxMembers?: number;
}) => {
  cy.navigateToSection('social');
  cy.get('[data-testid="tab-groups"]').click();
  
  cy.get('[data-testid="create-group-button"]').click();
  cy.get('[data-testid="group-modal"]').should('be.visible');
  
  cy.get('[data-testid="group-name-input"]').type(groupData.name);
  cy.get('[data-testid="group-book-select"]').click();
  cy.get(`[data-value="${groupData.book}"]`).click();
  
  if (groupData.schedule) {
    cy.get('[data-testid="group-schedule-input"]').type(groupData.schedule);
  }
  
  if (groupData.maxMembers) {
    cy.get('[data-testid="group-max-members-input"]').clear().type(groupData.maxMembers.toString());
  }
  
  cy.get('[data-testid="submit-group-button"]').click();
  
  cy.get('[data-testid="success-toast"]').should('contain', 'Grupo creado');
  cy.contains('[data-testid="group-card"]', groupData.name).should('be.visible');
});

// Comando para verificar accesibilidad
Cypress.Commands.add('checkA11y', (context?: string, options?: any) => {
  cy.checkAxe(context, options);
});

// Comando para simular diferentes dispositivos
Cypress.Commands.add('setMobileViewport', () => {
  cy.viewport(375, 667); // iPhone SE
});

Cypress.Commands.add('setTabletViewport', () => {
  cy.viewport(768, 1024); // iPad
});

Cypress.Commands.add('setDesktopViewport', () => {
  cy.viewport(1280, 720); // Desktop
});

// Comando para verificar performance
Cypress.Commands.add('checkPageLoadPerformance', (maxLoadTime: number = 3000) => {
  cy.window().then((win) => {
    const perfData = win.performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
    
    if (perfData) {
      const loadTime = perfData.loadEventEnd - perfData.navigationStart;
      expect(loadTime).to.be.lessThan(maxLoadTime);
      
      cy.log(`Page load time: ${loadTime.toFixed(2)}ms`);
    }
  });
});

// Comando para verificar que no hay errores de consola
Cypress.Commands.add('checkConsoleErrors', () => {
  cy.window().then((win) => {
    const errors: string[] = [];
    
    // Interceptar console.error
    const originalError = win.console.error;
    win.console.error = (...args: any[]) => {
      errors.push(args.join(' '));
      originalError.apply(win.console, args);
    };
    
    // Al final del test, verificar que no hay errores críticos
    cy.then(() => {
      const criticalErrors = errors.filter(error => 
        !error.includes('Warning:') && 
        !error.includes('ResizeObserver') &&
        !error.includes('Non-Error promise rejection')
      );
      
      expect(criticalErrors).to.have.length(0);
    });
  });
});

// Comando para simular conexión lenta
Cypress.Commands.add('simulateSlowConnection', () => {
  cy.intercept('**', (req) => {
    req.reply((res) => {
      // Agregar delay de 2 segundos para simular conexión lenta
      return new Promise((resolve) => {
        setTimeout(() => resolve(res), 2000);
      });
    });
  });
});

// Comando para verificar responsive design
Cypress.Commands.add('checkResponsiveDesign', () => {
  const viewports = [
    { width: 375, height: 667, name: 'mobile' },
    { width: 768, height: 1024, name: 'tablet' },
    { width: 1280, height: 720, name: 'desktop' }
  ];
  
  viewports.forEach(viewport => {
    cy.viewport(viewport.width, viewport.height);
    cy.log(`Testing ${viewport.name} viewport: ${viewport.width}x${viewport.height}`);
    
    // Verificar que el contenido principal es visible
    cy.get('[data-testid="main-content"]').should('be.visible');
    
    // Verificar que no hay overflow horizontal
    cy.get('body').then($body => {
      expect($body[0].scrollWidth).to.be.at.most($body[0].clientWidth + 1);
    });
  });
});

// Declarar tipos para TypeScript
declare global {
  namespace Cypress {
    interface Chainable {
      login(email?: string, password?: string): Chainable<void>;
      navigateToSection(section: string): Chainable<void>;
      createCommunity(data: {
        name: string;
        description: string;
        category?: string;
        privacy?: string;
      }): Chainable<void>;
      createStudyGroup(data: {
        name: string;
        book: string;
        schedule?: string;
        maxMembers?: number;
      }): Chainable<void>;
      checkA11y(context?: string, options?: any): Chainable<void>;
      setMobileViewport(): Chainable<void>;
      setTabletViewport(): Chainable<void>;
      setDesktopViewport(): Chainable<void>;
      checkPageLoadPerformance(maxLoadTime?: number): Chainable<void>;
      checkConsoleErrors(): Chainable<void>;
      simulateSlowConnection(): Chainable<void>;
      checkResponsiveDesign(): Chainable<void>;
    }
  }
}
