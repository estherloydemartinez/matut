// Cypress E2E Support File
import './commands';
import 'cypress-axe';

// Configuración global para tests E2E
Cypress.on('uncaught:exception', (err, runnable) => {
  // Retorna false para prevenir que Cypress falle el test por errores no capturados
  // que podrían ser normales en desarrollo
  if (err.message.includes('ResizeObserver loop limit exceeded')) {
    return false;
  }
  if (err.message.includes('Non-Error promise rejection captured')) {
    return false;
  }
  return true;
});

// Configurar viewport antes de cada test
beforeEach(() => {
  // Configurar datos de prueba en localStorage si es necesario
  cy.window().then((win) => {
    win.localStorage.setItem('formacion-biblica-theme', 'light');
    win.localStorage.setItem('formacion-biblica-user', JSON.stringify({
      id: 'cypress-test-user',
      name: 'Cypress Test User',
      email: 'cypress@test.com'
    }));
  });
  
  // Inyectar axe para accessibility testing
  cy.injectAxe();
});

// Limpiar después de cada test
afterEach(() => {
  cy.window().then((win) => {
    win.localStorage.clear();
    win.sessionStorage.clear();
  });
});

// Comandos globales para performance monitoring
Cypress.Commands.add('measurePerformance', (name: string) => {
  cy.window().then((win) => {
    win.performance.mark(`${name}-start`);
  });
});

Cypress.Commands.add('endPerformanceMeasure', (name: string) => {
  cy.window().then((win) => {
    win.performance.mark(`${name}-end`);
    win.performance.measure(name, `${name}-start`, `${name}-end`);
    
    const measure = win.performance.getEntriesByName(name)[0];
    cy.log(`Performance: ${name} took ${measure.duration.toFixed(2)}ms`);
    
    // Fallar si toma demasiado tiempo
    expect(measure.duration).to.be.lessThan(5000); // 5 segundos max
  });
});

// Comando para esperar que la aplicación esté lista
Cypress.Commands.add('waitForAppToLoad', () => {
  // Esperar a que React se monte
  cy.get('[data-testid="app-container"]', { timeout: 30000 }).should('be.visible');
  
  // Esperar a que se carguen los datos iniciales
  cy.get('[data-testid="loading-screen"]').should('not.exist');
  
  // Verificar que no hay errores críticos
  cy.get('[data-testid="error-boundary"]').should('not.exist');
});

declare global {
  namespace Cypress {
    interface Chainable {
      measurePerformance(name: string): Chainable<void>;
      endPerformanceMeasure(name: string): Chainable<void>;
      waitForAppToLoad(): Chainable<void>;
    }
  }
}
