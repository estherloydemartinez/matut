// E2E Tests for Social Features

describe('Social Features E2E Tests', () => {
  beforeEach(() => {
    cy.visit('/');
    cy.waitForAppToLoad();
    cy.checkConsoleErrors();
  });

  describe('Community Management', () => {
    it('should create a new community successfully', () => {
      cy.measurePerformance('create-community');
      
      cy.createCommunity({
        name: 'Estudio de Apocalipsis',
        description: 'Comunidad dedicada al estudio profundo del libro de Apocalipsis',
        category: 'Profético',
        privacy: 'público'
      });
      
      cy.endPerformanceMeasure('create-community');
      
      // Verificar que la comunidad aparece en la lista del usuario
      cy.get('[data-testid="my-communities"]').should('contain', 'Estudio de Apocalipsis');
      
      // Verificar que se puede navegar a la comunidad
      cy.contains('[data-testid="community-card"]', 'Estudio de Apocalipsis').click();
      cy.url().should('include', '/community/');
      
      // Verificar accesibilidad
      cy.checkA11y();
    });

    it('should search for communities', () => {
      // Primero crear algunas comunidades para buscar
      cy.createCommunity({
        name: 'Estudio de Génesis',
        description: 'Estudiamos el libro de Génesis',
        category: 'Pentateuco'
      });
      
      cy.createCommunity({
        name: 'Grupo de Oración',
        description: 'Nos reunimos para orar juntos',
        category: 'Oración'
      });
      
      // Buscar comunidades
      cy.get('[data-testid="community-search-input"]').type('Génesis');
      cy.get('[data-testid="search-button"]').click();
      
      // Verificar resultados
      cy.get('[data-testid="search-results"]').should('contain', 'Estudio de Génesis');
      cy.get('[data-testid="search-results"]').should('not.contain', 'Grupo de Oración');
      
      // Limpiar búsqueda
      cy.get('[data-testid="clear-search-button"]').click();
      cy.get('[data-testid="search-results"]').should('contain', 'Estudio de Génesis');
      cy.get('[data-testid="search-results"]').should('contain', 'Grupo de Oración');
    });

    it('should join and leave communities', () => {
      // Crear una comunidad pública
      cy.createCommunity({
        name: 'Comunidad Pública Test',
        description: 'Una comunidad para testing',
        privacy: 'público'
      });
      
      // Simular ser otro usuario
      cy.window().then((win) => {
        win.localStorage.setItem('formacion-biblica-user', JSON.stringify({
          id: 'other-user',
          name: 'Other User'
        }));
      });
      
      cy.reload();
      cy.waitForAppToLoad();
      
      // Buscar y unirse a la comunidad
      cy.navigateToSection('social');
      cy.get('[data-testid="browse-communities"]').click();
      
      cy.contains('[data-testid="community-card"]', 'Comunidad Pública Test')
        .within(() => {
          cy.get('[data-testid="join-community-button"]').click();
        });
      
      // Verificar que se unió exitosamente
      cy.get('[data-testid="success-toast"]').should('contain', 'Te has unido');
      
      // Verificar que aparece en "Mis Comunidades"
      cy.get('[data-testid="my-communities-tab"]').click();
      cy.get('[data-testid="my-communities"]').should('contain', 'Comunidad Pública Test');
      
      // Dejar la comunidad
      cy.contains('[data-testid="community-card"]', 'Comunidad Pública Test')
        .within(() => {
          cy.get('[data-testid="leave-community-button"]').click();
        });
      
      // Confirmar
      cy.get('[data-testid="confirm-leave-button"]').click();
      cy.get('[data-testid="success-toast"]').should('contain', 'Has dejado');
    });
  });

  describe('Study Groups', () => {
    it('should create and manage study groups', () => {
      cy.measurePerformance('create-study-group');
      
      cy.createStudyGroup({
        name: 'Estudio de Salmos',
        book: 'Salmos',
        schedule: 'Miércoles 7:00 PM',
        maxMembers: 8
      });
      
      cy.endPerformanceMeasure('create-study-group');
      
      // Verificar que el grupo aparece con la información correcta
      cy.contains('[data-testid="group-card"]', 'Estudio de Salmos')
        .within(() => {
          cy.should('contain', 'Salmos');
          cy.should('contain', 'Miércoles 7:00 PM');
          cy.should('contain', '8 miembros máximo');
          cy.should('contain', 'Líder');
        });
      
      // Navegar al grupo
      cy.contains('[data-testid="group-card"]', 'Estudio de Salmos').click();
      cy.url().should('include', '/group/');
      
      // Verificar información detallada del grupo
      cy.get('[data-testid="group-details"]').should('contain', 'Estudio de Salmos');
      cy.get('[data-testid="group-members"]').should('be.visible');
      cy.get('[data-testid="group-schedule"]').should('contain', 'Miércoles 7:00 PM');
    });

    it('should show study group recommendations', () => {
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-groups"]').click();
      cy.get('[data-testid="recommendations-tab"]').click();
      
      cy.get('[data-testid="group-recommendations"]').should('be.visible');
      cy.get('[data-testid="recommendation-reason"]').should('be.visible');
      
      // Verificar que se pueden ver más detalles
      cy.get('[data-testid="view-recommendation"]').first().click();
      cy.get('[data-testid="recommendation-details"]').should('be.visible');
    });

    it('should handle group joining workflow', () => {
      // Crear un grupo como un usuario
      cy.createStudyGroup({
        name: 'Grupo Abierto Test',
        book: 'Marcos',
        maxMembers: 5
      });
      
      // Cambiar a otro usuario
      cy.window().then((win) => {
        win.localStorage.setItem('formacion-biblica-user', JSON.stringify({
          id: 'joiner-user',
          name: 'Joiner User'
        }));
      });
      
      cy.reload();
      cy.waitForAppToLoad();
      
      // Encontrar y unirse al grupo
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-groups"]').click();
      cy.get('[data-testid="browse-groups"]').click();
      
      cy.contains('[data-testid="group-card"]', 'Grupo Abierto Test')
        .within(() => {
          cy.get('[data-testid="join-group-button"]').click();
        });
      
      // Llenar solicitud si es necesario
      cy.get('[data-testid="join-request-modal"]').then($modal => {
        if ($modal.is(':visible')) {
          cy.get('[data-testid="join-message-input"]').type('Me gustaría unirme al grupo');
          cy.get('[data-testid="submit-join-request"]').click();
        }
      });
      
      cy.get('[data-testid="success-toast"]').should('contain', 'Solicitud enviada');
    });
  });

  describe('Mentorship System', () => {
    it('should request mentorship', () => {
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-mentorships"]').click();
      
      cy.get('[data-testid="request-mentorship-button"]').click();
      cy.get('[data-testid="mentorship-modal"]').should('be.visible');
      
      // Llenar formulario de solicitud
      cy.get('[data-testid="mentorship-subject-input"]').type('Hermenéutica Bíblica');
      cy.get('[data-testid="mentorship-goals-input"]').type('Quiero aprender a interpretar correctamente las Escrituras');
      
      cy.get('[data-testid="mentorship-duration-select"]').click();
      cy.get('[data-value="3-months"]').click();
      
      cy.get('[data-testid="mentorship-schedule-input"]').type('Fines de semana por la tarde');
      
      // Enviar solicitud
      cy.get('[data-testid="submit-mentorship-request"]').click();
      
      cy.get('[data-testid="success-toast"]').should('contain', 'Solicitud enviada');
      
      // Verificar que aparece en solicitudes pendientes
      cy.get('[data-testid="pending-requests"]').should('contain', 'Hermenéutica Bíblica');
    });

    it('should browse mentors and view profiles', () => {
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-mentorships"]').click();
      cy.get('[data-testid="find-mentor-tab"]').click();
      
      cy.get('[data-testid="mentor-list"]').should('be.visible');
      
      // Ver perfil de un mentor
      cy.get('[data-testid="mentor-card"]').first().click();
      cy.get('[data-testid="mentor-profile"]').should('be.visible');
      
      // Verificar información del mentor
      cy.get('[data-testid="mentor-experience"]').should('be.visible');
      cy.get('[data-testid="mentor-specialties"]').should('be.visible');
      cy.get('[data-testid="mentor-reviews"]').should('be.visible');
      
      // Solicitar mentoría desde el perfil
      cy.get('[data-testid="request-from-profile"]').click();
      cy.get('[data-testid="mentorship-modal"]').should('be.visible');
    });
  });

  describe('Real-time Collaboration', () => {
    it('should start collaborative study session', () => {
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-collaboration"]').click();
      
      cy.get('[data-testid="start-session-button"]').click();
      cy.get('[data-testid="session-modal"]').should('be.visible');
      
      // Configurar sesión
      cy.get('[data-testid="session-name-input"]').type('Estudio de Juan 3:16');
      cy.get('[data-testid="session-type-select"]').click();
      cy.get('[data-value="verse-study"]').click();
      
      cy.get('[data-testid="session-verse-input"]').type('Juan 3:16');
      
      // Crear sesión
      cy.get('[data-testid="create-session-button"]').click();
      
      cy.get('[data-testid="success-toast"]').should('contain', 'Sesión iniciada');
      
      // Verificar herramientas disponibles
      cy.get('[data-testid="collaboration-tools"]').should('be.visible');
      cy.get('[data-testid="live-chat"]').should('be.visible');
      cy.get('[data-testid="shared-annotations"]').should('be.visible');
      cy.get('[data-testid="virtual-whiteboard"]').should('be.visible');
    });

    it('should join existing collaboration session', () => {
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-collaboration"]').click();
      
      cy.get('[data-testid="active-sessions-tab"]').click();
      cy.get('[data-testid="active-sessions"]').should('be.visible');
      
      // Unirse a una sesión activa
      cy.get('[data-testid="join-session-button"]').first().click();
      
      cy.get('[data-testid="success-toast"]').should('contain', 'Te has unido');
      
      // Verificar que está en la sesión
      cy.get('[data-testid="session-participants"]').should('be.visible');
      cy.get('[data-testid="leave-session-button"]').should('be.visible');
    });
  });

  describe('Gamification and Challenges', () => {
    it('should create and participate in challenges', () => {
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-challenges"]').click();
      
      cy.get('[data-testid="create-challenge-button"]').click();
      cy.get('[data-testid="challenge-modal"]').should('be.visible');
      
      // Llenar formulario de desafío
      cy.get('[data-testid="challenge-title-input"]').type('Leer Proverbios en 31 días');
      cy.get('[data-testid="challenge-description-input"]').type('Lee un capítulo de Proverbios cada día durante un mes');
      
      cy.get('[data-testid="challenge-type-select"]').click();
      cy.get('[data-value="individual"]').click();
      
      cy.get('[data-testid="challenge-difficulty-select"]').click();
      cy.get('[data-value="easy"]').click();
      
      // Configurar recompensas
      cy.get('[data-testid="challenge-points-input"]').clear().type('500');
      
      // Crear desafío
      cy.get('[data-testid="submit-challenge-button"]').click();
      
      cy.get('[data-testid="success-toast"]').should('contain', 'Desafío creado');
      
      // Verificar que aparece en la lista
      cy.contains('[data-testid="challenge-card"]', 'Leer Proverbios en 31 días').should('be.visible');
      
      // Unirse al propio desafío
      cy.contains('[data-testid="challenge-card"]', 'Leer Proverbios en 31 días')
        .within(() => {
          cy.get('[data-testid="join-challenge-button"]').click();
        });
      
      cy.get('[data-testid="success-toast"]').should('contain', 'Te has unido');
    });

    it('should track challenge progress', () => {
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-challenges"]').click();
      cy.get('[data-testid="my-progress-tab"]').click();
      
      cy.get('[data-testid="active-challenges"]').should('be.visible');
      cy.get('[data-testid="progress-bar"]').should('be.visible');
      
      // Actualizar progreso
      cy.get('[data-testid="update-progress-button"]').first().click();
      cy.get('[data-testid="progress-modal"]').should('be.visible');
      
      cy.get('[data-testid="chapters-read-input"]').clear().type('5');
      cy.get('[data-testid="notes-input"]').type('Completé los primeros 5 capítulos');
      
      cy.get('[data-testid="update-progress-submit"]').click();
      
      cy.get('[data-testid="success-toast"]').should('contain', 'Progreso actualizado');
    });

    it('should display leaderboards and achievements', () => {
      cy.navigateToSection('social');
      cy.get('[data-testid="tab-challenges"]').click();
      cy.get('[data-testid="leaderboard-tab"]').click();
      
      cy.get('[data-testid="global-leaderboard"]').should('be.visible');
      cy.get('[data-testid="user-ranking"]').should('be.visible');
      
      // Ver achievements
      cy.get('[data-testid="achievements-tab"]').click();
      cy.get('[data-testid="user-achievements"]').should('be.visible');
      cy.get('[data-testid="available-achievements"]').should('be.visible');
    });
  });

  describe('Cross-device and Responsive Testing', () => {
    it('should work correctly on mobile devices', () => {
      cy.setMobileViewport();
      
      cy.navigateToSection('social');
      
      // Verificar que la navegación móvil funciona
      cy.get('[data-testid="mobile-nav-toggle"]').click();
      cy.get('[data-testid="mobile-nav-menu"]').should('be.visible');
      
      // Verificar tabs responsive
      cy.get('[data-testid="tab-communities"]').click();
      cy.get('[data-testid="community-list"]').should('be.visible');
      
      // Crear comunidad en móvil
      cy.get('[data-testid="create-community-button"]').click();
      cy.get('[data-testid="community-modal"]').should('be.visible');
      
      // Verificar que el modal es responsive
      cy.get('[data-testid="community-modal"]').should('have.css', 'width');
      
      cy.checkA11y();
    });

    it('should maintain functionality across different viewports', () => {
      cy.checkResponsiveDesign();
    });
  });

  describe('Performance and Load Testing', () => {
    it('should load social features within performance budgets', () => {
      cy.measurePerformance('social-page-load');
      
      cy.navigateToSection('social');
      
      cy.endPerformanceMeasure('social-page-load');
      cy.checkPageLoadPerformance(3000);
      
      // Verificar que no hay errores de performance
      cy.window().then((win) => {
        const perfEntries = win.performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
        
        // First Contentful Paint < 1.5s
        expect(perfEntries.responseEnd - perfEntries.navigationStart).to.be.lessThan(1500);
        
        // DOM Content Loaded < 2s
        expect(perfEntries.domContentLoadedEventEnd - perfEntries.navigationStart).to.be.lessThan(2000);
      });
    });

    it('should handle large datasets efficiently', () => {
      // Mock large dataset response
      cy.intercept('GET', '**/communities', { fixture: 'large-communities-dataset.json' });
      cy.intercept('GET', '**/groups', { fixture: 'large-groups-dataset.json' });
      
      cy.navigateToSection('social');
      
      // Verificar que la lista se renderiza sin problemas
      cy.get('[data-testid="community-list"]', { timeout: 10000 }).should('be.visible');
      
      // Verificar scroll virtual si está implementado
      cy.get('[data-testid="community-list"]').scrollTo('bottom');
      cy.get('[data-testid="community-card"]').should('have.length.greaterThan', 10);
    });

    it('should handle network issues gracefully', () => {
      // Simular conexión lenta
      cy.simulateSlowConnection();
      
      cy.navigateToSection('social');
      
      // Verificar estados de carga
      cy.get('[data-testid="loading-spinner"]').should('be.visible');
      cy.get('[data-testid="loading-spinner"]', { timeout: 15000 }).should('not.exist');
      
      // Simular error de red
      cy.intercept('GET', '**/communities', { statusCode: 500 });
      
      cy.reload();
      cy.waitForAppToLoad();
      cy.navigateToSection('social');
      
      // Verificar manejo de errores
      cy.get('[data-testid="error-message"]').should('be.visible');
      cy.get('[data-testid="retry-button"]').should('be.visible');
      
      // Verificar recuperación
      cy.intercept('GET', '**/communities', { fixture: 'communities.json' });
      cy.get('[data-testid="retry-button"]').click();
      
      cy.get('[data-testid="community-list"]').should('be.visible');
    });
  });

  describe('Accessibility Compliance', () => {
    it('should meet WCAG 2.1 AA standards', () => {
      cy.navigateToSection('social');
      
      // Test accessibility for each major section
      cy.get('[data-testid="tab-communities"]').click();
      cy.checkA11y('[data-testid="communities-section"]');
      
      cy.get('[data-testid="tab-groups"]').click();
      cy.checkA11y('[data-testid="groups-section"]');
      
      cy.get('[data-testid="tab-mentorships"]').click();
      cy.checkA11y('[data-testid="mentorships-section"]');
      
      cy.get('[data-testid="tab-collaboration"]').click();
      cy.checkA11y('[data-testid="collaboration-section"]');
      
      cy.get('[data-testid="tab-challenges"]').click();
      cy.checkA11y('[data-testid="challenges-section"]');
    });

    it('should support keyboard navigation', () => {
      cy.navigateToSection('social');
      
      // Tab through all interactive elements
      cy.get('body').tab();
      cy.focused().should('have.attr', 'data-testid', 'tab-communities');
      
      cy.focused().tab();
      cy.focused().should('have.attr', 'data-testid', 'tab-groups');
      
      // Test Enter key activation
      cy.focused().type('{enter}');
      cy.get('[data-testid="groups-section"]').should('be.visible');
      
      // Test Escape key
      cy.get('[data-testid="create-group-button"]').click();
      cy.get('[data-testid="group-modal"]').should('be.visible');
      cy.get('body').type('{esc}');
      cy.get('[data-testid="group-modal"]').should('not.exist');
    });
  });
});
