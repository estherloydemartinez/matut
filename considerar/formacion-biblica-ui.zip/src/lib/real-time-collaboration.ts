/**
 * Sistema de Colaboración en Tiempo Real
 * WebRTC, WebSockets, Anotaciones Colaborativas, Chat y Sincronización
 */

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface RealTimeConnection {
  id: string;
  type: 'websocket' | 'webrtc' | 'peer-to-peer';
  status: 'connecting' | 'connected' | 'disconnected' | 'error';
  participants: RealTimeParticipant[];
  room: string;
  capabilities: ConnectionCapabilities;
}

export interface RealTimeParticipant {
  id: string;
  name: string;
  avatar?: string;
  role: 'host' | 'moderator' | 'participant' | 'observer';
  permissions: ParticipantPermissions;
  status: 'active' | 'away' | 'busy' | 'offline';
  lastActivity: Date;
  connection: {
    quality: 'excellent' | 'good' | 'poor';
    latency: number;
    bandwidth: number;
  };
}

export interface CollaborativeAnnotation {
  id: string;
  userId: string;
  type: 'text' | 'highlight' | 'bookmark' | 'question' | 'note';
  content: string;
  position: AnnotationPosition;
  verse?: {
    book: string;
    chapter: number;
    verse: number;
  };
  timestamp: Date;
  replies: AnnotationReply[];
  reactions: AnnotationReaction[];
  visibility: 'public' | 'group' | 'private';
  tags: string[];
}

export interface ChatMessage {
  id: string;
  userId: string;
  type: 'text' | 'image' | 'file' | 'verse' | 'poll' | 'system';
  content: any;
  timestamp: Date;
  replyTo?: string;
  reactions: MessageReaction[];
  mentions: string[];
  attachments: ChatAttachment[];
  isEdited: boolean;
  editHistory: EditHistory[];
}

export interface VirtualWhiteboard {
  id: string;
  name: string;
  elements: WhiteboardElement[];
  collaborators: string[];
  lastModified: Date;
  version: number;
  permissions: WhiteboardPermissions;
  background: {
    type: 'blank' | 'grid' | 'lines' | 'bible-timeline' | 'mind-map';
    color: string;
  };
}

export interface SyncSession {
  id: string;
  type: 'reading' | 'study' | 'discussion' | 'prayer';
  currentVerse: {
    book: string;
    chapter: number;
    verse: number;
  };
  participants: string[];
  leader: string;
  pace: 'slow' | 'normal' | 'fast';
  autoAdvance: boolean;
  settings: SyncSettings;
}

export interface VideoCallSession {
  id: string;
  roomId: string;
  participants: VideoParticipant[];
  status: 'waiting' | 'active' | 'ended';
  features: {
    audio: boolean;
    video: boolean;
    screenShare: boolean;
    recording: boolean;
    chat: boolean;
    whiteboard: boolean;
  };
  quality: VideoQuality;
  recording?: {
    isRecording: boolean;
    startTime?: Date;
    url?: string;
  };
}

// Interfaces auxiliares
interface ConnectionCapabilities {
  audio: boolean;
  video: boolean;
  screenShare: boolean;
  fileTransfer: boolean;
  realTimeSync: boolean;
  whiteboard: boolean;
}

interface ParticipantPermissions {
  canSpeak: boolean;
  canAnnotate: boolean;
  canControl: boolean;
  canInvite: boolean;
  canRecord: boolean;
  canModerate: boolean;
}

interface AnnotationPosition {
  x: number;
  y: number;
  width?: number;
  height?: number;
  element?: string;
}

interface AnnotationReply {
  id: string;
  userId: string;
  content: string;
  timestamp: Date;
}

interface AnnotationReaction {
  userId: string;
  type: 'like' | 'love' | 'pray' | 'question' | 'amen';
  timestamp: Date;
}

interface MessageReaction {
  userId: string;
  emoji: string;
  timestamp: Date;
}

interface ChatAttachment {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
}

interface EditHistory {
  content: string;
  timestamp: Date;
  reason?: string;
}

interface WhiteboardElement {
  id: string;
  type: 'text' | 'shape' | 'image' | 'line' | 'arrow' | 'sticky-note';
  position: { x: number; y: number };
  size: { width: number; height: number };
  style: ElementStyle;
  content: any;
  userId: string;
  timestamp: Date;
  locked: boolean;
}

interface ElementStyle {
  color: string;
  backgroundColor?: string;
  fontSize?: number;
  fontFamily?: string;
  strokeWidth?: number;
  opacity?: number;
}

interface WhiteboardPermissions {
  canEdit: string[];
  canView: string[];
  isPublic: boolean;
}

interface SyncSettings {
  allowParticipantControl: boolean;
  showCursor: boolean;
  highlightMode: 'leader' | 'all' | 'none';
  notifications: boolean;
}

interface VideoParticipant {
  userId: string;
  stream?: MediaStream;
  audioEnabled: boolean;
  videoEnabled: boolean;
  screenSharing: boolean;
  isSpeaking: boolean;
}

interface VideoQuality {
  resolution: '480p' | '720p' | '1080p';
  frameRate: number;
  bandwidth: number;
}

// =====================================================================
// SISTEMA DE COLABORACIÓN EN TIEMPO REAL
// =====================================================================

export class RealTimeCollaboration {
  private connections: Map<string, RealTimeConnection> = new Map();
  private annotations: Map<string, CollaborativeAnnotation[]> = new Map();
  private chatRooms: Map<string, ChatMessage[]> = new Map();
  private whiteboards: Map<string, VirtualWhiteboard> = new Map();
  private syncSessions: Map<string, SyncSession> = new Map();
  private videoCalls: Map<string, VideoCallSession> = new Map();
  
  private eventEmitter: EventTarget = new EventTarget();
  private currentUser: string = '';
  private isInitialized: boolean = false;

  // WebRTC y WebSocket simulados
  private webSocketConnection: WebSocket | null = null;
  private peerConnections: Map<string, RTCPeerConnection> = new Map();

  constructor(userId: string) {
    this.currentUser = userId;
    this.initialize();
  }

  // =====================================================================
  // INICIALIZACIÓN
  // =====================================================================

  private async initialize(): Promise<void> {
    try {
      await this.setupMockData();
      this.setupEventHandlers();
      
      this.isInitialized = true;
      console.log('Real-time collaboration system initialized');
    } catch (error) {
      console.error('Error initializing collaboration system:', error);
    }
  }

  private async setupMockData(): Promise<void> {
    // Datos de ejemplo para demostración
    const mockAnnotation: CollaborativeAnnotation = {
      id: 'ann1',
      userId: 'user1',
      type: 'highlight',
      content: 'Versículo clave sobre la fe',
      position: { x: 100, y: 200 },
      verse: { book: 'Hebreos', chapter: 11, verse: 1 },
      timestamp: new Date(),
      replies: [],
      reactions: [],
      visibility: 'group',
      tags: ['fe', 'estudio']
    };

    this.annotations.set('session1', [mockAnnotation]);

    const mockChatMessage: ChatMessage = {
      id: 'msg1',
      userId: 'user1',
      type: 'text',
      content: '¡Excelente punto sobre este versículo!',
      timestamp: new Date(),
      reactions: [],
      mentions: [],
      attachments: [],
      isEdited: false,
      editHistory: []
    };

    this.chatRooms.set('session1', [mockChatMessage]);
  }

  private setupEventHandlers(): void {
    // Simular eventos de tiempo real
    this.eventEmitter.addEventListener('annotation-added', this.handleAnnotationAdded.bind(this));
    this.eventEmitter.addEventListener('chat-message', this.handleChatMessage.bind(this));
    this.eventEmitter.addEventListener('sync-update', this.handleSyncUpdate.bind(this));
  }

  // =====================================================================
  // GESTIÓN DE CONEXIONES
  // =====================================================================

  async createConnection(roomId: string, type: 'websocket' | 'webrtc' = 'websocket'): Promise<RealTimeConnection> {
    const connection: RealTimeConnection = {
      id: this.generateId(),
      type,
      status: 'connecting',
      participants: [{
        id: this.currentUser,
        name: 'Usuario Actual',
        role: 'host',
        permissions: {
          canSpeak: true,
          canAnnotate: true,
          canControl: true,
          canInvite: true,
          canRecord: true,
          canModerate: true
        },
        status: 'active',
        lastActivity: new Date(),
        connection: {
          quality: 'excellent',
          latency: 45,
          bandwidth: 1000
        }
      }],
      room: roomId,
      capabilities: {
        audio: true,
        video: true,
        screenShare: true,
        fileTransfer: true,
        realTimeSync: true,
        whiteboard: true
      }
    };

    if (type === 'websocket') {
      await this.setupWebSocketConnection(roomId);
    } else {
      await this.setupWebRTCConnection(roomId);
    }

    connection.status = 'connected';
    this.connections.set(connection.id, connection);
    
    this.emitEvent('connection-established', { connection });
    return connection;
  }

  private async setupWebSocketConnection(roomId: string): Promise<void> {
    // Simulación de WebSocket
    console.log(`Setting up WebSocket connection for room: ${roomId}`);
    
    // En una implementación real, aquí estaría:
    // this.webSocketConnection = new WebSocket(`ws://your-server.com/room/${roomId}`);
    
    // Simular conexión exitosa
    setTimeout(() => {
      this.emitEvent('websocket-connected', { roomId });
    }, 1000);
  }

  private async setupWebRTCConnection(roomId: string): Promise<void> {
    // Simulación de WebRTC
    console.log(`Setting up WebRTC connection for room: ${roomId}`);
    
    // En una implementación real, aquí estaría el setup de WebRTC
    const peerConnection = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    });

    this.peerConnections.set(roomId, peerConnection);
    
    // Simular conexión exitosa
    setTimeout(() => {
      this.emitEvent('webrtc-connected', { roomId });
    }, 1500);
  }

  async joinRoom(connectionId: string, userId: string, userData: Partial<RealTimeParticipant>): Promise<boolean> {
    const connection = this.connections.get(connectionId);
    if (!connection) return false;

    const participant: RealTimeParticipant = {
      id: userId,
      name: userData.name || 'Usuario',
      avatar: userData.avatar,
      role: userData.role || 'participant',
      permissions: userData.permissions || this.getDefaultPermissions(),
      status: 'active',
      lastActivity: new Date(),
      connection: {
        quality: 'good',
        latency: 60,
        bandwidth: 800
      }
    };

    connection.participants.push(participant);
    this.connections.set(connectionId, connection);
    
    this.emitEvent('participant-joined', { connectionId, participant });
    return true;
  }

  // =====================================================================
  // ANOTACIONES COLABORATIVAS
  // =====================================================================

  async addAnnotation(sessionId: string, annotation: Partial<CollaborativeAnnotation>): Promise<CollaborativeAnnotation> {
    const newAnnotation: CollaborativeAnnotation = {
      id: this.generateId(),
      userId: this.currentUser,
      type: annotation.type || 'text',
      content: annotation.content || '',
      position: annotation.position || { x: 0, y: 0 },
      verse: annotation.verse,
      timestamp: new Date(),
      replies: [],
      reactions: [],
      visibility: annotation.visibility || 'group',
      tags: annotation.tags || []
    };

    const sessionAnnotations = this.annotations.get(sessionId) || [];
    sessionAnnotations.push(newAnnotation);
    this.annotations.set(sessionId, sessionAnnotations);

    this.emitEvent('annotation-added', { sessionId, annotation: newAnnotation });
    
    // Sincronizar con otros participantes
    this.broadcastToSession(sessionId, 'annotation-sync', newAnnotation);
    
    return newAnnotation;
  }

  async addAnnotationReply(sessionId: string, annotationId: string, content: string): Promise<boolean> {
    const sessionAnnotations = this.annotations.get(sessionId);
    if (!sessionAnnotations) return false;

    const annotation = sessionAnnotations.find(a => a.id === annotationId);
    if (!annotation) return false;

    const reply: AnnotationReply = {
      id: this.generateId(),
      userId: this.currentUser,
      content,
      timestamp: new Date()
    };

    annotation.replies.push(reply);
    this.annotations.set(sessionId, sessionAnnotations);

    this.emitEvent('annotation-reply-added', { sessionId, annotationId, reply });
    this.broadcastToSession(sessionId, 'annotation-reply-sync', { annotationId, reply });
    
    return true;
  }

  async reactToAnnotation(sessionId: string, annotationId: string, reactionType: string): Promise<boolean> {
    const sessionAnnotations = this.annotations.get(sessionId);
    if (!sessionAnnotations) return false;

    const annotation = sessionAnnotations.find(a => a.id === annotationId);
    if (!annotation) return false;

    // Remover reacción existente del usuario si existe
    annotation.reactions = annotation.reactions.filter(r => r.userId !== this.currentUser);

    // Agregar nueva reacción
    const reaction: AnnotationReaction = {
      userId: this.currentUser,
      type: reactionType as any,
      timestamp: new Date()
    };

    annotation.reactions.push(reaction);
    this.annotations.set(sessionId, sessionAnnotations);

    this.emitEvent('annotation-reaction-added', { sessionId, annotationId, reaction });
    this.broadcastToSession(sessionId, 'annotation-reaction-sync', { annotationId, reaction });
    
    return true;
  }

  getSessionAnnotations(sessionId: string): CollaborativeAnnotation[] {
    return this.annotations.get(sessionId) || [];
  }

  // =====================================================================
  // CHAT EN TIEMPO REAL
  // =====================================================================

  async sendChatMessage(sessionId: string, content: any, type: 'text' | 'image' | 'file' | 'verse' = 'text'): Promise<ChatMessage> {
    const message: ChatMessage = {
      id: this.generateId(),
      userId: this.currentUser,
      type,
      content,
      timestamp: new Date(),
      reactions: [],
      mentions: this.extractMentions(content),
      attachments: [],
      isEdited: false,
      editHistory: []
    };

    const roomMessages = this.chatRooms.get(sessionId) || [];
    roomMessages.push(message);
    this.chatRooms.set(sessionId, roomMessages);

    this.emitEvent('chat-message-sent', { sessionId, message });
    this.broadcastToSession(sessionId, 'chat-message', message);
    
    return message;
  }

  async reactToMessage(sessionId: string, messageId: string, emoji: string): Promise<boolean> {
    const roomMessages = this.chatRooms.get(sessionId);
    if (!roomMessages) return false;

    const message = roomMessages.find(m => m.id === messageId);
    if (!message) return false;

    // Remover reacción existente del usuario si existe
    message.reactions = message.reactions.filter(r => r.userId !== this.currentUser);

    // Agregar nueva reacción
    const reaction: MessageReaction = {
      userId: this.currentUser,
      emoji,
      timestamp: new Date()
    };

    message.reactions.push(reaction);
    this.chatRooms.set(sessionId, roomMessages);

    this.emitEvent('message-reaction-added', { sessionId, messageId, reaction });
    this.broadcastToSession(sessionId, 'message-reaction', { messageId, reaction });
    
    return true;
  }

  async editMessage(sessionId: string, messageId: string, newContent: string, reason?: string): Promise<boolean> {
    const roomMessages = this.chatRooms.get(sessionId);
    if (!roomMessages) return false;

    const message = roomMessages.find(m => m.id === messageId);
    if (!message || message.userId !== this.currentUser) return false;

    // Guardar en historial
    message.editHistory.push({
      content: message.content,
      timestamp: new Date(),
      reason
    });

    message.content = newContent;
    message.isEdited = true;
    
    this.chatRooms.set(sessionId, roomMessages);

    this.emitEvent('message-edited', { sessionId, messageId, newContent });
    this.broadcastToSession(sessionId, 'message-edit', { messageId, newContent });
    
    return true;
  }

  getChatMessages(sessionId: string): ChatMessage[] {
    return this.chatRooms.get(sessionId) || [];
  }

  // =====================================================================
  // PIZARRA VIRTUAL
  // =====================================================================

  async createWhiteboard(name: string, sessionId: string): Promise<VirtualWhiteboard> {
    const whiteboard: VirtualWhiteboard = {
      id: this.generateId(),
      name,
      elements: [],
      collaborators: [this.currentUser],
      lastModified: new Date(),
      version: 1,
      permissions: {
        canEdit: [this.currentUser],
        canView: [],
        isPublic: false
      },
      background: {
        type: 'grid',
        color: '#ffffff'
      }
    };

    this.whiteboards.set(whiteboard.id, whiteboard);
    this.emitEvent('whiteboard-created', { sessionId, whiteboard });
    
    return whiteboard;
  }

  async addWhiteboardElement(whiteboardId: string, element: Partial<WhiteboardElement>): Promise<WhiteboardElement> {
    const whiteboard = this.whiteboards.get(whiteboardId);
    if (!whiteboard) throw new Error('Whiteboard not found');

    const newElement: WhiteboardElement = {
      id: this.generateId(),
      type: element.type || 'text',
      position: element.position || { x: 100, y: 100 },
      size: element.size || { width: 100, height: 50 },
      style: element.style || { color: '#000000' },
      content: element.content || '',
      userId: this.currentUser,
      timestamp: new Date(),
      locked: false
    };

    whiteboard.elements.push(newElement);
    whiteboard.lastModified = new Date();
    whiteboard.version++;
    
    this.whiteboards.set(whiteboardId, whiteboard);

    this.emitEvent('whiteboard-element-added', { whiteboardId, element: newElement });
    this.broadcastWhiteboardUpdate(whiteboardId, 'element-added', newElement);
    
    return newElement;
  }

  async updateWhiteboardElement(whiteboardId: string, elementId: string, updates: Partial<WhiteboardElement>): Promise<boolean> {
    const whiteboard = this.whiteboards.get(whiteboardId);
    if (!whiteboard) return false;

    const elementIndex = whiteboard.elements.findIndex(e => e.id === elementId);
    if (elementIndex === -1) return false;

    const element = whiteboard.elements[elementIndex];
    
    // Verificar permisos
    if (element.locked && element.userId !== this.currentUser) return false;

    Object.assign(element, updates);
    whiteboard.lastModified = new Date();
    whiteboard.version++;
    
    this.whiteboards.set(whiteboardId, whiteboard);

    this.emitEvent('whiteboard-element-updated', { whiteboardId, elementId, updates });
    this.broadcastWhiteboardUpdate(whiteboardId, 'element-updated', { elementId, updates });
    
    return true;
  }

  getWhiteboard(whiteboardId: string): VirtualWhiteboard | undefined {
    return this.whiteboards.get(whiteboardId);
  }

  // =====================================================================
  // SINCRONIZACIÓN DE LECTURA
  // =====================================================================

  async createSyncSession(sessionId: string, initialVerse: { book: string; chapter: number; verse: number }): Promise<SyncSession> {
    const syncSession: SyncSession = {
      id: sessionId,
      type: 'reading',
      currentVerse: initialVerse,
      participants: [this.currentUser],
      leader: this.currentUser,
      pace: 'normal',
      autoAdvance: false,
      settings: {
        allowParticipantControl: false,
        showCursor: true,
        highlightMode: 'leader',
        notifications: true
      }
    };

    this.syncSessions.set(sessionId, syncSession);
    this.emitEvent('sync-session-created', { syncSession });
    
    return syncSession;
  }

  async updateSyncPosition(sessionId: string, verse: { book: string; chapter: number; verse: number }): Promise<boolean> {
    const syncSession = this.syncSessions.get(sessionId);
    if (!syncSession) return false;

    // Verificar si el usuario puede controlar
    if (syncSession.leader !== this.currentUser && !syncSession.settings.allowParticipantControl) {
      return false;
    }

    syncSession.currentVerse = verse;
    this.syncSessions.set(sessionId, syncSession);

    this.emitEvent('sync-position-updated', { sessionId, verse });
    this.broadcastToSession(sessionId, 'sync-update', { verse });
    
    return true;
  }

  async joinSyncSession(sessionId: string): Promise<boolean> {
    const syncSession = this.syncSessions.get(sessionId);
    if (!syncSession) return false;

    if (!syncSession.participants.includes(this.currentUser)) {
      syncSession.participants.push(this.currentUser);
      this.syncSessions.set(sessionId, syncSession);
    }

    this.emitEvent('sync-session-joined', { sessionId, userId: this.currentUser });
    this.broadcastToSession(sessionId, 'participant-joined-sync', { userId: this.currentUser });
    
    return true;
  }

  getSyncSession(sessionId: string): SyncSession | undefined {
    return this.syncSessions.get(sessionId);
  }

  // =====================================================================
  // VIDEOLLAMADAS (WebRTC)
  // =====================================================================

  async startVideoCall(sessionId: string, features: Partial<VideoCallSession['features']> = {}): Promise<VideoCallSession> {
    const videoCall: VideoCallSession = {
      id: this.generateId(),
      roomId: sessionId,
      participants: [{
        userId: this.currentUser,
        audioEnabled: true,
        videoEnabled: true,
        screenSharing: false,
        isSpeaking: false
      }],
      status: 'waiting',
      features: {
        audio: true,
        video: true,
        screenShare: true,
        recording: false,
        chat: true,
        whiteboard: true,
        ...features
      },
      quality: {
        resolution: '720p',
        frameRate: 30,
        bandwidth: 1000
      }
    };

    this.videoCalls.set(videoCall.id, videoCall);
    
    // Simular inicio de llamada
    setTimeout(() => {
      videoCall.status = 'active';
      this.videoCalls.set(videoCall.id, videoCall);
      this.emitEvent('video-call-started', { videoCall });
    }, 2000);

    return videoCall;
  }

  async joinVideoCall(callId: string): Promise<boolean> {
    const videoCall = this.videoCalls.get(callId);
    if (!videoCall) return false;

    const participant: VideoParticipant = {
      userId: this.currentUser,
      audioEnabled: true,
      videoEnabled: true,
      screenSharing: false,
      isSpeaking: false
    };

    videoCall.participants.push(participant);
    this.videoCalls.set(callId, videoCall);

    this.emitEvent('video-call-joined', { callId, participant });
    
    return true;
  }

  async toggleAudio(callId: string, enabled: boolean): Promise<boolean> {
    const videoCall = this.videoCalls.get(callId);
    if (!videoCall) return false;

    const participant = videoCall.participants.find(p => p.userId === this.currentUser);
    if (!participant) return false;

    participant.audioEnabled = enabled;
    this.videoCalls.set(callId, videoCall);

    this.emitEvent('audio-toggled', { callId, userId: this.currentUser, enabled });
    this.broadcastToVideoCall(callId, 'audio-toggle', { userId: this.currentUser, enabled });
    
    return true;
  }

  async toggleVideo(callId: string, enabled: boolean): Promise<boolean> {
    const videoCall = this.videoCalls.get(callId);
    if (!videoCall) return false;

    const participant = videoCall.participants.find(p => p.userId === this.currentUser);
    if (!participant) return false;

    participant.videoEnabled = enabled;
    this.videoCalls.set(callId, videoCall);

    this.emitEvent('video-toggled', { callId, userId: this.currentUser, enabled });
    this.broadcastToVideoCall(callId, 'video-toggle', { userId: this.currentUser, enabled });
    
    return true;
  }

  async startScreenShare(callId: string): Promise<boolean> {
    const videoCall = this.videoCalls.get(callId);
    if (!videoCall || !videoCall.features.screenShare) return false;

    const participant = videoCall.participants.find(p => p.userId === this.currentUser);
    if (!participant) return false;

    // Detener screen share de otros participantes
    videoCall.participants.forEach(p => {
      if (p.userId !== this.currentUser) {
        p.screenSharing = false;
      }
    });

    participant.screenSharing = true;
    this.videoCalls.set(callId, videoCall);

    this.emitEvent('screen-share-started', { callId, userId: this.currentUser });
    this.broadcastToVideoCall(callId, 'screen-share-start', { userId: this.currentUser });
    
    return true;
  }

  getVideoCall(callId: string): VideoCallSession | undefined {
    return this.videoCalls.get(callId);
  }

  // =====================================================================
  // MÉTODOS AUXILIARES
  // =====================================================================

  private extractMentions(content: string): string[] {
    if (typeof content !== 'string') return [];
    
    const mentionRegex = /@(\w+)/g;
    const mentions: string[] = [];
    let match;

    while ((match = mentionRegex.exec(content)) !== null) {
      mentions.push(match[1]);
    }

    return mentions;
  }

  private broadcastToSession(sessionId: string, event: string, data: any): void {
    // Simular broadcast a todos los participantes de la sesión
    console.log(`Broadcasting to session ${sessionId}:`, event, data);
    
    // En una implementación real, aquí se enviaría el evento via WebSocket
    setTimeout(() => {
      this.emitEvent('broadcast-received', { sessionId, event, data });
    }, 100);
  }

  private broadcastWhiteboardUpdate(whiteboardId: string, event: string, data: any): void {
    console.log(`Broadcasting whiteboard update ${whiteboardId}:`, event, data);
    
    setTimeout(() => {
      this.emitEvent('whiteboard-update-received', { whiteboardId, event, data });
    }, 100);
  }

  private broadcastToVideoCall(callId: string, event: string, data: any): void {
    console.log(`Broadcasting to video call ${callId}:`, event, data);
    
    setTimeout(() => {
      this.emitEvent('video-call-update-received', { callId, event, data });
    }, 100);
  }

  private getDefaultPermissions(): ParticipantPermissions {
    return {
      canSpeak: true,
      canAnnotate: true,
      canControl: false,
      canInvite: false,
      canRecord: false,
      canModerate: false
    };
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private emitEvent(eventType: string, data: any): void {
    this.eventEmitter.dispatchEvent(new CustomEvent(eventType, { detail: data }));
  }

  // Handlers de eventos
  private handleAnnotationAdded(event: Event): void {
    const detail = (event as CustomEvent).detail;
    console.log('Annotation added:', detail);
  }

  private handleChatMessage(event: Event): void {
    const detail = (event as CustomEvent).detail;
    console.log('Chat message received:', detail);
  }

  private handleSyncUpdate(event: Event): void {
    const detail = (event as CustomEvent).detail;
    console.log('Sync update received:', detail);
  }

  // =====================================================================
  // MÉTODOS PÚBLICOS ADICIONALES
  // =====================================================================

  addEventListener(eventType: string, listener: EventListener): void {
    this.eventEmitter.addEventListener(eventType, listener);
  }

  removeEventListener(eventType: string, listener: EventListener): void {
    this.eventEmitter.removeEventListener(eventType, listener);
  }

  disconnect(): void {
    // Cerrar todas las conexiones
    this.peerConnections.forEach((connection, roomId) => {
      connection.close();
    });
    
    if (this.webSocketConnection) {
      this.webSocketConnection.close();
    }

    this.peerConnections.clear();
    this.emitEvent('disconnected', {});
  }

  getConnectionStatus(): { connected: number; total: number } {
    let connected = 0;
    this.connections.forEach(conn => {
      if (conn.status === 'connected') connected++;
    });

    return {
      connected,
      total: this.connections.size
    };
  }

  getActiveParticipants(sessionId: string): RealTimeParticipant[] {
    const connection = Array.from(this.connections.values())
      .find(conn => conn.room === sessionId);
    
    return connection?.participants.filter(p => p.status === 'active') || [];
  }
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalRealTimeCollaboration = new RealTimeCollaboration('current-user');

// Exponer en window para debugging
if (typeof window !== 'undefined') {
  (window as any).realTimeCollaboration = globalRealTimeCollaboration;
}

export default RealTimeCollaboration;
