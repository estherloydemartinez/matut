/**
 * Sistema de Base de Datos Local con IndexedDB
 * Incluye sincronización offline, control de versiones y conflict resolution
 */

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface DatabaseSchema {
  version: number;
  stores: StoreDefinition[];
}

export interface StoreDefinition {
  name: string;
  keyPath: string | string[];
  autoIncrement?: boolean;
  indexes?: IndexDefinition[];
}

export interface IndexDefinition {
  name: string;
  keyPath: string | string[];
  unique?: boolean;
  multiEntry?: boolean;
}

export interface SyncConfig {
  endpoint: string;
  syncInterval: number; // en ms
  retryAttempts: number;
  conflictResolution: 'client' | 'server' | 'merge';
}

export interface DatabaseRecord {
  id: string;
  data: any;
  version: number;
  lastModified: number;
  synced: boolean;
  deleted?: boolean;
}

export interface ConflictResolution {
  strategy: 'client' | 'server' | 'merge' | 'manual';
  resolver?: (client: any, server: any) => any;
}

// =====================================================================
// DATABASE MANAGER PRINCIPAL
// =====================================================================

export class DatabaseManager {
  private db: IDBDatabase | null = null;
  private dbName: string;
  private schema: DatabaseSchema;
  private syncConfig?: SyncConfig;
  private syncTimer?: NodeJS.Timeout;
  private isOnline: boolean = navigator.onLine;

  constructor(dbName: string, schema: DatabaseSchema, syncConfig?: SyncConfig) {
    this.dbName = dbName;
    this.schema = schema;
    this.syncConfig = syncConfig;

    this.setupEventListeners();
  }

  // =====================================================================
  // INICIALIZACIÓN
  // =====================================================================

  async initialize(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.schema.version);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        this.setupSyncTimer();
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        this.upgradeDatabase(db, event.oldVersion, event.newVersion || 0);
      };
    });
  }

  private upgradeDatabase(db: IDBDatabase, oldVersion: number, newVersion: number): void {
    console.log(`Upgrading database from version ${oldVersion} to ${newVersion}`);

    // Crear stores según el schema
    for (const storeDefinition of this.schema.stores) {
      let store: IDBObjectStore;

      if (db.objectStoreNames.contains(storeDefinition.name)) {
        // Store existe, puede necesitar actualización
        continue;
      } else {
        // Crear nuevo store
        store = db.createObjectStore(storeDefinition.name, {
          keyPath: storeDefinition.keyPath,
          autoIncrement: storeDefinition.autoIncrement || false
        });
      }

      // Crear índices
      if (storeDefinition.indexes) {
        for (const indexDef of storeDefinition.indexes) {
          if (!store.indexNames.contains(indexDef.name)) {
            store.createIndex(indexDef.name, indexDef.keyPath, {
              unique: indexDef.unique || false,
              multiEntry: indexDef.multiEntry || false
            });
          }
        }
      }
    }
  }

  private setupEventListeners(): void {
    window.addEventListener('online', () => {
      this.isOnline = true;
      this.syncWithServer();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
    });
  }

  private setupSyncTimer(): void {
    if (this.syncConfig && this.isOnline) {
      this.syncTimer = setInterval(() => {
        this.syncWithServer();
      }, this.syncConfig.syncInterval);
    }
  }

  // =====================================================================
  // OPERACIONES CRUD
  // =====================================================================

  async create(storeName: string, data: any): Promise<string> {
    if (!this.db) throw new Error('Database not initialized');

    const id = this.generateId();
    const record: DatabaseRecord = {
      id,
      data,
      version: 1,
      lastModified: Date.now(),
      synced: false
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.add(record);

      request.onsuccess = () => {
        this.scheduleSync();
        resolve(id);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async read(storeName: string, id: string): Promise<any | null> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.get(id);

      request.onsuccess = () => {
        const record = request.result as DatabaseRecord;
        resolve(record && !record.deleted ? record.data : null);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async update(storeName: string, id: string, data: any): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      
      // Primero obtener el registro existente
      const getRequest = store.get(id);
      getRequest.onsuccess = () => {
        const existingRecord = getRequest.result as DatabaseRecord;
        
        if (!existingRecord) {
          reject(new Error('Record not found'));
          return;
        }

        const updatedRecord: DatabaseRecord = {
          ...existingRecord,
          data,
          version: existingRecord.version + 1,
          lastModified: Date.now(),
          synced: false
        };

        const putRequest = store.put(updatedRecord);
        putRequest.onsuccess = () => {
          this.scheduleSync();
          resolve();
        };
        putRequest.onerror = () => reject(putRequest.error);
      };
      getRequest.onerror = () => reject(getRequest.error);
    });
  }

  async delete(storeName: string, id: string): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      
      // Marcar como eliminado en lugar de eliminar físicamente
      const getRequest = store.get(id);
      getRequest.onsuccess = () => {
        const existingRecord = getRequest.result as DatabaseRecord;
        
        if (!existingRecord) {
          resolve(); // Ya eliminado
          return;
        }

        const deletedRecord: DatabaseRecord = {
          ...existingRecord,
          deleted: true,
          version: existingRecord.version + 1,
          lastModified: Date.now(),
          synced: false
        };

        const putRequest = store.put(deletedRecord);
        putRequest.onsuccess = () => {
          this.scheduleSync();
          resolve();
        };
        putRequest.onerror = () => reject(putRequest.error);
      };
      getRequest.onerror = () => reject(getRequest.error);
    });
  }

  async query(
    storeName: string, 
    filter?: (record: any) => boolean,
    limit?: number
  ): Promise<any[]> {
    if (!this.db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.openCursor();
      const results: any[] = [];

      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result;
        
        if (cursor && (!limit || results.length < limit)) {
          const record = cursor.value as DatabaseRecord;
          
          if (!record.deleted && (!filter || filter(record.data))) {
            results.push(record.data);
          }
          
          cursor.continue();
        } else {
          resolve(results);
        }
      };

      request.onerror = () => reject(request.error);
    });
  }

  // =====================================================================
  // SINCRONIZACIÓN
  // =====================================================================

  private scheduleSync(): void {
    if (this.isOnline && this.syncConfig) {
      // Debounce sync requests
      clearTimeout(this.syncTimer);
      this.syncTimer = setTimeout(() => {
        this.syncWithServer();
      }, 1000);
    }
  }

  async syncWithServer(): Promise<void> {
    if (!this.syncConfig || !this.isOnline) return;

    console.log('Starting sync with server...');

    try {
      for (const storeDefinition of this.schema.stores) {
        await this.syncStore(storeDefinition.name);
      }
      console.log('Sync completed successfully');
    } catch (error) {
      console.error('Sync failed:', error);
      this.retrySync();
    }
  }

  private async syncStore(storeName: string): Promise<void> {
    // 1. Obtener cambios locales no sincronizados
    const localChanges = await this.getUnsyncedRecords(storeName);
    
    // 2. Enviar cambios al servidor
    if (localChanges.length > 0) {
      await this.pushChangesToServer(storeName, localChanges);
    }

    // 3. Obtener cambios del servidor
    const serverChanges = await this.fetchChangesFromServer(storeName);
    
    // 4. Aplicar cambios del servidor
    if (serverChanges.length > 0) {
      await this.applyServerChanges(storeName, serverChanges);
    }
  }

  private async getUnsyncedRecords(storeName: string): Promise<DatabaseRecord[]> {
    if (!this.db) return [];

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.openCursor();
      const unsyncedRecords: DatabaseRecord[] = [];

      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result;
        
        if (cursor) {
          const record = cursor.value as DatabaseRecord;
          if (!record.synced) {
            unsyncedRecords.push(record);
          }
          cursor.continue();
        } else {
          resolve(unsyncedRecords);
        }
      };

      request.onerror = () => reject(request.error);
    });
  }

  private async pushChangesToServer(storeName: string, changes: DatabaseRecord[]): Promise<void> {
    if (!this.syncConfig) return;

    const response = await fetch(`${this.syncConfig.endpoint}/${storeName}/sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ changes })
    });

    if (!response.ok) {
      throw new Error(`Failed to push changes: ${response.statusText}`);
    }

    const result = await response.json();
    
    // Marcar registros como sincronizados
    await this.markRecordsAsSynced(storeName, result.syncedIds);
  }

  private async fetchChangesFromServer(storeName: string): Promise<any[]> {
    if (!this.syncConfig) return [];

    const lastSync = await this.getLastSyncTimestamp(storeName);
    const response = await fetch(
      `${this.syncConfig.endpoint}/${storeName}/changes?since=${lastSync}`
    );

    if (!response.ok) {
      throw new Error(`Failed to fetch changes: ${response.statusText}`);
    }

    const result = await response.json();
    return result.changes || [];
  }

  private async applyServerChanges(storeName: string, changes: any[]): Promise<void> {
    if (!this.db) return;

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      let processed = 0;

      const processNext = () => {
        if (processed >= changes.length) {
          this.updateLastSyncTimestamp(storeName);
          resolve();
          return;
        }

        const change = changes[processed++];
        this.applyServerChange(store, change).then(processNext).catch(reject);
      };

      processNext();
    });
  }

  private async applyServerChange(store: IDBObjectStore, serverRecord: any): Promise<void> {
    return new Promise((resolve, reject) => {
      const getRequest = store.get(serverRecord.id);
      
      getRequest.onsuccess = () => {
        const localRecord = getRequest.result as DatabaseRecord;
        
        if (!localRecord) {
          // Nuevo registro del servidor
          const newRecord: DatabaseRecord = {
            id: serverRecord.id,
            data: serverRecord.data,
            version: serverRecord.version,
            lastModified: serverRecord.lastModified,
            synced: true,
            deleted: serverRecord.deleted
          };
          
          const addRequest = store.add(newRecord);
          addRequest.onsuccess = () => resolve();
          addRequest.onerror = () => reject(addRequest.error);
        } else {
          // Resolver conflicto
          const resolvedRecord = this.resolveConflict(localRecord, serverRecord);
          const putRequest = store.put(resolvedRecord);
          putRequest.onsuccess = () => resolve();
          putRequest.onerror = () => reject(putRequest.error);
        }
      };

      getRequest.onerror = () => reject(getRequest.error);
    });
  }

  private resolveConflict(localRecord: DatabaseRecord, serverRecord: any): DatabaseRecord {
    if (!this.syncConfig) return localRecord;

    switch (this.syncConfig.conflictResolution) {
      case 'server':
        return {
          ...localRecord,
          data: serverRecord.data,
          version: serverRecord.version,
          lastModified: serverRecord.lastModified,
          synced: true
        };

      case 'client':
        return localRecord;

      case 'merge':
        // Implementar merge inteligente
        const mergedData = this.mergeData(localRecord.data, serverRecord.data);
        return {
          ...localRecord,
          data: mergedData,
          version: Math.max(localRecord.version, serverRecord.version) + 1,
          lastModified: Date.now(),
          synced: false // Necesita re-sincronización
        };

      default:
        return localRecord;
    }
  }

  private mergeData(localData: any, serverData: any): any {
    // Merge simple basado en timestamps de campos
    const merged = { ...localData };
    
    for (const [key, value] of Object.entries(serverData)) {
      if (!(key in localData) || 
          (serverData[`${key}_modified`] > localData[`${key}_modified`])) {
        merged[key] = value;
      }
    }

    return merged;
  }

  private async markRecordsAsSynced(storeName: string, syncedIds: string[]): Promise<void> {
    if (!this.db) return;

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      let processed = 0;

      const processNext = () => {
        if (processed >= syncedIds.length) {
          resolve();
          return;
        }

        const id = syncedIds[processed++];
        const getRequest = store.get(id);
        
        getRequest.onsuccess = () => {
          const record = getRequest.result as DatabaseRecord;
          if (record) {
            record.synced = true;
            const putRequest = store.put(record);
            putRequest.onsuccess = processNext;
            putRequest.onerror = () => reject(putRequest.error);
          } else {
            processNext();
          }
        };
        
        getRequest.onerror = () => reject(getRequest.error);
      };

      processNext();
    });
  }

  private async getLastSyncTimestamp(storeName: string): Promise<number> {
    const timestamp = localStorage.getItem(`${this.dbName}_${storeName}_lastSync`);
    return timestamp ? parseInt(timestamp) : 0;
  }

  private async updateLastSyncTimestamp(storeName: string): Promise<void> {
    localStorage.setItem(`${this.dbName}_${storeName}_lastSync`, Date.now().toString());
  }

  private retrySync(): void {
    if (!this.syncConfig) return;

    setTimeout(() => {
      this.syncWithServer();
    }, Math.min(this.syncConfig.retryAttempts * 1000, 30000));
  }

  // =====================================================================
  // UTILIDADES
  // =====================================================================

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  async getStats(): Promise<any> {
    if (!this.db) return null;

    const stats: any = {};

    for (const storeDefinition of this.schema.stores) {
      const storeName = storeDefinition.name;
      stats[storeName] = await this.getStoreStats(storeName);
    }

    return {
      dbName: this.dbName,
      version: this.schema.version,
      isOnline: this.isOnline,
      stores: stats
    };
  }

  private async getStoreStats(storeName: string): Promise<any> {
    if (!this.db) return null;

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const countRequest = store.count();

      countRequest.onsuccess = () => {
        const cursor = store.openCursor();
        let synced = 0;
        let unsynced = 0;
        let deleted = 0;

        cursor.onsuccess = (event) => {
          const cursor = (event.target as IDBRequest).result;
          
          if (cursor) {
            const record = cursor.value as DatabaseRecord;
            if (record.deleted) deleted++;
            else if (record.synced) synced++;
            else unsynced++;
            cursor.continue();
          } else {
            resolve({
              total: countRequest.result,
              synced,
              unsynced,
              deleted
            });
          }
        };

        cursor.onerror = () => reject(cursor.error);
      };

      countRequest.onerror = () => reject(countRequest.error);
    });
  }

  async close(): Promise<void> {
    if (this.syncTimer) {
      clearInterval(this.syncTimer);
    }

    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// =====================================================================
// SCHEMAS PREDEFINIDOS
// =====================================================================

export const BIBLICAL_FORMATION_SCHEMA: DatabaseSchema = {
  version: 1,
  stores: [
    {
      name: 'users',
      keyPath: 'id',
      indexes: [
        { name: 'email', keyPath: 'email', unique: true },
        { name: 'lastLogin', keyPath: 'lastLogin' }
      ]
    },
    {
      name: 'readingPlans',
      keyPath: 'id',
      indexes: [
        { name: 'userId', keyPath: 'userId' },
        { name: 'type', keyPath: 'type' },
        { name: 'created', keyPath: 'createdAt' }
      ]
    },
    {
      name: 'studyNotes',
      keyPath: 'id',
      indexes: [
        { name: 'userId', keyPath: 'userId' },
        { name: 'reference', keyPath: 'reference' },
        { name: 'created', keyPath: 'createdAt' }
      ]
    },
    {
      name: 'progress',
      keyPath: 'id',
      indexes: [
        { name: 'userId', keyPath: 'userId' },
        { name: 'planId', keyPath: 'planId' },
        { name: 'lastUpdate', keyPath: 'lastUpdated' }
      ]
    },
    {
      name: 'achievements',
      keyPath: 'id',
      indexes: [
        { name: 'userId', keyPath: 'userId' },
        { name: 'achievementId', keyPath: 'achievementId' },
        { name: 'unlocked', keyPath: 'unlockedAt' }
      ]
    }
  ]
};

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalDatabase = new DatabaseManager(
  'BiblicalFormationDB',
  BIBLICAL_FORMATION_SCHEMA,
  {
    endpoint: '/api/sync',
    syncInterval: 30000, // 30 segundos
    retryAttempts: 3,
    conflictResolution: 'merge'
  }
);

// Inicialización automática
if (typeof window !== 'undefined') {
  globalDatabase.initialize().then(() => {
    console.log('Global database initialized');
  }).catch(error => {
    console.error('Failed to initialize global database:', error);
  });

  // Exponer en window para debugging
  (window as any).globalDatabase = globalDatabase;
}

export default DatabaseManager;
