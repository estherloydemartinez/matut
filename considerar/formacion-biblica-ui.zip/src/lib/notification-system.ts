/**
 * Sistema Avanzado de Notificaciones
 * Notificaciones en tiempo real, personalizadas e inteligentes
 */

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface Notification {
  id: string;
  type: NotificationType;
  category: NotificationCategory;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  title: string;
  message: string;
  icon?: string;
  image?: string;
  color?: string;
  
  // Datos contextuales
  data: NotificationData;
  
  // Metadatos
  userId: string;
  timestamp: Date;
  read: boolean;
  clicked: boolean;
  dismissed: boolean;
  expiresAt?: Date;
  
  // Acciones disponibles
  actions: NotificationAction[];
  
  // Configuración de entrega
  channels: DeliveryChannel[];
  deliverySettings: DeliverySettings;
  
  // Seguimiento
  analytics: NotificationAnalytics;
}

export type NotificationType = 
  | 'community' | 'study_group' | 'mentorship' | 'content' | 'social'
  | 'achievement' | 'reminder' | 'update' | 'announcement' | 'system'
  | 'collaboration' | 'challenge' | 'milestone' | 'invitation';

export type NotificationCategory = 
  | 'engagement' | 'educational' | 'social' | 'achievement' | 'administrative'
  | 'security' | 'promotional' | 'reminder' | 'milestone';

export interface NotificationData {
  entityId?: string;
  entityType?: string;
  userId?: string;
  userName?: string;
  groupId?: string;
  contentId?: string;
  challengeId?: string;
  communityId?: string;
  url?: string;
  metadata?: { [key: string]: any };
}

export interface NotificationAction {
  id: string;
  label: string;
  type: 'primary' | 'secondary' | 'danger';
  url?: string;
  action?: string;
  data?: any;
}

export type DeliveryChannel = 'in_app' | 'email' | 'push' | 'sms' | 'webhook';

export interface DeliverySettings {
  immediate: boolean;
  digest: boolean;
  digestFrequency?: 'hourly' | 'daily' | 'weekly';
  quietHours?: {
    start: string; // HH:mm
    end: string;   // HH:mm
    timezone: string;
  };
  batchWithSimilar: boolean;
  maxPerDay?: number;
}

export interface NotificationAnalytics {
  delivered: Date;
  opened?: Date;
  clicked?: Date;
  actionTaken?: {
    actionId: string;
    timestamp: Date;
  };
  deliveryAttempts: number;
  deliveryChannel: DeliveryChannel;
}

export interface NotificationTemplate {
  id: string;
  name: string;
  type: NotificationType;
  category: NotificationCategory;
  title: string;
  message: string;
  icon?: string;
  color?: string;
  variables: string[];
  defaultActions: NotificationAction[];
  defaultChannels: DeliveryChannel[];
  defaultSettings: DeliverySettings;
}

export interface UserNotificationPreferences {
  userId: string;
  enabled: boolean;
  channels: {
    [key in DeliveryChannel]: boolean;
  };
  categories: {
    [key in NotificationCategory]: {
      enabled: boolean;
      channels: DeliveryChannel[];
      frequency: 'immediate' | 'digest' | 'disabled';
    };
  };
  quietHours: {
    enabled: boolean;
    start: string;
    end: string;
    timezone: string;
  };
  digestSettings: {
    frequency: 'hourly' | 'daily' | 'weekly';
    time: string; // HH:mm
    timezone: string;
  };
  advancedSettings: {
    intelligentGrouping: boolean;
    adaptiveTiming: boolean;
    contextualPriority: boolean;
    maxPerDay: number;
  };
}

export interface NotificationQueue {
  id: string;
  notifications: string[];
  scheduledFor: Date;
  type: 'immediate' | 'digest' | 'scheduled';
  status: 'pending' | 'processing' | 'sent' | 'failed';
  userId: string;
  channel: DeliveryChannel;
}

export interface DigestNotification {
  id: string;
  userId: string;
  period: 'hourly' | 'daily' | 'weekly';
  startDate: Date;
  endDate: Date;
  notifications: string[];
  summary: DigestSummary;
  generated: Date;
  sent?: Date;
}

export interface DigestSummary {
  totalNotifications: number;
  categoryCounts: { [key in NotificationCategory]?: number };
  highlights: string[];
  urgentItems: string[];
  newContent: number;
  socialActivity: number;
  achievements: number;
}

// =====================================================================
// SISTEMA DE NOTIFICACIONES
// =====================================================================

export class NotificationSystem {
  private notifications: Map<string, Notification> = new Map();
  private templates: Map<string, NotificationTemplate> = new Map();
  private userPreferences: Map<string, UserNotificationPreferences> = new Map();
  private queues: Map<string, NotificationQueue> = new Map();
  private digests: Map<string, DigestNotification> = new Map();
  
  private eventEmitter: EventTarget = new EventTarget();
  private isInitialized: boolean = false;
  private processingInterval?: number;

  constructor() {
    this.initialize();
  }

  // =====================================================================
  // INICIALIZACIÓN
  // =====================================================================

  private async initialize(): Promise<void> {
    try {
      await this.loadTemplates();
      await this.loadUserPreferences();
      this.startProcessingQueue();
      this.setupPeriodicTasks();
      
      this.isInitialized = true;
      console.log('Notification System initialized');
    } catch (error) {
      console.error('Error initializing notification system:', error);
    }
  }

  private async loadTemplates(): Promise<void> {
    const templates: NotificationTemplate[] = [
      {
        id: 'community_new_member',
        name: 'Nuevo Miembro en Comunidad',
        type: 'community',
        category: 'social',
        title: 'Nuevo miembro en {{communityName}}',
        message: '{{userName}} se ha unido a tu comunidad {{communityName}}',
        icon: '👥',
        color: '#3B82F6',
        variables: ['communityName', 'userName'],
        defaultActions: [
          {
            id: 'view_community',
            label: 'Ver Comunidad',
            type: 'primary',
            action: 'navigate',
            data: { route: '/social?tab=communities&id={{communityId}}' }
          }
        ],
        defaultChannels: ['in_app', 'email'],
        defaultSettings: {
          immediate: true,
          digest: false,
          batchWithSimilar: true,
          maxPerDay: 5
        }
      },
      {
        id: 'study_group_reminder',
        name: 'Recordatorio de Grupo de Estudio',
        type: 'reminder',
        category: 'educational',
        title: 'Sesión de {{groupName}} en 30 minutos',
        message: 'Tu grupo de estudio {{groupName}} comenzará pronto. ¡No faltes!',
        icon: '📚',
        color: '#059669',
        variables: ['groupName', 'sessionTime'],
        defaultActions: [
          {
            id: 'join_session',
            label: 'Unirse Ahora',
            type: 'primary',
            action: 'join_session',
            data: { groupId: '{{groupId}}' }
          },
          {
            id: 'reschedule',
            label: 'Reprogramar',
            type: 'secondary',
            action: 'reschedule'
          }
        ],
        defaultChannels: ['in_app', 'push'],
        defaultSettings: {
          immediate: true,
          digest: false,
          batchWithSimilar: false
        }
      },
      {
        id: 'achievement_unlocked',
        name: 'Logro Desbloqueado',
        type: 'achievement',
        category: 'achievement',
        title: '¡Nuevo logro desbloqueado! 🏆',
        message: 'Has obtenido el logro "{{achievementName}}" por {{reason}}',
        icon: '🏆',
        color: '#F59E0B',
        variables: ['achievementName', 'reason', 'points'],
        defaultActions: [
          {
            id: 'view_achievements',
            label: 'Ver Logros',
            type: 'primary',
            action: 'navigate',
            data: { route: '/social?tab=gamification' }
          },
          {
            id: 'share_achievement',
            label: 'Compartir',
            type: 'secondary',
            action: 'share'
          }
        ],
        defaultChannels: ['in_app', 'push'],
        defaultSettings: {
          immediate: true,
          digest: true,
          batchWithSimilar: false
        }
      },
      {
        id: 'content_approved',
        name: 'Contenido Aprobado',
        type: 'content',
        category: 'administrative',
        title: 'Tu contenido ha sido aprobado',
        message: 'Tu {{contentType}} "{{contentTitle}}" ha sido aprobado y ya está disponible públicamente',
        icon: '✅',
        color: '#10B981',
        variables: ['contentType', 'contentTitle'],
        defaultActions: [
          {
            id: 'view_content',
            label: 'Ver Contenido',
            type: 'primary',
            action: 'navigate',
            data: { route: '/content/{{contentId}}' }
          },
          {
            id: 'share_content',
            label: 'Compartir',
            type: 'secondary',
            action: 'share'
          }
        ],
        defaultChannels: ['in_app', 'email'],
        defaultSettings: {
          immediate: true,
          digest: true,
          batchWithSimilar: true
        }
      },
      {
        id: 'mentorship_request',
        name: 'Solicitud de Mentoría',
        type: 'mentorship',
        category: 'social',
        title: 'Nueva solicitud de mentoría',
        message: '{{studentName}} te ha solicitado mentoría en {{subject}}',
        icon: '🎓',
        color: '#8B5CF6',
        variables: ['studentName', 'subject'],
        defaultActions: [
          {
            id: 'accept',
            label: 'Aceptar',
            type: 'primary',
            action: 'accept_mentorship'
          },
          {
            id: 'view_profile',
            label: 'Ver Perfil',
            type: 'secondary',
            action: 'navigate',
            data: { route: '/profile/{{studentId}}' }
          },
          {
            id: 'decline',
            label: 'Declinar',
            type: 'danger',
            action: 'decline_mentorship'
          }
        ],
        defaultChannels: ['in_app', 'email'],
        defaultSettings: {
          immediate: true,
          digest: false,
          batchWithSimilar: false
        }
      },
      {
        id: 'daily_verse',
        name: 'Versículo del Día',
        type: 'reminder',
        category: 'educational',
        title: 'Versículo del día',
        message: '"{{verse}}" - {{reference}}',
        icon: '📖',
        color: '#6366F1',
        variables: ['verse', 'reference'],
        defaultActions: [
          {
            id: 'reflect',
            label: 'Reflexionar',
            type: 'primary',
            action: 'navigate',
            data: { route: '/bible/{{reference}}' }
          },
          {
            id: 'share',
            label: 'Compartir',
            type: 'secondary',
            action: 'share'
          }
        ],
        defaultChannels: ['in_app', 'push'],
        defaultSettings: {
          immediate: false,
          digest: true,
          digestFrequency: 'daily',
          batchWithSimilar: false
        }
      },
      {
        id: 'challenge_ending',
        name: 'Desafío Terminando',
        type: 'challenge',
        category: 'engagement',
        title: 'El desafío {{challengeName}} termina pronto',
        message: 'Solo quedan {{timeLeft}} para completar el desafío. ¡Puedes lograrlo!',
        icon: '⏰',
        color: '#EF4444',
        variables: ['challengeName', 'timeLeft', 'currentProgress'],
        defaultActions: [
          {
            id: 'continue_challenge',
            label: 'Continuar',
            type: 'primary',
            action: 'navigate',
            data: { route: '/challenges/{{challengeId}}' }
          }
        ],
        defaultChannels: ['in_app', 'push'],
        defaultSettings: {
          immediate: true,
          digest: false,
          batchWithSimilar: false
        }
      }
    ];

    for (const template of templates) {
      this.templates.set(template.id, template);
    }
  }

  private async loadUserPreferences(): Promise<void> {
    // Cargar preferencias por defecto para usuario de ejemplo
    const defaultPreferences: UserNotificationPreferences = {
      userId: 'user1',
      enabled: true,
      channels: {
        in_app: true,
        email: true,
        push: true,
        sms: false,
        webhook: false
      },
      categories: {
        engagement: { enabled: true, channels: ['in_app', 'push'], frequency: 'immediate' },
        educational: { enabled: true, channels: ['in_app', 'email'], frequency: 'digest' },
        social: { enabled: true, channels: ['in_app', 'email'], frequency: 'immediate' },
        achievement: { enabled: true, channels: ['in_app', 'push'], frequency: 'immediate' },
        administrative: { enabled: true, channels: ['in_app', 'email'], frequency: 'immediate' },
        security: { enabled: true, channels: ['in_app', 'email', 'push'], frequency: 'immediate' },
        promotional: { enabled: false, channels: ['email'], frequency: 'digest' },
        reminder: { enabled: true, channels: ['in_app', 'push'], frequency: 'immediate' },
        milestone: { enabled: true, channels: ['in_app', 'push'], frequency: 'immediate' }
      },
      quietHours: {
        enabled: true,
        start: '22:00',
        end: '08:00',
        timezone: 'America/Mexico_City'
      },
      digestSettings: {
        frequency: 'daily',
        time: '08:00',
        timezone: 'America/Mexico_City'
      },
      advancedSettings: {
        intelligentGrouping: true,
        adaptiveTiming: true,
        contextualPriority: true,
        maxPerDay: 20
      }
    };

    this.userPreferences.set('user1', defaultPreferences);
  }

  private startProcessingQueue(): void {
    this.processingInterval = window.setInterval(() => {
      this.processNotificationQueues();
    }, 5000); // Procesar cada 5 segundos
  }

  private setupPeriodicTasks(): void {
    // Generar digests
    setInterval(() => {
      this.generateDigests();
    }, 60 * 60 * 1000); // Cada hora

    // Limpiar notificaciones antiguas
    setInterval(() => {
      this.cleanupOldNotifications();
    }, 24 * 60 * 60 * 1000); // Cada día

    // Verificar recordatorios
    setInterval(() => {
      this.checkReminders();
    }, 60 * 1000); // Cada minuto
  }

  // =====================================================================
  // CREACIÓN Y ENVÍO DE NOTIFICACIONES
  // =====================================================================

  async sendNotification(templateId: string, userId: string, variables: { [key: string]: any }): Promise<string> {
    const template = this.templates.get(templateId);
    if (!template) {
      throw new Error(`Template ${templateId} not found`);
    }

    const userPrefs = this.userPreferences.get(userId);
    if (!userPrefs || !userPrefs.enabled) {
      return '';
    }

    // Verificar si la categoría está habilitada
    const categoryPrefs = userPrefs.categories[template.category];
    if (!categoryPrefs || !categoryPrefs.enabled) {
      return '';
    }

    // Procesar variables en título y mensaje
    const title = this.processTemplate(template.title, variables);
    const message = this.processTemplate(template.message, variables);

    // Crear notificación
    const notification: Notification = {
      id: this.generateId(),
      type: template.type,
      category: template.category,
      priority: this.calculatePriority(template, variables),
      title,
      message,
      icon: template.icon,
      color: template.color,
      data: {
        ...variables,
        templateId
      },
      userId,
      timestamp: new Date(),
      read: false,
      clicked: false,
      dismissed: false,
      actions: this.processActions(template.defaultActions, variables),
      channels: this.selectChannels(template, userPrefs),
      deliverySettings: {
        ...template.defaultSettings,
        ...this.adaptDeliverySettings(userPrefs, template)
      },
      analytics: {
        delivered: new Date(),
        deliveryAttempts: 0,
        deliveryChannel: 'in_app'
      }
    };

    // Verificar hora silenciosa
    if (this.isQuietTime(userId) && notification.priority !== 'urgent') {
      notification.deliverySettings.immediate = false;
      notification.deliverySettings.digest = true;
    }

    this.notifications.set(notification.id, notification);

    // Procesar entrega
    await this.processDelivery(notification);

    this.emitEvent('notification-created', { notification });
    return notification.id;
  }

  async sendCustomNotification(notificationData: Partial<Notification>): Promise<string> {
    const notification: Notification = {
      id: this.generateId(),
      type: notificationData.type || 'system',
      category: notificationData.category || 'administrative',
      priority: notificationData.priority || 'medium',
      title: notificationData.title || 'Notificación',
      message: notificationData.message || '',
      icon: notificationData.icon,
      color: notificationData.color,
      data: notificationData.data || {},
      userId: notificationData.userId || '',
      timestamp: new Date(),
      read: false,
      clicked: false,
      dismissed: false,
      actions: notificationData.actions || [],
      channels: notificationData.channels || ['in_app'],
      deliverySettings: notificationData.deliverySettings || {
        immediate: true,
        digest: false,
        batchWithSimilar: false
      },
      analytics: {
        delivered: new Date(),
        deliveryAttempts: 0,
        deliveryChannel: 'in_app'
      }
    };

    this.notifications.set(notification.id, notification);
    await this.processDelivery(notification);

    this.emitEvent('notification-created', { notification });
    return notification.id;
  }

  // =====================================================================
  // PROCESAMIENTO DE ENTREGA
  // =====================================================================

  private async processDelivery(notification: Notification): Promise<void> {
    const userPrefs = this.userPreferences.get(notification.userId);
    if (!userPrefs) return;

    if (notification.deliverySettings.immediate && !this.isQuietTime(notification.userId)) {
      // Entrega inmediata
      await this.deliverImmediate(notification);
    } else {
      // Agregar a digest o cola
      await this.addToQueue(notification);
    }
  }

  private async deliverImmediate(notification: Notification): Promise<void> {
    for (const channel of notification.channels) {
      try {
        await this.deliverToChannel(notification, channel);
        notification.analytics.deliveryChannel = channel;
        notification.analytics.deliveryAttempts++;
        
        this.emitEvent('notification-delivered', { 
          notificationId: notification.id, 
          channel 
        });
        
        break; // Solo intentar con el primer canal exitoso
      } catch (error) {
        console.error(`Failed to deliver notification ${notification.id} via ${channel}:`, error);
        notification.analytics.deliveryAttempts++;
      }
    }
  }

  private async deliverToChannel(notification: Notification, channel: DeliveryChannel): Promise<void> {
    switch (channel) {
      case 'in_app':
        this.emitEvent('notification-in-app', { notification });
        break;
      
      case 'push':
        // Simular notificación push
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification(notification.title, {
            body: notification.message,
            icon: notification.icon,
            badge: '/icon-192x192.png',
            tag: notification.id,
            data: notification.data
          });
        }
        break;
      
      case 'email':
        // Simular envío de email
        console.log(`Email sent to user ${notification.userId}:`, {
          subject: notification.title,
          body: notification.message
        });
        break;
      
      case 'sms':
        // Simular SMS
        console.log(`SMS sent to user ${notification.userId}:`, notification.message);
        break;
      
      case 'webhook':
        // Simular webhook
        console.log(`Webhook called for user ${notification.userId}:`, notification);
        break;
    }
  }

  private async addToQueue(notification: Notification): Promise<void> {
    const userPrefs = this.userPreferences.get(notification.userId);
    if (!userPrefs) return;

    const queueId = `${notification.userId}_${notification.deliverySettings.digest ? 'digest' : 'scheduled'}`;
    let queue = this.queues.get(queueId);

    if (!queue) {
      const scheduledTime = notification.deliverySettings.digest 
        ? this.getNextDigestTime(userPrefs)
        : new Date(Date.now() + 60000); // 1 minuto después

      queue = {
        id: queueId,
        notifications: [],
        scheduledFor: scheduledTime,
        type: notification.deliverySettings.digest ? 'digest' : 'scheduled',
        status: 'pending',
        userId: notification.userId,
        channel: notification.channels[0]
      };

      this.queues.set(queueId, queue);
    }

    queue.notifications.push(notification.id);
  }

  private processNotificationQueues(): void {
    const now = new Date();

    for (const [queueId, queue] of this.queues.entries()) {
      if (queue.status === 'pending' && queue.scheduledFor <= now) {
        this.processQueue(queue);
      }
    }
  }

  private async processQueue(queue: NotificationQueue): Promise<void> {
    queue.status = 'processing';

    try {
      if (queue.type === 'digest') {
        await this.sendDigest(queue);
      } else {
        // Enviar notificaciones programadas
        for (const notificationId of queue.notifications) {
          const notification = this.notifications.get(notificationId);
          if (notification) {
            await this.deliverImmediate(notification);
          }
        }
      }

      queue.status = 'sent';
    } catch (error) {
      queue.status = 'failed';
      console.error('Error processing queue:', error);
    }

    // Limpiar cola después de procesar
    setTimeout(() => {
      this.queues.delete(queue.id);
    }, 24 * 60 * 60 * 1000); // 24 horas
  }

  // =====================================================================
  // SISTEMA DE DIGEST
  // =====================================================================

  private async sendDigest(queue: NotificationQueue): Promise<void> {
    const notifications = queue.notifications
      .map(id => this.notifications.get(id))
      .filter(n => n) as Notification[];

    if (notifications.length === 0) return;

    const digest = this.generateDigestContent(notifications);
    
    // Crear notificación de digest
    const digestNotification: Notification = {
      id: this.generateId(),
      type: 'system',
      category: 'administrative',
      priority: 'low',
      title: `Resumen: ${notifications.length} notificación${notifications.length > 1 ? 'es' : ''}`,
      message: digest.summary.highlights.join(', '),
      data: { 
        digest: digest,
        originalNotifications: notifications.map(n => n.id)
      },
      userId: queue.userId,
      timestamp: new Date(),
      read: false,
      clicked: false,
      dismissed: false,
      actions: [
        {
          id: 'view_all',
          label: 'Ver Todas',
          type: 'primary',
          action: 'view_notifications'
        }
      ],
      channels: [queue.channel],
      deliverySettings: {
        immediate: true,
        digest: false,
        batchWithSimilar: false
      },
      analytics: {
        delivered: new Date(),
        deliveryAttempts: 0,
        deliveryChannel: queue.channel
      }
    };

    await this.deliverImmediate(digestNotification);
    this.notifications.set(digestNotification.id, digestNotification);
  }

  private generateDigestContent(notifications: Notification[]): DigestNotification {
    const categoryCounts: { [key in NotificationCategory]?: number } = {};
    const highlights: string[] = [];
    const urgentItems: string[] = [];

    let newContent = 0;
    let socialActivity = 0;
    let achievements = 0;

    for (const notification of notifications) {
      // Contar por categoría
      categoryCounts[notification.category] = (categoryCounts[notification.category] || 0) + 1;

      // Recopilar elementos urgentes
      if (notification.priority === 'urgent' || notification.priority === 'high') {
        urgentItems.push(notification.title);
      }

      // Clasificar por tipo
      switch (notification.type) {
        case 'content':
          newContent++;
          break;
        case 'community':
        case 'social':
        case 'mentorship':
          socialActivity++;
          break;
        case 'achievement':
          achievements++;
          break;
      }

      // Agregar a highlights si es importante
      if (notification.priority !== 'low') {
        highlights.push(notification.title);
      }
    }

    return {
      id: this.generateId(),
      userId: notifications[0].userId,
      period: 'daily', // Por simplicidad
      startDate: new Date(Math.min(...notifications.map(n => n.timestamp.getTime()))),
      endDate: new Date(),
      notifications: notifications.map(n => n.id),
      summary: {
        totalNotifications: notifications.length,
        categoryCounts,
        highlights: highlights.slice(0, 5),
        urgentItems,
        newContent,
        socialActivity,
        achievements
      },
      generated: new Date()
    };
  }

  private generateDigests(): void {
    // Generar digests según las preferencias del usuario
    for (const [userId, prefs] of this.userPreferences.entries()) {
      if (this.shouldGenerateDigest(userId, prefs)) {
        this.createDigestForUser(userId, prefs);
      }
    }
  }

  private shouldGenerateDigest(userId: string, prefs: UserNotificationPreferences): boolean {
    const now = new Date();
    const digestTime = this.parseTime(prefs.digestSettings.time);
    
    // Verificar si es hora de generar digest
    return now.getHours() === digestTime.hours && 
           now.getMinutes() >= digestTime.minutes && 
           now.getMinutes() < digestTime.minutes + 5; // Ventana de 5 minutos
  }

  private async createDigestForUser(userId: string, prefs: UserNotificationPreferences): Promise<void> {
    const now = new Date();
    const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    // Obtener notificaciones del período
    const periodNotifications = Array.from(this.notifications.values())
      .filter(n => 
        n.userId === userId && 
        n.timestamp >= yesterday && 
        n.timestamp <= now &&
        !n.read &&
        n.deliverySettings.digest
      );

    if (periodNotifications.length > 0) {
      const digest = this.generateDigestContent(periodNotifications);
      this.digests.set(digest.id, digest);
      
      // Crear y enviar notificación de digest
      await this.sendDigest({
        id: `digest_${userId}_${now.getTime()}`,
        notifications: periodNotifications.map(n => n.id),
        scheduledFor: now,
        type: 'digest',
        status: 'pending',
        userId,
        channel: 'in_app'
      });
    }
  }

  // =====================================================================
  // GESTIÓN DE NOTIFICACIONES
  // =====================================================================

  async markAsRead(notificationId: string): Promise<boolean> {
    const notification = this.notifications.get(notificationId);
    if (!notification) return false;

    notification.read = true;
    if (!notification.analytics.opened) {
      notification.analytics.opened = new Date();
    }

    this.notifications.set(notificationId, notification);
    this.emitEvent('notification-read', { notificationId });

    return true;
  }

  async markAsClicked(notificationId: string, actionId?: string): Promise<boolean> {
    const notification = this.notifications.get(notificationId);
    if (!notification) return false;

    notification.clicked = true;
    notification.analytics.clicked = new Date();

    if (actionId) {
      notification.analytics.actionTaken = {
        actionId,
        timestamp: new Date()
      };
    }

    this.notifications.set(notificationId, notification);
    this.emitEvent('notification-clicked', { notificationId, actionId });

    return true;
  }

  async dismissNotification(notificationId: string): Promise<boolean> {
    const notification = this.notifications.get(notificationId);
    if (!notification) return false;

    notification.dismissed = true;
    this.notifications.set(notificationId, notification);
    this.emitEvent('notification-dismissed', { notificationId });

    return true;
  }

  async markAllAsRead(userId: string): Promise<number> {
    const userNotifications = Array.from(this.notifications.values())
      .filter(n => n.userId === userId && !n.read);

    for (const notification of userNotifications) {
      await this.markAsRead(notification.id);
    }

    return userNotifications.length;
  }

  // =====================================================================
  // PREFERENCIAS DE USUARIO
  // =====================================================================

  async updateUserPreferences(userId: string, preferences: Partial<UserNotificationPreferences>): Promise<boolean> {
    const currentPrefs = this.userPreferences.get(userId);
    if (!currentPrefs) return false;

    const updatedPrefs = { ...currentPrefs, ...preferences };
    this.userPreferences.set(userId, updatedPrefs);

    this.emitEvent('preferences-updated', { userId, preferences: updatedPrefs });
    return true;
  }

  getUserPreferences(userId: string): UserNotificationPreferences | undefined {
    return this.userPreferences.get(userId);
  }

  // =====================================================================
  // UTILIDADES
  // =====================================================================

  private processTemplate(template: string, variables: { [key: string]: any }): string {
    let result = template;
    
    for (const [key, value] of Object.entries(variables)) {
      const placeholder = `{{${key}}}`;
      result = result.replace(new RegExp(placeholder, 'g'), String(value));
    }

    return result;
  }

  private processActions(actions: NotificationAction[], variables: { [key: string]: any }): NotificationAction[] {
    return actions.map(action => ({
      ...action,
      url: action.url ? this.processTemplate(action.url, variables) : undefined,
      data: action.data ? this.processObjectTemplate(action.data, variables) : action.data
    }));
  }

  private processObjectTemplate(obj: any, variables: { [key: string]: any }): any {
    if (typeof obj === 'string') {
      return this.processTemplate(obj, variables);
    } else if (Array.isArray(obj)) {
      return obj.map(item => this.processObjectTemplate(item, variables));
    } else if (typeof obj === 'object' && obj !== null) {
      const result: any = {};
      for (const [key, value] of Object.entries(obj)) {
        result[key] = this.processObjectTemplate(value, variables);
      }
      return result;
    }
    return obj;
  }

  private calculatePriority(template: NotificationTemplate, variables: { [key: string]: any }): 'low' | 'medium' | 'high' | 'urgent' {
    // Lógica para calcular prioridad basada en template y variables
    if (template.type === 'reminder' && variables.timeLeft && parseInt(variables.timeLeft) < 30) {
      return 'urgent';
    }
    
    if (template.category === 'security' || template.type === 'achievement') {
      return 'high';
    }
    
    if (template.category === 'promotional') {
      return 'low';
    }
    
    return 'medium';
  }

  private selectChannels(template: NotificationTemplate, userPrefs: UserNotificationPreferences): DeliveryChannel[] {
    const categoryPrefs = userPrefs.categories[template.category];
    if (!categoryPrefs) return template.defaultChannels;

    return template.defaultChannels.filter(channel => 
      userPrefs.channels[channel] && categoryPrefs.channels.includes(channel)
    );
  }

  private adaptDeliverySettings(userPrefs: UserNotificationPreferences, template: NotificationTemplate): Partial<DeliverySettings> {
    const categoryPrefs = userPrefs.categories[template.category];
    const settings: Partial<DeliverySettings> = {};

    if (categoryPrefs?.frequency === 'digest') {
      settings.immediate = false;
      settings.digest = true;
      settings.digestFrequency = userPrefs.digestSettings.frequency;
    }

    if (userPrefs.advancedSettings.maxPerDay) {
      settings.maxPerDay = userPrefs.advancedSettings.maxPerDay;
    }

    return settings;
  }

  private isQuietTime(userId: string): boolean {
    const prefs = this.userPreferences.get(userId);
    if (!prefs?.quietHours.enabled) return false;

    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    
    const start = this.parseTime(prefs.quietHours.start);
    const end = this.parseTime(prefs.quietHours.end);
    
    const startMinutes = start.hours * 60 + start.minutes;
    const endMinutes = end.hours * 60 + end.minutes;

    if (startMinutes > endMinutes) {
      // Quiet time crosses midnight
      return currentTime >= startMinutes || currentTime <= endMinutes;
    } else {
      return currentTime >= startMinutes && currentTime <= endMinutes;
    }
  }

  private getNextDigestTime(prefs: UserNotificationPreferences): Date {
    const now = new Date();
    const digestTime = this.parseTime(prefs.digestSettings.time);
    
    const nextDigest = new Date(now);
    nextDigest.setHours(digestTime.hours, digestTime.minutes, 0, 0);

    if (nextDigest <= now) {
      // Si ya pasó la hora de hoy, programar para mañana
      nextDigest.setDate(nextDigest.getDate() + 1);
    }

    return nextDigest;
  }

  private parseTime(timeString: string): { hours: number; minutes: number } {
    const [hours, minutes] = timeString.split(':').map(Number);
    return { hours, minutes };
  }

  private cleanupOldNotifications(): void {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    for (const [id, notification] of this.notifications.entries()) {
      if (notification.timestamp < thirtyDaysAgo && notification.read) {
        this.notifications.delete(id);
      }
    }
  }

  private checkReminders(): void {
    // Verificar si hay recordatorios que enviar
    // Esta función se puede conectar con el sistema de calendario o eventos
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private emitEvent(eventType: string, data: any): void {
    this.eventEmitter.dispatchEvent(new CustomEvent(eventType, { detail: data }));
  }

  // =====================================================================
  // MÉTODOS PÚBLICOS
  // =====================================================================

  getUserNotifications(userId: string, filters?: {
    unread?: boolean;
    category?: NotificationCategory;
    type?: NotificationType;
    limit?: number;
  }): Notification[] {
    let notifications = Array.from(this.notifications.values())
      .filter(n => n.userId === userId && !n.dismissed);

    if (filters) {
      if (filters.unread) {
        notifications = notifications.filter(n => !n.read);
      }
      if (filters.category) {
        notifications = notifications.filter(n => n.category === filters.category);
      }
      if (filters.type) {
        notifications = notifications.filter(n => n.type === filters.type);
      }
    }

    notifications.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    if (filters?.limit) {
      notifications = notifications.slice(0, filters.limit);
    }

    return notifications;
  }

  getNotificationStats(userId: string): {
    total: number;
    unread: number;
    byCategory: { [key in NotificationCategory]?: number };
    byPriority: { [key: string]: number };
  } {
    const userNotifications = this.getUserNotifications(userId);
    
    const stats = {
      total: userNotifications.length,
      unread: userNotifications.filter(n => !n.read).length,
      byCategory: {} as { [key in NotificationCategory]?: number },
      byPriority: { low: 0, medium: 0, high: 0, urgent: 0 }
    };

    for (const notification of userNotifications) {
      // Por categoría
      stats.byCategory[notification.category] = (stats.byCategory[notification.category] || 0) + 1;
      
      // Por prioridad
      stats.byPriority[notification.priority]++;
    }

    return stats;
  }

  getTemplate(templateId: string): NotificationTemplate | undefined {
    return this.templates.get(templateId);
  }

  getAllTemplates(): NotificationTemplate[] {
    return Array.from(this.templates.values());
  }

  addEventListener(eventType: string, listener: EventListener): void {
    this.eventEmitter.addEventListener(eventType, listener);
  }

  removeEventListener(eventType: string, listener: EventListener): void {
    this.eventEmitter.removeEventListener(eventType, listener);
  }

  // Cleanup
  destroy(): void {
    if (this.processingInterval) {
      clearInterval(this.processingInterval);
    }
  }
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalNotificationSystem = new NotificationSystem();

// Exponer en window para debugging
if (typeof window !== 'undefined') {
  (window as any).notificationSystem = globalNotificationSystem;
}

export default NotificationSystem;
