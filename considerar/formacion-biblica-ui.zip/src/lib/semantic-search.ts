/**
 * Sistema de Búsqueda Semántica Avanzada
 * Búsqueda por similitud conceptual, embeddings y contexto
 */

import { globalMLEngine, SemanticSearchResult } from './ml-engine';

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface SearchQuery {
  text: string;
  type: 'semantic' | 'keyword' | 'fuzzy' | 'contextual' | 'hybrid';
  filters?: {
    books?: string[];
    testament?: 'AT' | 'NT' | 'both';
    topics?: string[];
    sentiment?: 'positive' | 'negative' | 'neutral';
    dateRange?: [number, number]; // Años aproximados
  };
  options?: {
    limit?: number;
    threshold?: number;
    includeContext?: boolean;
    expandQuery?: boolean;
    autoCorrect?: boolean;
    synonyms?: boolean;
  };
  weights?: {
    semantic?: number;
    keyword?: number;
    context?: number;
    sentiment?: number;
  };
}

export interface SearchResult {
  verse: any;
  score: number;
  type: 'exact' | 'semantic' | 'fuzzy' | 'contextual';
  matches: {
    keywords: string[];
    concepts: string[];
    topics: string[];
  };
  context: {
    before?: any[];
    after?: any[];
    chapter: string;
    theme: string;
  };
  explanation: string;
  relevanceFactors: {
    textMatch: number;
    semanticMatch: number;
    contextMatch: number;
    topicMatch: number;
  };
}

export interface AutocompleteResult {
  text: string;
  type: 'verse' | 'concept' | 'person' | 'place' | 'topic';
  score: number;
  preview?: string;
  reference?: string;
}

export interface SearchSuggestion {
  query: string;
  reason: string;
  expectedResults: number;
  category: 'similar' | 'related' | 'broader' | 'narrower';
}

export interface SearchAnalytics {
  totalSearches: number;
  popularQueries: { query: string; count: number }[];
  averageResults: number;
  performanceMetrics: {
    averageResponseTime: number;
    cacheHitRate: number;
    accuracy: number;
  };
  userPatterns: {
    preferredSearchTypes: { [type: string]: number };
    commonFilters: { [filter: string]: number };
    sessionDepth: number;
  };
}

// =====================================================================
// CONFIGURACIÓN DE BÚSQUEDA
// =====================================================================

const SEARCH_CONFIG = {
  similarity: {
    threshold: 0.3,
    minKeywordMatch: 0.1,
    semanticWeight: 0.4,
    keywordWeight: 0.3,
    contextWeight: 0.2,
    topicWeight: 0.1
  },
  fuzzy: {
    maxDistance: 2, // Levenshtein distance
    minLength: 3,
    prefixLength: 1
  },
  context: {
    windowSize: 3, // Versículos antes y después
    chapterRelevance: 0.8,
    bookRelevance: 0.6
  },
  autocomplete: {
    maxSuggestions: 10,
    minLength: 2,
    debounceTime: 300
  },
  cache: {
    maxEntries: 1000,
    ttl: 3600000 // 1 hora
  },
  expansion: {
    synonyms: true,
    relatedTerms: true,
    maxExpansions: 5
  }
};

// Sinónimos y términos relacionados para expansión de consultas
const QUERY_EXPANSIONS: { [key: string]: string[] } = {
  // Términos teológicos
  'dios': ['señor', 'jehová', 'padre', 'altísimo', 'creador', 'todopoderoso'],
  'jesus': ['cristo', 'hijo', 'salvador', 'maestro', 'cordero', 'mesías'],
  'espiritu': ['espíritu santo', 'consolador', 'paráclito'],
  
  // Conceptos espirituales
  'amor': ['caridad', 'compasión', 'misericordia', 'bondad', 'ternura'],
  'fe': ['confianza', 'creencia', 'esperanza', 'fidelidad'],
  'perdón': ['remisión', 'absolución', 'reconciliación', 'clemencia'],
  'paz': ['tranquilidad', 'descanso', 'serenidad', 'armonía'],
  'sabiduría': ['entendimiento', 'prudencia', 'discernimiento', 'conocimiento'],
  
  // Acciones y estados
  'orar': ['suplicar', 'pedir', 'invocar', 'clamar', 'interceder'],
  'alabar': ['glorificar', 'exaltar', 'bendecir', 'magnificar'],
  'arrepentir': ['convertir', 'volver', 'cambiar', 'lamentar'],
  
  // Elementos simbólicos
  'agua': ['lluvia', 'río', 'fuente', 'mar', 'corriente'],
  'luz': ['lámpara', 'antorcha', 'resplandor', 'brillo', 'claridad'],
  'vida': ['existencia', 'ser', 'aliento', 'alma', 'espíritu']
};

// =====================================================================
// MOTOR DE BÚSQUEDA SEMÁNTICA
// =====================================================================

export class SemanticSearchEngine {
  private searchCache: Map<string, SearchResult[]> = new Map();
  private autocompleteCache: Map<string, AutocompleteResult[]> = new Map();
  private queryHistory: string[] = [];
  private searchAnalytics: SearchAnalytics;
  private isInitialized: boolean = false;

  constructor() {
    this.searchAnalytics = this.initializeAnalytics();
    this.initialize();
  }

  // =====================================================================
  // INICIALIZACIÓN
  // =====================================================================

  private async initialize(): Promise<void> {
    try {
      // Esperar que el ML Engine esté inicializado
      await new Promise(resolve => {
        const checkML = () => {
          if ((globalMLEngine as any).initialized) {
            resolve(true);
          } else {
            setTimeout(checkML, 100);
          }
        };
        checkML();
      });

      this.isInitialized = true;
      console.log('Semantic Search Engine initialized');
    } catch (error) {
      console.error('Error initializing Semantic Search Engine:', error);
    }
  }

  private initializeAnalytics(): SearchAnalytics {
    return {
      totalSearches: 0,
      popularQueries: [],
      averageResults: 0,
      performanceMetrics: {
        averageResponseTime: 0,
        cacheHitRate: 0,
        accuracy: 0.85
      },
      userPatterns: {
        preferredSearchTypes: {},
        commonFilters: {},
        sessionDepth: 0
      }
    };
  }

  // =====================================================================
  // BÚSQUEDA PRINCIPAL
  // =====================================================================

  async search(query: SearchQuery, verses: any[]): Promise<SearchResult[]> {
    const startTime = performance.now();
    
    if (!this.isInitialized) {
      await this.initialize();
    }

    // Normalizar consulta
    const normalizedQuery = this.normalizeQuery(query);
    
    // Verificar cache
    const cacheKey = this.generateCacheKey(normalizedQuery, verses);
    if (this.searchCache.has(cacheKey)) {
      this.updateAnalytics('cache_hit', performance.now() - startTime);
      return this.searchCache.get(cacheKey)!;
    }

    // Expandir consulta si está habilitado
    const expandedQuery = normalizedQuery.options?.expandQuery 
      ? this.expandQuery(normalizedQuery)
      : normalizedQuery;

    // Ejecutar búsqueda según el tipo
    let results: SearchResult[] = [];
    
    switch (expandedQuery.type) {
      case 'semantic':
        results = await this.performSemanticSearch(expandedQuery, verses);
        break;
      case 'keyword':
        results = await this.performKeywordSearch(expandedQuery, verses);
        break;
      case 'fuzzy':
        results = await this.performFuzzySearch(expandedQuery, verses);
        break;
      case 'contextual':
        results = await this.performContextualSearch(expandedQuery, verses);
        break;
      case 'hybrid':
        results = await this.performHybridSearch(expandedQuery, verses);
        break;
    }

    // Aplicar filtros
    if (expandedQuery.filters) {
      results = this.applyFilters(results, expandedQuery.filters);
    }

    // Aplicar límite
    const limit = expandedQuery.options?.limit || 20;
    results = results.slice(0, limit);

    // Guardar en cache
    this.searchCache.set(cacheKey, results);
    this.cleanupCache();

    // Actualizar analytics
    const executionTime = performance.now() - startTime;
    this.updateAnalytics('search', executionTime, results.length, expandedQuery);

    return results;
  }

  // =====================================================================
  // TIPOS DE BÚSQUEDA ESPECÍFICOS
  // =====================================================================

  private async performSemanticSearch(query: SearchQuery, verses: any[]): Promise<SearchResult[]> {
    const semanticResults = await globalMLEngine.semanticSearch(query.text, verses, query.options?.limit);
    
    return semanticResults.map(result => this.convertSemanticResult(result, query));
  }

  private async performKeywordSearch(query: SearchQuery, verses: any[]): Promise<SearchResult[]> {
    const keywords = this.extractKeywords(query.text);
    const results: SearchResult[] = [];

    for (const verse of verses) {
      const verseText = (verse.texto || verse.text || '').toLowerCase();
      const score = this.calculateKeywordScore(keywords, verseText);
      
      if (score > (query.options?.threshold || SEARCH_CONFIG.similarity.minKeywordMatch)) {
        const result = await this.createSearchResult(verse, score, 'exact', query, {
          keywords: keywords.filter(k => verseText.includes(k)),
          concepts: [],
          topics: []
        });
        results.push(result);
      }
    }

    return results.sort((a, b) => b.score - a.score);
  }

  private async performFuzzySearch(query: SearchQuery, verses: any[]): Promise<SearchResult[]> {
    const queryWords = this.extractKeywords(query.text);
    const results: SearchResult[] = [];

    for (const verse of verses) {
      const verseText = verse.texto || verse.text || '';
      const verseWords = this.extractKeywords(verseText);
      
      let totalScore = 0;
      const matchedWords: string[] = [];

      for (const queryWord of queryWords) {
        let bestMatch = 0;
        let bestWord = '';
        
        for (const verseWord of verseWords) {
          const similarity = this.calculateFuzzySimilarity(queryWord, verseWord);
          if (similarity > bestMatch) {
            bestMatch = similarity;
            bestWord = verseWord;
          }
        }
        
        if (bestMatch > 0.7) {
          totalScore += bestMatch;
          matchedWords.push(bestWord);
        }
      }

      const normalizedScore = queryWords.length > 0 ? totalScore / queryWords.length : 0;
      
      if (normalizedScore > (query.options?.threshold || 0.3)) {
        const result = await this.createSearchResult(verse, normalizedScore, 'fuzzy', query, {
          keywords: matchedWords,
          concepts: [],
          topics: []
        });
        results.push(result);
      }
    }

    return results.sort((a, b) => b.score - a.score);
  }

  private async performContextualSearch(query: SearchQuery, verses: any[]): Promise<SearchResult[]> {
    // Primero hacer búsqueda semántica básica
    const baseResults = await this.performSemanticSearch(query, verses);
    
    // Enriquecer con contexto
    const contextualResults: SearchResult[] = [];
    
    for (const result of baseResults) {
      const enhancedResult = await this.enhanceWithContext(result, verses, query);
      contextualResults.push(enhancedResult);
    }

    return contextualResults.sort((a, b) => b.score - a.score);
  }

  private async performHybridSearch(query: SearchQuery, verses: any[]): Promise<SearchResult[]> {
    const weights = query.weights || {
      semantic: 0.4,
      keyword: 0.3,
      context: 0.2,
      sentiment: 0.1
    };

    // Ejecutar diferentes tipos de búsqueda
    const [semanticResults, keywordResults, contextualResults] = await Promise.all([
      this.performSemanticSearch({ ...query, type: 'semantic' }, verses),
      this.performKeywordSearch({ ...query, type: 'keyword' }, verses),
      this.performContextualSearch({ ...query, type: 'contextual' }, verses)
    ]);

    // Combinar resultados con pesos
    return this.combineSearchResults([
      { results: semanticResults, weight: weights.semantic! },
      { results: keywordResults, weight: weights.keyword! },
      { results: contextualResults, weight: weights.context! }
    ]);
  }

  // =====================================================================
  // AUTOCOMPLETADO INTELIGENTE
  // =====================================================================

  async getAutocompletesuggestions(partialQuery: string, limit: number = 10): Promise<AutocompleteResult[]> {
    if (partialQuery.length < SEARCH_CONFIG.autocomplete.minLength) {
      return [];
    }

    const cacheKey = `autocomplete_${partialQuery.toLowerCase()}`;
    if (this.autocompleteCache.has(cacheKey)) {
      return this.autocompleteCache.get(cacheKey)!.slice(0, limit);
    }

    const suggestions: AutocompleteResult[] = [];

    // Sugerencias de conceptos bíblicos
    suggestions.push(...this.getConceptSuggestions(partialQuery));
    
    // Sugerencias de personas bíblicas
    suggestions.push(...this.getPersonSuggestions(partialQuery));
    
    // Sugerencias de lugares
    suggestions.push(...this.getPlaceSuggestions(partialQuery));
    
    // Sugerencias de tópicos
    suggestions.push(...this.getTopicSuggestions(partialQuery));
    
    // Sugerencias de versículos conocidos
    suggestions.push(...this.getVerseSuggestions(partialQuery));

    // Ordenar por relevancia
    const sortedSuggestions = suggestions
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);

    // Guardar en cache
    this.autocompleteCache.set(cacheKey, sortedSuggestions);
    
    return sortedSuggestions;
  }

  // =====================================================================
  // CORRECCIÓN AUTOMÁTICA
  // =====================================================================

  async autoCorrectQuery(query: string): Promise<string> {
    const words = query.toLowerCase().split(/\s+/);
    const correctedWords: string[] = [];

    for (const word of words) {
      const corrected = this.correctWord(word);
      correctedWords.push(corrected);
    }

    return correctedWords.join(' ');
  }

  private correctWord(word: string): string {
    // Diccionario de correcciones comunes
    const corrections: { [key: string]: string } = {
      'crito': 'cristo',
      'jesuscristo': 'jesucristo',
      'diso': 'dios',
      'espirito': 'espíritu',
      'amro': 'amor',
      'perdon': 'perdón',
      'oracion': 'oración',
      'sabiduria': 'sabiduría',
      'biblia': 'biblia'
    };

    if (corrections[word]) {
      return corrections[word];
    }

    // Buscar corrección por similitud fonética
    const biblicalTerms = [
      'jesus', 'cristo', 'dios', 'señor', 'padre', 'hijo', 'espíritu',
      'amor', 'fe', 'esperanza', 'paz', 'perdón', 'gracia', 'misericordia',
      'salvación', 'vida', 'verdad', 'luz', 'sabiduría', 'justicia'
    ];

    let bestMatch = word;
    let bestScore = 0;

    for (const term of biblicalTerms) {
      const similarity = this.calculateFuzzySimilarity(word, term);
      if (similarity > bestScore && similarity > 0.7) {
        bestScore = similarity;
        bestMatch = term;
      }
    }

    return bestMatch;
  }

  // =====================================================================
  // SUGERENCIAS DE BÚSQUEDA
  // =====================================================================

  async getSearchSuggestions(query: string, currentResults: SearchResult[]): Promise<SearchSuggestion[]> {
    const suggestions: SearchSuggestion[] = [];

    // Sugerencias similares
    suggestions.push(...this.getSimilarQuerySuggestions(query));
    
    // Sugerencias relacionadas
    suggestions.push(...this.getRelatedQuerySuggestions(query));
    
    // Sugerencias más amplias o específicas
    suggestions.push(...this.getBroaderNarrowerSuggestions(query, currentResults));

    return suggestions.slice(0, 5);
  }

  // =====================================================================
  // UTILIDADES DE PROCESAMIENTO
  // =====================================================================

  private normalizeQuery(query: SearchQuery): SearchQuery {
    return {
      ...query,
      text: query.text.trim().toLowerCase(),
      options: {
        limit: 20,
        threshold: 0.3,
        includeContext: true,
        expandQuery: false,
        autoCorrect: true,
        synonyms: true,
        ...query.options
      }
    };
  }

  private expandQuery(query: SearchQuery): SearchQuery {
    if (!query.options?.expandQuery) return query;

    const words = query.text.split(/\s+/);
    const expandedWords = [...words];

    for (const word of words) {
      const expansions = QUERY_EXPANSIONS[word];
      if (expansions) {
        expandedWords.push(...expansions.slice(0, SEARCH_CONFIG.expansion.maxExpansions));
      }
    }

    return {
      ...query,
      text: expandedWords.join(' ')
    };
  }

  private extractKeywords(text: string): string[] {
    return text
      .toLowerCase()
      .replace(/[^\w\sáéíóúñ]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2 && !this.isStopWord(word));
  }

  private isStopWord(word: string): boolean {
    const stopWords = [
      'el', 'la', 'de', 'que', 'y', 'en', 'un', 'es', 'se', 'no', 'te', 'lo',
      'le', 'da', 'su', 'por', 'son', 'con', 'para', 'al', 'del', 'los', 'las'
    ];
    return stopWords.includes(word);
  }

  private calculateKeywordScore(keywords: string[], text: string): number {
    let matches = 0;
    for (const keyword of keywords) {
      if (text.includes(keyword)) {
        matches++;
      }
    }
    return keywords.length > 0 ? matches / keywords.length : 0;
  }

  private calculateFuzzySimilarity(word1: string, word2: string): number {
    const distance = this.levenshteinDistance(word1, word2);
    const maxLength = Math.max(word1.length, word2.length);
    return maxLength > 0 ? 1 - (distance / maxLength) : 0;
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix = [];

    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }

    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }

    return matrix[str2.length][str1.length];
  }

  // =====================================================================
  // CONSTRUCCIÓN DE RESULTADOS
  // =====================================================================

  private convertSemanticResult(semanticResult: SemanticSearchResult, query: SearchQuery): SearchResult {
    return {
      verse: semanticResult.verse,
      score: semanticResult.similarity,
      type: 'semantic',
      matches: {
        keywords: [],
        concepts: [],
        topics: []
      },
      context: {
        chapter: '',
        theme: ''
      },
      explanation: semanticResult.explanation,
      relevanceFactors: {
        textMatch: semanticResult.relevance,
        semanticMatch: semanticResult.similarity,
        contextMatch: semanticResult.contextMatch,
        topicMatch: 0
      }
    };
  }

  private async createSearchResult(
    verse: any,
    score: number,
    type: SearchResult['type'],
    query: SearchQuery,
    matches: SearchResult['matches']
  ): Promise<SearchResult> {
    const context = query.options?.includeContext 
      ? await this.getVerseContext(verse)
      : { chapter: '', theme: '' };

    return {
      verse,
      score,
      type,
      matches,
      context,
      explanation: this.generateExplanation(matches, score, type),
      relevanceFactors: {
        textMatch: score,
        semanticMatch: 0,
        contextMatch: 0,
        topicMatch: 0
      }
    };
  }

  private async enhanceWithContext(
    result: SearchResult,
    allVerses: any[],
    query: SearchQuery
  ): Promise<SearchResult> {
    const contextVerses = this.getContextualVerses(result.verse, allVerses);
    const contextScore = await this.calculateContextScore(contextVerses, query.text);
    
    return {
      ...result,
      score: result.score * 0.7 + contextScore * 0.3,
      type: 'contextual',
      context: {
        ...result.context,
        before: contextVerses.before,
        after: contextVerses.after
      },
      relevanceFactors: {
        ...result.relevanceFactors,
        contextMatch: contextScore
      }
    };
  }

  private combineSearchResults(resultSets: { results: SearchResult[]; weight: number }[]): SearchResult[] {
    const verseMap = new Map<string, SearchResult>();

    for (const { results, weight } of resultSets) {
      for (const result of results) {
        const verseId = this.getVerseId(result.verse);
        const existing = verseMap.get(verseId);
        
        if (existing) {
          existing.score = existing.score + (result.score * weight);
          existing.type = 'hybrid';
        } else {
          verseMap.set(verseId, {
            ...result,
            score: result.score * weight,
            type: 'hybrid'
          });
        }
      }
    }

    return Array.from(verseMap.values()).sort((a, b) => b.score - a.score);
  }

  // =====================================================================
  // SUGERENCIAS DE AUTOCOMPLETADO
  // =====================================================================

  private getConceptSuggestions(partialQuery: string): AutocompleteResult[] {
    const concepts = [
      'amor de Dios', 'fe en Cristo', 'esperanza eterna', 'perdón de pecados',
      'paz de Dios', 'gracia divina', 'misericordia', 'salvación por fe',
      'vida eterna', 'reino de los cielos', 'segunda venida', 'resurreción'
    ];

    return concepts
      .filter(concept => concept.toLowerCase().includes(partialQuery.toLowerCase()))
      .map(concept => ({
        text: concept,
        type: 'concept' as const,
        score: this.calculateMatchScore(partialQuery, concept),
        preview: `Buscar versículos sobre "${concept}"`
      }));
  }

  private getPersonSuggestions(partialQuery: string): AutocompleteResult[] {
    const persons = [
      'Jesús', 'Cristo', 'Dios', 'Padre', 'Espíritu Santo',
      'Abraham', 'Moisés', 'David', 'Salomón', 'Pablo',
      'Pedro', 'Juan', 'María', 'José', 'Daniel'
    ];

    return persons
      .filter(person => person.toLowerCase().includes(partialQuery.toLowerCase()))
      .map(person => ({
        text: person,
        type: 'person' as const,
        score: this.calculateMatchScore(partialQuery, person),
        preview: `Versículos que mencionan a ${person}`
      }));
  }

  private getPlaceSuggestions(partialQuery: string): AutocompleteResult[] {
    const places = [
      'Jerusalén', 'Belén', 'Nazaret', 'Galilea', 'Judea',
      'Egipto', 'Babilonia', 'Roma', 'Corinto', 'Éfeso'
    ];

    return places
      .filter(place => place.toLowerCase().includes(partialQuery.toLowerCase()))
      .map(place => ({
        text: place,
        type: 'place' as const,
        score: this.calculateMatchScore(partialQuery, place),
        preview: `Pasajes relacionados con ${place}`
      }));
  }

  private getTopicSuggestions(partialQuery: string): AutocompleteResult[] {
    const topics = [
      'oración', 'alabanza', 'adoración', 'arrepentimiento',
      'obediencia', 'servicio', 'testimonio', 'evangelismo',
      'santidad', 'pureza', 'humildad', 'paciencia'
    ];

    return topics
      .filter(topic => topic.toLowerCase().includes(partialQuery.toLowerCase()))
      .map(topic => ({
        text: topic,
        type: 'topic' as const,
        score: this.calculateMatchScore(partialQuery, topic),
        preview: `Enseñanzas sobre ${topic}`
      }));
  }

  private getVerseSuggestions(partialQuery: string): AutocompleteResult[] {
    const famousVerses = [
      { text: 'Juan 3:16', preview: 'Porque de tal manera amó Dios al mundo...' },
      { text: 'Romanos 8:28', preview: 'Y sabemos que a los que aman a Dios...' },
      { text: 'Filipenses 4:13', preview: 'Todo lo puedo en Cristo que me fortalece' },
      { text: 'Salmo 23', preview: 'Jehová es mi pastor; nada me faltará' }
    ];

    return famousVerses
      .filter(verse => verse.text.toLowerCase().includes(partialQuery.toLowerCase()))
      .map(verse => ({
        text: verse.text,
        type: 'verse' as const,
        score: this.calculateMatchScore(partialQuery, verse.text),
        preview: verse.preview,
        reference: verse.text
      }));
  }

  // =====================================================================
  // UTILIDADES AUXILIARES
  // =====================================================================

  private calculateMatchScore(partialQuery: string, candidate: string): number {
    const partial = partialQuery.toLowerCase();
    const full = candidate.toLowerCase();
    
    if (full.startsWith(partial)) return 1.0;
    if (full.includes(partial)) return 0.8;
    
    return this.calculateFuzzySimilarity(partial, full);
  }

  private generateCacheKey(query: SearchQuery, verses: any[]): string {
    const queryStr = JSON.stringify(query);
    const versesHash = this.hashArray(verses.map(v => v.id || v.numero || ''));
    return btoa(`${queryStr}_${versesHash}`).slice(0, 32);
  }

  private hashArray(arr: string[]): string {
    return btoa(arr.join(','));
  }

  private getVerseId(verse: any): string {
    return verse.id || `${verse.libro}-${verse.capitulo}-${verse.versiculo}` || 
           `${verse.book}-${verse.chapter}-${verse.verse}` || Math.random().toString();
  }

  private async getVerseContext(verse: any): Promise<{ chapter: string; theme: string }> {
    // Implementación simplificada
    return {
      chapter: `${verse.libro} ${verse.capitulo}` || 'Desconocido',
      theme: 'General'
    };
  }

  private getContextualVerses(verse: any, allVerses: any[]): { before?: any[]; after?: any[] } {
    // Implementación simplificada para obtener contexto
    return {
      before: [],
      after: []
    };
  }

  private async calculateContextScore(contextVerses: any, queryText: string): Promise<number> {
    // Implementación simplificada
    return 0.5;
  }

  private generateExplanation(matches: SearchResult['matches'], score: number, type: string): string {
    const explanations = [];
    
    if (matches.keywords.length > 0) {
      explanations.push(`Palabras clave: ${matches.keywords.join(', ')}`);
    }
    
    if (matches.concepts.length > 0) {
      explanations.push(`Conceptos: ${matches.concepts.join(', ')}`);
    }
    
    explanations.push(`Relevancia: ${(score * 100).toFixed(1)}%`);
    explanations.push(`Tipo: ${type}`);
    
    return explanations.join(' | ');
  }

  private applyFilters(results: SearchResult[], filters: SearchQuery['filters']): SearchResult[] {
    return results.filter(result => {
      if (filters?.books && !filters.books.includes(result.verse.libro || result.verse.book)) {
        return false;
      }
      
      if (filters?.testament) {
        const isOT = this.isOldTestament(result.verse.libro || result.verse.book);
        if (filters.testament === 'AT' && !isOT) return false;
        if (filters.testament === 'NT' && isOT) return false;
      }
      
      return true;
    });
  }

  private isOldTestament(book: string): boolean {
    const otBooks = [
      'genesis', 'exodo', 'levitico', 'numeros', 'deuteronomio',
      'josue', 'jueces', 'rut', '1samuel', '2samuel', '1reyes', '2reyes',
      'salmos', 'proverbios', 'isaias', 'jeremias', 'ezequiel', 'daniel'
    ];
    return otBooks.includes(book?.toLowerCase());
  }

  private getSimilarQuerySuggestions(query: string): SearchSuggestion[] {
    // Implementación simplificada
    return [
      {
        query: query + ' cristianismo',
        reason: 'Agregar contexto cristiano',
        expectedResults: 50,
        category: 'similar'
      }
    ];
  }

  private getRelatedQuerySuggestions(query: string): SearchSuggestion[] {
    // Implementación simplificada
    return [
      {
        query: 'vida eterna',
        reason: 'Tema relacionado',
        expectedResults: 30,
        category: 'related'
      }
    ];
  }

  private getBroaderNarrowerSuggestions(query: string, results: SearchResult[]): SearchSuggestion[] {
    // Implementación simplificada
    return [
      {
        query: query.split(' ')[0],
        reason: 'Búsqueda más amplia',
        expectedResults: results.length * 2,
        category: 'broader'
      }
    ];
  }

  private cleanupCache(): void {
    if (this.searchCache.size > SEARCH_CONFIG.cache.maxEntries) {
      const entries = Array.from(this.searchCache.entries());
      const toDelete = entries.slice(0, entries.length - SEARCH_CONFIG.cache.maxEntries);
      toDelete.forEach(([key]) => this.searchCache.delete(key));
    }
  }

  private updateAnalytics(type: string, executionTime: number, resultCount?: number, query?: SearchQuery): void {
    this.searchAnalytics.totalSearches++;
    
    if (type === 'search' && query) {
      this.queryHistory.push(query.text);
      this.searchAnalytics.userPatterns.preferredSearchTypes[query.type] = 
        (this.searchAnalytics.userPatterns.preferredSearchTypes[query.type] || 0) + 1;
      
      if (resultCount !== undefined) {
        this.searchAnalytics.averageResults = 
          (this.searchAnalytics.averageResults + resultCount) / 2;
      }
    }
    
    this.searchAnalytics.performanceMetrics.averageResponseTime = 
      (this.searchAnalytics.performanceMetrics.averageResponseTime + executionTime) / 2;
  }

  // =====================================================================
  // MÉTODOS PÚBLICOS ADICIONALES
  // =====================================================================

  getSearchAnalytics(): SearchAnalytics {
    return { ...this.searchAnalytics };
  }

  clearCache(): void {
    this.searchCache.clear();
    this.autocompleteCache.clear();
  }

  getQueryHistory(): string[] {
    return [...this.queryHistory];
  }

  clearHistory(): void {
    this.queryHistory = [];
  }
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalSemanticSearch = new SemanticSearchEngine();

// Exponer en window para debugging
if (typeof window !== 'undefined') {
  (window as any).semanticSearch = globalSemanticSearch;
}

export default SemanticSearchEngine;
