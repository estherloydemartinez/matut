/**
 * Legacy Integration Bridge
 * Capa de integración entre módulos JavaScript optimizados y sistemas TypeScript
 */

// Declaraciones de tipos para los módulos JavaScript legacy
declare global {
  interface Window {
    BibliaRV1960Optimized?: any;
    AnalisisAvanzadoOptimizado?: any;
    SocialAvanzadoOptimizado?: any;
  }
}

export interface LegacyBibleModule {
  buscarTexto: (termino: string) => Promise<any[]>;
  obtenerCapitulo: (libro: string, capitulo: number) => Promise<any>;
  obtenerVersiculo: (libro: string, capitulo: number, versiculo: number) => Promise<any>;
  obtenerEstadisticas: () => any;
  limpiarCache: () => void;
}

export interface LegacyAnalyticsModule {
  analizarTexto: (texto: string) => Promise<any>;
  obtenerEstadisticas: (datos: any[]) => any;
  generarVisualizacion: (tipo: string, datos: any[]) => Promise<any>;
  obtenerPatrones: (datos: any[]) => any;
  limpiarCache: () => void;
}

export interface LegacySocialModule {
  obtenerPerfil: () => any;
  actualizarPerfil: (datos: any) => Promise<boolean>;
  obtenerAmigos: () => any[];
  obtenerEventos: () => any[];
  obtenerNotificaciones: () => any[];
  marcarNotificacionLeida: (id: string) => Promise<boolean>;
  limpiarCache: () => void;
}

/**
 * Bridge para integración de módulos legacy
 */
export class LegacyIntegrationBridge {
  private bibleModule: LegacyBibleModule | null = null;
  private analyticsModule: LegacyAnalyticsModule | null = null;
  private socialModule: LegacySocialModule | null = null;
  
  private initialized = false;
  private loadingPromise: Promise<void> | null = null;

  constructor() {
    this.initialize();
  }

  /**
   * Inicializa la integración con módulos legacy
   */
  private async initialize(): Promise<void> {
    if (this.loadingPromise) {
      return this.loadingPromise;
    }

    this.loadingPromise = this.loadModules();
    return this.loadingPromise;
  }

  /**
   * Carga los módulos JavaScript legacy
   */
  private async loadModules(): Promise<void> {
    try {
      // Cargar módulos si no están ya cargados
      await this.loadScript('/js/biblia_rv1960_optimizado.js');
      await this.loadScript('/js/funciones_analiticas_optimizado.js');
      await this.loadScript('/js/social_avanzado_optimizado.js');

      // Esperar a que los módulos se inicialicen
      await this.waitForModules();

      // Configurar referencias
      this.bibleModule = window.BibliaRV1960Optimized;
      this.analyticsModule = window.AnalisisAvanzadoOptimizado;
      this.socialModule = window.SocialAvanzadoOptimizado;

      this.initialized = true;
      console.log('Legacy modules loaded and integrated successfully');
    } catch (error) {
      console.error('Error loading legacy modules:', error);
      throw error;
    }
  }

  /**
   * Carga un script dinámicamente
   */
  private loadScript(src: string): Promise<void> {
    return new Promise((resolve, reject) => {
      // Verificar si el script ya está cargado
      const existingScript = document.querySelector(`script[src="${src}"]`);
      if (existingScript) {
        resolve();
        return;
      }

      const script = document.createElement('script');
      script.src = src;
      script.type = 'text/javascript';
      
      script.onload = () => resolve();
      script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
      
      document.head.appendChild(script);
    });
  }

  /**
   * Espera a que los módulos se inicialicen
   */
  private waitForModules(): Promise<void> {
    return new Promise((resolve) => {
      const checkModules = () => {
        if (
          window.BibliaRV1960Optimized &&
          window.AnalisisAvanzadoOptimizado &&
          window.SocialAvanzadoOptimizado
        ) {
          resolve();
        } else {
          setTimeout(checkModules, 100);
        }
      };
      checkModules();
    });
  }

  /**
   * Verifica si los módulos están inicializados
   */
  public isInitialized(): boolean {
    return this.initialized;
  }

  /**
   * Espera a que la inicialización complete
   */
  public async waitForInitialization(): Promise<void> {
    if (this.loadingPromise) {
      await this.loadingPromise;
    }
  }

  // =====================================================================
  // MÉTODOS DEL MÓDULO BÍBLICO
  // =====================================================================

  /**
   * Busca texto en la Biblia usando el módulo legacy
   */
  public async searchBibleText(term: string): Promise<any[]> {
    await this.waitForInitialization();
    
    if (!this.bibleModule) {
      throw new Error('Bible module not available');
    }

    try {
      return await this.bibleModule.buscarTexto(term);
    } catch (error) {
      console.error('Error searching bible text:', error);
      throw error;
    }
  }

  /**
   * Obtiene un capítulo específico
   */
  public async getBibleChapter(book: string, chapter: number): Promise<any> {
    await this.waitForInitialization();
    
    if (!this.bibleModule) {
      throw new Error('Bible module not available');
    }

    try {
      return await this.bibleModule.obtenerCapitulo(book, chapter);
    } catch (error) {
      console.error('Error getting bible chapter:', error);
      throw error;
    }
  }

  /**
   * Obtiene un versículo específico
   */
  public async getBibleVerse(book: string, chapter: number, verse: number): Promise<any> {
    await this.waitForInitialization();
    
    if (!this.bibleModule) {
      throw new Error('Bible module not available');
    }

    try {
      return await this.bibleModule.obtenerVersiculo(book, chapter, verse);
    } catch (error) {
      console.error('Error getting bible verse:', error);
      throw error;
    }
  }

  /**
   * Obtiene estadísticas del módulo bíblico
   */
  public getBibleStats(): any {
    if (!this.bibleModule) {
      throw new Error('Bible module not available');
    }

    return this.bibleModule.obtenerEstadisticas();
  }

  // =====================================================================
  // MÉTODOS DEL MÓDULO ANALÍTICO
  // =====================================================================

  /**
   * Analiza texto usando el módulo legacy
   */
  public async analyzeText(text: string): Promise<any> {
    await this.waitForInitialization();
    
    if (!this.analyticsModule) {
      throw new Error('Analytics module not available');
    }

    try {
      return await this.analyticsModule.analizarTexto(text);
    } catch (error) {
      console.error('Error analyzing text:', error);
      throw error;
    }
  }

  /**
   * Obtiene estadísticas de datos
   */
  public getAnalyticsStats(data: any[]): any {
    if (!this.analyticsModule) {
      throw new Error('Analytics module not available');
    }

    return this.analyticsModule.obtenerEstadisticas(data);
  }

  /**
   * Genera visualización
   */
  public async generateVisualization(type: string, data: any[]): Promise<any> {
    await this.waitForInitialization();
    
    if (!this.analyticsModule) {
      throw new Error('Analytics module not available');
    }

    try {
      return await this.analyticsModule.generarVisualizacion(type, data);
    } catch (error) {
      console.error('Error generating visualization:', error);
      throw error;
    }
  }

  /**
   * Obtiene patrones de datos
   */
  public getDataPatterns(data: any[]): any {
    if (!this.analyticsModule) {
      throw new Error('Analytics module not available');
    }

    return this.analyticsModule.obtenerPatrones(data);
  }

  // =====================================================================
  // MÉTODOS DEL MÓDULO SOCIAL
  // =====================================================================

  /**
   * Obtiene perfil de usuario
   */
  public getUserProfile(): any {
    if (!this.socialModule) {
      throw new Error('Social module not available');
    }

    return this.socialModule.obtenerPerfil();
  }

  /**
   * Actualiza perfil de usuario
   */
  public async updateUserProfile(data: any): Promise<boolean> {
    await this.waitForInitialization();
    
    if (!this.socialModule) {
      throw new Error('Social module not available');
    }

    try {
      return await this.socialModule.actualizarPerfil(data);
    } catch (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
  }

  /**
   * Obtiene lista de amigos
   */
  public getFriends(): any[] {
    if (!this.socialModule) {
      throw new Error('Social module not available');
    }

    return this.socialModule.obtenerAmigos();
  }

  /**
   * Obtiene eventos sociales
   */
  public getSocialEvents(): any[] {
    if (!this.socialModule) {
      throw new Error('Social module not available');
    }

    return this.socialModule.obtenerEventos();
  }

  /**
   * Obtiene notificaciones
   */
  public getNotifications(): any[] {
    if (!this.socialModule) {
      throw new Error('Social module not available');
    }

    return this.socialModule.obtenerNotificaciones();
  }

  /**
   * Marca notificación como leída
   */
  public async markNotificationAsRead(id: string): Promise<boolean> {
    await this.waitForInitialization();
    
    if (!this.socialModule) {
      throw new Error('Social module not available');
    }

    try {
      return await this.socialModule.marcarNotificacionLeida(id);
    } catch (error) {
      console.error('Error marking notification as read:', error);
      throw error;
    }
  }

  // =====================================================================
  // MÉTODOS DE UTILIDAD
  // =====================================================================

  /**
   * Limpia todos los caches
   */
  public clearAllCaches(): void {
    if (this.bibleModule) {
      this.bibleModule.limpiarCache();
    }
    
    if (this.analyticsModule) {
      this.analyticsModule.limpiarCache();
    }
    
    if (this.socialModule) {
      this.socialModule.limpiarCache();
    }
  }

  /**
   * Obtiene el estado de todos los módulos
   */
  public getModulesStatus(): {
    bible: boolean;
    analytics: boolean;
    social: boolean;
    initialized: boolean;
  } {
    return {
      bible: !!this.bibleModule,
      analytics: !!this.analyticsModule,
      social: !!this.socialModule,
      initialized: this.initialized
    };
  }

  /**
   * Ejecuta operación de health check en todos los módulos
   */
  public async healthCheck(): Promise<{
    bible: boolean;
    analytics: boolean;
    social: boolean;
    overall: boolean;
  }> {
    const status = {
      bible: false,
      analytics: false,
      social: false,
      overall: false
    };

    try {
      // Test Bible module
      if (this.bibleModule) {
        const stats = this.bibleModule.obtenerEstadisticas();
        status.bible = !!stats;
      }

      // Test Analytics module
      if (this.analyticsModule) {
        const testData = [1, 2, 3, 4, 5];
        const stats = this.analyticsModule.obtenerEstadisticas(testData);
        status.analytics = !!stats;
      }

      // Test Social module
      if (this.socialModule) {
        const profile = this.socialModule.obtenerPerfil();
        status.social = profile !== null;
      }

      status.overall = status.bible && status.analytics && status.social;
    } catch (error) {
      console.error('Health check failed:', error);
    }

    return status;
  }
}

// Instancia global del bridge
export const legacyBridge = new LegacyIntegrationBridge();

// Exportar para uso en window si es necesario
if (typeof window !== 'undefined') {
  (window as any).legacyBridge = legacyBridge;
}

export default LegacyIntegrationBridge;
