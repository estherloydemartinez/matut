/**
 * Tests para Social Engine
 * Testing completo del motor social
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { 
  SocialEngine, 
  globalSocialEngine,
  type Community,
  type StudyGroup,
  type Mentorship
} from '../social-engine';

describe('SocialEngine', () => {
  let socialEngine: SocialEngine;

  beforeEach(() => {
    socialEngine = new SocialEngine();
    vi.clearAllMocks();
  });

  describe('Community Management', () => {
    it('should create a new community successfully', async () => {
      const communityData = {
        name: 'Test Community',
        description: 'A test community for unit testing',
        category: 'Theology' as const,
        privacy: 'public' as const,
        settings: {
          allowDiscussions: true,
          requireApproval: false,
          allowFileSharing: true,
          maxMembers: 100
        }
      };

      const communityId = await socialEngine.createCommunity('user1', communityData);
      
      expect(communityId).toBeDefined();
      expect(typeof communityId).toBe('string');
      
      const community = socialEngine.getCommunity(communityId);
      expect(community).toBeDefined();
      expect(community?.name).toBe(communityData.name);
      expect(community?.members).toContain('user1');
      expect(community?.admins).toContain('user1');
    });

    it('should allow users to join public communities', async () => {
      const communityId = await socialEngine.createCommunity('user1', {
        name: 'Public Community',
        description: 'Test',
        category: 'Bible Study',
        privacy: 'public',
        settings: { allowDiscussions: true, requireApproval: false, allowFileSharing: true, maxMembers: 100 }
      });

      const result = await socialEngine.joinCommunity('user2', communityId);
      
      expect(result).toBe(true);
      
      const community = socialEngine.getCommunity(communityId);
      expect(community?.members).toContain('user2');
    });

    it('should not allow joining private communities without invitation', async () => {
      const communityId = await socialEngine.createCommunity('user1', {
        name: 'Private Community',
        description: 'Test',
        category: 'Bible Study',
        privacy: 'private',
        settings: { allowDiscussions: true, requireApproval: true, allowFileSharing: true, maxMembers: 100 }
      });

      const result = await socialEngine.joinCommunity('user2', communityId);
      
      expect(result).toBe(false);
    });

    it('should get user communities correctly', () => {
      // Crear datos de prueba
      socialEngine['communities'].set('comm1', {
        id: 'comm1',
        name: 'Community 1',
        description: 'Test',
        category: 'Bible Study',
        privacy: 'public',
        members: ['user1', 'user2'],
        admins: ['user1'],
        moderators: [],
        createdBy: 'user1',
        createdAt: new Date(),
        stats: { totalMembers: 2, totalPosts: 0, totalEvents: 0, engagementRate: 0 },
        settings: { allowDiscussions: true, requireApproval: false, allowFileSharing: true, maxMembers: 100 },
        tags: [],
        avatar: undefined,
        banner: undefined
      });

      const userCommunities = socialEngine.getUserCommunities('user1');
      
      expect(userCommunities).toHaveLength(1);
      expect(userCommunities[0].id).toBe('comm1');
    });
  });

  describe('Study Group Management', () => {
    it('should create a study group successfully', async () => {
      const groupData = {
        name: 'Genesis Study Group',
        description: 'Studying the book of Genesis',
        book: 'Genesis',
        schedule: {
          frequency: 'weekly' as const,
          dayOfWeek: 2,
          time: '19:00',
          timezone: 'UTC'
        },
        maxMembers: 10,
        isPrivate: false
      };

      const groupId = await socialEngine.createStudyGroup('user1', groupData);
      
      expect(groupId).toBeDefined();
      
      const group = socialEngine.getStudyGroup(groupId);
      expect(group?.name).toBe(groupData.name);
      expect(group?.leader).toBe('user1');
      expect(group?.members).toContain('user1');
    });

    it('should find suitable study groups for a user', async () => {
      // Crear grupo de prueba
      await socialEngine.createStudyGroup('user1', {
        name: 'Psalms Study',
        description: 'Studying Psalms',
        book: 'Psalms',
        schedule: { frequency: 'weekly', dayOfWeek: 3, time: '20:00', timezone: 'UTC' },
        maxMembers: 8,
        isPrivate: false
      });

      const userPreferences = {
        favoriteBooks: ['Psalms', 'Proverbs'],
        studyTimes: ['evening'],
        studyFrequency: 'weekly' as const,
        timezone: 'UTC'
      };

      const recommendations = await socialEngine.findSuitableStudyGroups('user2', userPreferences);
      
      expect(recommendations.length).toBeGreaterThan(0);
      expect(recommendations[0].matchScore).toBeGreaterThan(0);
    });
  });

  describe('Mentorship System', () => {
    it('should create a mentorship request', async () => {
      const requestData = {
        mentorId: 'mentor1',
        subject: 'Biblical Hermeneutics',
        goals: 'Learn interpretation techniques',
        duration: '3 months',
        preferredSchedule: 'weekends'
      };

      const requestId = await socialEngine.requestMentorship('student1', requestData);
      
      expect(requestId).toBeDefined();
      
      const mentorship = socialEngine.getMentorship(requestId);
      expect(mentorship?.student).toBe('student1');
      expect(mentorship?.mentor).toBe('mentor1');
      expect(mentorship?.status).toBe('pending');
    });

    it('should accept mentorship requests', async () => {
      // Crear solicitud
      const requestId = await socialEngine.requestMentorship('student1', {
        mentorId: 'mentor1',
        subject: 'Theology',
        goals: 'Deep understanding',
        duration: '6 months',
        preferredSchedule: 'evenings'
      });

      const result = await socialEngine.acceptMentorshipRequest('mentor1', requestId);
      
      expect(result).toBe(true);
      
      const mentorship = socialEngine.getMentorship(requestId);
      expect(mentorship?.status).toBe('active');
    });

    it('should find suitable mentors for students', async () => {
      const userProfile = {
        interests: ['Biblical History', 'Theology'],
        currentLevel: 'beginner' as const,
        preferredLanguage: 'Spanish',
        timezone: 'America/Mexico_City'
      };

      const mentors = await socialEngine.findSuitableMentors('student1', userProfile);
      
      expect(Array.isArray(mentors)).toBe(true);
      // Puede estar vacío si no hay mentores disponibles
    });
  });

  describe('Gamification System', () => {
    it('should create challenges successfully', async () => {
      const challengeData = {
        title: 'Read Through Psalms',
        description: 'Read all 150 Psalms in 30 days',
        type: 'individual' as const,
        difficulty: 'medium' as const,
        duration: 30 * 24 * 60 * 60 * 1000, // 30 días en ms
        requirements: {
          readChapters: 150,
          minimumTime: 5,
          consecutiveDays: 5
        },
        rewards: {
          points: 500,
          badges: ['psalm-reader'],
          unlocks: ['advanced-psalms-study']
        }
      };

      const challengeId = await socialEngine.createChallenge('admin1', challengeData);
      
      expect(challengeId).toBeDefined();
      
      const challenge = socialEngine.getChallenge(challengeId);
      expect(challenge?.title).toBe(challengeData.title);
      expect(challenge?.type).toBe('individual');
    });

    it('should allow users to join challenges', async () => {
      // Crear desafío
      const challengeId = await socialEngine.createChallenge('admin1', {
        title: 'Prayer Challenge',
        description: 'Pray daily for 7 days',
        type: 'individual',
        difficulty: 'easy',
        duration: 7 * 24 * 60 * 60 * 1000,
        requirements: { consecutiveDays: 7 },
        rewards: { points: 100, badges: ['prayer-warrior'], unlocks: [] }
      });

      const result = await socialEngine.joinChallenge('user1', challengeId);
      
      expect(result).toBe(true);
      
      const challenge = socialEngine.getChallenge(challengeId);
      expect(challenge?.participants).toContain('user1');
    });

    it('should update user progress correctly', async () => {
      const result = await socialEngine.updateUserProgress('user1', {
        chaptersRead: 5,
        timeSpent: 30,
        activitiesCompleted: ['prayer', 'reading'],
        date: new Date()
      });

      expect(result).toBe(true);
      
      const progress = socialEngine.getUserProgress('user1');
      expect(progress?.chaptersRead).toBe(5);
      expect(progress?.timeSpent).toBe(30);
    });
  });

  describe('Analytics and Metrics', () => {
    it('should calculate community metrics correctly', () => {
      // Configurar datos de prueba
      socialEngine['communities'].set('comm1', {
        id: 'comm1',
        name: 'Test Community',
        description: 'Test',
        category: 'Bible Study',
        privacy: 'public',
        members: ['user1', 'user2', 'user3'],
        admins: ['user1'],
        moderators: [],
        createdBy: 'user1',
        createdAt: new Date(),
        stats: { totalMembers: 3, totalPosts: 10, totalEvents: 2, engagementRate: 0.75 },
        settings: { allowDiscussions: true, requireApproval: false, allowFileSharing: true, maxMembers: 100 },
        tags: [],
        avatar: undefined,
        banner: undefined
      });

      const metrics = socialEngine.getCommunityMetrics('comm1');
      
      expect(metrics.memberCount).toBe(3);
      expect(metrics.engagementRate).toBe(0.75);
      expect(metrics.totalPosts).toBe(10);
      expect(metrics.totalEvents).toBe(2);
    });

    it('should generate user analytics', () => {
      const analytics = socialEngine.getUserAnalytics('user1');
      
      expect(analytics).toBeDefined();
      expect(typeof analytics.totalActivities).toBe('number');
      expect(typeof analytics.engagementScore).toBe('number');
      expect(Array.isArray(analytics.participationTrends)).toBe(true);
    });

    it('should get global social analytics', () => {
      const analytics = socialEngine.getGlobalSocialAnalytics();
      
      expect(analytics).toBeDefined();
      expect(typeof analytics.totalUsers).toBe('number');
      expect(typeof analytics.totalCommunities).toBe('number');
      expect(typeof analytics.totalStudyGroups).toBe('number');
      expect(typeof analytics.activeMentorships).toBe('number');
    });
  });

  describe('Performance Tests', () => {
    it('should handle large number of communities efficiently', async () => {
      const startTime = performance.now();
      
      // Crear 100 comunidades
      const promises = [];
      for (let i = 0; i < 100; i++) {
        promises.push(socialEngine.createCommunity(`user${i}`, {
          name: `Community ${i}`,
          description: `Test community ${i}`,
          category: 'Bible Study',
          privacy: 'public',
          settings: { allowDiscussions: true, requireApproval: false, allowFileSharing: true, maxMembers: 100 }
        }));
      }
      
      await Promise.all(promises);
      
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      // Debería completarse en menos de 1 segundo
      expect(duration).toBeLessThan(1000);
      expect(socialEngine['communities'].size).toBe(100);
    });

    it('should efficiently search through large datasets', () => {
      // Agregar muchas comunidades para búsqueda
      for (let i = 0; i < 1000; i++) {
        socialEngine['communities'].set(`comm${i}`, {
          id: `comm${i}`,
          name: `Community ${i}`,
          description: `Test community about ${i % 10 === 0 ? 'Genesis' : 'random topic'}`,
          category: 'Bible Study',
          privacy: 'public',
          members: [`user${i}`],
          admins: [`user${i}`],
          moderators: [],
          createdBy: `user${i}`,
          createdAt: new Date(),
          stats: { totalMembers: 1, totalPosts: 0, totalEvents: 0, engagementRate: 0 },
          settings: { allowDiscussions: true, requireApproval: false, allowFileSharing: true, maxMembers: 100 },
          tags: [],
          avatar: undefined,
          banner: undefined
        });
      }

      const startTime = performance.now();
      
      const results = socialEngine.searchCommunities('Genesis');
      
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      // La búsqueda debería ser rápida incluso con 1000 elementos
      expect(duration).toBeLessThan(100);
      expect(results.length).toBeGreaterThan(0);
    });
  });

  describe('Error Handling', () => {
    it('should handle invalid community creation gracefully', async () => {
      const invalidData = {
        name: '', // Nombre vacío
        description: 'Test',
        category: 'Bible Study' as const,
        privacy: 'public' as const,
        settings: { allowDiscussions: true, requireApproval: false, allowFileSharing: true, maxMembers: 100 }
      };

      await expect(socialEngine.createCommunity('user1', invalidData)).rejects.toThrow();
    });

    it('should handle non-existent community access', () => {
      const community = socialEngine.getCommunity('non-existent-id');
      expect(community).toBeUndefined();
    });

    it('should handle invalid user operations', async () => {
      const result = await socialEngine.joinCommunity('', 'some-community-id');
      expect(result).toBe(false);
    });
  });
});

describe('Global Social Engine', () => {
  it('should be a singleton instance', () => {
    expect(globalSocialEngine).toBeDefined();
    expect(globalSocialEngine).toBeInstanceOf(SocialEngine);
  });

  it('should maintain state across calls', async () => {
    const communityId = await globalSocialEngine.createCommunity('global-user', {
      name: 'Global Test Community',
      description: 'Testing global instance',
      category: 'Bible Study',
      privacy: 'public',
      settings: { allowDiscussions: true, requireApproval: false, allowFileSharing: true, maxMembers: 100 }
    });

    expect(communityId).toBeDefined();
    
    const community = globalSocialEngine.getCommunity(communityId);
    expect(community?.name).toBe('Global Test Community');
  });
});
