/**
 * Tests para ML Engine
 * Testing completo del motor de Machine Learning
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { 
  MLEngine, 
  globalMLEngine,
  type MLModel,
  type PredictionResult,
  type TrainingData
} from '../ml-engine';

describe('MLEngine', () => {
  let mlEngine: MLEngine;

  beforeEach(() => {
    mlEngine = new MLEngine();
    vi.clearAllMocks();
  });

  describe('Text Analysis', () => {
    it('should analyze text sentiment correctly', async () => {
      const positiveText = "This is a wonderful Bible study session! I learned so much.";
      const negativeText = "I'm struggling with understanding this passage.";
      const neutralText = "Today we studied Genesis chapter 1.";

      const positiveResult = await mlEngine.analyzeSentiment(positiveText);
      const negativeResult = await mlEngine.analyzeSentiment(negativeText);
      const neutralResult = await mlEngine.analyzeSentiment(neutralText);

      expect(positiveResult.sentiment).toBe('positive');
      expect(positiveResult.confidence).toBeGreaterThan(0.5);
      
      expect(negativeResult.sentiment).toBe('negative');
      expect(negativeResult.confidence).toBeGreaterThan(0.5);
      
      expect(neutralResult.sentiment).toBe('neutral');
    });

    it('should extract key topics from text', async () => {
      const text = `
        Today we discussed the creation story in Genesis. 
        We talked about how God created the heavens and the earth in six days.
        The concept of sabbath was also important in our discussion.
        Many participants had questions about the theological implications.
      `;

      const topics = await mlEngine.extractTopics(text);

      expect(Array.isArray(topics)).toBe(true);
      expect(topics.length).toBeGreaterThan(0);
      
      const topicNames = topics.map(t => t.topic.toLowerCase());
      expect(topicNames).toContain('creation');
      expect(topicNames.some(name => name.includes('genesis'))).toBe(true);
    });

    it('should classify text content correctly', async () => {
      const prayerText = "Dear God, please bless our study group and help us understand your word.";
      const questionText = "What does this verse mean in the original Hebrew?";
      const studyText = "The book of Romans explains justification by faith in detail.";

      const prayerResult = await mlEngine.classifyContent(prayerText);
      const questionResult = await mlEngine.classifyContent(questionText);
      const studyResult = await mlEngine.classifyContent(studyText);

      expect(prayerResult.category).toBe('prayer');
      expect(questionResult.category).toBe('question');
      expect(studyResult.category).toBe('study_note');
    });

    it('should detect language correctly', async () => {
      const englishText = "This is a text in English about the Bible.";
      const spanishText = "Este es un texto en español sobre la Biblia.";
      const portugueseText = "Este é um texto em português sobre a Bíblia.";

      const englishResult = await mlEngine.detectLanguage(englishText);
      const spanishResult = await mlEngine.detectLanguage(spanishText);
      const portugueseResult = await mlEngine.detectLanguage(portugueseText);

      expect(englishResult.language).toBe('en');
      expect(spanishResult.language).toBe('es');
      expect(portugueseResult.language).toBe('pt');
      
      expect(englishResult.confidence).toBeGreaterThan(0.8);
      expect(spanishResult.confidence).toBeGreaterThan(0.8);
      expect(portugueseResult.confidence).toBeGreaterThan(0.8);
    });
  });

  describe('Recommendation System', () => {
    it('should generate content recommendations', async () => {
      const userProfile = {
        interests: ['New Testament', 'Pauline Epistles', 'Theology'],
        readingHistory: ['Romans', 'Ephesians', 'Philippians'],
        preferredDifficulty: 'intermediate' as const,
        studyGoals: ['deeper understanding', 'practical application']
      };

      const recommendations = await mlEngine.getContentRecommendations('user1', userProfile);

      expect(Array.isArray(recommendations)).toBe(true);
      expect(recommendations.length).toBeGreaterThan(0);
      
      recommendations.forEach(rec => {
        expect(rec).toHaveProperty('contentId');
        expect(rec).toHaveProperty('title');
        expect(rec).toHaveProperty('relevanceScore');
        expect(rec).toHaveProperty('reasons');
        expect(rec.relevanceScore).toBeGreaterThan(0);
        expect(rec.relevanceScore).toBeLessThanOrEqual(1);
      });
    });

    it('should recommend study groups based on user preferences', async () => {
      const userPreferences = {
        favoriteBooks: ['Psalms', 'Proverbs'],
        studyTimes: ['evening'],
        studyFrequency: 'weekly' as const,
        experience: 'beginner' as const,
        interests: ['worship', 'wisdom literature']
      };

      const groupRecommendations = await mlEngine.recommendStudyGroups('user1', userPreferences);

      expect(Array.isArray(groupRecommendations)).toBe(true);
      
      groupRecommendations.forEach(rec => {
        expect(rec).toHaveProperty('groupId');
        expect(rec).toHaveProperty('groupName');
        expect(rec).toHaveProperty('matchScore');
        expect(rec).toHaveProperty('matchReasons');
        expect(rec.matchScore).toBeGreaterThan(0);
        expect(rec.matchScore).toBeLessThanOrEqual(1);
      });
    });

    it('should recommend mentors based on student profile', async () => {
      const studentProfile = {
        currentLevel: 'beginner' as const,
        interests: ['Biblical History', 'Archaeology'],
        goals: ['understand historical context', 'learn Hebrew'],
        preferredMentorCharacteristics: ['patient', 'experienced', 'scholarly']
      };

      const mentorRecommendations = await mlEngine.recommendMentors('student1', studentProfile);

      expect(Array.isArray(mentorRecommendations)).toBe(true);
      
      mentorRecommendations.forEach(rec => {
        expect(rec).toHaveProperty('mentorId');
        expect(rec).toHaveProperty('mentorName');
        expect(rec).toHaveProperty('compatibilityScore');
        expect(rec).toHaveProperty('strengths');
        expect(rec.compatibilityScore).toBeGreaterThan(0);
        expect(rec.compatibilityScore).toBeLessThanOrEqual(1);
      });
    });
  });

  describe('Personalization', () => {
    it('should create personalized study plan', async () => {
      const userProfile = {
        currentLevel: 'intermediate' as const,
        availableTime: 30, // minutes per day
        goals: ['read through Bible in a year', 'deeper theological understanding'],
        preferences: {
          mixOldNew: true,
          includeCommentary: true,
          focusAreas: ['salvation', 'prophecy']
        }
      };

      const studyPlan = await mlEngine.createPersonalizedStudyPlan('user1', userProfile);

      expect(studyPlan).toBeDefined();
      expect(studyPlan.userId).toBe('user1');
      expect(Array.isArray(studyPlan.dailyPlans)).toBe(true);
      expect(studyPlan.estimatedDuration).toBeGreaterThan(0);
      expect(studyPlan.difficulty).toBe('intermediate');
      
      studyPlan.dailyPlans.forEach(plan => {
        expect(plan).toHaveProperty('date');
        expect(plan).toHaveProperty('readings');
        expect(plan).toHaveProperty('exercises');
        expect(Array.isArray(plan.readings)).toBe(true);
      });
    });

    it('should adapt content difficulty based on user performance', async () => {
      const userPerformance = {
        completionRate: 0.85,
        averageTime: 25, // minutes
        comprehensionScores: [0.8, 0.9, 0.7, 0.85],
        strugglingAreas: ['prophetic literature', 'genealogies'],
        strongAreas: ['parables', 'epistles']
      };

      const adaptedContent = await mlEngine.adaptContentDifficulty('user1', userPerformance);

      expect(adaptedContent).toBeDefined();
      expect(adaptedContent.recommendedDifficulty).toBeDefined();
      expect(adaptedContent.adjustments).toBeDefined();
      expect(Array.isArray(adaptedContent.focusAreas)).toBe(true);
      expect(Array.isArray(adaptedContent.supportAreas)).toBe(true);
    });
  });

  describe('Learning Analytics', () => {
    it('should predict learning outcomes', async () => {
      const learningData = {
        studyTime: 45, // minutes per day
        consistency: 0.8, // 80% consistency
        participationLevel: 'high' as const,
        initialAssessment: 0.6,
        goals: ['complete New Testament', 'understand key doctrines']
      };

      const prediction = await mlEngine.predictLearningOutcome('user1', learningData);

      expect(prediction).toBeDefined();
      expect(prediction.successProbability).toBeGreaterThan(0);
      expect(prediction.successProbability).toBeLessThanOrEqual(1);
      expect(prediction.estimatedCompletionTime).toBeGreaterThan(0);
      expect(Array.isArray(prediction.riskFactors)).toBe(true);
      expect(Array.isArray(prediction.recommendations)).toBe(true);
    });

    it('should identify learning patterns', async () => {
      const behaviorData = [
        { date: new Date('2024-01-01'), studyTime: 30, comprehension: 0.8 },
        { date: new Date('2024-01-02'), studyTime: 25, comprehension: 0.7 },
        { date: new Date('2024-01-03'), studyTime: 35, comprehension: 0.9 },
        { date: new Date('2024-01-04'), studyTime: 20, comprehension: 0.6 },
        { date: new Date('2024-01-05'), studyTime: 40, comprehension: 0.85 }
      ];

      const patterns = await mlEngine.identifyLearningPatterns('user1', behaviorData);

      expect(patterns).toBeDefined();
      expect(Array.isArray(patterns.timePatterns)).toBe(true);
      expect(Array.isArray(patterns.performancePatterns)).toBe(true);
      expect(patterns.averageStudyTime).toBeGreaterThan(0);
      expect(patterns.averageComprehension).toBeGreaterThan(0);
      expect(patterns.averageComprehension).toBeLessThanOrEqual(1);
    });

    it('should detect engagement levels', async () => {
      const engagementData = {
        sessionDuration: 35,
        interactionCount: 15,
        questionsAsked: 3,
        notesCreated: 2,
        sharingActivity: 1,
        returnFrequency: 0.9
      };

      const engagement = await mlEngine.analyzeEngagement('user1', engagementData);

      expect(engagement).toBeDefined();
      expect(engagement.level).toMatch(/^(low|medium|high)$/);
      expect(engagement.score).toBeGreaterThan(0);
      expect(engagement.score).toBeLessThanOrEqual(1);
      expect(Array.isArray(engagement.factors)).toBe(true);
      expect(Array.isArray(engagement.recommendations)).toBe(true);
    });
  });

  describe('Model Management', () => {
    it('should register custom models', async () => {
      const customModel: MLModel = {
        id: 'custom-sentiment',
        name: 'Custom Sentiment Analysis',
        type: 'classification',
        version: '1.0.0',
        inputSchema: {
          text: 'string'
        },
        outputSchema: {
          sentiment: 'string',
          confidence: 'number'
        },
        predict: async (input: any) => ({
          sentiment: 'positive',
          confidence: 0.85
        }),
        train: async (data: TrainingData[]) => true,
        evaluate: async (testData: TrainingData[]) => ({
          accuracy: 0.92,
          precision: 0.89,
          recall: 0.94,
          f1Score: 0.91
        })
      };

      const result = await mlEngine.registerModel(customModel);
      expect(result).toBe(true);

      const retrievedModel = mlEngine.getModel('custom-sentiment');
      expect(retrievedModel).toBeDefined();
      expect(retrievedModel?.name).toBe('Custom Sentiment Analysis');
    });

    it('should handle model predictions', async () => {
      // Registrar modelo primero
      const testModel: MLModel = {
        id: 'test-classifier',
        name: 'Test Classifier',
        type: 'classification',
        version: '1.0.0',
        inputSchema: { text: 'string' },
        outputSchema: { category: 'string', confidence: 'number' },
        predict: async (input: any) => ({
          category: 'test-category',
          confidence: 0.95
        }),
        train: async () => true,
        evaluate: async () => ({ accuracy: 0.9, precision: 0.9, recall: 0.9, f1Score: 0.9 })
      };

      await mlEngine.registerModel(testModel);

      const prediction = await mlEngine.predict('test-classifier', { text: 'test input' });
      
      expect(prediction).toBeDefined();
      expect(prediction.category).toBe('test-category');
      expect(prediction.confidence).toBe(0.95);
    });
  });

  describe('Performance Tests', () => {
    it('should handle multiple concurrent predictions efficiently', async () => {
      const startTime = performance.now();
      
      // Realizar 100 predicciones de sentimiento concurrentemente
      const promises = [];
      for (let i = 0; i < 100; i++) {
        promises.push(mlEngine.analyzeSentiment(`This is test text number ${i}`));
      }
      
      const results = await Promise.all(promises);
      
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      expect(results).toHaveLength(100);
      expect(duration).toBeLessThan(5000); // 5 segundos
      
      results.forEach(result => {
        expect(result).toHaveProperty('sentiment');
        expect(result).toHaveProperty('confidence');
      });
    });

    it('should efficiently process large text analysis batches', async () => {
      const largeBatch = Array.from({ length: 50 }, (_, i) => ({
        id: `text-${i}`,
        content: `This is a longer text for analysis number ${i}. `.repeat(10)
      }));

      const startTime = performance.now();
      
      const results = await mlEngine.batchAnalyzeSentiment(largeBatch.map(item => item.content));
      
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      expect(results).toHaveLength(50);
      expect(duration).toBeLessThan(3000); // 3 segundos
    });
  });

  describe('Error Handling', () => {
    it('should handle invalid model predictions gracefully', async () => {
      await expect(
        mlEngine.predict('non-existent-model', { text: 'test' })
      ).rejects.toThrow('Model non-existent-model not found');
    });

    it('should handle empty or invalid text input', async () => {
      const emptyResult = await mlEngine.analyzeSentiment('');
      expect(emptyResult.sentiment).toBe('neutral');
      expect(emptyResult.confidence).toBeLessThan(0.5);

      const invalidResult = await mlEngine.analyzeSentiment(null as any);
      expect(invalidResult.sentiment).toBe('neutral');
    });

    it('should handle malformed user profiles gracefully', async () => {
      const invalidProfile = {
        // Missing required fields
        interests: undefined,
        readingHistory: null
      };

      const recommendations = await mlEngine.getContentRecommendations('user1', invalidProfile as any);
      
      expect(Array.isArray(recommendations)).toBe(true);
      // Should return empty array or default recommendations
    });
  });

  describe('Data Quality and Validation', () => {
    it('should validate input data before processing', async () => {
      const validData = {
        text: 'Valid text for analysis',
        userId: 'user123',
        timestamp: new Date()
      };

      const invalidData = {
        text: null,
        userId: '',
        timestamp: 'invalid-date'
      };

      const validResult = await mlEngine.validateInput(validData);
      const invalidResult = await mlEngine.validateInput(invalidData);

      expect(validResult.isValid).toBe(true);
      expect(invalidResult.isValid).toBe(false);
      expect(Array.isArray(invalidResult.errors)).toBe(true);
      expect(invalidResult.errors.length).toBeGreaterThan(0);
    });

    it('should clean and preprocess text data', async () => {
      const noisyText = `
        This text has     extra    spaces!!!
        And some <html>tags</html> and @special #characters.
        It also has URLs like https://example.com
      `;

      const cleanedText = await mlEngine.preprocessText(noisyText);

      expect(cleanedText).toBeDefined();
      expect(cleanedText.length).toBeLessThan(noisyText.length);
      expect(cleanedText).not.toContain('<html>');
      expect(cleanedText).not.toContain('https://');
      expect(cleanedText.includes('extra spaces')).toBe(false); // Extra spaces removed
    });
  });

  describe('Learning and Adaptation', () => {
    it('should update models based on feedback', async () => {
      const feedback = {
        modelId: 'sentiment-analysis',
        inputData: 'This movie is great!',
        expectedOutput: { sentiment: 'positive', confidence: 0.9 },
        actualOutput: { sentiment: 'neutral', confidence: 0.6 },
        userId: 'user1',
        timestamp: new Date()
      };

      const result = await mlEngine.provideFeedback(feedback);
      expect(result).toBe(true);

      // Verificar que el feedback fue almacenado
      const feedbackHistory = mlEngine.getFeedbackHistory('sentiment-analysis');
      expect(Array.isArray(feedbackHistory)).toBe(true);
      expect(feedbackHistory.length).toBeGreaterThan(0);
    });

    it('should adapt recommendations based on user behavior', async () => {
      const userBehavior = {
        viewedContent: ['genesis-1', 'psalms-23', 'john-3-16'],
        completedStudies: ['creation-study', 'salvation-basics'],
        timeSpentPerTopic: {
          'old-testament': 120,
          'new-testament': 180,
          'theology': 90
        },
        preferredFormat: 'video' as const
      };

      const adaptedRecommendations = await mlEngine.adaptRecommendations('user1', userBehavior);

      expect(adaptedRecommendations).toBeDefined();
      expect(Array.isArray(adaptedRecommendations.content)).toBe(true);
      expect(adaptedRecommendations.reasoningExplanation).toBeDefined();
      expect(typeof adaptedRecommendations.confidenceScore).toBe('number');
    });
  });
});

describe('Global ML Engine', () => {
  it('should be a singleton instance', () => {
    expect(globalMLEngine).toBeDefined();
    expect(globalMLEngine).toBeInstanceOf(MLEngine);
  });

  it('should maintain model registry across calls', async () => {
    const testModel: MLModel = {
      id: 'global-test-model',
      name: 'Global Test Model',
      type: 'regression',
      version: '1.0.0',
      inputSchema: { value: 'number' },
      outputSchema: { prediction: 'number' },
      predict: async (input: any) => ({ prediction: input.value * 2 }),
      train: async () => true,
      evaluate: async () => ({ accuracy: 0.95, precision: 0.95, recall: 0.95, f1Score: 0.95 })
    };

    await globalMLEngine.registerModel(testModel);
    
    const retrievedModel = globalMLEngine.getModel('global-test-model');
    expect(retrievedModel).toBeDefined();
    expect(retrievedModel?.name).toBe('Global Test Model');
  });
});
