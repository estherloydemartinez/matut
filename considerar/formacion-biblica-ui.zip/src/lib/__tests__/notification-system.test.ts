/**
 * Tests para Notification System
 * Testing completo del sistema de notificaciones
 */

import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { 
  NotificationSystem, 
  globalNotificationSystem,
  type Notification,
  type NotificationTemplate,
  type UserNotificationPreferences
} from '../notification-system';

describe('NotificationSystem', () => {
  let notificationSystem: NotificationSystem;

  beforeEach(() => {
    notificationSystem = new NotificationSystem();
    vi.clearAllMocks();
    // Mock de performance.now para tests consistentes
    vi.spyOn(performance, 'now').mockReturnValue(1000);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('Notification Creation and Sending', () => {
    it('should send notification using template successfully', async () => {
      const templateId = 'community_new_member';
      const userId = 'user1';
      const variables = {
        communityName: 'Test Community',
        userName: 'John Doe',
        communityId: 'comm123'
      };

      const notificationId = await notificationSystem.sendNotification(templateId, userId, variables);
      
      expect(notificationId).toBeDefined();
      expect(typeof notificationId).toBe('string');
      
      const notifications = notificationSystem.getUserNotifications(userId);
      expect(notifications).toHaveLength(1);
      expect(notifications[0].title).toContain('Test Community');
    });

    it('should send custom notification successfully', async () => {
      const customNotification = {
        type: 'announcement' as const,
        category: 'administrative' as const,
        priority: 'high' as const,
        title: 'Custom Announcement',
        message: 'This is a custom notification',
        userId: 'user1',
        data: { customField: 'value' },
        actions: [{
          id: 'action1',
          label: 'Take Action',
          type: 'primary' as const
        }],
        channels: ['in_app' as const]
      };

      const notificationId = await notificationSystem.sendCustomNotification(customNotification);
      
      expect(notificationId).toBeDefined();
      
      const notifications = notificationSystem.getUserNotifications('user1');
      expect(notifications).toHaveLength(1);
      expect(notifications[0].title).toBe('Custom Announcement');
      expect(notifications[0].priority).toBe('high');
    });

    it('should not send notification if user preferences disabled', async () => {
      // Deshabilitar notificaciones para el usuario
      await notificationSystem.updateUserPreferences('user1', {
        enabled: false
      });

      const notificationId = await notificationSystem.sendNotification(
        'community_new_member', 
        'user1', 
        { communityName: 'Test', userName: 'John', communityId: 'comm1' }
      );
      
      expect(notificationId).toBe('');
      
      const notifications = notificationSystem.getUserNotifications('user1');
      expect(notifications).toHaveLength(0);
    });

    it('should not send notification for disabled category', async () => {
      // Deshabilitar categoría social
      await notificationSystem.updateUserPreferences('user1', {
        categories: {
          social: { enabled: false, channels: [], frequency: 'disabled' }
        }
      });

      const notificationId = await notificationSystem.sendNotification(
        'community_new_member', 
        'user1', 
        { communityName: 'Test', userName: 'John', communityId: 'comm1' }
      );
      
      expect(notificationId).toBe('');
    });
  });

  describe('Notification Management', () => {
    it('should mark notification as read', async () => {
      const notificationId = await notificationSystem.sendCustomNotification({
        type: 'system',
        category: 'administrative',
        priority: 'medium',
        title: 'Test Notification',
        message: 'Test message',
        userId: 'user1',
        data: {},
        actions: [],
        channels: ['in_app']
      });

      const result = await notificationSystem.markAsRead(notificationId);
      expect(result).toBe(true);
      
      const notifications = notificationSystem.getUserNotifications('user1');
      expect(notifications[0].read).toBe(true);
      expect(notifications[0].analytics.opened).toBeDefined();
    });

    it('should mark notification as clicked with action', async () => {
      const notificationId = await notificationSystem.sendCustomNotification({
        type: 'system',
        category: 'administrative',
        priority: 'medium',
        title: 'Test Notification',
        message: 'Test message',
        userId: 'user1',
        data: {},
        actions: [{ id: 'test-action', label: 'Test', type: 'primary' }],
        channels: ['in_app']
      });

      const result = await notificationSystem.markAsClicked(notificationId, 'test-action');
      expect(result).toBe(true);
      
      const notifications = notificationSystem.getUserNotifications('user1');
      expect(notifications[0].clicked).toBe(true);
      expect(notifications[0].analytics.actionTaken?.actionId).toBe('test-action');
    });

    it('should dismiss notification', async () => {
      const notificationId = await notificationSystem.sendCustomNotification({
        type: 'system',
        category: 'administrative',
        priority: 'medium',
        title: 'Test Notification',
        message: 'Test message',
        userId: 'user1',
        data: {},
        actions: [],
        channels: ['in_app']
      });

      const result = await notificationSystem.dismissNotification(notificationId);
      expect(result).toBe(true);
      
      // Las notificaciones dismissedshould not appear in regular queries
      const notifications = notificationSystem.getUserNotifications('user1');
      expect(notifications).toHaveLength(0);
    });

    it('should mark all notifications as read', async () => {
      // Crear múltiples notificaciones
      await notificationSystem.sendCustomNotification({
        type: 'system', category: 'administrative', priority: 'medium',
        title: 'Notification 1', message: 'Message 1', userId: 'user1',
        data: {}, actions: [], channels: ['in_app']
      });
      
      await notificationSystem.sendCustomNotification({
        type: 'system', category: 'administrative', priority: 'medium',
        title: 'Notification 2', message: 'Message 2', userId: 'user1',
        data: {}, actions: [], channels: ['in_app']
      });

      const markedCount = await notificationSystem.markAllAsRead('user1');
      expect(markedCount).toBe(2);
      
      const notifications = notificationSystem.getUserNotifications('user1');
      expect(notifications.every(n => n.read)).toBe(true);
    });
  });

  describe('User Preferences Management', () => {
    it('should update user preferences successfully', async () => {
      const newPreferences = {
        quietHours: {
          enabled: true,
          start: '23:00',
          end: '07:00',
          timezone: 'America/Mexico_City'
        },
        digestSettings: {
          frequency: 'weekly' as const,
          time: '09:00',
          timezone: 'America/Mexico_City'
        }
      };

      const result = await notificationSystem.updateUserPreferences('user1', newPreferences);
      expect(result).toBe(true);
      
      const preferences = notificationSystem.getUserPreferences('user1');
      expect(preferences?.quietHours.start).toBe('23:00');
      expect(preferences?.digestSettings.frequency).toBe('weekly');
    });

    it('should return user preferences correctly', () => {
      const preferences = notificationSystem.getUserPreferences('user1');
      
      expect(preferences).toBeDefined();
      expect(preferences?.userId).toBe('user1');
      expect(preferences?.enabled).toBe(true);
      expect(typeof preferences?.channels).toBe('object');
      expect(typeof preferences?.categories).toBe('object');
    });
  });

  describe('Notification Filtering and Querying', () => {
    beforeEach(async () => {
      // Crear notificaciones de prueba con diferentes categorías y tipos
      await notificationSystem.sendCustomNotification({
        type: 'community', category: 'social', priority: 'medium',
        title: 'Community Notification', message: 'Social message', userId: 'user1',
        data: {}, actions: [], channels: ['in_app']
      });
      
      await notificationSystem.sendCustomNotification({
        type: 'achievement', category: 'achievement', priority: 'high',
        title: 'Achievement Unlocked', message: 'You got an achievement!', userId: 'user1',
        data: {}, actions: [], channels: ['in_app']
      });
      
      await notificationSystem.sendCustomNotification({
        type: 'reminder', category: 'educational', priority: 'low',
        title: 'Study Reminder', message: 'Time to study', userId: 'user1',
        data: {}, actions: [], channels: ['in_app']
      });
    });

    it('should filter notifications by unread status', () => {
      const unreadNotifications = notificationSystem.getUserNotifications('user1', { unread: true });
      expect(unreadNotifications).toHaveLength(3);
      expect(unreadNotifications.every(n => !n.read)).toBe(true);
    });

    it('should filter notifications by category', () => {
      const socialNotifications = notificationSystem.getUserNotifications('user1', { 
        category: 'social' 
      });
      
      expect(socialNotifications).toHaveLength(1);
      expect(socialNotifications[0].category).toBe('social');
    });

    it('should filter notifications by type', () => {
      const achievementNotifications = notificationSystem.getUserNotifications('user1', { 
        type: 'achievement' 
      });
      
      expect(achievementNotifications).toHaveLength(1);
      expect(achievementNotifications[0].type).toBe('achievement');
    });

    it('should limit notification results', () => {
      const limitedNotifications = notificationSystem.getUserNotifications('user1', { 
        limit: 2 
      });
      
      expect(limitedNotifications).toHaveLength(2);
    });

    it('should sort notifications by timestamp descending', () => {
      const notifications = notificationSystem.getUserNotifications('user1');
      
      expect(notifications).toHaveLength(3);
      
      // Verificar que están ordenadas por timestamp descendente
      for (let i = 0; i < notifications.length - 1; i++) {
        expect(notifications[i].timestamp.getTime()).toBeGreaterThanOrEqual(
          notifications[i + 1].timestamp.getTime()
        );
      }
    });
  });

  describe('Notification Statistics', () => {
    beforeEach(async () => {
      // Crear notificaciones de diferentes prioridades y categorías
      await notificationSystem.sendCustomNotification({
        type: 'community', category: 'social', priority: 'high',
        title: 'High Priority Social', message: 'Important social update', userId: 'user1',
        data: {}, actions: [], channels: ['in_app']
      });
      
      await notificationSystem.sendCustomNotification({
        type: 'achievement', category: 'achievement', priority: 'medium',
        title: 'Medium Achievement', message: 'You achieved something', userId: 'user1',
        data: {}, actions: [], channels: ['in_app']
      });
      
      await notificationSystem.sendCustomNotification({
        type: 'reminder', category: 'educational', priority: 'low',
        title: 'Low Priority Reminder', message: 'Don\'t forget', userId: 'user1',
        data: {}, actions: [], channels: ['in_app']
      });
    });

    it('should calculate notification statistics correctly', () => {
      const stats = notificationSystem.getNotificationStats('user1');
      
      expect(stats.total).toBe(3);
      expect(stats.unread).toBe(3);
      expect(stats.byCategory.social).toBe(1);
      expect(stats.byCategory.achievement).toBe(1);
      expect(stats.byCategory.educational).toBe(1);
      expect(stats.byPriority.high).toBe(1);
      expect(stats.byPriority.medium).toBe(1);
      expect(stats.byPriority.low).toBe(1);
    });
  });

  describe('Template Management', () => {
    it('should get existing template', () => {
      const template = notificationSystem.getTemplate('community_new_member');
      
      expect(template).toBeDefined();
      expect(template?.name).toBe('Nuevo Miembro en Comunidad');
      expect(template?.type).toBe('community');
      expect(template?.category).toBe('social');
    });

    it('should return undefined for non-existent template', () => {
      const template = notificationSystem.getTemplate('non_existent_template');
      expect(template).toBeUndefined();
    });

    it('should get all templates', () => {
      const templates = notificationSystem.getAllTemplates();
      
      expect(Array.isArray(templates)).toBe(true);
      expect(templates.length).toBeGreaterThan(0);
      
      // Verificar que incluye templates conocidos
      const templateIds = templates.map(t => t.id);
      expect(templateIds).toContain('community_new_member');
      expect(templateIds).toContain('achievement_unlocked');
      expect(templateIds).toContain('study_group_reminder');
    });
  });

  describe('Performance Tests', () => {
    it('should handle large number of notifications efficiently', async () => {
      const startTime = performance.now();
      
      // Crear 1000 notificaciones
      const promises = [];
      for (let i = 0; i < 1000; i++) {
        promises.push(notificationSystem.sendCustomNotification({
          type: 'system',
          category: 'administrative',
          priority: 'low',
          title: `Notification ${i}`,
          message: `Message ${i}`,
          userId: 'user1',
          data: { index: i },
          actions: [],
          channels: ['in_app']
        }));
      }
      
      await Promise.all(promises);
      
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      // Debería completarse en tiempo razonable
      expect(duration).toBeLessThan(2000); // 2 segundos
      
      const notifications = notificationSystem.getUserNotifications('user1');
      expect(notifications).toHaveLength(1000);
    });

    it('should efficiently query large notification sets', async () => {
      // Crear muchas notificaciones primero
      for (let i = 0; i < 500; i++) {
        await notificationSystem.sendCustomNotification({
          type: i % 2 === 0 ? 'community' : 'achievement',
          category: i % 2 === 0 ? 'social' : 'achievement',
          priority: 'medium',
          title: `Notification ${i}`,
          message: `Message ${i}`,
          userId: 'user1',
          data: {},
          actions: [],
          channels: ['in_app']
        });
      }

      const startTime = performance.now();
      
      // Realizar consultas con filtros
      const socialNotifications = notificationSystem.getUserNotifications('user1', { 
        category: 'social',
        limit: 10
      });
      
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      // La consulta debería ser rápida
      expect(duration).toBeLessThan(100); // 100ms
      expect(socialNotifications).toHaveLength(10);
      expect(socialNotifications.every(n => n.category === 'social')).toBe(true);
    });
  });

  describe('Error Handling', () => {
    it('should handle invalid template ID gracefully', async () => {
      await expect(
        notificationSystem.sendNotification('invalid_template', 'user1', {})
      ).rejects.toThrow('Template invalid_template not found');
    });

    it('should handle invalid notification ID in operations', async () => {
      const result1 = await notificationSystem.markAsRead('invalid-id');
      expect(result1).toBe(false);
      
      const result2 = await notificationSystem.markAsClicked('invalid-id');
      expect(result2).toBe(false);
      
      const result3 = await notificationSystem.dismissNotification('invalid-id');
      expect(result3).toBe(false);
    });

    it('should handle invalid user preferences update', async () => {
      const result = await notificationSystem.updateUserPreferences('non-existent-user', {
        enabled: false
      });
      
      expect(result).toBe(false);
    });
  });

  describe('Event System', () => {
    it('should emit events when notifications are created', async () => {
      let eventFired = false;
      let eventData = null;

      const handleNotificationCreated = (event: CustomEvent) => {
        eventFired = true;
        eventData = event.detail;
      };

      notificationSystem.addEventListener('notification-created', handleNotificationCreated);

      await notificationSystem.sendCustomNotification({
        type: 'system',
        category: 'administrative',
        priority: 'medium',
        title: 'Event Test',
        message: 'Testing events',
        userId: 'user1',
        data: {},
        actions: [],
        channels: ['in_app']
      });

      expect(eventFired).toBe(true);
      expect(eventData).toBeDefined();
      expect(eventData.notification).toBeDefined();
      expect(eventData.notification.title).toBe('Event Test');

      notificationSystem.removeEventListener('notification-created', handleNotificationCreated);
    });

    it('should emit events when notifications are read', async () => {
      let readEventFired = false;

      const handleNotificationRead = () => {
        readEventFired = true;
      };

      notificationSystem.addEventListener('notification-read', handleNotificationRead);

      const notificationId = await notificationSystem.sendCustomNotification({
        type: 'system',
        category: 'administrative',
        priority: 'medium',
        title: 'Read Test',
        message: 'Testing read events',
        userId: 'user1',
        data: {},
        actions: [],
        channels: ['in_app']
      });

      await notificationSystem.markAsRead(notificationId);

      expect(readEventFired).toBe(true);

      notificationSystem.removeEventListener('notification-read', handleNotificationRead);
    });
  });
});

describe('Global Notification System', () => {
  it('should be a singleton instance', () => {
    expect(globalNotificationSystem).toBeDefined();
    expect(globalNotificationSystem).toBeInstanceOf(NotificationSystem);
  });

  it('should maintain state across calls', async () => {
    const notificationId = await globalNotificationSystem.sendCustomNotification({
      type: 'system',
      category: 'administrative',
      priority: 'medium',
      title: 'Global Test',
      message: 'Testing global instance',
      userId: 'global-user',
      data: {},
      actions: [],
      channels: ['in_app']
    });

    expect(notificationId).toBeDefined();
    
    const notifications = globalNotificationSystem.getUserNotifications('global-user');
    expect(notifications).toHaveLength(1);
    expect(notifications[0].title).toBe('Global Test');
  });
});
