/**
 * Tests de Integración para Módulos JavaScript Legacy Optimizados
 * Valida la correcta conexión entre módulos JS optimizados y sistemas TypeScript
 */

import { describe, it, expect, beforeAll, afterEach, vi } from 'vitest';
import { LegacyIntegrationBridge, legacyBridge } from '../legacy-integration';

// Mock de window y scripts
const mockWindow = {
  BibliaRV1960Optimized: {
    buscarTexto: vi.fn(),
    obtenerCapitulo: vi.fn(),
    obtenerVersiculo: vi.fn(),
    obtenerEstadisticas: vi.fn(),
    limpiarCache: vi.fn()
  },
  AnalisisAvanzadoOptimizado: {
    analizarTexto: vi.fn(),
    obtenerEstadisticas: vi.fn(),
    generarVisualizacion: vi.fn(),
    obtenerPatrones: vi.fn(),
    limpiarCache: vi.fn()
  },
  SocialAvanzadoOptimizado: {
    obtenerPerfil: vi.fn(),
    actualizarPerfil: vi.fn(),
    obtenerAmigos: vi.fn(),
    obtenerEventos: vi.fn(),
    obtenerNotificaciones: vi.fn(),
    marcarNotificacionLeida: vi.fn(),
    limpiarCache: vi.fn()
  }
};

// Mock DOM para carga de scripts
const mockCreateElement = vi.fn();
const mockAppendChild = vi.fn();

Object.defineProperty(global, 'window', {
  value: mockWindow,
  writable: true
});

Object.defineProperty(global, 'document', {
  value: {
    createElement: mockCreateElement,
    head: {
      appendChild: mockAppendChild
    },
    querySelector: vi.fn(() => null)
  },
  writable: true
});

describe('Legacy Integration Bridge', () => {
  let bridge: LegacyIntegrationBridge;

  beforeAll(async () => {
    // Configurar mocks de script loading
    mockCreateElement.mockImplementation((tagName: string) => {
      if (tagName === 'script') {
        const script = {
          src: '',
          type: '',
          onload: null as any,
          onerror: null as any
        };
        
        // Simular carga exitosa después de un timeout
        setTimeout(() => {
          if (script.onload) script.onload();
        }, 10);
        
        return script;
      }
      return {};
    });

    bridge = new LegacyIntegrationBridge();
    await bridge.waitForInitialization();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('Inicialización del Bridge', () => {
    it('debe inicializarse correctamente', () => {
      expect(bridge.isInitialized()).toBe(true);
    });

    it('debe tener acceso a todos los módulos legacy', () => {
      const status = bridge.getModulesStatus();
      expect(status.bible).toBe(true);
      expect(status.analytics).toBe(true);
      expect(status.social).toBe(true);
      expect(status.initialized).toBe(true);
    });

    it('debe ejecutar health check exitosamente', async () => {
      // Configurar mocks para health check
      mockWindow.BibliaRV1960Optimizado.obtenerEstadisticas.mockReturnValue({
        libros: 66,
        capitulos: 1189,
        versiculos: 31102
      });

      mockWindow.AnalisisAvanzadoOptimizado.obtenerEstadisticas.mockReturnValue({
        media: 3,
        mediana: 3,
        desviacion: 1.58
      });

      mockWindow.SocialAvanzadoOptimizado.obtenerPerfil.mockReturnValue({
        id: 'test-user',
        nombre: 'Usuario Test'
      });

      const healthStatus = await bridge.healthCheck();
      
      expect(healthStatus.bible).toBe(true);
      expect(healthStatus.analytics).toBe(true);
      expect(healthStatus.social).toBe(true);
      expect(healthStatus.overall).toBe(true);
    });
  });

  describe('Integración del Módulo Bíblico', () => {
    it('debe buscar texto en la Biblia', async () => {
      const mockResults = [
        {
          libro: 'Génesis',
          capitulo: 1,
          versiculo: 1,
          texto: 'En el principio creó Dios los cielos y la tierra.'
        }
      ];

      mockWindow.BibliaRV1960Optimizado.buscarTexto.mockResolvedValue(mockResults);

      const results = await bridge.searchBibleText('En el principio');
      
      expect(mockWindow.BibliaRV1960Optimizado.buscarTexto).toHaveBeenCalledWith('En el principio');
      expect(results).toEqual(mockResults);
    });

    it('debe obtener un capítulo específico', async () => {
      const mockChapter = {
        libro: 'Génesis',
        capitulo: 1,
        versiculos: [
          { numero: 1, texto: 'En el principio creó Dios los cielos y la tierra.' },
          { numero: 2, texto: 'Y la tierra estaba desordenada y vacía...' }
        ]
      };

      mockWindow.BibliaRV1960Optimizado.obtenerCapitulo.mockResolvedValue(mockChapter);

      const chapter = await bridge.getBibleChapter('Génesis', 1);
      
      expect(mockWindow.BibliaRV1960Optimizado.obtenerCapitulo).toHaveBeenCalledWith('Génesis', 1);
      expect(chapter).toEqual(mockChapter);
    });

    it('debe obtener un versículo específico', async () => {
      const mockVerse = {
        libro: 'Juan',
        capitulo: 3,
        versiculo: 16,
        texto: 'Porque de tal manera amó Dios al mundo...'
      };

      mockWindow.BibliaRV1960Optimizado.obtenerVersiculo.mockResolvedValue(mockVerse);

      const verse = await bridge.getBibleVerse('Juan', 3, 16);
      
      expect(mockWindow.BibliaRV1960Optimizado.obtenerVersiculo).toHaveBeenCalledWith('Juan', 3, 16);
      expect(verse).toEqual(mockVerse);
    });

    it('debe obtener estadísticas bíblicas', () => {
      const mockStats = {
        libros: 66,
        capitulos: 1189,
        versiculos: 31102,
        palabras: 783137
      };

      mockWindow.BibliaRV1960Optimizado.obtenerEstadisticas.mockReturnValue(mockStats);

      const stats = bridge.getBibleStats();
      
      expect(mockWindow.BibliaRV1960Optimizado.obtenerEstadisticas).toHaveBeenCalled();
      expect(stats).toEqual(mockStats);
    });

    it('debe manejar errores en búsqueda bíblica', async () => {
      mockWindow.BibliaRV1960Optimizado.buscarTexto.mockRejectedValue(new Error('API Error'));

      await expect(bridge.searchBibleText('test')).rejects.toThrow('API Error');
    });
  });

  describe('Integración del Módulo Analítico', () => {
    it('debe analizar texto correctamente', async () => {
      const mockAnalysis = {
        sentimiento: 'positivo',
        palabrasClave: ['amor', 'esperanza', 'fe'],
        complejidad: 'media',
        temas: ['religioso', 'esperanza']
      };

      mockWindow.AnalisisAvanzadoOptimizado.analizarTexto.mockResolvedValue(mockAnalysis);

      const analysis = await bridge.analyzeText('Texto de prueba para análisis');
      
      expect(mockWindow.AnalisisAvanzadoOptimizado.analizarTexto).toHaveBeenCalledWith('Texto de prueba para análisis');
      expect(analysis).toEqual(mockAnalysis);
    });

    it('debe obtener estadísticas de datos', () => {
      const testData = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
      const mockStats = {
        media: 5.5,
        mediana: 5.5,
        moda: null,
        desviacion: 3.03,
        varianza: 9.17,
        minimo: 1,
        maximo: 10,
        rango: 9
      };

      mockWindow.AnalisisAvanzadoOptimizado.obtenerEstadisticas.mockReturnValue(mockStats);

      const stats = bridge.getAnalyticsStats(testData);
      
      expect(mockWindow.AnalisisAvanzadoOptimizado.obtenerEstadisticas).toHaveBeenCalledWith(testData);
      expect(stats).toEqual(mockStats);
    });

    it('debe generar visualización', async () => {
      const testData = [
        { categoria: 'A', valor: 10 },
        { categoria: 'B', valor: 20 },
        { categoria: 'C', valor: 15 }
      ];

      const mockVisualization = {
        tipo: 'barras',
        datos: testData,
        configuracion: {
          width: 400,
          height: 300,
          margin: { top: 20, right: 30, bottom: 40, left: 40 }
        }
      };

      mockWindow.AnalisisAvanzadoOptimizado.generarVisualizacion.mockResolvedValue(mockVisualization);

      const viz = await bridge.generateVisualization('barras', testData);
      
      expect(mockWindow.AnalisisAvanzadoOptimizado.generarVisualizacion).toHaveBeenCalledWith('barras', testData);
      expect(viz).toEqual(mockVisualization);
    });

    it('debe obtener patrones de datos', () => {
      const testData = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5];
      const mockPatterns = {
        frecuencias: { '1': 2, '2': 2, '3': 2, '4': 2, '5': 2 },
        tendencias: 'creciente',
        correlaciones: [],
        outliers: []
      };

      mockWindow.AnalisisAvanzadoOptimizado.obtenerPatrones.mockReturnValue(mockPatterns);

      const patterns = bridge.getDataPatterns(testData);
      
      expect(mockWindow.AnalisisAvanzadoOptimizado.obtenerPatrones).toHaveBeenCalledWith(testData);
      expect(patterns).toEqual(mockPatterns);
    });

    it('debe manejar errores en análisis de texto', async () => {
      mockWindow.AnalisisAvanzadoOptimizado.analizarTexto.mockRejectedValue(new Error('Analysis Error'));

      await expect(bridge.analyzeText('test')).rejects.toThrow('Analysis Error');
    });
  });

  describe('Integración del Módulo Social', () => {
    it('debe obtener perfil de usuario', () => {
      const mockProfile = {
        id: 'user123',
        nombre: 'Juan Pérez',
        email: 'juan@example.com',
        nivelEstudio: 'intermedio',
        librosLeidos: 5,
        tiempoEstudio: 120
      };

      mockWindow.SocialAvanzadoOptimizado.obtenerPerfil.mockReturnValue(mockProfile);

      const profile = bridge.getUserProfile();
      
      expect(mockWindow.SocialAvanzadoOptimizado.obtenerPerfil).toHaveBeenCalled();
      expect(profile).toEqual(mockProfile);
    });

    it('debe actualizar perfil de usuario', async () => {
      const updateData = {
        nombre: 'Juan Carlos Pérez',
        nivelEstudio: 'avanzado'
      };

      mockWindow.SocialAvanzadoOptimizado.actualizarPerfil.mockResolvedValue(true);

      const result = await bridge.updateUserProfile(updateData);
      
      expect(mockWindow.SocialAvanzadoOptimizado.actualizarPerfil).toHaveBeenCalledWith(updateData);
      expect(result).toBe(true);
    });

    it('debe obtener lista de amigos', () => {
      const mockFriends = [
        { id: 'friend1', nombre: 'María García', estado: 'activo' },
        { id: 'friend2', nombre: 'Pedro López', estado: 'ocupado' }
      ];

      mockWindow.SocialAvanzadoOptimizado.obtenerAmigos.mockReturnValue(mockFriends);

      const friends = bridge.getFriends();
      
      expect(mockWindow.SocialAvanzadoOptimizado.obtenerAmigos).toHaveBeenCalled();
      expect(friends).toEqual(mockFriends);
    });

    it('debe obtener eventos sociales', () => {
      const mockEvents = [
        {
          id: 'event1',
          titulo: 'Estudio de Génesis',
          fecha: '2024-01-15',
          participantes: 12
        },
        {
          id: 'event2',
          titulo: 'Grupo de Oración',
          fecha: '2024-01-16',
          participantes: 8
        }
      ];

      mockWindow.SocialAvanzadoOptimizado.obtenerEventos.mockReturnValue(mockEvents);

      const events = bridge.getSocialEvents();
      
      expect(mockWindow.SocialAvanzadoOptimizado.obtenerEventos).toHaveBeenCalled();
      expect(events).toEqual(mockEvents);
    });

    it('debe obtener notificaciones', () => {
      const mockNotifications = [
        {
          id: 'notif1',
          tipo: 'mensaje',
          contenido: 'Tienes un nuevo mensaje',
          fecha: '2024-01-15T10:30:00Z',
          leida: false
        },
        {
          id: 'notif2',
          tipo: 'evento',
          contenido: 'Recordatorio: Estudio mañana',
          fecha: '2024-01-15T09:00:00Z',
          leida: true
        }
      ];

      mockWindow.SocialAvanzadoOptimizado.obtenerNotificaciones.mockReturnValue(mockNotifications);

      const notifications = bridge.getNotifications();
      
      expect(mockWindow.SocialAvanzadoOptimizado.obtenerNotificaciones).toHaveBeenCalled();
      expect(notifications).toEqual(mockNotifications);
    });

    it('debe marcar notificación como leída', async () => {
      mockWindow.SocialAvanzadoOptimizado.marcarNotificacionLeida.mockResolvedValue(true);

      const result = await bridge.markNotificationAsRead('notif1');
      
      expect(mockWindow.SocialAvanzadoOptimizado.marcarNotificacionLeida).toHaveBeenCalledWith('notif1');
      expect(result).toBe(true);
    });

    it('debe manejar errores en actualización de perfil', async () => {
      mockWindow.SocialAvanzadoOptimizado.actualizarPerfil.mockRejectedValue(new Error('Update Error'));

      await expect(bridge.updateUserProfile({})).rejects.toThrow('Update Error');
    });
  });

  describe('Funcionalidades de Utilidad', () => {
    it('debe limpiar todos los caches', () => {
      bridge.clearAllCaches();
      
      expect(mockWindow.BibliaRV1960Optimizado.limpiarCache).toHaveBeenCalled();
      expect(mockWindow.AnalisisAvanzadoOptimizado.limpiarCache).toHaveBeenCalled();
      expect(mockWindow.SocialAvanzadoOptimizado.limpiarCache).toHaveBeenCalled();
    });

    it('debe reportar estado correcto de módulos', () => {
      const status = bridge.getModulesStatus();
      
      expect(status).toEqual({
        bible: true,
        analytics: true,
        social: true,
        initialized: true
      });
    });
  });

  describe('Manejo de Errores y Estados Edge', () => {
    it('debe manejar módulo bíblico no disponible', async () => {
      const bridgeWithoutBible = new LegacyIntegrationBridge();
      // Simular que el módulo no se cargó
      (bridgeWithoutBible as any).bibleModule = null;

      await expect(bridgeWithoutBible.searchBibleText('test')).rejects.toThrow('Bible module not available');
    });

    it('debe manejar módulo analítico no disponible', async () => {
      const bridgeWithoutAnalytics = new LegacyIntegrationBridge();
      (bridgeWithoutAnalytics as any).analyticsModule = null;

      await expect(bridgeWithoutAnalytics.analyzeText('test')).rejects.toThrow('Analytics module not available');
    });

    it('debe manejar módulo social no disponible', async () => {
      const bridgeWithoutSocial = new LegacyIntegrationBridge();
      (bridgeWithoutSocial as any).socialModule = null;

      expect(() => bridgeWithoutSocial.getUserProfile()).toThrow('Social module not available');
    });

    it('debe manejar health check con módulos fallidos', async () => {
      // Simular error en módulo bíblico
      mockWindow.BibliaRV1960Optimizada = null;
      
      const bridgeWithFailures = new LegacyIntegrationBridge();
      await bridgeWithFailures.waitForInitialization();
      
      const healthStatus = await bridgeWithFailures.healthCheck();
      
      expect(healthStatus.overall).toBe(false);
    });
  });

  describe('Performance y Optimización', () => {
    it('debe manejar carga concurrente de módulos', async () => {
      // Crear múltiples bridges simultáneamente
      const bridges = await Promise.all([
        new LegacyIntegrationBridge().waitForInitialization(),
        new LegacyIntegrationBridge().waitForInitialization(),
        new LegacyIntegrationBridge().waitForInitialization()
      ]);

      // Todos deben inicializarse correctamente
      bridges.forEach(async () => {
        const bridge = new LegacyIntegrationBridge();
        await bridge.waitForInitialization();
        expect(bridge.isInitialized()).toBe(true);
      });
    });

    it('debe tener tiempos de respuesta aceptables', async () => {
      const startTime = performance.now();
      
      await bridge.searchBibleText('test');
      await bridge.analyzeText('test');
      const profile = bridge.getUserProfile();
      
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      // Debe completarse en menos de 100ms (excluyendo network)
      expect(duration).toBeLessThan(100);
      expect(profile).toBeDefined();
    });

    it('debe manejar operaciones de alto volumen', async () => {
      // Preparar datos de prueba
      const searchTerms = Array.from({ length: 10 }, (_, i) => `term${i}`);
      const texts = Array.from({ length: 10 }, (_, i) => `Texto ${i} para análisis`);
      
      // Configurar mocks para respuestas rápidas
      mockWindow.BibliaRV1960Optimizado.buscarTexto.mockImplementation(async (term) => [
        { texto: `Resultado para ${term}` }
      ]);
      
      mockWindow.AnalisisAvanzadoOptimizado.analizarTexto.mockImplementation(async (text) => ({
        resultado: `Análisis de ${text}`
      }));

      const startTime = performance.now();
      
      // Ejecutar operaciones concurrentes
      const searchPromises = searchTerms.map(term => bridge.searchBibleText(term));
      const analysisPromises = texts.map(text => bridge.analyzeText(text));
      
      await Promise.all([...searchPromises, ...analysisPromises]);
      
      const endTime = performance.now();
      const duration = endTime - startTime;
      
      // 20 operaciones deben completarse en tiempo razonable
      expect(duration).toBeLessThan(500);
    });
  });

  describe('Integración con Global legacyBridge', () => {
    it('debe tener una instancia global disponible', () => {
      expect(legacyBridge).toBeDefined();
      expect(legacyBridge instanceof LegacyIntegrationBridge).toBe(true);
    });

    it('debe mantener estado consistente entre instancias', async () => {
      await legacyBridge.waitForInitialization();
      
      const status1 = legacyBridge.getModulesStatus();
      const status2 = bridge.getModulesStatus();
      
      expect(status1.initialized).toBe(status2.initialized);
    });
  });
});

describe('Integración End-to-End con Módulos Legacy', () => {
  it('debe ejecutar flujo completo de búsqueda y análisis', async () => {
    // Configurar mocks para flujo completo
    const searchResults = [
      {
        libro: 'Salmos',
        capitulo: 23,
        versiculo: 1,
        texto: 'Jehová es mi pastor; nada me faltará.'
      }
    ];

    const analysis = {
      sentimiento: 'positivo',
      temas: ['confianza', 'providencia'],
      palabrasClave: ['Jehová', 'pastor', 'faltará']
    };

    mockWindow.BibliaRV1960Optimizado.buscarTexto.mockResolvedValue(searchResults);
    mockWindow.AnalisisAvanzadoOptimizado.analizarTexto.mockResolvedValue(analysis);

    // Ejecutar flujo completo
    const results = await legacyBridge.searchBibleText('Jehová es mi pastor');
    expect(results).toEqual(searchResults);

    const textAnalysis = await legacyBridge.analyzeText(results[0].texto);
    expect(textAnalysis).toEqual(analysis);

    // Verificar que ambos módulos fueron llamados
    expect(mockWindow.BibliaRV1960Optimizado.buscarTexto).toHaveBeenCalledWith('Jehová es mi pastor');
    expect(mockWindow.AnalisisAvanzadoOptimizado.analizarTexto).toHaveBeenCalledWith('Jehová es mi pastor; nada me faltará.');
  });

  it('debe manejar flujo social completo', async () => {
    // Simular datos sociales
    const profile = { id: 'user1', nombre: 'Usuario Test' };
    const friends = [{ id: 'friend1', nombre: 'Amigo Test' }];
    const notifications = [{ id: 'notif1', contenido: 'Nueva notificación' }];

    mockWindow.SocialAvanzadoOptimizado.obtenerPerfil.mockReturnValue(profile);
    mockWindow.SocialAvanzadoOptimizado.obtenerAmigos.mockReturnValue(friends);
    mockWindow.SocialAvanzadoOptimizado.obtenerNotificaciones.mockReturnValue(notifications);
    mockWindow.SocialAvanzadoOptimizado.marcarNotificacionLeida.mockResolvedValue(true);

    // Ejecutar flujo social
    const userProfile = legacyBridge.getUserProfile();
    const userFriends = legacyBridge.getFriends();
    const userNotifications = legacyBridge.getNotifications();
    const markResult = await legacyBridge.markNotificationAsRead('notif1');

    expect(userProfile).toEqual(profile);
    expect(userFriends).toEqual(friends);
    expect(userNotifications).toEqual(notifications);
    expect(markResult).toBe(true);
  });
});
