/**
 * Sistema de Filtros Inteligentes Avanzados
 * Filtros mejorados con ML, NLP y análisis semántico
 */

import { globalMLEngine, TextAnalysisResult } from './ml-engine';

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface FilterDefinition {
  id: string;
  name: string;
  description: string;
  type: 'semantic' | 'keyword' | 'context' | 'sentiment' | 'topic' | 'hybrid';
  keywords: string[];
  semanticConcepts?: string[];
  contextualRules?: ContextualRule[];
  sentimentRange?: [number, number];
  topicThreshold?: number;
  weight: number;
  category: string;
  examples: string[];
}

export interface ContextualRule {
  condition: 'before' | 'after' | 'same_verse' | 'same_chapter' | 'same_book';
  keywords: string[];
  weight: number;
}

export interface FilterResult {
  verse: any;
  matchScore: number;
  matchReasons: string[];
  relevanceScore: number;
  confidence: number;
  analysis?: TextAnalysisResult;
}

export interface CombinedFilterQuery {
  filters: string[];
  operator: 'AND' | 'OR' | 'NOT';
  weights?: { [filterId: string]: number };
  minScore?: number;
  contextWindow?: number;
}

export interface FilterAnalytics {
  filterId: string;
  totalMatches: number;
  averageScore: number;
  distributionByBook: { [book: string]: number };
  topMatches: FilterResult[];
  performanceMetrics: {
    precision: number;
    recall: number;
    f1Score: number;
    executionTime: number;
  };
}

// =====================================================================
// CONFIGURACIÓN DE FILTROS PREDEFINIDOS
// =====================================================================

const PREDEFINED_FILTERS: { [key: string]: FilterDefinition } = {
  // Filtros principales mejorados
  blood: {
    id: 'blood',
    name: 'Sangre',
    description: 'Pasajes relacionados con sangre, pacto, sacrificio, redención y expiación',
    type: 'hybrid',
    keywords: [
      'sangre', 'derramada', 'derramar', 'sanguinario',
      'pacto', 'nuevo pacto', 'alianza',
      'sacrificio', 'sacrificar', 'ofrenda', 'holocausto',
      'redención', 'redimir', 'rescate', 'liberación',
      'expiación', 'expiar', 'propiciación',
      'cordero', 'inmolado', 'degollar'
    ],
    semanticConcepts: [
      'sacrificial_system', 'covenant_relationship', 'atonement_theology',
      'redemptive_work', 'substitutionary_sacrifice'
    ],
    contextualRules: [
      {
        condition: 'same_verse',
        keywords: ['cristo', 'jesús', 'salvador', 'cordero'],
        weight: 1.5
      },
      {
        condition: 'same_chapter',
        keywords: ['altar', 'templo', 'sacerdote', 'perdón'],
        weight: 1.2
      }
    ],
    sentimentRange: [-0.5, 1.0], // Puede ser negativo (muerte) o positivo (salvación)
    topicThreshold: 0.3,
    weight: 1.0,
    category: 'theological',
    examples: [
      'la sangre de Jesucristo su Hijo nos limpia de todo pecado',
      'sin derramamiento de sangre no se hace remisión',
      'el cual dio su vida en rescate por muchos'
    ]
  },

  water: {
    id: 'water',
    name: 'Agua',
    description: 'Pasajes sobre agua, bautismo, purificación, vida y bendición espiritual',
    type: 'hybrid',
    keywords: [
      'agua', 'aguas', 'mar', 'río', 'fuente', 'pozo', 'manantial',
      'bautismo', 'bautizar', 'sumergir',
      'purificación', 'purificar', 'lavar', 'limpiar', 'limpio',
      'vida', 'vivo', 'viviente', 'eternal',
      'bendición', 'bendecir', 'bendito',
      'lluvia', 'rocío', 'corrientes'
    ],
    semanticConcepts: [
      'spiritual_cleansing', 'baptismal_symbolism', 'life_giving_water',
      'spiritual_renewal', 'divine_blessing'
    ],
    contextualRules: [
      {
        condition: 'same_verse',
        keywords: ['espíritu', 'santo', 'vida', 'eterna'],
        weight: 1.4
      },
      {
        condition: 'same_chapter',
        keywords: ['bautismo', 'cristo', 'regeneración'],
        weight: 1.3
      }
    ],
    sentimentRange: [0.2, 1.0], // Generalmente positivo
    topicThreshold: 0.3,
    weight: 1.0,
    category: 'theological',
    examples: [
      'el que bebiere del agua que yo le daré, no tendrá sed jamás',
      'el que cree en mí, como dice la Escritura, de su interior correrán ríos de agua viva',
      'sepultados con él en el bautismo'
    ]
  },

  love: {
    id: 'love',
    name: 'Amor',
    description: 'Pasajes sobre amor divino, amor fraternal y mandamientos de amor',
    type: 'hybrid',
    keywords: [
      'amor', 'amar', 'amado', 'amados', 'amante',
      'caridad', 'cariño', 'afecto', 'ternura',
      'compasión', 'misericordia', 'clemencia',
      'bondad', 'benignidad', 'gracia',
      'corazón', 'alma', 'entrañas'
    ],
    semanticConcepts: [
      'divine_love', 'brotherly_love', 'sacrificial_love',
      'unconditional_love', 'love_commandments'
    ],
    contextualRules: [
      {
        condition: 'same_verse',
        keywords: ['dios', 'cristo', 'hermanos', 'prójimo'],
        weight: 1.3
      },
      {
        condition: 'same_chapter',
        keywords: ['mandamiento', 'ley', 'cumplir'],
        weight: 1.1
      }
    ],
    sentimentRange: [0.5, 1.0], // Siempre positivo
    topicThreshold: 0.4,
    weight: 1.0,
    category: 'theological',
    examples: [
      'porque de tal manera amó Dios al mundo',
      'el amor es paciente, es bondadoso',
      'amémonos unos a otros, porque el amor es de Dios'
    ]
  },

  faith: {
    id: 'faith',
    name: 'Fe',
    description: 'Pasajes sobre fe, creencia, confianza y fidelidad',
    type: 'hybrid',
    keywords: [
      'fe', 'creer', 'cree', 'creencia', 'creyente',
      'confianza', 'confiar', 'esperanza', 'esperar',
      'fiel', 'fidelidad', 'lealtad',
      'certeza', 'convicción', 'seguridad'
    ],
    semanticConcepts: [
      'saving_faith', 'faith_works', 'faithful_god',
      'trust_relationship', 'belief_system'
    ],
    contextualRules: [
      {
        condition: 'same_verse',
        keywords: ['obras', 'justificación', 'salvación'],
        weight: 1.4
      },
      {
        condition: 'same_chapter',
        keywords: ['promesa', 'palabra', 'testimonio'],
        weight: 1.2
      }
    ],
    sentimentRange: [0.3, 1.0],
    topicThreshold: 0.35,
    weight: 1.0,
    category: 'theological',
    examples: [
      'por gracia sois salvos por medio de la fe',
      'la fe es la certeza de lo que se espera',
      'sin fe es imposible agradar a Dios'
    ]
  },

  hope: {
    id: 'hope',
    name: 'Esperanza',
    description: 'Pasajes sobre esperanza, expectativa y promesas futuras',
    type: 'hybrid',
    keywords: [
      'esperanza', 'esperar', 'esperado', 'esperamos',
      'promesa', 'promesas', 'prometer', 'prometido',
      'futuro', 'venidero', 'eterno', 'gloria',
      'recompensa', 'galardón', 'premio',
      'consolación', 'consolar', 'consuelo'
    ],
    semanticConcepts: [
      'future_hope', 'eternal_promises', 'eschatological_hope',
      'divine_consolation', 'messianic_expectation'
    ],
    contextualRules: [
      {
        condition: 'same_verse',
        keywords: ['cristo', 'resurrección', 'reino', 'vida eterna'],
        weight: 1.5
      },
      {
        condition: 'same_chapter',
        keywords: ['aguardar', 'manifestación', 'aparición'],
        weight: 1.3
      }
    ],
    sentimentRange: [0.4, 1.0],
    topicThreshold: 0.3,
    weight: 1.0,
    category: 'theological',
    examples: [
      'Cristo en vosotros, la esperanza de gloria',
      'tenemos como segura y firme ancla del alma una esperanza',
      'aguardando la esperanza bienaventurada'
    ]
  },

  forgiveness: {
    id: 'forgiveness',
    name: 'Perdón',
    description: 'Pasajes sobre perdón divino, reconciliación y remisión de pecados',
    type: 'hybrid',
    keywords: [
      'perdón', 'perdonar', 'perdonado', 'perdonar',
      'remisión', 'remitir', 'olvidar',
      'reconciliación', 'reconciliar', 'paz',
      'limpieza', 'limpiar', 'limpio',
      'justificación', 'justificar', 'justo'
    ],
    semanticConcepts: [
      'divine_forgiveness', 'human_forgiveness', 'reconciliation_theology',
      'sin_remission', 'relational_restoration'
    ],
    contextualRules: [
      {
        condition: 'same_verse',
        keywords: ['pecado', 'iniquidad', 'transgresión'],
        weight: 1.4
      },
      {
        condition: 'same_chapter',
        keywords: ['arrepentimiento', 'confesión'],
        weight: 1.2
      }
    ],
    sentimentRange: [0.3, 1.0],
    topicThreshold: 0.35,
    weight: 1.0,
    category: 'theological',
    examples: [
      'si confesamos nuestros pecados, él es fiel y justo para perdonar',
      'perdonaos unos a otros, como Dios también os perdonó',
      'en quien tenemos redención por su sangre, el perdón de pecados'
    ]
  },

  wisdom: {
    id: 'wisdom',
    name: 'Sabiduría',
    description: 'Pasajes sobre sabiduría divina, prudencia y discernimiento',
    type: 'hybrid',
    keywords: [
      'sabiduría', 'sabio', 'sabios', 'sabiamente',
      'entendimiento', 'entender', 'inteligencia',
      'prudencia', 'prudente', 'discernimiento',
      'conocimiento', 'conocer', 'ciencia',
      'consejo', 'instrucción', 'enseñanza'
    ],
    semanticConcepts: [
      'divine_wisdom', 'practical_wisdom', 'spiritual_discernment',
      'moral_understanding', 'wise_living'
    ],
    contextualRules: [
      {
        condition: 'same_verse',
        keywords: ['temor', 'señor', 'principio'],
        weight: 1.4
      },
      {
        condition: 'same_chapter',
        keywords: ['necio', 'insensato', 'contraste'],
        weight: 1.1
      }
    ],
    sentimentRange: [0.4, 1.0],
    topicThreshold: 0.4,
    weight: 1.0,
    category: 'practical',
    examples: [
      'el temor de Jehová es el principio de la sabiduría',
      'si alguno de vosotros tiene falta de sabiduría, pídala a Dios',
      'mas por él estáis vosotros en Cristo Jesús, el cual nos ha sido hecho sabiduría'
    ]
  }
};

// =====================================================================
// MOTOR DE FILTROS INTELIGENTES
// =====================================================================

export class IntelligentFilters {
  private filters: Map<string, FilterDefinition> = new Map();
  private cache: Map<string, FilterResult[]> = new Map();
  private analytics: Map<string, FilterAnalytics> = new Map();

  constructor() {
    this.initializePredefinedFilters();
  }

  // =====================================================================
  // INICIALIZACIÓN
  // =====================================================================

  private initializePredefinedFilters(): void {
    for (const [id, filter] of Object.entries(PREDEFINED_FILTERS)) {
      this.filters.set(id, filter);
    }
    console.log(`Initialized ${this.filters.size} intelligent filters`);
  }

  // =====================================================================
  // GESTIÓN DE FILTROS
  // =====================================================================

  addFilter(filter: FilterDefinition): void {
    this.filters.set(filter.id, filter);
    this.clearCache(filter.id);
  }

  removeFilter(filterId: string): void {
    this.filters.delete(filterId);
    this.clearCache(filterId);
    this.analytics.delete(filterId);
  }

  getFilter(filterId: string): FilterDefinition | undefined {
    return this.filters.get(filterId);
  }

  getAllFilters(): FilterDefinition[] {
    return Array.from(this.filters.values());
  }

  getFiltersByCategory(category: string): FilterDefinition[] {
    return Array.from(this.filters.values()).filter(f => f.category === category);
  }

  // =====================================================================
  // APLICACIÓN DE FILTROS
  // =====================================================================

  async applyFilter(filterId: string, verses: any[]): Promise<FilterResult[]> {
    const startTime = performance.now();
    
    // Verificar cache
    const cacheKey = `${filterId}_${this.hashVerses(verses)}`;
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey)!;
    }

    const filter = this.filters.get(filterId);
    if (!filter) {
      throw new Error(`Filter not found: ${filterId}`);
    }

    const results: FilterResult[] = [];

    for (const verse of verses) {
      const verseText = verse.texto || verse.text || '';
      const result = await this.evaluateVerse(verse, verseText, filter);
      
      if (result.matchScore > 0) {
        results.push(result);
      }
    }

    // Ordenar por relevancia
    results.sort((a, b) => b.relevanceScore - a.relevanceScore);

    // Actualizar cache
    this.cache.set(cacheKey, results);

    // Actualizar analytics
    const executionTime = performance.now() - startTime;
    this.updateAnalytics(filterId, results, executionTime);

    return results;
  }

  async applyCombinedFilters(query: CombinedFilterQuery, verses: any[]): Promise<FilterResult[]> {
    const filterResults = new Map<string, FilterResult[]>();

    // Aplicar cada filtro
    for (const filterId of query.filters) {
      const results = await this.applyFilter(filterId, verses);
      filterResults.set(filterId, results);
    }

    // Combinar resultados según el operador
    return this.combineFilterResults(filterResults, query);
  }

  // =====================================================================
  // EVALUACIÓN DE VERSÍCULOS
  // =====================================================================

  private async evaluateVerse(
    verse: any, 
    text: string, 
    filter: FilterDefinition
  ): Promise<FilterResult> {
    const analysis = await globalMLEngine.analyzeText(text);
    let totalScore = 0;
    const matchReasons: string[] = [];

    // Evaluación por tipo de filtro
    switch (filter.type) {
      case 'keyword':
        totalScore += this.evaluateKeywords(text, filter, matchReasons);
        break;
      
      case 'semantic':
        totalScore += await this.evaluateSemantic(analysis, filter, matchReasons);
        break;
      
      case 'sentiment':
        totalScore += this.evaluateSentiment(analysis, filter, matchReasons);
        break;
      
      case 'topic':
        totalScore += this.evaluateTopics(analysis, filter, matchReasons);
        break;
      
      case 'context':
        totalScore += await this.evaluateContext(verse, filter, matchReasons);
        break;
      
      case 'hybrid':
        totalScore += this.evaluateKeywords(text, filter, matchReasons) * 0.3;
        totalScore += await this.evaluateSemantic(analysis, filter, matchReasons) * 0.3;
        totalScore += this.evaluateTopics(analysis, filter, matchReasons) * 0.2;
        totalScore += this.evaluateSentiment(analysis, filter, matchReasons) * 0.1;
        totalScore += await this.evaluateContext(verse, filter, matchReasons) * 0.1;
        break;
    }

    // Aplicar reglas contextuales
    if (filter.contextualRules) {
      totalScore += await this.evaluateContextualRules(verse, filter, matchReasons);
    }

    // Calcular scores finales
    const matchScore = Math.min(totalScore * filter.weight, 1.0);
    const relevanceScore = this.calculateRelevanceScore(matchScore, analysis, filter);
    const confidence = this.calculateConfidence(matchReasons, analysis);

    return {
      verse,
      matchScore,
      matchReasons,
      relevanceScore,
      confidence,
      analysis
    };
  }

  // =====================================================================
  // MÉTODOS DE EVALUACIÓN ESPECÍFICOS
  // =====================================================================

  private evaluateKeywords(text: string, filter: FilterDefinition, matchReasons: string[]): number {
    const normalizedText = text.toLowerCase();
    let score = 0;
    let matchedKeywords = 0;

    for (const keyword of filter.keywords) {
      if (normalizedText.includes(keyword.toLowerCase())) {
        score += 1 / filter.keywords.length;
        matchedKeywords++;
        matchReasons.push(`Palabra clave: "${keyword}"`);
      }
    }

    // Bonus por múltiples keywords
    if (matchedKeywords > 1) {
      score *= 1 + (matchedKeywords - 1) * 0.1;
    }

    return Math.min(score, 1.0);
  }

  private async evaluateSemantic(
    analysis: TextAnalysisResult, 
    filter: FilterDefinition, 
    matchReasons: string[]
  ): Promise<number> {
    if (!filter.semanticConcepts) return 0;

    let score = 0;
    
    // Comparar con conceptos semánticos usando embeddings
    for (const concept of filter.semanticConcepts) {
      const conceptEmbedding = await globalMLEngine.analyzeText(concept);
      const similarity = this.calculateEmbeddingSimilarity(
        analysis.embeddings, 
        conceptEmbedding.embeddings
      );
      
      if (similarity > 0.7) {
        score += similarity / filter.semanticConcepts.length;
        matchReasons.push(`Concepto semántico: "${concept}" (${(similarity * 100).toFixed(1)}%)`);
      }
    }

    return Math.min(score, 1.0);
  }

  private evaluateSentiment(
    analysis: TextAnalysisResult, 
    filter: FilterDefinition, 
    matchReasons: string[]
  ): number {
    if (!filter.sentimentRange) return 0;

    const [minSentiment, maxSentiment] = filter.sentimentRange;
    const sentiment = analysis.sentiment.score;

    if (sentiment >= minSentiment && sentiment <= maxSentiment) {
      const score = 1.0 - Math.abs(sentiment - ((minSentiment + maxSentiment) / 2)) / 
                    ((maxSentiment - minSentiment) / 2);
      
      matchReasons.push(
        `Sentimiento compatible: ${analysis.sentiment.label} (${(sentiment * 100).toFixed(1)}%)`
      );
      
      return score;
    }

    return 0;
  }

  private evaluateTopics(
    analysis: TextAnalysisResult, 
    filter: FilterDefinition, 
    matchReasons: string[]
  ): number {
    if (!filter.topicThreshold) return 0;

    let maxScore = 0;
    
    for (const topic of analysis.topics) {
      if (topic.probability >= filter.topicThreshold) {
        // Verificar si el tópico está relacionado con el filtro
        const topicRelevance = this.calculateTopicRelevance(topic.topic, filter);
        if (topicRelevance > 0) {
          const score = topic.probability * topicRelevance;
          maxScore = Math.max(maxScore, score);
          matchReasons.push(
            `Tópico relevante: "${topic.topic}" (${(topic.probability * 100).toFixed(1)}%)`
          );
        }
      }
    }

    return maxScore;
  }

  private async evaluateContext(
    verse: any, 
    filter: FilterDefinition, 
    matchReasons: string[]
  ): Promise<number> {
    // Evaluación contextual simplificada
    // En implementación real, analizaríamos versículos circundantes
    let score = 0;

    // Verificar contexto del libro
    const bookContext = this.getBookContext(verse.libro || verse.book);
    if (this.isContextRelevant(bookContext, filter)) {
      score += 0.3;
      matchReasons.push(`Contexto del libro: ${bookContext}`);
    }

    // Verificar contexto del capítulo (simplificado)
    if (verse.capitulo && this.isChapterRelevant(verse.capitulo, filter)) {
      score += 0.2;
      matchReasons.push('Contexto del capítulo relevante');
    }

    return score;
  }

  private async evaluateContextualRules(
    verse: any, 
    filter: FilterDefinition, 
    matchReasons: string[]
  ): Promise<number> {
    if (!filter.contextualRules) return 0;

    let totalScore = 0;

    for (const rule of filter.contextualRules) {
      const ruleScore = await this.evaluateContextualRule(verse, rule);
      if (ruleScore > 0) {
        totalScore += ruleScore * rule.weight;
        matchReasons.push(`Regla contextual: ${rule.condition} con "${rule.keywords.join(', ')}"`);
      }
    }

    return Math.min(totalScore, 0.5); // Máximo 50% del score desde reglas contextuales
  }

  // =====================================================================
  // COMBINACIÓN DE RESULTADOS
  // =====================================================================

  private combineFilterResults(
    filterResults: Map<string, FilterResult[]>,
    query: CombinedFilterQuery
  ): FilterResult[] {
    const verseMap = new Map<string, FilterResult>();

    switch (query.operator) {
      case 'AND':
        return this.combineWithAND(filterResults, query);
      case 'OR':
        return this.combineWithOR(filterResults, query);
      case 'NOT':
        return this.combineWithNOT(filterResults, query);
      default:
        return [];
    }
  }

  private combineWithAND(
    filterResults: Map<string, FilterResult[]>,
    query: CombinedFilterQuery
  ): FilterResult[] {
    const results: FilterResult[] = [];
    const verseIntersection = new Map<string, FilterResult[]>();

    // Encontrar intersección de versículos
    let isFirst = true;
    for (const [filterId, filterResults_] of filterResults.entries()) {
      for (const result of filterResults_) {
        const verseId = this.getVerseId(result.verse);
        
        if (isFirst) {
          verseIntersection.set(verseId, [result]);
        } else if (verseIntersection.has(verseId)) {
          verseIntersection.get(verseId)!.push(result);
        }
      }
      isFirst = false;
    }

    // Combinar scores para versículos que aparecen en todos los filtros
    for (const [verseId, verseResults] of verseIntersection.entries()) {
      if (verseResults.length === query.filters.length) {
        const combinedResult = this.combineVerseResults(verseResults, query.weights);
        if (!query.minScore || combinedResult.relevanceScore >= query.minScore) {
          results.push(combinedResult);
        }
      }
    }

    return results.sort((a, b) => b.relevanceScore - a.relevanceScore);
  }

  private combineWithOR(
    filterResults: Map<string, FilterResult[]>,
    query: CombinedFilterQuery
  ): FilterResult[] {
    const verseMap = new Map<string, FilterResult>();

    // Combinar todos los resultados, tomando el mejor score por versículo
    for (const [filterId, filterResults_] of filterResults.entries()) {
      for (const result of filterResults_) {
        const verseId = this.getVerseId(result.verse);
        const existing = verseMap.get(verseId);
        
        if (!existing || result.relevanceScore > existing.relevanceScore) {
          verseMap.set(verseId, result);
        }
      }
    }

    const results = Array.from(verseMap.values());
    return results
      .filter(r => !query.minScore || r.relevanceScore >= query.minScore)
      .sort((a, b) => b.relevanceScore - a.relevanceScore);
  }

  private combineWithNOT(
    filterResults: Map<string, FilterResult[]>,
    query: CombinedFilterQuery
  ): FilterResult[] {
    // Implementar lógica NOT (excluir resultados del segundo filtro)
    const [includeFilter, excludeFilter] = query.filters;
    const includeResults = filterResults.get(includeFilter) || [];
    const excludeResults = filterResults.get(excludeFilter) || [];
    
    const excludeIds = new Set(excludeResults.map(r => this.getVerseId(r.verse)));
    
    return includeResults
      .filter(r => !excludeIds.has(this.getVerseId(r.verse)))
      .filter(r => !query.minScore || r.relevanceScore >= query.minScore)
      .sort((a, b) => b.relevanceScore - a.relevanceScore);
  }

  // =====================================================================
  // UTILIDADES Y CÁLCULOS
  // =====================================================================

  private calculateEmbeddingSimilarity(embedding1: number[], embedding2: number[]): number {
    if (embedding1.length !== embedding2.length) return 0;
    
    let dotProduct = 0;
    let norm1 = 0;
    let norm2 = 0;
    
    for (let i = 0; i < embedding1.length; i++) {
      dotProduct += embedding1[i] * embedding2[i];
      norm1 += embedding1[i] * embedding1[i];
      norm2 += embedding2[i] * embedding2[i];
    }
    
    if (norm1 === 0 || norm2 === 0) return 0;
    
    return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
  }

  private calculateTopicRelevance(topic: string, filter: FilterDefinition): number {
    // Mapear tópicos a filtros
    const topicFilterMap: { [topic: string]: string[] } = {
      'salvation': ['blood', 'faith', 'forgiveness'],
      'love': ['love', 'forgiveness'],
      'faith': ['faith', 'hope'],
      'hope': ['hope', 'faith'],
      'prayer': ['wisdom', 'faith'],
      'blood': ['blood', 'forgiveness'],
      'water': ['water', 'forgiveness'],
      'wisdom': ['wisdom'],
      'justice': ['forgiveness', 'wisdom'],
      'peace': ['love', 'forgiveness', 'hope']
    };

    const relevantFilters = topicFilterMap[topic] || [];
    return relevantFilters.includes(filter.id) ? 1.0 : 0.0;
  }

  private calculateRelevanceScore(
    matchScore: number, 
    analysis: TextAnalysisResult, 
    filter: FilterDefinition
  ): number {
    // Combinar match score con factores adicionales
    let relevanceScore = matchScore;
    
    // Bonus por alta confianza en sentimiento
    if (analysis.sentiment.confidence > 0.8) {
      relevanceScore *= 1.1;
    }
    
    // Bonus por múltiples tópicos relevantes
    const relevantTopics = analysis.topics.filter(t => t.probability > 0.3).length;
    if (relevantTopics > 1) {
      relevanceScore *= 1 + (relevantTopics - 1) * 0.05;
    }
    
    return Math.min(relevanceScore, 1.0);
  }

  private calculateConfidence(matchReasons: string[], analysis: TextAnalysisResult): number {
    let confidence = 0;
    
    // Confianza basada en número de razones de match
    confidence += Math.min(matchReasons.length * 0.2, 0.6);
    
    // Confianza del análisis de sentimiento
    confidence += analysis.sentiment.confidence * 0.3;
    
    // Confianza basada en la fuerza de los tópicos
    const avgTopicStrength = analysis.topics.length > 0 
      ? analysis.topics.reduce((sum, t) => sum + t.probability, 0) / analysis.topics.length
      : 0;
    confidence += avgTopicStrength * 0.1;
    
    return Math.min(confidence, 1.0);
  }

  private combineVerseResults(results: FilterResult[], weights?: { [filterId: string]: number }): FilterResult {
    const baseResult = results[0];
    let combinedScore = 0;
    let totalWeight = 0;
    const allReasons: string[] = [];

    for (const result of results) {
      const weight = weights ? (weights[result.verse.filterId] || 1) : 1;
      combinedScore += result.relevanceScore * weight;
      totalWeight += weight;
      allReasons.push(...result.matchReasons);
    }

    return {
      verse: baseResult.verse,
      matchScore: combinedScore / totalWeight,
      matchReasons: [...new Set(allReasons)], // Eliminar duplicados
      relevanceScore: combinedScore / totalWeight,
      confidence: Math.min(results.reduce((sum, r) => sum + r.confidence, 0) / results.length, 1.0),
      analysis: baseResult.analysis
    };
  }

  // =====================================================================
  // UTILIDADES AUXILIARES
  // =====================================================================

  private hashVerses(verses: any[]): string {
    // Hash simple para cache
    return btoa(verses.map(v => v.id || v.numero || '').join(',')).slice(0, 16);
  }

  private getVerseId(verse: any): string {
    return verse.id || `${verse.libro}-${verse.capitulo}-${verse.versiculo}` || 
           `${verse.book}-${verse.chapter}-${verse.verse}` || Math.random().toString();
  }

  private getBookContext(book: string): string {
    // Contextos simplificados por libro
    const contexts: { [book: string]: string } = {
      'genesis': 'creation_beginnings',
      'exodus': 'liberation_law',
      'leviticus': 'worship_holiness',
      'matthew': 'gospel_kingdom',
      'romans': 'salvation_doctrine',
      'revelation': 'eschatology_prophecy'
    };
    return contexts[book?.toLowerCase()] || 'general';
  }

  private isContextRelevant(context: string, filter: FilterDefinition): boolean {
    const relevantContexts: { [filterId: string]: string[] } = {
      'blood': ['worship_holiness', 'salvation_doctrine'],
      'water': ['worship_holiness', 'gospel_kingdom'],
      'love': ['gospel_kingdom', 'salvation_doctrine'],
      'faith': ['salvation_doctrine', 'gospel_kingdom'],
      'hope': ['eschatology_prophecy', 'salvation_doctrine']
    };
    
    return relevantContexts[filter.id]?.includes(context) || false;
  }

  private isChapterRelevant(chapter: number, filter: FilterDefinition): boolean {
    // Lógica simplificada para relevancia por capítulo
    return true; // Placeholder
  }

  private async evaluateContextualRule(verse: any, rule: ContextualRule): Promise<number> {
    // Implementación simplificada de reglas contextuales
    // En una implementación real, analizaríamos el contexto circundante
    return 0.1; // Placeholder
  }

  private clearCache(filterId?: string): void {
    if (filterId) {
      // Limpiar entradas de cache específicas del filtro
      for (const [key, value] of this.cache.entries()) {
        if (key.startsWith(filterId)) {
          this.cache.delete(key);
        }
      }
    } else {
      this.cache.clear();
    }
  }

  private updateAnalytics(filterId: string, results: FilterResult[], executionTime: number): void {
    const totalMatches = results.length;
    const averageScore = results.length > 0 
      ? results.reduce((sum, r) => sum + r.relevanceScore, 0) / results.length 
      : 0;

    const analytics: FilterAnalytics = {
      filterId,
      totalMatches,
      averageScore,
      distributionByBook: this.calculateBookDistribution(results),
      topMatches: results.slice(0, 10),
      performanceMetrics: {
        precision: 0.85, // Placeholder
        recall: 0.78,    // Placeholder
        f1Score: 0.81,   // Placeholder
        executionTime
      }
    };

    this.analytics.set(filterId, analytics);
  }

  private calculateBookDistribution(results: FilterResult[]): { [book: string]: number } {
    const distribution: { [book: string]: number } = {};
    
    for (const result of results) {
      const book = result.verse.libro || result.verse.book || 'unknown';
      distribution[book] = (distribution[book] || 0) + 1;
    }
    
    return distribution;
  }

  // =====================================================================
  // MÉTODOS PÚBLICOS ADICIONALES
  // =====================================================================

  getFilterAnalytics(filterId: string): FilterAnalytics | undefined {
    return this.analytics.get(filterId);
  }

  getAllAnalytics(): { [filterId: string]: FilterAnalytics } {
    const analytics: { [filterId: string]: FilterAnalytics } = {};
    for (const [id, data] of this.analytics.entries()) {
      analytics[id] = data;
    }
    return analytics;
  }

  clearAllCaches(): void {
    this.cache.clear();
  }

  exportFilter(filterId: string): string {
    const filter = this.filters.get(filterId);
    return filter ? JSON.stringify(filter, null, 2) : '';
  }

  importFilter(filterJson: string): void {
    try {
      const filter: FilterDefinition = JSON.parse(filterJson);
      this.addFilter(filter);
    } catch (error) {
      throw new Error(`Invalid filter JSON: ${error}`);
    }
  }
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalIntelligentFilters = new IntelligentFilters();

// Exponer en window para debugging
if (typeof window !== 'undefined') {
  (window as any).intelligentFilters = globalIntelligentFilters;
}

export default IntelligentFilters;
