/**
 * Motor Social Avanzado
 * Sistema completo de comunidades, grupos, mentorías y colaboración
 */

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface User {
  id: string;
  username: string;
  displayName: string;
  email: string;
  avatar?: string;
  bio?: string;
  location?: string;
  joinDate: Date;
  lastActive: Date;
  reputation: number;
  level: number;
  badges: Badge[];
  interests: string[];
  studyPreferences: StudyPreferences;
  privacy: PrivacySettings;
  stats: UserStats;
}

export interface Community {
  id: string;
  name: string;
  description: string;
  category: string;
  visibility: 'public' | 'private' | 'restricted';
  memberCount: number;
  admins: string[];
  moderators: string[];
  members: string[];
  tags: string[];
  rules: string[];
  createdDate: Date;
  lastActivity: Date;
  settings: CommunitySettings;
  analytics: CommunityAnalytics;
}

export interface StudyGroup {
  id: string;
  name: string;
  description: string;
  communityId?: string;
  type: 'open' | 'closed' | 'invite-only';
  capacity: number;
  members: GroupMember[];
  studyPlan: StudyPlan;
  schedule: GroupSchedule;
  progress: GroupProgress;
  resources: SharedResource[];
  meetings: Meeting[];
  createdDate: Date;
  status: 'active' | 'paused' | 'completed';
}

export interface Mentorship {
  id: string;
  mentorId: string;
  menteeId: string;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  focus: string[];
  goals: string[];
  schedule: MentorshipSchedule;
  progress: MentorshipProgress;
  resources: SharedResource[];
  evaluations: Evaluation[];
  startDate: Date;
  endDate?: Date;
}

export interface RealTimeSession {
  id: string;
  type: 'study' | 'discussion' | 'mentorship' | 'community-event';
  title: string;
  participants: Participant[];
  moderators: string[];
  content: SessionContent;
  startTime: Date;
  endTime?: Date;
  status: 'scheduled' | 'active' | 'ended';
  recording?: string;
  chat: ChatMessage[];
  annotations: Annotation[];
}

export interface SocialChallenge {
  id: string;
  title: string;
  description: string;
  type: 'individual' | 'group' | 'community';
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
  requirements: ChallengeRequirement[];
  rewards: Reward[];
  timeLimit?: number;
  participants: string[];
  leaderboard: LeaderboardEntry[];
  startDate: Date;
  endDate: Date;
  status: 'upcoming' | 'active' | 'ended';
}

export interface UserGeneratedContent {
  id: string;
  type: 'course' | 'lesson' | 'article' | 'discussion' | 'resource';
  title: string;
  content: any;
  authorId: string;
  tags: string[];
  category: string;
  visibility: 'public' | 'community' | 'private';
  ratings: Rating[];
  views: number;
  downloads: number;
  createdDate: Date;
  lastModified: Date;
  status: 'draft' | 'published' | 'archived';
  moderation: ModerationStatus;
}

// Interfaces auxiliares
export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedDate: Date;
}

export interface StudyPreferences {
  studyTimes: string[];
  difficultyLevel: 'beginner' | 'intermediate' | 'advanced';
  topics: string[];
  language: string;
  groupSize: 'small' | 'medium' | 'large';
  meetingFrequency: 'daily' | 'weekly' | 'biweekly' | 'monthly';
}

export interface PrivacySettings {
  profileVisibility: 'public' | 'friends' | 'private';
  showActivity: boolean;
  showProgress: boolean;
  allowMessages: 'all' | 'friends' | 'none';
  allowInvites: boolean;
}

export interface UserStats {
  totalStudyTime: number;
  completedCourses: number;
  communityContributions: number;
  helpfulVotes: number;
  streakDays: number;
  averageRating: number;
}

export interface SocialAnalytics {
  engagement: EngagementMetrics;
  network: NetworkAnalytics;
  content: ContentAnalytics;
  growth: GrowthMetrics;
  influence: InfluenceMetrics;
}

// =====================================================================
// CONFIGURACIÓN DEL SISTEMA SOCIAL
// =====================================================================

const SOCIAL_CONFIG = {
  reputation: {
    actions: {
      post_helpful_answer: 10,
      receive_upvote: 5,
      complete_challenge: 15,
      mentor_session: 20,
      create_course: 50,
      moderate_content: 8
    },
    levels: [
      { threshold: 0, name: 'Novato', benefits: [] },
      { threshold: 100, name: 'Aprendiz', benefits: ['create_groups'] },
      { threshold: 500, name: 'Estudiante', benefits: ['create_challenges'] },
      { threshold: 1000, name: 'Maestro', benefits: ['mentor_others'] },
      { threshold: 2500, name: 'Líder', benefits: ['create_communities'] },
      { threshold: 5000, name: 'Experto', benefits: ['moderate_content'] }
    ]
  },
  matching: {
    algorithms: {
      study_group: ['interests', 'level', 'availability', 'location'],
      mentorship: ['expertise', 'goals', 'personality', 'availability'],
      community: ['topics', 'activity_level', 'contribution_style']
    },
    weights: {
      interests: 0.4,
      level: 0.3,
      availability: 0.2,
      personality: 0.1
    }
  },
  moderation: {
    autoModeration: true,
    flagThresholds: {
      spam: 3,
      inappropriate: 2,
      harassment: 1
    },
    trustedUserLevel: 1000 // reputación mínima para moderar
  },
  gamification: {
    pointsPerAction: {
      daily_login: 1,
      complete_lesson: 5,
      help_others: 10,
      participate_discussion: 3,
      create_content: 25,
      mentor_session: 15
    },
    streakBonuses: {
      7: 1.5,
      30: 2.0,
      90: 2.5,
      365: 3.0
    }
  }
};

// =====================================================================
// MOTOR SOCIAL PRINCIPAL
// =====================================================================

export class SocialEngine {
  private users: Map<string, User> = new Map();
  private communities: Map<string, Community> = new Map();
  private studyGroups: Map<string, StudyGroup> = new Map();
  private mentorships: Map<string, Mentorship> = new Map();
  private realTimeSessions: Map<string, RealTimeSession> = new Map();
  private challenges: Map<string, SocialChallenge> = new Map();
  private userContent: Map<string, UserGeneratedContent> = new Map();
  private connections: Map<string, string[]> = new Map(); // red social
  
  private eventEmitter: EventTarget = new EventTarget();
  private isInitialized: boolean = false;

  constructor() {
    this.initialize();
  }

  // =====================================================================
  // INICIALIZACIÓN
  // =====================================================================

  private async initialize(): Promise<void> {
    try {
      await this.loadMockData();
      this.setupEventListeners();
      this.startPeriodicTasks();
      
      this.isInitialized = true;
      console.log('Social Engine initialized successfully');
    } catch (error) {
      console.error('Error initializing Social Engine:', error);
    }
  }

  private async loadMockData(): Promise<void> {
    // Usuarios de ejemplo
    const mockUsers: User[] = [
      {
        id: 'user1',
        username: 'pastor_martinez',
        displayName: 'Pastor Martínez',
        email: 'martinez@example.com',
        bio: 'Pastor con 15 años de experiencia en formación bíblica',
        joinDate: new Date('2023-01-15'),
        lastActive: new Date(),
        reputation: 2500,
        level: 4,
        badges: [],
        interests: ['teología', 'liderazgo', 'evangelismo'],
        studyPreferences: {
          studyTimes: ['morning', 'evening'],
          difficultyLevel: 'advanced',
          topics: ['teología sistemática', 'hermenéutica'],
          language: 'spanish',
          groupSize: 'medium',
          meetingFrequency: 'weekly'
        },
        privacy: {
          profileVisibility: 'public',
          showActivity: true,
          showProgress: true,
          allowMessages: 'all',
          allowInvites: true
        },
        stats: {
          totalStudyTime: 320,
          completedCourses: 12,
          communityContributions: 45,
          helpfulVotes: 123,
          streakDays: 28,
          averageRating: 4.8
        }
      },
      {
        id: 'user2',
        username: 'maria_estudiante',
        displayName: 'María González',
        email: 'maria@example.com',
        bio: 'Estudiante de teología en busca de mentorías',
        joinDate: new Date('2024-03-20'),
        lastActive: new Date(),
        reputation: 150,
        level: 1,
        badges: [],
        interests: ['estudio bíblico', 'oración', 'música cristiana'],
        studyPreferences: {
          studyTimes: ['evening'],
          difficultyLevel: 'beginner',
          topics: ['nuevo testamento', 'vida cristiana'],
          language: 'spanish',
          groupSize: 'small',
          meetingFrequency: 'weekly'
        },
        privacy: {
          profileVisibility: 'public',
          showActivity: true,
          showProgress: true,
          allowMessages: 'all',
          allowInvites: true
        },
        stats: {
          totalStudyTime: 45,
          completedCourses: 2,
          communityContributions: 8,
          helpfulVotes: 15,
          streakDays: 7,
          averageRating: 4.2
        }
      }
    ];

    for (const user of mockUsers) {
      this.users.set(user.id, user);
    }

    // Comunidades de ejemplo
    const mockCommunities: Community[] = [
      {
        id: 'comm1',
        name: 'Teología Sistemática',
        description: 'Comunidad para el estudio profundo de la teología sistemática',
        category: 'Estudios Académicos',
        visibility: 'public',
        memberCount: 156,
        admins: ['user1'],
        moderators: ['user1'],
        members: ['user1', 'user2'],
        tags: ['teología', 'doctrina', 'estudio'],
        rules: [
          'Mantener respeto en todas las discusiones',
          'Usar fuentes bíblicas para respaldar argumentos',
          'No promover divisiones denominacionales'
        ],
        createdDate: new Date('2023-06-01'),
        lastActivity: new Date(),
        settings: {
          allowUserContent: true,
          requireApproval: false,
          autoModeration: true
        },
        analytics: {
          dailyActiveUsers: 25,
          weeklyPosts: 12,
          engagementRate: 0.68
        }
      }
    ];

    for (const community of mockCommunities) {
      this.communities.set(community.id, community);
    }
  }

  private setupEventListeners(): void {
    // Event listeners para tiempo real
    this.eventEmitter.addEventListener('user-action', this.handleUserAction.bind(this));
    this.eventEmitter.addEventListener('moderation-flag', this.handleModerationFlag.bind(this));
  }

  private startPeriodicTasks(): void {
    // Tareas periódicas cada 5 minutos
    setInterval(() => {
      this.updateAnalytics();
      this.checkModerationQueue();
      this.updateRecommendations();
    }, 5 * 60 * 1000);
  }

  // =====================================================================
  // GESTIÓN DE USUARIOS
  // =====================================================================

  async createUser(userData: Partial<User>): Promise<User> {
    const user: User = {
      id: this.generateId(),
      username: userData.username || '',
      displayName: userData.displayName || '',
      email: userData.email || '',
      bio: userData.bio || '',
      joinDate: new Date(),
      lastActive: new Date(),
      reputation: 0,
      level: 0,
      badges: [],
      interests: userData.interests || [],
      studyPreferences: userData.studyPreferences || this.getDefaultStudyPreferences(),
      privacy: userData.privacy || this.getDefaultPrivacySettings(),
      stats: {
        totalStudyTime: 0,
        completedCourses: 0,
        communityContributions: 0,
        helpfulVotes: 0,
        streakDays: 0,
        averageRating: 0
      }
    };

    this.users.set(user.id, user);
    this.emitEvent('user-created', { user });
    
    return user;
  }

  async updateUserReputation(userId: string, action: string, points?: number): Promise<void> {
    const user = this.users.get(userId);
    if (!user) return;

    const reputationPoints = points || SOCIAL_CONFIG.reputation.actions[action as keyof typeof SOCIAL_CONFIG.reputation.actions] || 0;
    user.reputation += reputationPoints;
    
    // Verificar si sube de nivel
    const newLevel = this.calculateUserLevel(user.reputation);
    if (newLevel > user.level) {
      user.level = newLevel;
      this.emitEvent('level-up', { userId, newLevel });
      await this.awardLevelBadge(userId, newLevel);
    }

    this.users.set(userId, user);
    this.emitEvent('reputation-updated', { userId, action, points: reputationPoints });
  }

  // =====================================================================
  // SISTEMA DE COMUNIDADES
  // =====================================================================

  async createCommunity(creatorId: string, communityData: Partial<Community>): Promise<Community> {
    const creator = this.users.get(creatorId);
    if (!creator || creator.level < 4) { // Requiere nivel Líder
      throw new Error('Insufficient privileges to create community');
    }

    const community: Community = {
      id: this.generateId(),
      name: communityData.name || '',
      description: communityData.description || '',
      category: communityData.category || 'General',
      visibility: communityData.visibility || 'public',
      memberCount: 1,
      admins: [creatorId],
      moderators: [creatorId],
      members: [creatorId],
      tags: communityData.tags || [],
      rules: communityData.rules || [],
      createdDate: new Date(),
      lastActivity: new Date(),
      settings: {
        allowUserContent: true,
        requireApproval: false,
        autoModeration: true
      },
      analytics: {
        dailyActiveUsers: 0,
        weeklyPosts: 0,
        engagementRate: 0
      }
    };

    this.communities.set(community.id, community);
    await this.updateUserReputation(creatorId, 'create_community', 100);
    
    this.emitEvent('community-created', { community, creatorId });
    return community;
  }

  async joinCommunity(userId: string, communityId: string): Promise<boolean> {
    const user = this.users.get(userId);
    const community = this.communities.get(communityId);
    
    if (!user || !community) return false;
    
    if (community.members.includes(userId)) return true;

    // Verificar si puede unirse
    if (community.visibility === 'private') {
      // Requiere invitación
      return false;
    }

    community.members.push(userId);
    community.memberCount++;
    community.lastActivity = new Date();

    this.communities.set(communityId, community);
    this.emitEvent('user-joined-community', { userId, communityId });
    
    return true;
  }

  // =====================================================================
  // GRUPOS DE ESTUDIO INTELIGENTES
  // =====================================================================

  async createStudyGroup(creatorId: string, groupData: Partial<StudyGroup>): Promise<StudyGroup> {
    const creator = this.users.get(creatorId);
    if (!creator || creator.level < 1) {
      throw new Error('Insufficient privileges to create study group');
    }

    const studyGroup: StudyGroup = {
      id: this.generateId(),
      name: groupData.name || '',
      description: groupData.description || '',
      communityId: groupData.communityId,
      type: groupData.type || 'open',
      capacity: groupData.capacity || 12,
      members: [{
        userId: creatorId,
        role: 'leader',
        joinDate: new Date(),
        progress: { completed: 0, total: 0 }
      }],
      studyPlan: groupData.studyPlan || this.createDefaultStudyPlan(),
      schedule: groupData.schedule || this.createDefaultSchedule(),
      progress: { currentLesson: 0, completionRate: 0 },
      resources: [],
      meetings: [],
      createdDate: new Date(),
      status: 'active'
    };

    this.studyGroups.set(studyGroup.id, studyGroup);
    await this.updateUserReputation(creatorId, 'create_group', 25);
    
    this.emitEvent('study-group-created', { studyGroup, creatorId });
    return studyGroup;
  }

  async findRecommendedStudyGroups(userId: string): Promise<StudyGroup[]> {
    const user = this.users.get(userId);
    if (!user) return [];

    const allGroups = Array.from(this.studyGroups.values());
    const recommendations: Array<{ group: StudyGroup; score: number }> = [];

    for (const group of allGroups) {
      if (group.members.length >= group.capacity) continue;
      if (group.members.some(m => m.userId === userId)) continue;

      const score = this.calculateGroupMatchScore(user, group);
      recommendations.push({ group, score });
    }

    return recommendations
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
      .map(r => r.group);
  }

  // =====================================================================
  // SISTEMA DE MENTORÍAS
  // =====================================================================

  async createMentorshipRequest(menteeId: string, mentorId: string, requestData: Partial<Mentorship>): Promise<Mentorship> {
    const mentee = this.users.get(menteeId);
    const mentor = this.users.get(mentorId);
    
    if (!mentee || !mentor) {
      throw new Error('Invalid user IDs');
    }

    if (mentor.level < 3) { // Requiere nivel Maestro
      throw new Error('Mentor must have at least Master level');
    }

    const mentorship: Mentorship = {
      id: this.generateId(),
      mentorId,
      menteeId,
      status: 'pending',
      focus: requestData.focus || [],
      goals: requestData.goals || [],
      schedule: requestData.schedule || this.createDefaultMentorshipSchedule(),
      progress: { goalsCompleted: 0, totalGoals: requestData.goals?.length || 0 },
      resources: [],
      evaluations: [],
      startDate: new Date()
    };

    this.mentorships.set(mentorship.id, mentorship);
    this.emitEvent('mentorship-requested', { mentorship });
    
    return mentorship;
  }

  async acceptMentorship(mentorshipId: string, mentorId: string): Promise<boolean> {
    const mentorship = this.mentorships.get(mentorshipId);
    if (!mentorship || mentorship.mentorId !== mentorId) return false;

    mentorship.status = 'active';
    mentorship.startDate = new Date();

    this.mentorships.set(mentorshipId, mentorship);
    this.emitEvent('mentorship-accepted', { mentorshipId });
    
    return true;
  }

  async findRecommendedMentors(userId: string, interests: string[]): Promise<User[]> {
    const user = this.users.get(userId);
    if (!user) return [];

    const potentialMentors = Array.from(this.users.values())
      .filter(u => u.level >= 3 && u.id !== userId);

    const recommendations: Array<{ user: User; score: number }> = [];

    for (const mentor of potentialMentors) {
      const score = this.calculateMentorMatchScore(user, mentor, interests);
      recommendations.push({ user: mentor, score });
    }

    return recommendations
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
      .map(r => r.user);
  }

  // =====================================================================
  // COLABORACIÓN EN TIEMPO REAL
  // =====================================================================

  async createRealTimeSession(creatorId: string, sessionData: Partial<RealTimeSession>): Promise<RealTimeSession> {
    const session: RealTimeSession = {
      id: this.generateId(),
      type: sessionData.type || 'study',
      title: sessionData.title || '',
      participants: [{
        userId: creatorId,
        role: 'host',
        joinTime: new Date(),
        isActive: true
      }],
      moderators: [creatorId],
      content: sessionData.content || { type: 'bible-study', data: {} },
      startTime: new Date(),
      status: 'active',
      chat: [],
      annotations: []
    };

    this.realTimeSessions.set(session.id, session);
    this.emitEvent('session-created', { session });
    
    return session;
  }

  async joinRealTimeSession(sessionId: string, userId: string): Promise<boolean> {
    const session = this.realTimeSessions.get(sessionId);
    const user = this.users.get(userId);
    
    if (!session || !user) return false;

    const participant: Participant = {
      userId,
      role: 'participant',
      joinTime: new Date(),
      isActive: true
    };

    session.participants.push(participant);
    this.realTimeSessions.set(sessionId, session);
    
    this.emitEvent('user-joined-session', { sessionId, userId });
    return true;
  }

  async addChatMessage(sessionId: string, userId: string, message: string): Promise<boolean> {
    const session = this.realTimeSessions.get(sessionId);
    if (!session) return false;

    const chatMessage: ChatMessage = {
      id: this.generateId(),
      userId,
      message,
      timestamp: new Date(),
      type: 'text'
    };

    session.chat.push(chatMessage);
    this.realTimeSessions.set(sessionId, session);
    
    this.emitEvent('chat-message', { sessionId, message: chatMessage });
    return true;
  }

  // =====================================================================
  // GAMIFICACIÓN SOCIAL
  // =====================================================================

  async createChallenge(creatorId: string, challengeData: Partial<SocialChallenge>): Promise<SocialChallenge> {
    const creator = this.users.get(creatorId);
    if (!creator || creator.level < 2) {
      throw new Error('Insufficient privileges to create challenge');
    }

    const challenge: SocialChallenge = {
      id: this.generateId(),
      title: challengeData.title || '',
      description: challengeData.description || '',
      type: challengeData.type || 'individual',
      category: challengeData.category || 'study',
      difficulty: challengeData.difficulty || 'medium',
      points: challengeData.points || 50,
      requirements: challengeData.requirements || [],
      rewards: challengeData.rewards || [],
      timeLimit: challengeData.timeLimit,
      participants: [],
      leaderboard: [],
      startDate: new Date(),
      endDate: challengeData.endDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      status: 'active'
    };

    this.challenges.set(challenge.id, challenge);
    await this.updateUserReputation(creatorId, 'create_challenge', 30);
    
    this.emitEvent('challenge-created', { challenge });
    return challenge;
  }

  async joinChallenge(challengeId: string, userId: string): Promise<boolean> {
    const challenge = this.challenges.get(challengeId);
    const user = this.users.get(userId);
    
    if (!challenge || !user) return false;
    if (challenge.participants.includes(userId)) return true;

    challenge.participants.push(userId);
    challenge.leaderboard.push({
      userId,
      score: 0,
      progress: 0,
      lastUpdate: new Date()
    });

    this.challenges.set(challengeId, challenge);
    this.emitEvent('user-joined-challenge', { challengeId, userId });
    
    return true;
  }

  // =====================================================================
  // CONTENIDO GENERADO POR USUARIOS
  // =====================================================================

  async createUserContent(authorId: string, contentData: Partial<UserGeneratedContent>): Promise<UserGeneratedContent> {
    const author = this.users.get(authorId);
    if (!author) throw new Error('Invalid author ID');

    const content: UserGeneratedContent = {
      id: this.generateId(),
      type: contentData.type || 'article',
      title: contentData.title || '',
      content: contentData.content || {},
      authorId,
      tags: contentData.tags || [],
      category: contentData.category || 'General',
      visibility: contentData.visibility || 'public',
      ratings: [],
      views: 0,
      downloads: 0,
      createdDate: new Date(),
      lastModified: new Date(),
      status: 'draft',
      moderation: {
        status: 'pending',
        flags: [],
        reviewedBy: null,
        reviewDate: null
      }
    };

    // Auto-moderación con IA (simplificada)
    if (SOCIAL_CONFIG.moderation.autoModeration) {
      content.moderation.status = await this.autoModerateContent(content);
    }

    this.userContent.set(content.id, content);
    await this.updateUserReputation(authorId, 'create_content', 25);
    
    this.emitEvent('content-created', { content });
    return content;
  }

  async rateContent(contentId: string, userId: string, rating: number, review?: string): Promise<boolean> {
    const content = this.userContent.get(contentId);
    if (!content) return false;

    const existingRating = content.ratings.find(r => r.userId === userId);
    if (existingRating) {
      existingRating.rating = rating;
      existingRating.review = review;
      existingRating.date = new Date();
    } else {
      content.ratings.push({
        userId,
        rating,
        review,
        date: new Date()
      });
    }

    this.userContent.set(contentId, content);
    
    // Actualizar reputación del autor si es una buena calificación
    if (rating >= 4) {
      await this.updateUserReputation(content.authorId, 'receive_good_rating', 5);
    }

    this.emitEvent('content-rated', { contentId, userId, rating });
    return true;
  }

  // =====================================================================
  // ANALYTICS SOCIALES
  // =====================================================================

  async getSocialAnalytics(userId?: string, communityId?: string): Promise<SocialAnalytics> {
    const analytics: SocialAnalytics = {
      engagement: await this.calculateEngagementMetrics(userId, communityId),
      network: await this.calculateNetworkAnalytics(userId),
      content: await this.calculateContentAnalytics(userId, communityId),
      growth: await this.calculateGrowthMetrics(communityId),
      influence: await this.calculateInfluenceMetrics(userId)
    };

    return analytics;
  }

  private async calculateEngagementMetrics(userId?: string, communityId?: string): Promise<EngagementMetrics> {
    // Implementación simplificada
    return {
      dailyActiveUsers: 45,
      weeklyActiveUsers: 156,
      averageSessionTime: 28,
      interactionRate: 0.73,
      contentEngagementRate: 0.45
    };
  }

  private async calculateNetworkAnalytics(userId?: string): Promise<NetworkAnalytics> {
    return {
      connectionCount: 23,
      mutualConnections: 8,
      networkDensity: 0.34,
      clusteringCoefficient: 0.67,
      centralityScore: 0.42
    };
  }

  // =====================================================================
  // UTILIDADES Y MÉTODOS AUXILIARES
  // =====================================================================

  private calculateUserLevel(reputation: number): number {
    const levels = SOCIAL_CONFIG.reputation.levels;
    for (let i = levels.length - 1; i >= 0; i--) {
      if (reputation >= levels[i].threshold) {
        return i;
      }
    }
    return 0;
  }

  private calculateGroupMatchScore(user: User, group: StudyGroup): number {
    let score = 0;
    
    // Intereses comunes
    const commonInterests = user.interests.filter(interest => 
      group.studyPlan.topics?.includes(interest)
    ).length;
    score += commonInterests * 0.4;

    // Nivel de dificultad
    const levelMatch = this.matchDifficultyLevels(user.studyPreferences.difficultyLevel, group.studyPlan.difficulty);
    score += levelMatch * 0.3;

    // Disponibilidad horaria
    const timeMatch = this.matchAvailability(user.studyPreferences.studyTimes, group.schedule.preferredTimes);
    score += timeMatch * 0.2;

    // Tamaño de grupo preferido
    const sizeMatch = this.matchGroupSize(user.studyPreferences.groupSize, group.members.length, group.capacity);
    score += sizeMatch * 0.1;

    return Math.min(score, 1.0);
  }

  private calculateMentorMatchScore(mentee: User, mentor: User, interests: string[]): number {
    let score = 0;

    // Intereses compartidos
    const commonInterests = mentee.interests.filter(interest => 
      mentor.interests.includes(interest)
    ).length;
    score += (commonInterests / Math.max(mentee.interests.length, 1)) * 0.4;

    // Diferencia de nivel (mentor debe ser superior)
    const levelDiff = mentor.level - mentee.level;
    if (levelDiff > 0) {
      score += Math.min(levelDiff / 3, 1) * 0.3;
    }

    // Reputación y calificaciones del mentor
    score += Math.min(mentor.reputation / 5000, 1) * 0.2;
    score += mentor.stats.averageRating / 5 * 0.1;

    return Math.min(score, 1.0);
  }

  private async autoModerateContent(content: UserGeneratedContent): Promise<'approved' | 'flagged' | 'rejected'> {
    // Implementación simplificada de moderación automática
    const suspiciousWords = ['spam', 'promoción', 'venta', 'dinero'];
    const contentText = JSON.stringify(content.content).toLowerCase();
    
    for (const word of suspiciousWords) {
      if (contentText.includes(word)) {
        return 'flagged';
      }
    }

    return 'approved';
  }

  private matchDifficultyLevels(userLevel: string, groupLevel: string): number {
    const levels = { 'beginner': 1, 'intermediate': 2, 'advanced': 3 };
    const userNum = levels[userLevel as keyof typeof levels] || 1;
    const groupNum = levels[groupLevel as keyof typeof levels] || 1;
    
    return 1 - Math.abs(userNum - groupNum) / 2;
  }

  private matchAvailability(userTimes: string[], groupTimes: string[]): number {
    const commonTimes = userTimes.filter(time => groupTimes.includes(time));
    return commonTimes.length / Math.max(userTimes.length, 1);
  }

  private matchGroupSize(preferred: string, current: number, capacity: number): number {
    const sizes = { 'small': 6, 'medium': 12, 'large': 20 };
    const preferredSize = sizes[preferred as keyof typeof sizes] || 12;
    
    if (current >= capacity) return 0;
    
    const idealSize = Math.min(preferredSize, capacity);
    return 1 - Math.abs(current - idealSize) / idealSize;
  }

  private createDefaultStudyPlan(): StudyPlan {
    return {
      title: 'Plan de Estudio Básico',
      description: 'Plan de estudio fundamental',
      duration: 8, // semanas
      difficulty: 'intermediate',
      topics: ['estudio bíblico', 'oración', 'vida cristiana'],
      lessons: []
    };
  }

  private createDefaultSchedule(): GroupSchedule {
    return {
      frequency: 'weekly',
      duration: 60, // minutos
      preferredTimes: ['evening'],
      timezone: 'America/Mexico_City'
    };
  }

  private createDefaultMentorshipSchedule(): MentorshipSchedule {
    return {
      frequency: 'weekly',
      duration: 45,
      preferredTimes: ['evening'],
      sessionType: 'video-call'
    };
  }

  private getDefaultStudyPreferences(): StudyPreferences {
    return {
      studyTimes: ['evening'],
      difficultyLevel: 'beginner',
      topics: [],
      language: 'spanish',
      groupSize: 'medium',
      meetingFrequency: 'weekly'
    };
  }

  private getDefaultPrivacySettings(): PrivacySettings {
    return {
      profileVisibility: 'public',
      showActivity: true,
      showProgress: true,
      allowMessages: 'all',
      allowInvites: true
    };
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private emitEvent(eventType: string, data: any): void {
    this.eventEmitter.dispatchEvent(new CustomEvent(eventType, { detail: data }));
  }

  private handleUserAction(event: Event): void {
    // Manejar acciones de usuario para analytics
  }

  private handleModerationFlag(event: Event): void {
    // Manejar flags de moderación
  }

  private updateAnalytics(): void {
    // Actualizar analytics periódicamente
  }

  private checkModerationQueue(): void {
    // Revisar cola de moderación
  }

  private updateRecommendations(): void {
    // Actualizar recomendaciones
  }

  private async awardLevelBadge(userId: string, level: number): Promise<void> {
    // Otorgar badge por nivel
  }

  // =====================================================================
  // MÉTODOS PÚBLICOS ADICIONALES
  // =====================================================================

  getUser(userId: string): User | undefined {
    return this.users.get(userId);
  }

  getCommunity(communityId: string): Community | undefined {
    return this.communities.get(communityId);
  }

  getStudyGroup(groupId: string): StudyGroup | undefined {
    return this.studyGroups.get(groupId);
  }

  getAllCommunities(): Community[] {
    return Array.from(this.communities.values());
  }

  getAllStudyGroups(): StudyGroup[] {
    return Array.from(this.studyGroups.values());
  }

  async searchUsers(query: string, filters?: any): Promise<User[]> {
    const users = Array.from(this.users.values());
    return users.filter(user => 
      user.username.toLowerCase().includes(query.toLowerCase()) ||
      user.displayName.toLowerCase().includes(query.toLowerCase())
    );
  }

  addEventListener(eventType: string, listener: EventListener): void {
    this.eventEmitter.addEventListener(eventType, listener);
  }

  removeEventListener(eventType: string, listener: EventListener): void {
    this.eventEmitter.removeEventListener(eventType, listener);
  }
}

// =====================================================================
// TIPOS AUXILIARES
// =====================================================================

interface GroupMember {
  userId: string;
  role: 'leader' | 'member' | 'moderator';
  joinDate: Date;
  progress: { completed: number; total: number };
}

interface StudyPlan {
  title: string;
  description: string;
  duration: number;
  difficulty: string;
  topics: string[];
  lessons: any[];
}

interface GroupSchedule {
  frequency: string;
  duration: number;
  preferredTimes: string[];
  timezone: string;
}

interface GroupProgress {
  currentLesson: number;
  completionRate: number;
}

interface SharedResource {
  id: string;
  name: string;
  type: string;
  url: string;
  uploadedBy: string;
  uploadDate: Date;
}

interface Meeting {
  id: string;
  title: string;
  scheduledDate: Date;
  duration: number;
  attendees: string[];
  recording?: string;
}

interface MentorshipSchedule {
  frequency: string;
  duration: number;
  preferredTimes: string[];
  sessionType: string;
}

interface MentorshipProgress {
  goalsCompleted: number;
  totalGoals: number;
}

interface Evaluation {
  id: string;
  evaluatorId: string;
  rating: number;
  feedback: string;
  date: Date;
}

interface Participant {
  userId: string;
  role: 'host' | 'moderator' | 'participant';
  joinTime: Date;
  isActive: boolean;
}

interface SessionContent {
  type: string;
  data: any;
}

interface ChatMessage {
  id: string;
  userId: string;
  message: string;
  timestamp: Date;
  type: 'text' | 'image' | 'file';
}

interface Annotation {
  id: string;
  userId: string;
  content: string;
  position: any;
  timestamp: Date;
}

interface ChallengeRequirement {
  type: string;
  description: string;
  criteria: any;
}

interface Reward {
  type: 'points' | 'badge' | 'item';
  value: any;
  description: string;
}

interface LeaderboardEntry {
  userId: string;
  score: number;
  progress: number;
  lastUpdate: Date;
}

interface Rating {
  userId: string;
  rating: number;
  review?: string;
  date: Date;
}

interface ModerationStatus {
  status: 'pending' | 'approved' | 'flagged' | 'rejected';
  flags: string[];
  reviewedBy: string | null;
  reviewDate: Date | null;
}

interface CommunitySettings {
  allowUserContent: boolean;
  requireApproval: boolean;
  autoModeration: boolean;
}

interface CommunityAnalytics {
  dailyActiveUsers: number;
  weeklyPosts: number;
  engagementRate: number;
}

interface EngagementMetrics {
  dailyActiveUsers: number;
  weeklyActiveUsers: number;
  averageSessionTime: number;
  interactionRate: number;
  contentEngagementRate: number;
}

interface NetworkAnalytics {
  connectionCount: number;
  mutualConnections: number;
  networkDensity: number;
  clusteringCoefficient: number;
  centralityScore: number;
}

interface ContentAnalytics {
  totalPosts?: number;
  averageRating?: number;
  engagementRate?: number;
}

interface GrowthMetrics {
  newMembers?: number;
  retentionRate?: number;
  growthRate?: number;
}

interface InfluenceMetrics {
  influenceScore?: number;
  reachScore?: number;
  authorityScore?: number;
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalSocialEngine = new SocialEngine();

// Exponer en window para debugging
if (typeof window !== 'undefined') {
  (window as any).socialEngine = globalSocialEngine;
}

export default SocialEngine;
