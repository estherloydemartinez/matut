/**
 * Motor de Machine Learning para Análisis Bíblico
 * Implementa algoritmos de ML, NLP y análisis semántico
 */

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface TextAnalysisResult {
  sentiment: {
    score: number; // -1 a 1
    label: 'positivo' | 'neutro' | 'negativo';
    confidence: number;
  };
  topics: {
    topic: string;
    probability: number;
    keywords: string[];
  }[];
  entities: {
    entity: string;
    type: 'person' | 'place' | 'concept' | 'event';
    confidence: number;
    context: string;
  }[];
  embeddings: number[];
  tfIdf: { [word: string]: number };
}

export interface SemanticSearchResult {
  verse: any;
  similarity: number;
  relevance: number;
  contextMatch: number;
  explanation: string;
}

export interface ClusterResult {
  clusterId: number;
  center: number[];
  verses: any[];
  topicLabel: string;
  coherenceScore: number;
}

export interface RecommendationResult {
  verse: any;
  score: number;
  reason: string;
  category: 'similar_topic' | 'complementary' | 'next_study' | 'related_theme';
}

// =====================================================================
// CONFIGURACIÓN DE MODELOS
// =====================================================================

const ML_CONFIG = {
  sentiment: {
    positiveWords: [
      'amor', 'paz', 'gozo', 'alegría', 'bendición', 'gracia', 'misericordia',
      'salvación', 'vida', 'esperanza', 'fe', 'gloria', 'santo', 'bueno',
      'justo', 'verdad', 'luz', 'sabiduría', 'perdón', 'compasión'
    ],
    negativeWords: [
      'muerte', 'pecado', 'ira', 'juicio', 'castigo', 'maldición', 'dolor',
      'sufrimiento', 'tristeza', 'odio', 'guerra', 'destrucción', 'mal',
      'tinieblas', 'temor', 'angustia', 'aflicción', 'adversidad'
    ],
    neutralWords: [
      'dijo', 'habló', 'vino', 'fue', 'están', 'hacer', 'tiempo', 'lugar',
      'pueblo', 'tierra', 'casa', 'día', 'año', 'ciudad', 'rey', 'hombre'
    ]
  },
  topics: {
    // Definición de temas bíblicos principales
    'salvation': {
      keywords: ['salvación', 'salvar', 'salvador', 'redención', 'rescate', 'liberación'],
      weight: 1.0
    },
    'love': {
      keywords: ['amor', 'amar', 'amado', 'caridad', 'compasión', 'misericordia'],
      weight: 1.0
    },
    'faith': {
      keywords: ['fe', 'creer', 'confianza', 'fiel', 'fidelidad', 'confiar'],
      weight: 1.0
    },
    'hope': {
      keywords: ['esperanza', 'esperar', 'promesa', 'futuro', 'gloria'],
      weight: 1.0
    },
    'prayer': {
      keywords: ['oración', 'orar', 'pedir', 'suplicar', 'invocar', 'clamar'],
      weight: 0.9
    },
    'blood': {
      keywords: ['sangre', 'derramada', 'pacto', 'sacrificio', 'expiación', 'redención'],
      weight: 1.0
    },
    'water': {
      keywords: ['agua', 'bautismo', 'purificación', 'lavar', 'limpiar', 'rio'],
      weight: 1.0
    },
    'wisdom': {
      keywords: ['sabiduría', 'sabio', 'entendimiento', 'prudencia', 'conocimiento'],
      weight: 0.9
    },
    'justice': {
      keywords: ['justicia', 'justo', 'rectitud', 'derecho', 'equidad'],
      weight: 0.9
    },
    'peace': {
      keywords: ['paz', 'tranquilidad', 'descanso', 'reposo', 'calma'],
      weight: 0.8
    }
  },
  clustering: {
    numClusters: 10,
    maxIterations: 100,
    tolerance: 0.001
  },
  embeddings: {
    dimensions: 100,
    windowSize: 5,
    minCount: 2
  }
};

// =====================================================================
// MOTOR DE MACHINE LEARNING PRINCIPAL
// =====================================================================

export class MLEngine {
  private wordVectors: Map<string, number[]> = new Map();
  private topicModels: Map<string, any> = new Map();
  private sentimentModel: any = null;
  private initialized: boolean = false;

  constructor() {
    this.initializeModels();
  }

  // =====================================================================
  // INICIALIZACIÓN
  // =====================================================================

  async initializeModels(): Promise<void> {
    try {
      await Promise.all([
        this.initializeSentimentModel(),
        this.initializeTopicModels(),
        this.initializeWordEmbeddings()
      ]);
      
      this.initialized = true;
      console.log('ML Engine initialized successfully');
    } catch (error) {
      console.error('Error initializing ML Engine:', error);
    }
  }

  private async initializeSentimentModel(): Promise<void> {
    // Modelo de análisis de sentimiento simplificado
    this.sentimentModel = {
      predict: (text: string) => {
        const words = this.tokenizeText(text);
        let score = 0;
        let totalWords = 0;

        for (const word of words) {
          if (ML_CONFIG.sentiment.positiveWords.includes(word.toLowerCase())) {
            score += 1;
            totalWords++;
          } else if (ML_CONFIG.sentiment.negativeWords.includes(word.toLowerCase())) {
            score -= 1;
            totalWords++;
          }
        }

        const normalizedScore = totalWords > 0 ? score / totalWords : 0;
        const confidence = Math.min(totalWords / 10, 1); // Más palabras = más confianza

        return {
          score: Math.max(-1, Math.min(1, normalizedScore)),
          confidence: confidence,
          label: normalizedScore > 0.1 ? 'positivo' : 
                 normalizedScore < -0.1 ? 'negativo' : 'neutro'
        };
      }
    };
  }

  private async initializeTopicModels(): Promise<void> {
    // Implementación simplificada de LDA (Latent Dirichlet Allocation)
    for (const [topicName, topicConfig] of Object.entries(ML_CONFIG.topics)) {
      this.topicModels.set(topicName, {
        keywords: topicConfig.keywords,
        weight: topicConfig.weight,
        predict: (text: string) => {
          const words = this.tokenizeText(text);
          let score = 0;
          let matches = 0;

          for (const word of words) {
            if (topicConfig.keywords.includes(word.toLowerCase())) {
              score += topicConfig.weight;
              matches++;
            }
          }

          return {
            probability: Math.min(score / words.length, 1),
            matches: matches,
            relevantWords: words.filter(w => topicConfig.keywords.includes(w.toLowerCase()))
          };
        }
      });
    }
  }

  private async initializeWordEmbeddings(): Promise<void> {
    // Implementación simplificada de word embeddings
    // En una implementación real, cargaríamos vectores pre-entrenados
    const vocabulary = this.buildVocabulary();
    
    for (const word of vocabulary) {
      // Generar vector aleatorio pero consistente para cada palabra
      const vector = this.generateConsistentVector(word, ML_CONFIG.embeddings.dimensions);
      this.wordVectors.set(word, vector);
    }
  }

  // =====================================================================
  // ANÁLISIS DE TEXTO
  // =====================================================================

  async analyzeText(text: string): Promise<TextAnalysisResult> {
    if (!this.initialized) {
      await this.initializeModels();
    }

    const [sentiment, topics, entities, embeddings, tfIdf] = await Promise.all([
      this.analyzeSentiment(text),
      this.analyzeTopics(text),
      this.extractEntities(text),
      this.getTextEmbedding(text),
      this.calculateTfIdf(text)
    ]);

    return {
      sentiment,
      topics,
      entities,
      embeddings,
      tfIdf
    };
  }

  private async analyzeSentiment(text: string): Promise<any> {
    return this.sentimentModel.predict(text);
  }

  private async analyzeTopics(text: string): Promise<any[]> {
    const topics = [];
    
    for (const [topicName, model] of this.topicModels.entries()) {
      const result = model.predict(text);
      
      if (result.probability > 0.1) { // Umbral mínimo
        topics.push({
          topic: topicName,
          probability: result.probability,
          keywords: result.relevantWords
        });
      }
    }

    return topics.sort((a, b) => b.probability - a.probability);
  }

  private async extractEntities(text: string): Promise<any[]> {
    const entities = [];
    const words = this.tokenizeText(text);
    
    // Patrones simples para reconocimiento de entidades
    const patterns = {
      person: /^[A-Z][a-záéíóúñ]+$/,
      place: /^[A-Z][a-záéíóúñ]*(?:ía|án|ón|én|ín|bel|salem|dad)$/,
      concept: /^[A-Z][a-záéíóúñ]*(?:dad|ción|miento|eza|ura)$/
    };

    for (const word of words) {
      if (word.length > 2) {
        for (const [type, pattern] of Object.entries(patterns)) {
          if (pattern.test(word)) {
            entities.push({
              entity: word,
              type: type as any,
              confidence: 0.7,
              context: this.getWordContext(text, word)
            });
            break;
          }
        }
      }
    }

    return entities;
  }

  // =====================================================================
  // BÚSQUEDA SEMÁNTICA
  // =====================================================================

  async semanticSearch(query: string, verses: any[], limit: number = 10): Promise<SemanticSearchResult[]> {
    const queryAnalysis = await this.analyzeText(query);
    const results: SemanticSearchResult[] = [];

    for (const verse of verses) {
      const verseText = verse.texto || verse.text || '';
      const verseAnalysis = await this.analyzeText(verseText);
      
      const similarity = this.calculateSimilarity(queryAnalysis, verseAnalysis);
      const relevance = this.calculateRelevance(query, verseText);
      const contextMatch = this.calculateContextMatch(queryAnalysis.topics, verseAnalysis.topics);
      
      results.push({
        verse,
        similarity,
        relevance,
        contextMatch,
        explanation: this.generateExplanation(queryAnalysis, verseAnalysis)
      });
    }

    return results
      .sort((a, b) => (b.similarity * 0.4 + b.relevance * 0.4 + b.contextMatch * 0.2) - 
                     (a.similarity * 0.4 + a.relevance * 0.4 + a.contextMatch * 0.2))
      .slice(0, limit);
  }

  private calculateSimilarity(analysis1: TextAnalysisResult, analysis2: TextAnalysisResult): number {
    // Similitud basada en embeddings
    const similarity = this.cosineSimilarity(analysis1.embeddings, analysis2.embeddings);
    return Math.max(0, similarity);
  }

  private calculateRelevance(query: string, text: string): number {
    const queryWords = this.tokenizeText(query.toLowerCase());
    const textWords = this.tokenizeText(text.toLowerCase());
    
    let matches = 0;
    for (const word of queryWords) {
      if (textWords.includes(word)) {
        matches++;
      }
    }
    
    return queryWords.length > 0 ? matches / queryWords.length : 0;
  }

  private calculateContextMatch(topics1: any[], topics2: any[]): number {
    if (topics1.length === 0 || topics2.length === 0) return 0;
    
    let maxMatch = 0;
    for (const topic1 of topics1) {
      for (const topic2 of topics2) {
        if (topic1.topic === topic2.topic) {
          const match = Math.min(topic1.probability, topic2.probability);
          maxMatch = Math.max(maxMatch, match);
        }
      }
    }
    
    return maxMatch;
  }

  // =====================================================================
  // CLUSTERING
  // =====================================================================

  async clusterVerses(verses: any[]): Promise<ClusterResult[]> {
    // Implementación de K-Means simplificado
    const embeddings = [];
    
    for (const verse of verses) {
      const text = verse.texto || verse.text || '';
      const embedding = await this.getTextEmbedding(text);
      embeddings.push(embedding);
    }

    const clusters = this.kMeansClustering(embeddings, ML_CONFIG.clustering.numClusters);
    const results: ClusterResult[] = [];

    for (let i = 0; i < clusters.length; i++) {
      const clusterVerses = clusters[i].map(index => verses[index]);
      const center = this.calculateClusterCenter(clusters[i].map(index => embeddings[index]));
      const topicLabel = await this.generateClusterLabel(clusterVerses);
      const coherenceScore = this.calculateCoherenceScore(clusterVerses);

      results.push({
        clusterId: i,
        center,
        verses: clusterVerses,
        topicLabel,
        coherenceScore
      });
    }

    return results;
  }

  private kMeansClustering(embeddings: number[][], k: number): number[][] {
    // Implementación simplificada de K-Means
    const n = embeddings.length;
    const dim = embeddings[0].length;
    
    // Inicializar centroides aleatoriamente
    const centroids = [];
    for (let i = 0; i < k; i++) {
      const centroid = [];
      for (let j = 0; j < dim; j++) {
        centroid.push(Math.random());
      }
      centroids.push(centroid);
    }

    let assignments = new Array(n).fill(0);
    let changed = true;
    let iterations = 0;

    while (changed && iterations < ML_CONFIG.clustering.maxIterations) {
      changed = false;
      
      // Asignar puntos a centroides más cercanos
      for (let i = 0; i < n; i++) {
        let minDist = Infinity;
        let bestCluster = 0;
        
        for (let j = 0; j < k; j++) {
          const dist = this.euclideanDistance(embeddings[i], centroids[j]);
          if (dist < minDist) {
            minDist = dist;
            bestCluster = j;
          }
        }
        
        if (assignments[i] !== bestCluster) {
          assignments[i] = bestCluster;
          changed = true;
        }
      }

      // Actualizar centroides
      for (let j = 0; j < k; j++) {
        const clusterPoints = embeddings.filter((_, i) => assignments[i] === j);
        if (clusterPoints.length > 0) {
          for (let d = 0; d < dim; d++) {
            centroids[j][d] = clusterPoints.reduce((sum, point) => sum + point[d], 0) / clusterPoints.length;
          }
        }
      }

      iterations++;
    }

    // Organizar resultados por cluster
    const clusters: number[][] = [];
    for (let i = 0; i < k; i++) {
      clusters.push([]);
    }
    
    for (let i = 0; i < n; i++) {
      clusters[assignments[i]].push(i);
    }

    return clusters;
  }

  // =====================================================================
  // SISTEMA DE RECOMENDACIONES
  // =====================================================================

  async generateRecommendations(
    currentVerse: any, 
    allVerses: any[], 
    userHistory: any[] = [],
    limit: number = 5
  ): Promise<RecommendationResult[]> {
    const currentAnalysis = await this.analyzeText(currentVerse.texto || currentVerse.text || '');
    const recommendations: RecommendationResult[] = [];

    for (const verse of allVerses) {
      if (verse.id === currentVerse.id) continue; // Skip mismo versículo
      
      const verseAnalysis = await this.analyzeText(verse.texto || verse.text || '');
      
      // Diferentes tipos de recomendaciones
      const similarTopicScore = this.calculateTopicSimilarity(currentAnalysis.topics, verseAnalysis.topics);
      const complementaryScore = this.calculateComplementaryScore(currentAnalysis, verseAnalysis);
      const userPreferenceScore = this.calculateUserPreferenceScore(verse, userHistory);
      
      if (similarTopicScore > 0.3) {
        recommendations.push({
          verse,
          score: similarTopicScore,
          reason: `Comparte temas similares: ${this.getSharedTopics(currentAnalysis.topics, verseAnalysis.topics).join(', ')}`,
          category: 'similar_topic'
        });
      }
      
      if (complementaryScore > 0.4) {
        recommendations.push({
          verse,
          score: complementaryScore,
          reason: 'Complementa el mensaje con perspectiva adicional',
          category: 'complementary'
        });
      }
      
      if (userPreferenceScore > 0.5) {
        recommendations.push({
          verse,
          score: userPreferenceScore,
          reason: 'Basado en tu historial de lectura',
          category: 'next_study'
        });
      }
    }

    return recommendations
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  // =====================================================================
  // UTILIDADES MATEMÁTICAS
  // =====================================================================

  private cosineSimilarity(vec1: number[], vec2: number[]): number {
    if (vec1.length !== vec2.length) return 0;
    
    let dotProduct = 0;
    let norm1 = 0;
    let norm2 = 0;
    
    for (let i = 0; i < vec1.length; i++) {
      dotProduct += vec1[i] * vec2[i];
      norm1 += vec1[i] * vec1[i];
      norm2 += vec2[i] * vec2[i];
    }
    
    if (norm1 === 0 || norm2 === 0) return 0;
    
    return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
  }

  private euclideanDistance(vec1: number[], vec2: number[]): number {
    if (vec1.length !== vec2.length) return Infinity;
    
    let sum = 0;
    for (let i = 0; i < vec1.length; i++) {
      sum += Math.pow(vec1[i] - vec2[i], 2);
    }
    
    return Math.sqrt(sum);
  }

  // =====================================================================
  // UTILIDADES DE TEXTO
  // =====================================================================

  private tokenizeText(text: string): string[] {
    return text
      .toLowerCase()
      .replace(/[^\w\sáéíóúñ]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2);
  }

  private async getTextEmbedding(text: string): Promise<number[]> {
    const words = this.tokenizeText(text);
    const vectors = words
      .map(word => this.wordVectors.get(word))
      .filter(vector => vector !== undefined);
    
    if (vectors.length === 0) {
      return new Array(ML_CONFIG.embeddings.dimensions).fill(0);
    }
    
    // Promedio de vectores de palabras
    const embedding = new Array(ML_CONFIG.embeddings.dimensions).fill(0);
    for (const vector of vectors) {
      for (let i = 0; i < embedding.length; i++) {
        embedding[i] += vector![i];
      }
    }
    
    for (let i = 0; i < embedding.length; i++) {
      embedding[i] /= vectors.length;
    }
    
    return embedding;
  }

  private calculateTfIdf(text: string): { [word: string]: number } {
    const words = this.tokenizeText(text);
    const wordCount = new Map<string, number>();
    
    // Calcular TF (Term Frequency)
    for (const word of words) {
      wordCount.set(word, (wordCount.get(word) || 0) + 1);
    }
    
    const tfIdf: { [word: string]: number } = {};
    for (const [word, count] of wordCount.entries()) {
      const tf = count / words.length;
      const idf = Math.log(1000 / (this.getWordDocumentFrequency(word) + 1)); // IDF simplificado
      tfIdf[word] = tf * idf;
    }
    
    return tfIdf;
  }

  private generateConsistentVector(word: string, dimensions: number): number[] {
    // Generar vector consistente basado en hash de la palabra
    const hash = this.simpleHash(word);
    const vector = [];
    
    for (let i = 0; i < dimensions; i++) {
      const seed = hash + i;
      vector.push((Math.sin(seed) + 1) / 2); // Normalize to [0, 1]
    }
    
    return vector;
  }

  private simpleHash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash;
  }

  // =====================================================================
  // UTILIDADES AUXILIARES
  // =====================================================================

  private buildVocabulary(): string[] {
    // Vocabulario básico bíblico
    const baseVocabulary = [
      'dios', 'señor', 'jesus', 'cristo', 'espiritu', 'santo', 'padre', 'hijo',
      'amor', 'paz', 'fe', 'esperanza', 'gracia', 'misericordia', 'verdad',
      'vida', 'luz', 'salvacion', 'redencion', 'perdon', 'justicia', 'sabiduria'
    ];

    // Agregar palabras de configuración de temas
    for (const topicConfig of Object.values(ML_CONFIG.topics)) {
      baseVocabulary.push(...topicConfig.keywords);
    }

    return [...new Set(baseVocabulary)]; // Eliminar duplicados
  }

  private getWordContext(text: string, word: string): string {
    const index = text.toLowerCase().indexOf(word.toLowerCase());
    if (index === -1) return '';
    
    const start = Math.max(0, index - 30);
    const end = Math.min(text.length, index + word.length + 30);
    
    return text.substring(start, end);
  }

  private getWordDocumentFrequency(word: string): number {
    // Frecuencia de documento simplificada
    const commonWords = new Set(['el', 'la', 'de', 'que', 'y', 'en', 'un', 'es', 'se', 'no']);
    return commonWords.has(word) ? 800 : 50;
  }

  private calculateClusterCenter(embeddings: number[][]): number[] {
    if (embeddings.length === 0) return [];
    
    const dimensions = embeddings[0].length;
    const center = new Array(dimensions).fill(0);
    
    for (const embedding of embeddings) {
      for (let i = 0; i < dimensions; i++) {
        center[i] += embedding[i];
      }
    }
    
    for (let i = 0; i < dimensions; i++) {
      center[i] /= embeddings.length;
    }
    
    return center;
  }

  private async generateClusterLabel(verses: any[]): Promise<string> {
    const allTopics = [];
    
    for (const verse of verses) {
      const analysis = await this.analyzeText(verse.texto || verse.text || '');
      allTopics.push(...analysis.topics);
    }
    
    // Encontrar tema más común
    const topicCounts = new Map<string, number>();
    for (const topic of allTopics) {
      topicCounts.set(topic.topic, (topicCounts.get(topic.topic) || 0) + topic.probability);
    }
    
    let bestTopic = 'general';
    let maxScore = 0;
    
    for (const [topic, score] of topicCounts.entries()) {
      if (score > maxScore) {
        maxScore = score;
        bestTopic = topic;
      }
    }
    
    return bestTopic;
  }

  private calculateCoherenceScore(verses: any[]): number {
    // Simplificado: coherencia basada en longitud promedio y variabilidad
    if (verses.length === 0) return 0;
    
    const lengths = verses.map(v => (v.texto || v.text || '').length);
    const avgLength = lengths.reduce((a, b) => a + b, 0) / lengths.length;
    const variance = lengths.reduce((sum, len) => sum + Math.pow(len - avgLength, 2), 0) / lengths.length;
    
    // Coherencia alta = longitudes similares y reasonables
    return Math.max(0, 1 - (variance / (avgLength * avgLength)));
  }

  private calculateTopicSimilarity(topics1: any[], topics2: any[]): number {
    let similarity = 0;
    let totalWeight = 0;
    
    for (const topic1 of topics1) {
      for (const topic2 of topics2) {
        if (topic1.topic === topic2.topic) {
          const weight = Math.min(topic1.probability, topic2.probability);
          similarity += weight;
          totalWeight += weight;
        }
      }
    }
    
    return totalWeight > 0 ? similarity / totalWeight : 0;
  }

  private calculateComplementaryScore(analysis1: TextAnalysisResult, analysis2: TextAnalysisResult): number {
    // Complementario = diferentes temas pero mismo sentimiento
    const sentimentSimilarity = 1 - Math.abs(analysis1.sentiment.score - analysis2.sentiment.score);
    const topicDifference = 1 - this.calculateTopicSimilarity(analysis1.topics, analysis2.topics);
    
    return (sentimentSimilarity + topicDifference) / 2;
  }

  private calculateUserPreferenceScore(verse: any, userHistory: any[]): number {
    // Simplificado: score basado en frecuencia de temas en historial
    // En implementación real, usaríamos algoritmos de collaborative filtering
    return Math.random() * 0.8; // Placeholder
  }

  private getSharedTopics(topics1: any[], topics2: any[]): string[] {
    const shared = [];
    
    for (const topic1 of topics1) {
      for (const topic2 of topics2) {
        if (topic1.topic === topic2.topic && !shared.includes(topic1.topic)) {
          shared.push(topic1.topic);
        }
      }
    }
    
    return shared;
  }

  private generateExplanation(queryAnalysis: TextAnalysisResult, verseAnalysis: TextAnalysisResult): string {
    const sharedTopics = this.getSharedTopics(queryAnalysis.topics, verseAnalysis.topics);
    const sentimentMatch = Math.abs(queryAnalysis.sentiment.score - verseAnalysis.sentiment.score) < 0.3;
    
    let explanation = '';
    
    if (sharedTopics.length > 0) {
      explanation += `Temas compartidos: ${sharedTopics.join(', ')}. `;
    }
    
    if (sentimentMatch) {
      explanation += `Tono similar (${verseAnalysis.sentiment.label}). `;
    }
    
    return explanation || 'Relación semántica detectada.';
  }
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalMLEngine = new MLEngine();

// Exponer en window para debugging
if (typeof window !== 'undefined') {
  (window as any).mlEngine = globalMLEngine;
}

export default MLEngine;
