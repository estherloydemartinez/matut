/**
 * Sistema de Monitoreo de Performance
 * Tracking de Core Web Vitals y métricas personalizadas
 */

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface WebVitalsMetric {
  name: 'FCP' | 'LCP' | 'FID' | 'CLS' | 'TTFB' | 'INP';
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  delta: number;
  id: string;
  timestamp: number;
}

export interface CustomMetric {
  name: string;
  value: number;
  type: 'timing' | 'counter' | 'gauge' | 'histogram';
  timestamp: number;
  tags?: Record<string, string>;
}

export interface PerformanceReport {
  url: string;
  timestamp: number;
  vitals: WebVitalsMetric[];
  customMetrics: CustomMetric[];
  resourceTiming: PerformanceResourceTiming[];
  navigationTiming: PerformanceNavigationTiming | null;
  memoryInfo?: any;
  connectionInfo?: any;
}

export interface PerformanceThresholds {
  FCP: { good: number; poor: number };
  LCP: { good: number; poor: number };
  FID: { good: number; poor: number };
  CLS: { good: number; poor: number };
  TTFB: { good: number; poor: number };
}

// =====================================================================
// CONFIGURACIÓN DE THRESHOLDS
// =====================================================================

export const DEFAULT_THRESHOLDS: PerformanceThresholds = {
  FCP: { good: 1800, poor: 3000 },
  LCP: { good: 2500, poor: 4000 },
  FID: { good: 100, poor: 300 },
  CLS: { good: 0.1, poor: 0.25 },
  TTFB: { good: 800, poor: 1800 }
};

// =====================================================================
// PERFORMANCE MONITOR PRINCIPAL
// =====================================================================

export class PerformanceMonitor {
  private vitalsCache = new Map<string, WebVitalsMetric>();
  private customMetrics: CustomMetric[] = [];
  private observers: PerformanceObserver[] = [];
  private isInitialized = false;
  private reportCallback?: (report: PerformanceReport) => void;

  constructor() {
    this.initialize();
  }

  private initialize(): void {
    if (this.isInitialized || typeof window === 'undefined') return;

    try {
      this.setupWebVitalsTracking();
      this.setupResourceTimingObserver();
      this.setupLongTaskObserver();
      this.setupLayoutShiftObserver();
      this.setupNavigationObserver();
      
      this.isInitialized = true;
      console.log('Performance Monitor initialized');
    } catch (error) {
      console.error('Error initializing Performance Monitor:', error);
    }
  }

  // =====================================================================
  // WEB VITALS TRACKING
  // =====================================================================

  private setupWebVitalsTracking(): void {
    // First Contentful Paint (FCP)
    this.observePerformanceEntry('paint', (entries) => {
      const fcpEntry = entries.find(entry => entry.name === 'first-contentful-paint');
      if (fcpEntry) {
        this.recordWebVital('FCP', fcpEntry.startTime);
      }
    });

    // Largest Contentful Paint (LCP)
    this.observePerformanceEntry('largest-contentful-paint', (entries) => {
      const lcpEntry = entries[entries.length - 1];
      if (lcpEntry) {
        this.recordWebVital('LCP', lcpEntry.startTime);
      }
    });

    // First Input Delay (FID)
    this.observePerformanceEntry('first-input', (entries) => {
      const fidEntry = entries[0];
      if (fidEntry) {
        const fid = fidEntry.processingStart - fidEntry.startTime;
        this.recordWebVital('FID', fid);
      }
    });

    // Time to First Byte (TTFB)
    if ('navigation' in performance) {
      const navTiming = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      if (navTiming) {
        const ttfb = navTiming.responseStart - navTiming.requestStart;
        this.recordWebVital('TTFB', ttfb);
      }
    }
  }

  private setupLayoutShiftObserver(): void {
    if (!('PerformanceObserver' in window)) return;

    let clsValue = 0;
    let sessionValue = 0;
    let sessionEntries: PerformanceEntry[] = [];

    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (!(entry as any).hadRecentInput) {
          const firstSessionEntry = sessionEntries[0];
          const lastSessionEntry = sessionEntries[sessionEntries.length - 1];

          if (sessionValue && 
              entry.startTime - lastSessionEntry.startTime < 1000 &&
              entry.startTime - firstSessionEntry.startTime < 5000) {
            sessionValue += (entry as any).value;
            sessionEntries.push(entry);
          } else {
            sessionValue = (entry as any).value;
            sessionEntries = [entry];
          }

          if (sessionValue > clsValue) {
            clsValue = sessionValue;
            this.recordWebVital('CLS', clsValue);
          }
        }
      }
    });

    observer.observe({ type: 'layout-shift', buffered: true });
    this.observers.push(observer);
  }

  private setupLongTaskObserver(): void {
    if (!('PerformanceObserver' in window)) return;

    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        this.recordCustomMetric('long-task', entry.duration, 'timing', {
          entryType: entry.entryType,
          startTime: entry.startTime.toString()
        });
      }
    });

    try {
      observer.observe({ type: 'longtask', buffered: true });
      this.observers.push(observer);
    } catch (e) {
      // Long task observer no soportado
    }
  }

  private setupResourceTimingObserver(): void {
    if (!('PerformanceObserver' in window)) return;

    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        const resource = entry as PerformanceResourceTiming;
        
        // Métricas de recursos
        this.recordCustomMetric(`resource-${this.getResourceType(resource)}`, resource.duration, 'timing', {
          name: resource.name,
          size: resource.transferSize?.toString() || '0'
        });

        // Detectar recursos lentos
        if (resource.duration > 1000) {
          this.recordCustomMetric('slow-resource', resource.duration, 'timing', {
            name: resource.name,
            type: this.getResourceType(resource)
          });
        }
      }
    });

    observer.observe({ type: 'resource', buffered: true });
    this.observers.push(observer);
  }

  private setupNavigationObserver(): void {
    if (!('PerformanceObserver' in window)) return;

    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        const nav = entry as PerformanceNavigationTiming;
        
        // Métricas de navegación
        this.recordCustomMetric('dns-lookup', nav.domainLookupEnd - nav.domainLookupStart, 'timing');
        this.recordCustomMetric('tcp-connect', nav.connectEnd - nav.connectStart, 'timing');
        this.recordCustomMetric('dom-interactive', nav.domInteractive - nav.navigationStart, 'timing');
        this.recordCustomMetric('dom-complete', nav.domComplete - nav.navigationStart, 'timing');
        this.recordCustomMetric('load-complete', nav.loadEventEnd - nav.navigationStart, 'timing');
      }
    });

    observer.observe({ type: 'navigation', buffered: true });
    this.observers.push(observer);
  }

  private observePerformanceEntry(type: string, callback: (entries: PerformanceEntry[]) => void): void {
    if (!('PerformanceObserver' in window)) return;

    const observer = new PerformanceObserver((list) => {
      callback(list.getEntries());
    });

    try {
      observer.observe({ type, buffered: true });
      this.observers.push(observer);
    } catch (e) {
      console.warn(`Performance observer for ${type} not supported`);
    }
  }

  // =====================================================================
  // MÉTRICA RECORDING
  // =====================================================================

  private recordWebVital(name: WebVitalsMetric['name'], value: number): void {
    const thresholds = DEFAULT_THRESHOLDS[name];
    let rating: WebVitalsMetric['rating'] = 'good';
    
    if (thresholds) {
      if (value > thresholds.poor) {
        rating = 'poor';
      } else if (value > thresholds.good) {
        rating = 'needs-improvement';
      }
    }

    const metric: WebVitalsMetric = {
      name,
      value,
      rating,
      delta: value,
      id: this.generateId(),
      timestamp: Date.now()
    };

    this.vitalsCache.set(name, metric);
    this.emitMetric('vital', metric);

    // Reportar métricas críticas inmediatamente
    if (rating === 'poor') {
      console.warn(`Poor ${name} detected:`, value);
    }
  }

  recordCustomMetric(name: string, value: number, type: CustomMetric['type'] = 'timing', tags?: Record<string, string>): void {
    const metric: CustomMetric = {
      name,
      value,
      type,
      timestamp: Date.now(),
      tags
    };

    this.customMetrics.push(metric);
    this.emitMetric('custom', metric);

    // Mantener solo las últimas 1000 métricas en memoria
    if (this.customMetrics.length > 1000) {
      this.customMetrics = this.customMetrics.slice(-1000);
    }
  }

  // =====================================================================
  // MEMORY & DEVICE MONITORING
  // =====================================================================

  getMemoryInfo(): any {
    if ('memory' in performance) {
      return {
        usedJSHeapSize: (performance as any).memory.usedJSHeapSize,
        totalJSHeapSize: (performance as any).memory.totalJSHeapSize,
        jsHeapSizeLimit: (performance as any).memory.jsHeapSizeLimit
      };
    }
    return null;
  }

  getConnectionInfo(): any {
    if ('connection' in navigator) {
      const conn = (navigator as any).connection;
      return {
        effectiveType: conn.effectiveType,
        downlink: conn.downlink,
        rtt: conn.rtt,
        saveData: conn.saveData
      };
    }
    return null;
  }

  // =====================================================================
  // REPORTING
  // =====================================================================

  generateReport(): PerformanceReport {
    return {
      url: window.location.href,
      timestamp: Date.now(),
      vitals: Array.from(this.vitalsCache.values()),
      customMetrics: [...this.customMetrics],
      resourceTiming: performance.getEntriesByType('resource') as PerformanceResourceTiming[],
      navigationTiming: performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming || null,
      memoryInfo: this.getMemoryInfo(),
      connectionInfo: this.getConnectionInfo()
    };
  }

  setReportCallback(callback: (report: PerformanceReport) => void): void {
    this.reportCallback = callback;
  }

  sendReport(): void {
    if (this.reportCallback) {
      const report = this.generateReport();
      this.reportCallback(report);
    }
  }

  // =====================================================================
  // UTILIDADES
  // =====================================================================

  private getResourceType(resource: PerformanceResourceTiming): string {
    const url = new URL(resource.name);
    const extension = url.pathname.split('.').pop()?.toLowerCase();
    
    if (['js', 'mjs'].includes(extension || '')) return 'script';
    if (['css'].includes(extension || '')) return 'stylesheet';
    if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(extension || '')) return 'image';
    if (['woff', 'woff2', 'ttf', 'otf'].includes(extension || '')) return 'font';
    if (resource.initiatorType === 'fetch' || resource.initiatorType === 'xmlhttprequest') return 'api';
    
    return 'other';
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private emitMetric(type: string, metric: any): void {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('performance-metric', {
        detail: { type, metric }
      }));
    }
  }

  // =====================================================================
  // LIFECYCLE
  // =====================================================================

  destroy(): void {
    this.observers.forEach(observer => observer.disconnect());
    this.observers = [];
    this.vitalsCache.clear();
    this.customMetrics = [];
    this.isInitialized = false;
  }
}

// =====================================================================
// PERFORMANCE UTILITIES
// =====================================================================

export class PerformanceUtils {
  static measureFunction<T>(fn: () => T, name: string): T {
    const start = performance.now();
    const result = fn();
    const duration = performance.now() - start;
    
    globalPerformanceMonitor.recordCustomMetric(`function-${name}`, duration, 'timing');
    return result;
  }

  static async measureAsyncFunction<T>(fn: () => Promise<T>, name: string): Promise<T> {
    const start = performance.now();
    const result = await fn();
    const duration = performance.now() - start;
    
    globalPerformanceMonitor.recordCustomMetric(`async-function-${name}`, duration, 'timing');
    return result;
  }

  static measureComponentRender(componentName: string): () => void {
    const start = performance.now();
    
    return () => {
      const duration = performance.now() - start;
      globalPerformanceMonitor.recordCustomMetric(`component-render-${componentName}`, duration, 'timing');
    };
  }

  static debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number,
    immediate: boolean = false
  ): T {
    let timeout: NodeJS.Timeout | null = null;
    
    return ((...args: any[]) => {
      const later = () => {
        timeout = null;
        if (!immediate) func(...args);
      };
      
      const callNow = immediate && !timeout;
      
      if (timeout) clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      
      if (callNow) func(...args);
    }) as T;
  }

  static throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
  ): T {
    let inThrottle: boolean = false;
    
    return ((...args: any[]) => {
      if (!inThrottle) {
        func(...args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    }) as T;
  }
}

// =====================================================================
// REACT HOOKS
// =====================================================================

export function usePerformanceMetric(metricName: string) {
  const measureStart = (): number => performance.now();
  
  const measureEnd = (startTime: number, tags?: Record<string, string>): void => {
    const duration = performance.now() - startTime;
    globalPerformanceMonitor.recordCustomMetric(metricName, duration, 'timing', tags);
  };

  return { measureStart, measureEnd };
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalPerformanceMonitor = new PerformanceMonitor();

// Configurar reporte automático
if (typeof window !== 'undefined') {
  // Enviar reporte cuando la página se está descargando
  window.addEventListener('beforeunload', () => {
    globalPerformanceMonitor.sendReport();
  });

  // Enviar reporte cada 30 segundos
  setInterval(() => {
    globalPerformanceMonitor.sendReport();
  }, 30000);

  // Exponer en window para debugging
  (window as any).performanceMonitor = globalPerformanceMonitor;
}

// =====================================================================
// EXPORTS
// =====================================================================

export default PerformanceMonitor;
