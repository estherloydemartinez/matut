/**
 * Sistema de Gestión de Contenido Generado por Usuarios
 * Moderación, calificaciones, biblioteca de recursos y marketplace
 */

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

export interface UserContent {
  id: string;
  type: 'course' | 'lesson' | 'article' | 'discussion' | 'resource' | 'video' | 'audio';
  title: string;
  description: string;
  content: any;
  authorId: string;
  authorName: string;
  tags: string[];
  category: string;
  subcategory?: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  visibility: 'public' | 'community' | 'private' | 'premium';
  license: 'free' | 'paid' | 'donation';
  price?: number;
  currency?: string;
  
  // Metadatos
  createdDate: Date;
  lastModified: Date;
  publishedDate?: Date;
  version: string;
  language: string;
  duration?: number; // en minutos
  
  // Engagement
  views: number;
  downloads: number;
  likes: number;
  shares: number;
  bookmarks: number;
  
  // Calificaciones y reseñas
  ratings: ContentRating[];
  averageRating: number;
  totalRatings: number;
  reviews: ContentReview[];
  
  // Estado y moderación
  status: 'draft' | 'pending' | 'approved' | 'rejected' | 'archived';
  moderation: ModerationInfo;
  flags: ContentFlag[];
  
  // SEO y descubrimiento
  keywords: string[];
  thumbnail?: string;
  preview?: string;
  relatedContent: string[];
  
  // Analytics
  analytics: ContentAnalytics;
}

export interface ContentRating {
  userId: string;
  rating: number; // 1-5
  timestamp: Date;
  helpful: boolean;
}

export interface ContentReview {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  title: string;
  content: string;
  timestamp: Date;
  helpful: number;
  reported: number;
  verified: boolean;
  response?: AuthorResponse;
}

export interface AuthorResponse {
  content: string;
  timestamp: Date;
}

export interface ModerationInfo {
  status: 'pending' | 'approved' | 'rejected' | 'flagged';
  reviewedBy?: string;
  reviewDate?: Date;
  reason?: string;
  autoModeration: AutoModerationResult;
  manualReview?: ManualReviewResult;
}

export interface AutoModerationResult {
  score: number;
  issues: string[];
  confidence: number;
  recommendations: string[];
}

export interface ManualReviewResult {
  approved: boolean;
  feedback: string;
  requirements: string[];
}

export interface ContentFlag {
  id: string;
  userId: string;
  type: 'spam' | 'inappropriate' | 'copyright' | 'misleading' | 'harassment' | 'other';
  reason: string;
  timestamp: Date;
  status: 'pending' | 'resolved' | 'dismissed';
}

export interface ContentAnalytics {
  dailyViews: { date: string; views: number }[];
  topReferrers: { source: string; count: number }[];
  userEngagement: {
    averageTimeSpent: number;
    completionRate: number;
    returnRate: number;
  };
  demographics: {
    ageGroups: { range: string; percentage: number }[];
    locations: { country: string; percentage: number }[];
  };
}

export interface ContentLibrary {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  isPublic: boolean;
  items: LibraryItem[];
  collaborators: string[];
  tags: string[];
  createdDate: Date;
  lastModified: Date;
}

export interface LibraryItem {
  contentId: string;
  addedDate: Date;
  notes?: string;
  progress?: number;
  rating?: number;
}

export interface ContentMarketplace {
  featuredContent: UserContent[];
  categories: MarketplaceCategory[];
  trending: UserContent[];
  topRated: UserContent[];
  newReleases: UserContent[];
  freeContent: UserContent[];
  sales: MarketplaceSale[];
}

export interface MarketplaceCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  subcategories: string[];
  contentCount: number;
}

export interface MarketplaceSale {
  contentId: string;
  originalPrice: number;
  salePrice: number;
  discount: number;
  startDate: Date;
  endDate: Date;
  reason: string;
}

export interface ContentRecommendation {
  contentId: string;
  score: number;
  reason: string;
  type: 'similar' | 'author' | 'community' | 'trending' | 'personalized';
}

// =====================================================================
// SISTEMA DE GESTIÓN DE CONTENIDO
// =====================================================================

export class ContentManagement {
  private content: Map<string, UserContent> = new Map();
  private libraries: Map<string, ContentLibrary> = new Map();
  private marketplace: ContentMarketplace;
  private moderationQueue: string[] = [];
  
  private eventEmitter: EventTarget = new EventTarget();
  private isInitialized: boolean = false;

  constructor() {
    this.marketplace = this.initializeMarketplace();
    this.initialize();
  }

  // =====================================================================
  // INICIALIZACIÓN
  // =====================================================================

  private async initialize(): Promise<void> {
    try {
      await this.loadMockContent();
      this.setupModerationSystem();
      this.startPeriodicTasks();
      
      this.isInitialized = true;
      console.log('Content Management System initialized');
    } catch (error) {
      console.error('Error initializing content management:', error);
    }
  }

  private async loadMockContent(): Promise<void> {
    const mockContent: UserContent[] = [
      {
        id: 'content1',
        type: 'course',
        title: 'Introducción a la Hermenéutica Bíblica',
        description: 'Curso completo sobre interpretación bíblica para principiantes',
        content: {
          lessons: [
            { title: 'Principios básicos', duration: 30 },
            { title: 'Contexto histórico', duration: 45 },
            { title: 'Géneros literarios', duration: 35 }
          ]
        },
        authorId: 'user1',
        authorName: 'Pastor Martínez',
        tags: ['hermenéutica', 'interpretación', 'biblia'],
        category: 'Estudios Bíblicos',
        subcategory: 'Hermenéutica',
        difficulty: 'beginner',
        visibility: 'public',
        license: 'free',
        createdDate: new Date('2024-01-15'),
        lastModified: new Date('2024-02-01'),
        publishedDate: new Date('2024-01-20'),
        version: '1.2',
        language: 'español',
        duration: 110,
        views: 1247,
        downloads: 89,
        likes: 156,
        shares: 23,
        bookmarks: 67,
        ratings: [],
        averageRating: 4.6,
        totalRatings: 34,
        reviews: [],
        status: 'approved',
        moderation: {
          status: 'approved',
          reviewedBy: 'moderator1',
          reviewDate: new Date('2024-01-18'),
          autoModeration: {
            score: 0.95,
            issues: [],
            confidence: 0.98,
            recommendations: ['approved']
          }
        },
        flags: [],
        keywords: ['hermenéutica', 'biblia', 'interpretación', 'curso'],
        thumbnail: '/images/hermeneutica-course.jpg',
        relatedContent: ['content2', 'content3'],
        analytics: {
          dailyViews: [],
          topReferrers: [],
          userEngagement: {
            averageTimeSpent: 45,
            completionRate: 0.78,
            returnRate: 0.65
          },
          demographics: {
            ageGroups: [],
            locations: []
          }
        }
      },
      {
        id: 'content2',
        type: 'article',
        title: 'La Importancia de la Oración en la Vida Cristiana',
        description: 'Reflexión profunda sobre el papel de la oración en el crecimiento espiritual',
        content: {
          body: 'Contenido del artículo sobre oración...',
          references: ['Mateo 6:9-13', '1 Tesalonicenses 5:17', 'Lucas 11:1-4']
        },
        authorId: 'user2',
        authorName: 'María González',
        tags: ['oración', 'espiritualidad', 'vida cristiana'],
        category: 'Vida Espiritual',
        subcategory: 'Oración',
        difficulty: 'intermediate',
        visibility: 'public',
        license: 'free',
        createdDate: new Date('2024-02-10'),
        lastModified: new Date('2024-02-12'),
        publishedDate: new Date('2024-02-11'),
        version: '1.0',
        language: 'español',
        duration: 15,
        views: 892,
        downloads: 45,
        likes: 98,
        shares: 34,
        bookmarks: 28,
        ratings: [],
        averageRating: 4.3,
        totalRatings: 22,
        reviews: [],
        status: 'approved',
        moderation: {
          status: 'approved',
          autoModeration: {
            score: 0.92,
            issues: [],
            confidence: 0.96,
            recommendations: ['approved']
          }
        },
        flags: [],
        keywords: ['oración', 'espiritualidad', 'cristiano'],
        relatedContent: ['content1'],
        analytics: {
          dailyViews: [],
          topReferrers: [],
          userEngagement: {
            averageTimeSpent: 12,
            completionRate: 0.85,
            returnRate: 0.43
          },
          demographics: {
            ageGroups: [],
            locations: []
          }
        }
      }
    ];

    for (const content of mockContent) {
      this.content.set(content.id, content);
    }
  }

  private initializeMarketplace(): ContentMarketplace {
    return {
      featuredContent: [],
      categories: [
        {
          id: 'biblical-studies',
          name: 'Estudios Bíblicos',
          description: 'Cursos y recursos para el estudio profundo de la Biblia',
          icon: '📚',
          subcategories: ['Hermenéutica', 'Exégesis', 'Teología Bíblica'],
          contentCount: 0
        },
        {
          id: 'spiritual-life',
          name: 'Vida Espiritual',
          description: 'Recursos para el crecimiento espiritual personal',
          icon: '🙏',
          subcategories: ['Oración', 'Devoción', 'Disciplinas Espirituales'],
          contentCount: 0
        },
        {
          id: 'theology',
          name: 'Teología',
          description: 'Estudios teológicos sistemáticos y doctrinales',
          icon: '⛪',
          subcategories: ['Sistemática', 'Histórica', 'Práctica'],
          contentCount: 0
        }
      ],
      trending: [],
      topRated: [],
      newReleases: [],
      freeContent: [],
      sales: []
    };
  }

  private setupModerationSystem(): void {
    // Configurar sistema de moderación automática
    setInterval(() => {
      this.processModerationQueue();
    }, 30000); // Cada 30 segundos
  }

  private startPeriodicTasks(): void {
    // Tareas periódicas cada hora
    setInterval(() => {
      this.updateAnalytics();
      this.updateRecommendations();
      this.processFlags();
    }, 60 * 60 * 1000);
  }

  // =====================================================================
  // CREACIÓN Y GESTIÓN DE CONTENIDO
  // =====================================================================

  async createContent(authorId: string, contentData: Partial<UserContent>): Promise<UserContent> {
    const content: UserContent = {
      id: this.generateId(),
      type: contentData.type || 'article',
      title: contentData.title || '',
      description: contentData.description || '',
      content: contentData.content || {},
      authorId,
      authorName: contentData.authorName || 'Usuario',
      tags: contentData.tags || [],
      category: contentData.category || 'General',
      subcategory: contentData.subcategory,
      difficulty: contentData.difficulty || 'beginner',
      visibility: contentData.visibility || 'draft',
      license: contentData.license || 'free',
      price: contentData.price,
      currency: contentData.currency || 'USD',
      
      createdDate: new Date(),
      lastModified: new Date(),
      version: '1.0',
      language: contentData.language || 'español',
      duration: contentData.duration,
      
      views: 0,
      downloads: 0,
      likes: 0,
      shares: 0,
      bookmarks: 0,
      
      ratings: [],
      averageRating: 0,
      totalRatings: 0,
      reviews: [],
      
      status: 'draft',
      moderation: {
        status: 'pending',
        autoModeration: {
          score: 0,
          issues: [],
          confidence: 0,
          recommendations: []
        }
      },
      flags: [],
      
      keywords: contentData.keywords || [],
      thumbnail: contentData.thumbnail,
      preview: contentData.preview,
      relatedContent: [],
      
      analytics: {
        dailyViews: [],
        topReferrers: [],
        userEngagement: {
          averageTimeSpent: 0,
          completionRate: 0,
          returnRate: 0
        },
        demographics: {
          ageGroups: [],
          locations: []
        }
      }
    };

    this.content.set(content.id, content);
    
    // Trigger auto-moderation if publishing
    if (contentData.visibility !== 'draft') {
      await this.triggerAutoModeration(content.id);
    }

    this.emitEvent('content-created', { content });
    return content;
  }

  async updateContent(contentId: string, updates: Partial<UserContent>): Promise<boolean> {
    const content = this.content.get(contentId);
    if (!content) return false;

    // Actualizar campos
    Object.assign(content, updates);
    content.lastModified = new Date();
    
    // Incrementar versión si hay cambios significativos
    if (updates.content || updates.title || updates.description) {
      const [major, minor] = content.version.split('.').map(Number);
      content.version = `${major}.${minor + 1}`;
    }

    // Re-trigger moderation si es necesario
    if (updates.visibility && updates.visibility !== 'draft') {
      await this.triggerAutoModeration(contentId);
    }

    this.content.set(contentId, content);
    this.emitEvent('content-updated', { contentId, updates });
    
    return true;
  }

  async publishContent(contentId: string): Promise<boolean> {
    const content = this.content.get(contentId);
    if (!content) return false;

    content.status = 'pending';
    content.publishedDate = new Date();
    content.visibility = 'public';

    await this.triggerAutoModeration(contentId);
    
    this.content.set(contentId, content);
    this.emitEvent('content-published', { contentId });
    
    return true;
  }

  // =====================================================================
  // SISTEMA DE MODERACIÓN
  // =====================================================================

  private async triggerAutoModeration(contentId: string): Promise<void> {
    const content = this.content.get(contentId);
    if (!content) return;

    const result = await this.performAutoModeration(content);
    content.moderation.autoModeration = result;

    if (result.score >= 0.8 && result.issues.length === 0) {
      content.moderation.status = 'approved';
      content.status = 'approved';
    } else if (result.score < 0.3 || result.issues.length > 3) {
      content.moderation.status = 'rejected';
      content.status = 'rejected';
    } else {
      content.moderation.status = 'flagged';
      this.moderationQueue.push(contentId);
    }

    this.content.set(contentId, content);
  }

  private async performAutoModeration(content: UserContent): Promise<AutoModerationResult> {
    let score = 1.0;
    const issues: string[] = [];
    const recommendations: string[] = [];

    // Verificar contenido inapropiado
    const inappropriateWords = ['spam', 'fake', 'scam'];
    const contentText = JSON.stringify(content.content).toLowerCase();
    
    for (const word of inappropriateWords) {
      if (contentText.includes(word)) {
        score -= 0.3;
        issues.push(`Contenido potencialmente inapropiado: ${word}`);
      }
    }

    // Verificar calidad del contenido
    if (content.description.length < 50) {
      score -= 0.1;
      issues.push('Descripción muy breve');
      recommendations.push('Ampliar la descripción del contenido');
    }

    if (content.tags.length < 3) {
      score -= 0.05;
      recommendations.push('Agregar más etiquetas para mejor descubrimiento');
    }

    // Verificar completitud
    if (!content.thumbnail) {
      score -= 0.05;
      recommendations.push('Agregar imagen de portada');
    }

    const confidence = Math.max(0.7, 1 - (issues.length * 0.1));

    return {
      score: Math.max(0, score),
      issues,
      confidence,
      recommendations
    };
  }

  private processModerationQueue(): void {
    // Procesar elementos en cola de moderación
    while (this.moderationQueue.length > 0) {
      const contentId = this.moderationQueue.shift();
      if (contentId) {
        this.reviewContent(contentId);
      }
    }
  }

  private async reviewContent(contentId: string): Promise<void> {
    const content = this.content.get(contentId);
    if (!content) return;

    // Simulación de revisión manual
    const shouldApprove = Math.random() > 0.3; // 70% de probabilidad de aprobación

    if (shouldApprove) {
      content.moderation.status = 'approved';
      content.status = 'approved';
      content.moderation.manualReview = {
        approved: true,
        feedback: 'Contenido aprobado tras revisión manual',
        requirements: []
      };
    } else {
      content.moderation.status = 'rejected';
      content.status = 'rejected';
      content.moderation.manualReview = {
        approved: false,
        feedback: 'El contenido requiere mejoras antes de ser publicado',
        requirements: ['Mejorar descripción', 'Añadir referencias bíblicas']
      };
    }

    content.moderation.reviewedBy = 'system';
    content.moderation.reviewDate = new Date();

    this.content.set(contentId, content);
    this.emitEvent('content-moderated', { contentId, approved: shouldApprove });
  }

  // =====================================================================
  // CALIFICACIONES Y RESEÑAS
  // =====================================================================

  async rateContent(contentId: string, userId: string, rating: number): Promise<boolean> {
    const content = this.content.get(contentId);
    if (!content || rating < 1 || rating > 5) return false;

    // Remover calificación existente del usuario
    content.ratings = content.ratings.filter(r => r.userId !== userId);

    // Agregar nueva calificación
    content.ratings.push({
      userId,
      rating,
      timestamp: new Date(),
      helpful: false
    });

    // Recalcular promedio
    content.averageRating = content.ratings.reduce((sum, r) => sum + r.rating, 0) / content.ratings.length;
    content.totalRatings = content.ratings.length;

    this.content.set(contentId, content);
    this.emitEvent('content-rated', { contentId, userId, rating });

    return true;
  }

  async addReview(contentId: string, userId: string, reviewData: Partial<ContentReview>): Promise<ContentReview> {
    const content = this.content.get(contentId);
    if (!content) throw new Error('Content not found');

    const review: ContentReview = {
      id: this.generateId(),
      userId,
      userName: reviewData.userName || 'Usuario',
      rating: reviewData.rating || 5,
      title: reviewData.title || '',
      content: reviewData.content || '',
      timestamp: new Date(),
      helpful: 0,
      reported: 0,
      verified: false
    };

    content.reviews.push(review);
    this.content.set(contentId, content);

    this.emitEvent('review-added', { contentId, review });
    return review;
  }

  async markReviewHelpful(contentId: string, reviewId: string, userId: string): Promise<boolean> {
    const content = this.content.get(contentId);
    if (!content) return false;

    const review = content.reviews.find(r => r.id === reviewId);
    if (!review) return false;

    review.helpful++;
    this.content.set(contentId, content);

    return true;
  }

  // =====================================================================
  // SISTEMA DE FLAGS Y REPORTES
  // =====================================================================

  async flagContent(contentId: string, userId: string, flagData: Partial<ContentFlag>): Promise<boolean> {
    const content = this.content.get(contentId);
    if (!content) return false;

    const flag: ContentFlag = {
      id: this.generateId(),
      userId,
      type: flagData.type || 'other',
      reason: flagData.reason || '',
      timestamp: new Date(),
      status: 'pending'
    };

    content.flags.push(flag);
    this.content.set(contentId, content);

    // Auto-suspender si hay muchos flags
    if (content.flags.length >= 5) {
      content.status = 'rejected';
      content.moderation.status = 'flagged';
    }

    this.emitEvent('content-flagged', { contentId, flag });
    return true;
  }

  private processFlags(): void {
    // Procesar flags pendientes
    for (const [contentId, content] of this.content.entries()) {
      const pendingFlags = content.flags.filter(f => f.status === 'pending');
      
      if (pendingFlags.length > 0) {
        // Revisar flags automáticamente
        pendingFlags.forEach(flag => {
          // Simulación de procesamiento
          flag.status = Math.random() > 0.5 ? 'resolved' : 'dismissed';
        });
        
        this.content.set(contentId, content);
      }
    }
  }

  // =====================================================================
  // BIBLIOTECA DE CONTENIDO
  // =====================================================================

  async createLibrary(userId: string, libraryData: Partial<ContentLibrary>): Promise<ContentLibrary> {
    const library: ContentLibrary = {
      id: this.generateId(),
      name: libraryData.name || 'Mi Biblioteca',
      description: libraryData.description || '',
      ownerId: userId,
      isPublic: libraryData.isPublic || false,
      items: [],
      collaborators: libraryData.collaborators || [],
      tags: libraryData.tags || [],
      createdDate: new Date(),
      lastModified: new Date()
    };

    this.libraries.set(library.id, library);
    this.emitEvent('library-created', { library });

    return library;
  }

  async addToLibrary(libraryId: string, contentId: string, notes?: string): Promise<boolean> {
    const library = this.libraries.get(libraryId);
    const content = this.content.get(contentId);
    
    if (!library || !content) return false;

    // Verificar si ya está en la biblioteca
    if (library.items.some(item => item.contentId === contentId)) {
      return false;
    }

    const libraryItem: LibraryItem = {
      contentId,
      addedDate: new Date(),
      notes,
      progress: 0,
      rating: undefined
    };

    library.items.push(libraryItem);
    library.lastModified = new Date();

    this.libraries.set(libraryId, library);
    this.emitEvent('content-added-to-library', { libraryId, contentId });

    return true;
  }

  async updateLibraryItemProgress(libraryId: string, contentId: string, progress: number): Promise<boolean> {
    const library = this.libraries.get(libraryId);
    if (!library) return false;

    const item = library.items.find(i => i.contentId === contentId);
    if (!item) return false;

    item.progress = Math.max(0, Math.min(100, progress));
    library.lastModified = new Date();

    this.libraries.set(libraryId, library);
    return true;
  }

  // =====================================================================
  // RECOMENDACIONES Y DESCUBRIMIENTO
  // =====================================================================

  async getRecommendations(userId: string, contentId?: string): Promise<ContentRecommendation[]> {
    const recommendations: ContentRecommendation[] = [];
    const allContent = Array.from(this.content.values()).filter(c => c.status === 'approved');

    if (contentId) {
      // Recomendaciones basadas en contenido específico
      const currentContent = this.content.get(contentId);
      if (currentContent) {
        // Contenido similar por tags
        const similarContent = allContent.filter(c => 
          c.id !== contentId && 
          c.tags.some(tag => currentContent.tags.includes(tag))
        );

        similarContent.forEach(content => {
          const commonTags = content.tags.filter(tag => currentContent.tags.includes(tag));
          const score = commonTags.length / Math.max(content.tags.length, currentContent.tags.length);
          
          recommendations.push({
            contentId: content.id,
            score,
            reason: `Temas similares: ${commonTags.slice(0, 2).join(', ')}`,
            type: 'similar'
          });
        });

        // Contenido del mismo autor
        const authorContent = allContent.filter(c => 
          c.authorId === currentContent.authorId && c.id !== contentId
        );

        authorContent.forEach(content => {
          recommendations.push({
            contentId: content.id,
            score: 0.7,
            reason: `Más contenido de ${content.authorName}`,
            type: 'author'
          });
        });
      }
    } else {
      // Recomendaciones generales
      const trending = allContent
        .sort((a, b) => b.views - a.views)
        .slice(0, 5);

      trending.forEach(content => {
        recommendations.push({
          contentId: content.id,
          score: content.views / 10000,
          reason: `Trending: ${content.views} vistas`,
          type: 'trending'
        });
      });

      const topRated = allContent
        .filter(c => c.totalRatings >= 5)
        .sort((a, b) => b.averageRating - a.averageRating)
        .slice(0, 5);

      topRated.forEach(content => {
        recommendations.push({
          contentId: content.id,
          score: content.averageRating / 5,
          reason: `Muy valorado: ${content.averageRating}/5 ⭐`,
          type: 'community'
        });
      });
    }

    return recommendations
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }

  private updateRecommendations(): void {
    // Actualizar recomendaciones generales del marketplace
    const allContent = Array.from(this.content.values()).filter(c => c.status === 'approved');

    // Trending (más vistas recientes)
    this.marketplace.trending = allContent
      .sort((a, b) => b.views - a.views)
      .slice(0, 10);

    // Top rated
    this.marketplace.topRated = allContent
      .filter(c => c.totalRatings >= 3)
      .sort((a, b) => b.averageRating - a.averageRating)
      .slice(0, 10);

    // New releases
    this.marketplace.newReleases = allContent
      .sort((a, b) => new Date(b.publishedDate || 0).getTime() - new Date(a.publishedDate || 0).getTime())
      .slice(0, 10);

    // Free content
    this.marketplace.freeContent = allContent
      .filter(c => c.license === 'free')
      .slice(0, 15);

    // Update category counts
    this.marketplace.categories.forEach(category => {
      category.contentCount = allContent.filter(c => c.category === category.name).length;
    });
  }

  // =====================================================================
  // ANALYTICS Y ESTADÍSTICAS
  // =====================================================================

  async trackView(contentId: string, userId?: string): Promise<void> {
    const content = this.content.get(contentId);
    if (!content) return;

    content.views++;
    
    // Track daily views
    const today = new Date().toISOString().split('T')[0];
    const todayView = content.analytics.dailyViews.find(dv => dv.date === today);
    
    if (todayView) {
      todayView.views++;
    } else {
      content.analytics.dailyViews.push({ date: today, views: 1 });
    }

    this.content.set(contentId, content);
  }

  async trackDownload(contentId: string, userId?: string): Promise<void> {
    const content = this.content.get(contentId);
    if (!content) return;

    content.downloads++;
    this.content.set(contentId, content);
  }

  async trackEngagement(contentId: string, timeSpent: number, completed: boolean): Promise<void> {
    const content = this.content.get(contentId);
    if (!content) return;

    const engagement = content.analytics.userEngagement;
    
    // Update average time spent (simple moving average)
    engagement.averageTimeSpent = (engagement.averageTimeSpent + timeSpent) / 2;
    
    // Update completion rate
    if (completed) {
      engagement.completionRate = (engagement.completionRate + 1) / 2;
    }

    this.content.set(contentId, content);
  }

  private updateAnalytics(): void {
    // Procesar analytics de todos los contenidos
    for (const [contentId, content] of this.content.entries()) {
      // Limpiar datos antiguos de analytics
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      content.analytics.dailyViews = content.analytics.dailyViews.filter(
        dv => new Date(dv.date) >= thirtyDaysAgo
      );
      
      this.content.set(contentId, content);
    }
  }

  // =====================================================================
  // UTILIDADES Y MÉTODOS AUXILIARES
  // =====================================================================

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private emitEvent(eventType: string, data: any): void {
    this.eventEmitter.dispatchEvent(new CustomEvent(eventType, { detail: data }));
  }

  // =====================================================================
  // MÉTODOS PÚBLICOS
  // =====================================================================

  getContent(contentId: string): UserContent | undefined {
    return this.content.get(contentId);
  }

  getAllContent(filters?: {
    category?: string;
    type?: string;
    status?: string;
    authorId?: string;
    difficulty?: string;
  }): UserContent[] {
    let content = Array.from(this.content.values());

    if (filters) {
      if (filters.category) {
        content = content.filter(c => c.category === filters.category);
      }
      if (filters.type) {
        content = content.filter(c => c.type === filters.type);
      }
      if (filters.status) {
        content = content.filter(c => c.status === filters.status);
      }
      if (filters.authorId) {
        content = content.filter(c => c.authorId === filters.authorId);
      }
      if (filters.difficulty) {
        content = content.filter(c => c.difficulty === filters.difficulty);
      }
    }

    return content;
  }

  getLibrary(libraryId: string): ContentLibrary | undefined {
    return this.libraries.get(libraryId);
  }

  getUserLibraries(userId: string): ContentLibrary[] {
    return Array.from(this.libraries.values()).filter(l => 
      l.ownerId === userId || l.collaborators.includes(userId)
    );
  }

  getMarketplace(): ContentMarketplace {
    return this.marketplace;
  }

  async searchContent(query: string, filters?: any): Promise<UserContent[]> {
    const allContent = this.getAllContent(filters);
    const searchTerms = query.toLowerCase().split(' ');

    return allContent.filter(content => {
      const searchableText = [
        content.title,
        content.description,
        ...content.tags,
        ...content.keywords,
        content.category,
        content.authorName
      ].join(' ').toLowerCase();

      return searchTerms.every(term => searchableText.includes(term));
    }).sort((a, b) => {
      // Score by relevance (simple implementation)
      const aScore = searchTerms.reduce((score, term) => {
        if (a.title.toLowerCase().includes(term)) score += 3;
        if (a.description.toLowerCase().includes(term)) score += 2;
        if (a.tags.some(tag => tag.toLowerCase().includes(term))) score += 1;
        return score;
      }, 0);

      const bScore = searchTerms.reduce((score, term) => {
        if (b.title.toLowerCase().includes(term)) score += 3;
        if (b.description.toLowerCase().includes(term)) score += 2;
        if (b.tags.some(tag => tag.toLowerCase().includes(term))) score += 1;
        return score;
      }, 0);

      return bScore - aScore;
    });
  }

  addEventListener(eventType: string, listener: EventListener): void {
    this.eventEmitter.addEventListener(eventType, listener);
  }

  removeEventListener(eventType: string, listener: EventListener): void {
    this.eventEmitter.removeEventListener(eventType, listener);
  }
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalContentManagement = new ContentManagement();

// Exponer en window para debugging
if (typeof window !== 'undefined') {
  (window as any).contentManagement = globalContentManagement;
}

export default ContentManagement;
