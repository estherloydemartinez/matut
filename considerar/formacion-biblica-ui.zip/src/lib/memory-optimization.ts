/**
 * Utilidades de Optimización de Memoria
 * Prevención de memory leaks y gestión eficiente de recursos
 */

// =====================================================================
// OBJECT POOL PATTERN
// =====================================================================

export class ObjectPool<T> {
  private pool: T[] = [];
  private createFn: () => T;
  private resetFn: (obj: T) => void;
  private maxSize: number;

  constructor(
    createFn: () => T,
    resetFn: (obj: T) => void,
    initialSize: number = 10,
    maxSize: number = 100
  ) {
    this.createFn = createFn;
    this.resetFn = resetFn;
    this.maxSize = maxSize;

    // Pre-crear objetos
    for (let i = 0; i < initialSize; i++) {
      this.pool.push(this.createFn());
    }
  }

  acquire(): T {
    const obj = this.pool.pop();
    if (obj) {
      return obj;
    }
    return this.createFn();
  }

  release(obj: T): void {
    if (this.pool.length < this.maxSize) {
      this.resetFn(obj);
      this.pool.push(obj);
    }
  }

  clear(): void {
    this.pool.length = 0;
  }

  getStats() {
    return {
      poolSize: this.pool.length,
      maxSize: this.maxSize
    };
  }
}

// =====================================================================
// MEMORY LEAK DETECTOR
// =====================================================================

export class MemoryLeakDetector {
  private listeners: Map<string, number> = new Map();
  private timers: Set<NodeJS.Timeout> = new Set();
  private intervals: Set<NodeJS.Timeout> = new Set();
  private observers: Set<any> = new Set();
  private subscriptions: Set<() => void> = new Set();

  // Tracking de event listeners
  trackEventListener(element: EventTarget, event: string, listener: EventListener): () => void {
    const key = `${element.constructor.name}-${event}`;
    this.listeners.set(key, (this.listeners.get(key) || 0) + 1);

    const cleanup = () => {
      element.removeEventListener(event, listener);
      const count = this.listeners.get(key) || 0;
      if (count > 1) {
        this.listeners.set(key, count - 1);
      } else {
        this.listeners.delete(key);
      }
    };

    this.subscriptions.add(cleanup);
    return cleanup;
  }

  // Tracking de timers
  trackTimeout(callback: () => void, delay: number): NodeJS.Timeout {
    const timer = setTimeout(() => {
      callback();
      this.timers.delete(timer);
    }, delay);

    this.timers.add(timer);
    return timer;
  }

  trackInterval(callback: () => void, delay: number): NodeJS.Timeout {
    const interval = setInterval(callback, delay);
    this.intervals.add(interval);
    return interval;
  }

  // Tracking de observers
  trackObserver(observer: any): void {
    this.observers.add(observer);
  }

  // Limpieza completa
  cleanup(): void {
    // Limpiar event listeners
    this.subscriptions.forEach(cleanup => {
      try {
        cleanup();
      } catch (error) {
        console.warn('Error cleaning up subscription:', error);
      }
    });
    this.subscriptions.clear();

    // Limpiar timers
    this.timers.forEach(timer => clearTimeout(timer));
    this.timers.clear();

    // Limpiar intervals
    this.intervals.forEach(interval => clearInterval(interval));
    this.intervals.clear();

    // Limpiar observers
    this.observers.forEach(observer => {
      try {
        if (observer.disconnect) observer.disconnect();
        if (observer.unobserve) observer.unobserve();
      } catch (error) {
        console.warn('Error cleaning up observer:', error);
      }
    });
    this.observers.clear();

    this.listeners.clear();
  }

  // Obtener estadísticas
  getStats() {
    return {
      listeners: Object.fromEntries(this.listeners),
      activeTimers: this.timers.size,
      activeIntervals: this.intervals.size,
      activeObservers: this.observers.size,
      activeSubscriptions: this.subscriptions.size
    };
  }

  // Detectar posibles leaks
  detectLeaks(): string[] {
    const warnings: string[] = [];

    if (this.timers.size > 50) {
      warnings.push(`Muchos timers activos: ${this.timers.size}`);
    }

    if (this.intervals.size > 20) {
      warnings.push(`Muchos intervals activos: ${this.intervals.size}`);
    }

    if (this.subscriptions.size > 100) {
      warnings.push(`Muchas suscripciones activas: ${this.subscriptions.size}`);
    }

    // Verificar listeners duplicados
    this.listeners.forEach((count, key) => {
      if (count > 10) {
        warnings.push(`Posible leak en listener: ${key} (${count} instancias)`);
      }
    });

    return warnings;
  }
}

// =====================================================================
// VIRTUAL SCROLLING
// =====================================================================

export interface VirtualScrollConfig {
  itemHeight: number;
  containerHeight: number;
  overscan: number; // Elementos extra a renderizar fuera de la vista
}

export class VirtualScrollManager {
  private config: VirtualScrollConfig;
  private scrollTop: number = 0;
  private totalItems: number = 0;

  constructor(config: VirtualScrollConfig) {
    this.config = config;
  }

  updateScroll(scrollTop: number): void {
    this.scrollTop = scrollTop;
  }

  updateItemCount(count: number): void {
    this.totalItems = count;
  }

  getVisibleRange(): { start: number; end: number; offset: number } {
    const { itemHeight, containerHeight, overscan } = this.config;
    
    const visibleStart = Math.floor(this.scrollTop / itemHeight);
    const visibleEnd = Math.min(
      visibleStart + Math.ceil(containerHeight / itemHeight),
      this.totalItems
    );

    const start = Math.max(0, visibleStart - overscan);
    const end = Math.min(this.totalItems, visibleEnd + overscan);
    const offset = start * itemHeight;

    return { start, end, offset };
  }

  getTotalHeight(): number {
    return this.totalItems * this.config.itemHeight;
  }
}

// =====================================================================
// WEAK REFERENCES MANAGER
// =====================================================================

export class WeakReferencesManager {
  private weakRefs: WeakRef<any>[] = [];
  private cleanupCallbacks: (() => void)[] = [];

  addWeakRef<T extends object>(obj: T, onFinalize?: () => void): WeakRef<T> {
    const weakRef = new WeakRef(obj);
    this.weakRefs.push(weakRef);

    if (onFinalize) {
      this.cleanupCallbacks.push(onFinalize);
    }

    return weakRef;
  }

  cleanup(): void {
    // Filtrar referencias que ya no existen
    let cleaned = 0;
    this.weakRefs = this.weakRefs.filter(ref => {
      if (ref.deref() === undefined) {
        cleaned++;
        return false;
      }
      return true;
    });

    if (cleaned > 0) {
      console.log(`Cleaned up ${cleaned} weak references`);
    }

    // Ejecutar callbacks de limpieza
    this.cleanupCallbacks.forEach(callback => {
      try {
        callback();
      } catch (error) {
        console.warn('Error in cleanup callback:', error);
      }
    });
    this.cleanupCallbacks = [];
  }

  getStats() {
    const alive = this.weakRefs.filter(ref => ref.deref() !== undefined).length;
    return {
      totalRefs: this.weakRefs.length,
      aliveRefs: alive,
      deadRefs: this.weakRefs.length - alive,
      pendingCallbacks: this.cleanupCallbacks.length
    };
  }
}

// =====================================================================
// EFFICIENT DATA STRUCTURES
// =====================================================================

export class LRUMap<K, V> extends Map<K, V> {
  private maxSize: number;

  constructor(maxSize: number = 1000) {
    super();
    this.maxSize = maxSize;
  }

  get(key: K): V | undefined {
    const value = super.get(key);
    if (value !== undefined) {
      // Mover al final (más reciente)
      this.delete(key);
      this.set(key, value);
    }
    return value;
  }

  set(key: K, value: V): this {
    if (this.has(key)) {
      this.delete(key);
    } else if (this.size >= this.maxSize) {
      // Eliminar el más antiguo (primer elemento)
      const firstKey = this.keys().next().value;
      this.delete(firstKey);
    }
    
    return super.set(key, value);
  }
}

export class BloomFilter {
  private bits: Uint8Array;
  private size: number;
  private hashCount: number;

  constructor(expectedElements: number, falsePositiveRate: number = 0.01) {
    this.size = Math.ceil(
      (-expectedElements * Math.log(falsePositiveRate)) / (Math.log(2) ** 2)
    );
    this.hashCount = Math.ceil((this.size / expectedElements) * Math.log(2));
    this.bits = new Uint8Array(Math.ceil(this.size / 8));
  }

  add(item: string): void {
    const hashes = this.getHashes(item);
    for (const hash of hashes) {
      const index = hash % this.size;
      const byteIndex = Math.floor(index / 8);
      const bitIndex = index % 8;
      this.bits[byteIndex] |= (1 << bitIndex);
    }
  }

  contains(item: string): boolean {
    const hashes = this.getHashes(item);
    for (const hash of hashes) {
      const index = hash % this.size;
      const byteIndex = Math.floor(index / 8);
      const bitIndex = index % 8;
      if (!(this.bits[byteIndex] & (1 << bitIndex))) {
        return false;
      }
    }
    return true;
  }

  private getHashes(item: string): number[] {
    const hashes: number[] = [];
    let hash1 = this.hash(item);
    let hash2 = this.hash(item + '1');

    for (let i = 0; i < this.hashCount; i++) {
      hashes.push(Math.abs(hash1 + i * hash2));
    }

    return hashes;
  }

  private hash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash;
  }
}

// =====================================================================
// MEMORY MONITORING
// =====================================================================

export class MemoryMonitor {
  private measurements: Array<{
    timestamp: number;
    used: number;
    total: number;
    limit: number;
  }> = [];

  private measurementInterval?: NodeJS.Timeout;

  startMonitoring(intervalMs: number = 10000): void {
    this.measurementInterval = setInterval(() => {
      this.takeMeasurement();
    }, intervalMs);
  }

  stopMonitoring(): void {
    if (this.measurementInterval) {
      clearInterval(this.measurementInterval);
      this.measurementInterval = undefined;
    }
  }

  takeMeasurement(): void {
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      this.measurements.push({
        timestamp: Date.now(),
        used: memory.usedJSHeapSize,
        total: memory.totalJSHeapSize,
        limit: memory.jsHeapSizeLimit
      });

      // Mantener solo las últimas 100 mediciones
      if (this.measurements.length > 100) {
        this.measurements = this.measurements.slice(-100);
      }

      // Detectar uso excesivo de memoria
      const usagePercentage = (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100;
      if (usagePercentage > 80) {
        console.warn(`High memory usage detected: ${usagePercentage.toFixed(1)}%`);
        this.suggestGarbageCollection();
      }
    }
  }

  private suggestGarbageCollection(): void {
    // Forzar garbage collection si está disponible (solo en desarrollo)
    if ('gc' in window && typeof (window as any).gc === 'function') {
      (window as any).gc();
    }
  }

  getMemoryTrend(): 'increasing' | 'stable' | 'decreasing' {
    if (this.measurements.length < 5) return 'stable';

    const recent = this.measurements.slice(-5);
    const trend = recent.reduce((acc, curr, index) => {
      if (index === 0) return acc;
      const prev = recent[index - 1];
      return acc + (curr.used - prev.used);
    }, 0);

    const threshold = 1024 * 1024; // 1MB
    if (trend > threshold) return 'increasing';
    if (trend < -threshold) return 'decreasing';
    return 'stable';
  }

  getCurrentMemoryInfo() {
    if ('memory' in performance) {
      const memory = (performance as any).memory;
      return {
        used: memory.usedJSHeapSize,
        total: memory.totalJSHeapSize,
        limit: memory.jsHeapSizeLimit,
        usagePercentage: (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100
      };
    }
    return null;
  }

  getStats() {
    return {
      measurementCount: this.measurements.length,
      isMonitoring: !!this.measurementInterval,
      trend: this.getMemoryTrend(),
      currentInfo: this.getCurrentMemoryInfo()
    };
  }
}

// =====================================================================
// REACT HOOKS PARA OPTIMIZACIÓN
// =====================================================================

export function useMemoryOptimization() {
  const leakDetector = React.useRef(new MemoryLeakDetector());
  const memoryMonitor = React.useRef(new MemoryMonitor());

  React.useEffect(() => {
    memoryMonitor.current.startMonitoring();
    
    return () => {
      memoryMonitor.current.stopMonitoring();
      leakDetector.current.cleanup();
    };
  }, []);

  const trackEventListener = React.useCallback(
    (element: EventTarget, event: string, listener: EventListener) => {
      return leakDetector.current.trackEventListener(element, event, listener);
    },
    []
  );

  const trackTimeout = React.useCallback(
    (callback: () => void, delay: number) => {
      return leakDetector.current.trackTimeout(callback, delay);
    },
    []
  );

  const getMemoryStats = React.useCallback(() => {
    return {
      leaks: leakDetector.current.getStats(),
      memory: memoryMonitor.current.getStats()
    };
  }, []);

  return {
    trackEventListener,
    trackTimeout,
    getMemoryStats
  };
}

export function useVirtualScroll<T>(
  items: T[],
  config: VirtualScrollConfig
) {
  const [scrollTop, setScrollTop] = React.useState(0);
  const virtualScroll = React.useRef(new VirtualScrollManager(config));

  React.useEffect(() => {
    virtualScroll.current.updateItemCount(items.length);
  }, [items.length]);

  React.useEffect(() => {
    virtualScroll.current.updateScroll(scrollTop);
  }, [scrollTop]);

  const visibleRange = React.useMemo(() => {
    return virtualScroll.current.getVisibleRange();
  }, [scrollTop, items.length]);

  const visibleItems = React.useMemo(() => {
    return items.slice(visibleRange.start, visibleRange.end);
  }, [items, visibleRange.start, visibleRange.end]);

  return {
    visibleItems,
    visibleRange,
    totalHeight: virtualScroll.current.getTotalHeight(),
    setScrollTop
  };
}

// =====================================================================
// INSTANCIAS GLOBALES
// =====================================================================

export const globalMemoryMonitor = new MemoryMonitor();
export const globalLeakDetector = new MemoryLeakDetector();
export const globalWeakRefsManager = new WeakReferencesManager();

// Inicializar monitoreo automático
if (typeof window !== 'undefined') {
  globalMemoryMonitor.startMonitoring();
  
  // Limpieza periódica
  setInterval(() => {
    globalWeakRefsManager.cleanup();
  }, 60000); // Cada minuto

  // Exponer en window para debugging
  (window as any).memoryOptimization = {
    monitor: globalMemoryMonitor,
    leakDetector: globalLeakDetector,
    weakRefs: globalWeakRefsManager
  };
}
