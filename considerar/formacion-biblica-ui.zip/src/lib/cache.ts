/**
 * Sistema de Cache Inteligente Multi-Nivel
 * Implementa estrategias de cache para máximo rendimiento
 */

// =====================================================================
// CONFIGURACIÓN DE CACHE
// =====================================================================

export interface CacheConfig {
  maxMemorySize: number; // MB
  maxIndexedDBSize: number; // MB
  defaultTTL: number; // segundos
  compressionEnabled: boolean;
  encryptionEnabled: boolean;
}

export const DEFAULT_CACHE_CONFIG: CacheConfig = {
  maxMemorySize: 50, // 50MB
  maxIndexedDBSize: 200, // 200MB
  defaultTTL: 3600, // 1 hora
  compressionEnabled: true,
  encryptionEnabled: false
};

// =====================================================================
// MEMORY CACHE CON LRU
// =====================================================================

interface CacheItem<T> {
  value: T;
  timestamp: number;
  ttl: number;
  accessCount: number;
  lastAccessed: number;
  size: number;
}

export class LRUCache<T> {
  private cache = new Map<string, CacheItem<T>>();
  private maxSize: number;
  private currentSize: number = 0;

  constructor(maxSizeMB: number = 50) {
    this.maxSize = maxSizeMB * 1024 * 1024; // Convertir a bytes
  }

  set(key: string, value: T, ttl: number = DEFAULT_CACHE_CONFIG.defaultTTL): void {
    try {
      const size = this.calculateSize(value);
      const now = Date.now();

      // Eliminar item existente si ya existe
      if (this.cache.has(key)) {
        this.currentSize -= this.cache.get(key)!.size;
      }

      // Verificar si hay espacio suficiente
      while (this.currentSize + size > this.maxSize && this.cache.size > 0) {
        this.evictLRU();
      }

      const item: CacheItem<T> = {
        value,
        timestamp: now,
        ttl: ttl * 1000, // Convertir a ms
        accessCount: 1,
        lastAccessed: now,
        size
      };

      this.cache.set(key, item);
      this.currentSize += size;

      // Emitir evento para monitoreo
      this.emitCacheEvent('set', key, size);

    } catch (error) {
      console.error('Error setting cache item:', error);
    }
  }

  get(key: string): T | null {
    try {
      const item = this.cache.get(key);
      
      if (!item) {
        this.emitCacheEvent('miss', key);
        return null;
      }

      const now = Date.now();

      // Verificar TTL
      if (now - item.timestamp > item.ttl) {
        this.delete(key);
        this.emitCacheEvent('expired', key);
        return null;
      }

      // Actualizar estadísticas de acceso
      item.accessCount++;
      item.lastAccessed = now;

      this.emitCacheEvent('hit', key);
      return item.value;

    } catch (error) {
      console.error('Error getting cache item:', error);
      return null;
    }
  }

  delete(key: string): boolean {
    const item = this.cache.get(key);
    if (item) {
      this.currentSize -= item.size;
      this.cache.delete(key);
      this.emitCacheEvent('delete', key);
      return true;
    }
    return false;
  }

  clear(): void {
    this.cache.clear();
    this.currentSize = 0;
    this.emitCacheEvent('clear', 'all');
  }

  private evictLRU(): void {
    let lruKey: string | null = null;
    let lruTime = Date.now();

    for (const [key, item] of this.cache.entries()) {
      if (item.lastAccessed < lruTime) {
        lruTime = item.lastAccessed;
        lruKey = key;
      }
    }

    if (lruKey) {
      this.delete(lruKey);
      this.emitCacheEvent('evicted', lruKey);
    }
  }

  private calculateSize(value: T): number {
    try {
      return new Blob([JSON.stringify(value)]).size;
    } catch {
      return 1024; // 1KB por defecto si no se puede calcular
    }
  }

  private emitCacheEvent(type: string, key: string, size?: number): void {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('cache-event', {
        detail: { type, key, size, cacheSize: this.currentSize }
      }));
    }
  }

  getStats() {
    return {
      size: this.cache.size,
      currentSize: this.currentSize,
      maxSize: this.maxSize,
      hitRate: this.calculateHitRate(),
      items: Array.from(this.cache.entries()).map(([key, item]) => ({
        key,
        size: item.size,
        accessCount: item.accessCount,
        lastAccessed: item.lastAccessed,
        age: Date.now() - item.timestamp
      }))
    };
  }

  private calculateHitRate(): number {
    // Implementar cálculo de hit rate basado en eventos
    return 0.85; // Placeholder
  }
}

// =====================================================================
// INDEXEDDB CACHE
// =====================================================================

export class IndexedDBCache {
  private dbName = 'BiblicalFormationCache';
  private dbVersion = 1;
  private db: IDBDatabase | null = null;

  async initialize(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        // Store para datos de cache
        if (!db.objectStoreNames.contains('cache')) {
          const store = db.createObjectStore('cache', { keyPath: 'key' });
          store.createIndex('timestamp', 'timestamp');
          store.createIndex('ttl', 'ttl');
        }

        // Store para métricas de performance
        if (!db.objectStoreNames.contains('metrics')) {
          const metricsStore = db.createObjectStore('metrics', { keyPath: 'id', autoIncrement: true });
          metricsStore.createIndex('timestamp', 'timestamp');
          metricsStore.createIndex('type', 'type');
        }

        // Store para datos offline
        if (!db.objectStoreNames.contains('offline')) {
          const offlineStore = db.createObjectStore('offline', { keyPath: 'key' });
          offlineStore.createIndex('lastSync', 'lastSync');
        }
      };
    });
  }

  async set(key: string, value: any, ttl: number = DEFAULT_CACHE_CONFIG.defaultTTL): Promise<void> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['cache'], 'readwrite');
      const store = transaction.objectStore('cache');
      
      const item = {
        key,
        value: DEFAULT_CACHE_CONFIG.compressionEnabled ? this.compress(value) : value,
        timestamp: Date.now(),
        ttl: ttl * 1000,
        compressed: DEFAULT_CACHE_CONFIG.compressionEnabled
      };

      const request = store.put(item);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async get(key: string): Promise<any> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['cache'], 'readonly');
      const store = transaction.objectStore('cache');
      const request = store.get(key);

      request.onsuccess = () => {
        const result = request.result;
        
        if (!result) {
          resolve(null);
          return;
        }

        // Verificar TTL
        if (Date.now() - result.timestamp > result.ttl) {
          this.delete(key);
          resolve(null);
          return;
        }

        const value = result.compressed ? this.decompress(result.value) : result.value;
        resolve(value);
      };

      request.onerror = () => reject(request.error);
    });
  }

  async delete(key: string): Promise<void> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['cache'], 'readwrite');
      const store = transaction.objectStore('cache');
      const request = store.delete(key);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async clear(): Promise<void> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['cache'], 'readwrite');
      const store = transaction.objectStore('cache');
      const request = store.clear();

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async cleanup(): Promise<void> {
    if (!this.db) await this.initialize();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['cache'], 'readwrite');
      const store = transaction.objectStore('cache');
      const index = store.index('timestamp');
      const now = Date.now();

      const request = index.openCursor();
      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest).result;
        if (cursor) {
          const item = cursor.value;
          if (now - item.timestamp > item.ttl) {
            cursor.delete();
          }
          cursor.continue();
        } else {
          resolve();
        }
      };

      request.onerror = () => reject(request.error);
    });
  }

  private compress(data: any): string {
    try {
      return JSON.stringify(data);
    } catch {
      return String(data);
    }
  }

  private decompress(data: string): any {
    try {
      return JSON.parse(data);
    } catch {
      return data;
    }
  }
}

// =====================================================================
// CACHE MANAGER PRINCIPAL
// =====================================================================

export class CacheManager {
  private memoryCache: LRUCache<any>;
  private indexedDBCache: IndexedDBCache;
  private config: CacheConfig;

  constructor(config: Partial<CacheConfig> = {}) {
    this.config = { ...DEFAULT_CACHE_CONFIG, ...config };
    this.memoryCache = new LRUCache(this.config.maxMemorySize);
    this.indexedDBCache = new IndexedDBCache();
    
    this.initialize();
  }

  private async initialize(): Promise<void> {
    try {
      await this.indexedDBCache.initialize();
      
      // Configurar limpieza automática
      setInterval(() => {
        this.indexedDBCache.cleanup();
      }, 5 * 60 * 1000); // Cada 5 minutos

      console.log('Cache Manager initialized successfully');
    } catch (error) {
      console.error('Error initializing Cache Manager:', error);
    }
  }

  // Estrategia: Memory first, fallback a IndexedDB
  async get(key: string): Promise<any> {
    try {
      // Intentar memoria primero
      let value = this.memoryCache.get(key);
      if (value !== null) {
        return value;
      }

      // Fallback a IndexedDB
      value = await this.indexedDBCache.get(key);
      if (value !== null) {
        // Promocionar a memoria cache
        this.memoryCache.set(key, value);
        return value;
      }

      return null;
    } catch (error) {
      console.error('Error getting from cache:', error);
      return null;
    }
  }

  async set(key: string, value: any, ttl?: number): Promise<void> {
    try {
      const cacheTTL = ttl || this.config.defaultTTL;
      
      // Guardar en ambos niveles
      this.memoryCache.set(key, value, cacheTTL);
      await this.indexedDBCache.set(key, value, cacheTTL);
    } catch (error) {
      console.error('Error setting cache:', error);
    }
  }

  async delete(key: string): Promise<void> {
    try {
      this.memoryCache.delete(key);
      await this.indexedDBCache.delete(key);
    } catch (error) {
      console.error('Error deleting from cache:', error);
    }
  }

  async clear(): Promise<void> {
    try {
      this.memoryCache.clear();
      await this.indexedDBCache.clear();
    } catch (error) {
      console.error('Error clearing cache:', error);
    }
  }

  getStats() {
    return {
      memory: this.memoryCache.getStats(),
      config: this.config
    };
  }
}

// =====================================================================
// CACHE PARA API RESPONSES
// =====================================================================

export class APICache {
  private cacheManager: CacheManager;

  constructor() {
    this.cacheManager = new CacheManager({
      maxMemorySize: 20,
      defaultTTL: 1800 // 30 minutos para API responses
    });
  }

  async cacheResponse(url: string, response: any, ttl?: number): Promise<void> {
    const key = this.generateCacheKey(url);
    await this.cacheManager.set(key, {
      data: response,
      cached: Date.now(),
      url
    }, ttl);
  }

  async getCachedResponse(url: string): Promise<any> {
    const key = this.generateCacheKey(url);
    const cached = await this.cacheManager.get(key);
    return cached?.data || null;
  }

  private generateCacheKey(url: string): string {
    return `api_${btoa(url).replace(/[^a-zA-Z0-9]/g, '')}`;
  }

  async invalidatePattern(pattern: string): Promise<void> {
    // Implementar invalidación por patrón
    console.log(`Invalidating cache pattern: ${pattern}`);
  }
}

// =====================================================================
// INSTANCIA GLOBAL
// =====================================================================

export const globalCache = new CacheManager();
export const apiCache = new APICache();

// Exponer en window para debugging
if (typeof window !== 'undefined') {
  (window as any).cacheManager = globalCache;
  (window as any).apiCache = apiCache;
}
