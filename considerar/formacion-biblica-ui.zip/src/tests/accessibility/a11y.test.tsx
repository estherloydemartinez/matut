/**
 * Accessibility Tests
 * Tests para validar cumplimiento de WCAG 2.1
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { axe, toHaveNoViolations } from 'vitest-axe';
import userEvent from '@testing-library/user-event';

// Extender expect con matchers de axe
expect.extend(toHaveNoViolations);

// Mock de componentes para testing
import { SocialContainer } from '../../components/SocialContainer';
import { BibleContainer } from '../../components/BibleContainer';
import { StudyContainer } from '../../components/StudyContainer';
import { Header } from '../../components/Header';
import { Navigation } from '../../components/Navigation';

// Mock de react-router-dom
vi.mock('react-router-dom', () => ({
  useNavigate: () => vi.fn(),
  useLocation: () => ({ pathname: '/' }),
  Link: ({ children, to, ...props }: any) => (
    <a href={to} {...props}>{children}</a>
  )
}));

// Mock de hooks personalizados
vi.mock('../../hooks/use-mobile', () => ({
  useMobile: () => false
}));

vi.mock('../../hooks/use-toast', () => ({
  useToast: () => ({
    toast: vi.fn()
  })
}));

// Mock de contextos
vi.mock('../../contexts/ThemeContext', () => ({
  useTheme: () => ({
    theme: 'light',
    setTheme: vi.fn()
  })
}));

vi.mock('../../contexts/AppStateContext', () => ({
  useAppState: () => ({
    currentSection: 'bible',
    setCurrentSection: vi.fn(),
    user: { id: 'test-user', name: 'Test User' }
  })
}));

describe('Accessibility Tests', () => {
  const user = userEvent.setup();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('WCAG 2.1 Level AA Compliance', () => {
    it('should pass axe accessibility tests for main app components', async () => {
      const { container } = render(<SocialContainer />);
      const results = await axe(container);
      expect(results).toHaveNoViolations();
    });

    it('should pass axe tests for Bible container', async () => {
      const { container } = render(<BibleContainer />);
      const results = await axe(container);
      expect(results).toHaveNoViolations();
    });

    it('should pass axe tests for Study container', async () => {
      const { container } = render(<StudyContainer />);
      const results = await axe(container);
      expect(results).toHaveNoViolations();
    });

    it('should pass axe tests for Header component', async () => {
      const { container } = render(<Header />);
      const results = await axe(container);
      expect(results).toHaveNoViolations();
    });

    it('should pass axe tests for Navigation component', async () => {
      const { container } = render(<Navigation />);
      const results = await axe(container);
      expect(results).toHaveNoViolations();
    });
  });

  describe('Keyboard Navigation', () => {
    it('should support tab navigation through all interactive elements', async () => {
      render(<SocialContainer />);

      // Obtener todos los elementos interactivos
      const buttons = screen.getAllByRole('button');
      const links = screen.getAllByRole('link');
      const inputs = screen.getAllByRole('textbox');

      // Verificar que todos los elementos son accesibles por teclado
      const allInteractive = [...buttons, ...links, ...inputs];
      
      for (const element of allInteractive) {
        expect(element).toHaveAttribute('tabIndex');
        expect(parseInt(element.getAttribute('tabIndex') || '0')).toBeGreaterThanOrEqual(0);
      }
    });

    it('should handle keyboard shortcuts correctly', async () => {
      render(<SocialContainer />);

      // Probar navegación con teclas de flecha en tabs
      const tabButtons = screen.getAllByRole('tab');
      
      if (tabButtons.length > 1) {
        tabButtons[0].focus();
        expect(document.activeElement).toBe(tabButtons[0]);

        // Simular flecha derecha
        await user.keyboard('{ArrowRight}');
        expect(document.activeElement).toBe(tabButtons[1]);

        // Simular flecha izquierda
        await user.keyboard('{ArrowLeft}');
        expect(document.activeElement).toBe(tabButtons[0]);
      }
    });

    it('should trap focus in modal dialogs', async () => {
      render(<SocialContainer />);

      // Abrir modal
      const createButton = screen.getByText('Crear Comunidad');
      await user.click(createButton);

      // Verificar que el foco está en el modal
      const modal = screen.getByRole('dialog');
      expect(modal).toBeInTheDocument();

      // Verificar que el foco no puede salir del modal con Tab
      const focusableElements = modal.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      
      expect(focusableElements.length).toBeGreaterThan(0);

      // El primer elemento debería estar enfocado
      expect(document.activeElement).toBe(focusableElements[0]);
    });

    it('should support escape key to close modals', async () => {
      render(<SocialContainer />);

      const createButton = screen.getByText('Crear Comunidad');
      await user.click(createButton);

      // Verificar que el modal está abierto
      expect(screen.getByRole('dialog')).toBeInTheDocument();

      // Presionar Escape
      await user.keyboard('{Escape}');

      // Verificar que el modal se cerró
      expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    });
  });

  describe('ARIA Labels and Roles', () => {
    it('should have proper ARIA labels for all interactive elements', () => {
      render(<SocialContainer />);

      // Verificar botones con aria-label o texto descriptivo
      const buttons = screen.getAllByRole('button');
      buttons.forEach(button => {
        const hasAriaLabel = button.hasAttribute('aria-label');
        const hasText = button.textContent && button.textContent.trim().length > 0;
        const hasAriaLabelledBy = button.hasAttribute('aria-labelledby');
        
        expect(hasAriaLabel || hasText || hasAriaLabelledBy).toBe(true);
      });
    });

    it('should use proper heading hierarchy', () => {
      render(<SocialContainer />);

      const headings = screen.getAllByRole('heading');
      const headingLevels = headings.map(h => parseInt(h.tagName.charAt(1)));

      // Verificar que hay al menos un h1
      expect(headingLevels).toContain(1);

      // Verificar jerarquía lógica (no saltar niveles)
      for (let i = 1; i < headingLevels.length; i++) {
        const current = headingLevels[i];
        const previous = headingLevels[i - 1];
        
        // No debe saltar más de un nivel
        expect(current - previous).toBeLessThanOrEqual(1);
      }
    });

    it('should have proper form labels', async () => {
      render(<SocialContainer />);

      const createButton = screen.getByText('Crear Comunidad');
      await user.click(createButton);

      // Verificar que todos los inputs tienen labels
      const inputs = screen.getAllByRole('textbox');
      inputs.forEach(input => {
        const hasLabel = input.hasAttribute('aria-label') || 
                        input.hasAttribute('aria-labelledby') ||
                        screen.queryByLabelText(input.getAttribute('placeholder') || '');
        
        expect(hasLabel).toBe(true);
      });
    });

    it('should use proper ARIA states for dynamic content', async () => {
      render(<SocialContainer />);

      // Verificar estados ARIA en tabs
      const tabs = screen.getAllByRole('tab');
      tabs.forEach(tab => {
        expect(tab).toHaveAttribute('aria-selected');
      });

      // Verificar que los panels están asociados
      const tabPanels = screen.getAllByRole('tabpanel');
      tabPanels.forEach(panel => {
        expect(panel).toHaveAttribute('aria-labelledby');
      });
    });

    it('should indicate loading states with ARIA', async () => {
      render(<SocialContainer />);

      // Simular estado de carga
      const loadingElement = screen.queryByRole('status') || 
                            screen.queryByLabelText(/loading/i) ||
                            screen.queryByText(/cargando/i);

      if (loadingElement) {
        expect(loadingElement).toHaveAttribute('aria-live');
      }
    });
  });

  describe('Color and Contrast', () => {
    it('should not rely solely on color for information', () => {
      render(<SocialContainer />);

      // Verificar que elementos con estado usan más que solo color
      const statusElements = screen.getAllByTestId(/status|badge/);
      statusElements.forEach(element => {
        // Debería tener texto o icono además del color
        const hasText = element.textContent && element.textContent.trim().length > 0;
        const hasIcon = element.querySelector('svg') || element.querySelector('[data-testid*="icon"]');
        
        expect(hasText || hasIcon).toBe(true);
      });
    });

    it('should provide sufficient color contrast', () => {
      render(<SocialContainer />);

      // Verificar que los elementos usan clases CSS apropiadas para contraste
      const textElements = screen.getAllByText(/./);
      textElements.forEach(element => {
        const computedStyle = window.getComputedStyle(element);
        const backgroundColor = computedStyle.backgroundColor;
        const color = computedStyle.color;
        
        // Verificar que hay color definido (no transparente por defecto)
        expect(color).toBeDefined();
        expect(color).not.toBe('rgba(0, 0, 0, 0)');
      });
    });
  });

  describe('Screen Reader Support', () => {
    it('should provide proper alt text for images', () => {
      render(<SocialContainer />);

      const images = screen.getAllByRole('img');
      images.forEach(img => {
        const hasAlt = img.hasAttribute('alt');
        const isDecorative = img.getAttribute('alt') === '';
        const hasAriaLabel = img.hasAttribute('aria-label');
        
        // Debe tener alt (puede estar vacío para decorativo) o aria-label
        expect(hasAlt || hasAriaLabel).toBe(true);
      });
    });

    it('should announce dynamic content changes', async () => {
      render(<SocialContainer />);

      // Verificar regiones live
      const liveRegions = screen.getAllByRole('alert') || 
                         screen.queryAllByLabelText(/announcement/i);

      // Debería haber al menos una región para anuncios
      if (liveRegions.length > 0) {
        liveRegions.forEach(region => {
          expect(region).toHaveAttribute('aria-live');
        });
      }
    });

    it('should provide descriptive error messages', async () => {
      render(<SocialContainer />);

      const createButton = screen.getByText('Crear Comunidad');
      await user.click(createButton);

      // Intentar enviar formulario sin datos
      const submitButton = screen.getByText('Crear Comunidad');
      await user.click(submitButton);

      // Verificar mensajes de error accesibles
      const errorMessages = screen.queryAllByRole('alert') || 
                           screen.queryAllByText(/error|requerido/i);

      errorMessages.forEach(error => {
        expect(error).toBeInTheDocument();
        // Debería estar asociado con el campo correspondiente
        expect(error).toHaveAttribute('aria-describedby');
      });
    });
  });

  describe('Mobile Accessibility', () => {
    it('should have touch targets of appropriate size', () => {
      // Mock mobile viewport
      Object.defineProperty(window, 'innerWidth', {
        writable: true,
        configurable: true,
        value: 375,
      });

      render(<SocialContainer />);

      const interactiveElements = [
        ...screen.getAllByRole('button'),
        ...screen.getAllByRole('link'),
        ...screen.getAllByRole('tab')
      ];

      interactiveElements.forEach(element => {
        const rect = element.getBoundingClientRect();
        // Touch targets deberían ser al menos 44x44px
        expect(rect.width).toBeGreaterThanOrEqual(44);
        expect(rect.height).toBeGreaterThanOrEqual(44);
      });
    });

    it('should support zoom up to 200% without horizontal scrolling', () => {
      // Simular zoom al 200%
      Object.defineProperty(window, 'devicePixelRatio', {
        writable: true,
        value: 2,
      });

      render(<SocialContainer />);

      // Verificar que el contenido sigue siendo accesible
      expect(screen.getByText('Comunidades')).toBeInTheDocument();
    });
  });

  describe('Focus Management', () => {
    it('should have visible focus indicators', () => {
      render(<SocialContainer />);

      const focusableElements = screen.getAllByRole('button');
      
      focusableElements.forEach(element => {
        element.focus();
        
        // Verificar que hay un indicador de foco visible
        const computedStyle = window.getComputedStyle(element, ':focus');
        const hasOutline = computedStyle.outline !== 'none';
        const hasBoxShadow = computedStyle.boxShadow !== 'none';
        const hasBorder = computedStyle.border !== 'none';
        
        expect(hasOutline || hasBoxShadow || hasBorder).toBe(true);
      });
    });

    it('should restore focus after modal closes', async () => {
      render(<SocialContainer />);

      const createButton = screen.getByText('Crear Comunidad');
      createButton.focus();
      
      // Abrir modal
      await user.click(createButton);
      expect(screen.getByRole('dialog')).toBeInTheDocument();

      // Cerrar modal
      await user.keyboard('{Escape}');
      
      // El foco debería volver al botón original
      expect(document.activeElement).toBe(createButton);
    });

    it('should skip to main content', () => {
      render(<SocialContainer />);

      // Verificar que hay un enlace "skip to main content"
      const skipLink = screen.queryByText(/skip to main|saltar al contenido/i);
      
      if (skipLink) {
        expect(skipLink).toHaveAttribute('href', '#main');
      }

      // Verificar que hay un elemento main con id
      const mainElement = screen.getByRole('main') || document.getElementById('main');
      expect(mainElement).toBeInTheDocument();
    });
  });

  describe('Language and Internationalization', () => {
    it('should have proper lang attributes', () => {
      render(<SocialContainer />);

      // Verificar idioma principal
      const htmlElement = document.documentElement;
      expect(htmlElement).toHaveAttribute('lang');
      expect(htmlElement.getAttribute('lang')).toBe('es');
    });

    it('should handle text expansion for different languages', () => {
      render(<SocialContainer />);

      // Verificar que los textos no se cortan
      const textElements = screen.getAllByText(/./);
      textElements.forEach(element => {
        const rect = element.getBoundingClientRect();
        
        // El texto no debería estar cortado
        expect(element.scrollWidth).toBeLessThanOrEqual(rect.width + 1);
      });
    });
  });

  describe('Complex Interactions', () => {
    it('should handle drag and drop accessibility', async () => {
      render(<SocialContainer />);

      // Verificar elementos arrastrables si existen
      const draggableElements = screen.queryAllByAttribute('draggable', 'true');
      
      draggableElements.forEach(element => {
        // Debe tener texto descriptivo
        expect(element).toHaveAttribute('aria-describedby');
        
        // Debe tener instrucciones de teclado alternativo
        const instructions = screen.queryByText(/keyboard instructions|instrucciones de teclado/i);
        expect(instructions).toBeInTheDocument();
      });
    });

    it('should provide keyboard alternatives for gestures', async () => {
      render(<SocialContainer />);

      // Verificar que las acciones de gesto tienen alternativas de teclado
      const gestureElements = screen.queryAllByAttribute('data-gesture', /.+/);
      
      gestureElements.forEach(element => {
        // Debería tener evento de teclado alternativo
        expect(element).toHaveAttribute('onKeyDown');
      });
    });
  });

  describe('Error Prevention and Recovery', () => {
    it('should provide confirmation for destructive actions', async () => {
      render(<SocialContainer />);

      // Buscar acciones destructivas
      const deleteButtons = screen.queryAllByText(/delete|eliminar|borrar/i);
      
      for (const button of deleteButtons) {
        await user.click(button);
        
        // Debería mostrar confirmación
        const confirmation = screen.queryByText(/confirm|confirmar|seguro/i);
        expect(confirmation).toBeInTheDocument();
      }
    });

    it('should allow users to undo recent actions', async () => {
      render(<SocialContainer />);

      // Verificar disponibilidad de undo
      const undoButton = screen.queryByText(/undo|deshacer/i);
      
      if (undoButton) {
        expect(undoButton).toBeInTheDocument();
        expect(undoButton).not.toBeDisabled();
      }
    });

    it('should preserve user input during errors', async () => {
      render(<SocialContainer />);

      const createButton = screen.getByText('Crear Comunidad');
      await user.click(createButton);

      const nameInput = screen.getByPlaceholderText('Nombre de la comunidad');
      await user.type(nameInput, 'Test Community');

      // Simular error de envío
      const submitButton = screen.getByText('Crear Comunidad');
      await user.click(submitButton);

      // El valor del input debería mantenerse
      expect(nameInput).toHaveValue('Test Community');
    });
  });

  describe('Performance and Accessibility', () => {
    it('should not block accessibility tree updates', async () => {
      render(<SocialContainer />);

      // Simular múltiples cambios rápidos
      const tabs = screen.getAllByRole('tab');
      
      for (const tab of tabs) {
        await user.click(tab);
        
        // Verificar que el aria-selected se actualiza correctamente
        expect(tab).toHaveAttribute('aria-selected', 'true');
      }
    });

    it('should handle large lists with virtual scrolling accessibility', () => {
      render(<SocialContainer />);

      // Verificar listas virtualizadas si existen
      const lists = screen.getAllByRole('list');
      
      lists.forEach(list => {
        // Debería tener aria-setsize y aria-posinset para ítems virtualizados
        const items = list.querySelectorAll('[role="listitem"]');
        
        if (items.length > 50) { // Probablemente virtualizada
          items.forEach((item, index) => {
            expect(item).toHaveAttribute('aria-setsize');
            expect(item).toHaveAttribute('aria-posinset');
          });
        }
      });
    });
  });
});
