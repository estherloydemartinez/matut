/**
 * Tests de Integración Completa: Módulos Legacy + Componentes React
 * Valida la integración entre módulos JavaScript optimizados y componentes TypeScript/React
 */

import React from 'react';
import { describe, it, expect, beforeAll, afterEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { legacyBridge } from '../../lib/legacy-integration';
import BibleContainer from '../../components/BibleContainer';
import SocialContainer from '../../components/SocialContainer';
import StudyContainer from '../../components/StudyContainer';

// Mock de módulos legacy
const mockLegacyModules = {
  BibliaRV1960Optimized: {
    buscarTexto: vi.fn(),
    obtenerCapitulo: vi.fn(),
    obtenerVersiculo: vi.fn(),
    obtenerEstadisticas: vi.fn(),
    limpiarCache: vi.fn()
  },
  AnalisisAvanzadoOptimizado: {
    analizarTexto: vi.fn(),
    obtenerEstadisticas: vi.fn(),
    generarVisualizacion: vi.fn(),
    obtenerPatrones: vi.fn(),
    limpiarCache: vi.fn()
  },
  SocialAvanzadoOptimizado: {
    obtenerPerfil: vi.fn(),
    actualizarPerfil: vi.fn(),
    obtenerAmigos: vi.fn(),
    obtenerEventos: vi.fn(),
    obtenerNotificaciones: vi.fn(),
    marcarNotificacionLeida: vi.fn(),
    limpiarCache: vi.fn()
  }
};

// Configurar window mock
Object.defineProperty(global, 'window', {
  value: {
    ...global.window,
    ...mockLegacyModules,
    matchMedia: vi.fn(() => ({
      matches: false,
      addListener: vi.fn(),
      removeListener: vi.fn(),
    })),
    ResizeObserver: vi.fn(() => ({
      observe: vi.fn(),
      unobserve: vi.fn(),
      disconnect: vi.fn(),
    })),
  },
  writable: true
});

// Mock de document para script loading
const mockCreateElement = vi.fn();
const mockAppendChild = vi.fn();

Object.defineProperty(global, 'document', {
  value: {
    ...global.document,
    createElement: mockCreateElement,
    head: {
      appendChild: mockAppendChild
    },
    querySelector: vi.fn(() => null)
  },
  writable: true
});

describe('Integración Legacy Modules + React Components', () => {
  beforeAll(async () => {
    // Configurar mock de script loading
    mockCreateElement.mockImplementation((tagName: string) => {
      if (tagName === 'script') {
        const script = {
          src: '',
          type: '',
          onload: null as any,
          onerror: null as any
        };
        
        setTimeout(() => {
          if (script.onload) script.onload();
        }, 10);
        
        return script;
      }
      return { style: {} };
    });

    // Esperar inicialización del bridge
    await legacyBridge.waitForInitialization();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  describe('BibleContainer + Módulo Bíblico Legacy', () => {
    it('debe integrar búsqueda bíblica con módulo legacy', async () => {
      const user = userEvent.setup();
      
      // Configurar mock del módulo bíblico
      const mockSearchResults = [
        {
          libro: 'Génesis',
          capitulo: 1,
          versiculo: 1,
          texto: 'En el principio creó Dios los cielos y la tierra.',
          id: 'gen-1-1'
        },
        {
          libro: 'Juan',
          capitulo: 1,
          versiculo: 1,
          texto: 'En el principio era el Verbo, y el Verbo era con Dios.',
          id: 'jn-1-1'
        }
      ];

      mockLegacyModules.BibliaRV1960Optimized.buscarTexto.mockResolvedValue(mockSearchResults);

      render(<BibleContainer />);

      // Verificar que el componente se renderiza
      expect(screen.getByText(/biblia/i)).toBeInTheDocument();

      // Buscar campo de búsqueda y realizar búsqueda
      const searchInput = screen.getByPlaceholderText(/buscar/i) || screen.getByRole('textbox');
      await user.type(searchInput, 'En el principio');

      // Simular envío de búsqueda
      const searchButton = screen.getByRole('button', { name: /buscar/i }) || 
                          screen.getByTestId('search-button');
      await user.click(searchButton);

      // Verificar que se llamó al módulo legacy
      await waitFor(() => {
        expect(mockLegacyModules.BibliaRV1960Optimized.buscarTexto).toHaveBeenCalledWith('En el principio');
      });

      // Verificar que los resultados se muestran
      await waitFor(() => {
        expect(screen.getByText(/génesis/i)).toBeInTheDocument();
        expect(screen.getByText(/juan/i)).toBeInTheDocument();
      });
    });

    it('debe obtener capítulo específico desde el componente', async () => {
      const mockChapter = {
        libro: 'Salmos',
        capitulo: 23,
        versiculos: [
          { numero: 1, texto: 'Jehová es mi pastor; nada me faltará.' },
          { numero: 2, texto: 'En lugares de delicados pastos me hará descansar.' }
        ]
      };

      mockLegacyModules.BibliaRV1960Optimized.obtenerCapitulo.mockResolvedValue(mockChapter);

      render(<BibleContainer />);

      // Simular selección de libro y capítulo
      const bookSelect = screen.getByDisplayValue(/seleccionar libro/i) || 
                        screen.getByRole('combobox');
      await userEvent.selectOptions(bookSelect, 'Salmos');

      const chapterSelect = screen.getByDisplayValue(/seleccionar capítulo/i) || 
                           screen.getAllByRole('combobox')[1];
      await userEvent.selectOptions(chapterSelect, '23');

      await waitFor(() => {
        expect(mockLegacyModules.BibliaRV1960Optimized.obtenerCapitulo).toHaveBeenCalledWith('Salmos', 23);
      });

      // Verificar renderizado del capítulo
      await waitFor(() => {
        expect(screen.getByText(/jehová es mi pastor/i)).toBeInTheDocument();
      });
    });

    it('debe manejar errores del módulo bíblico gracefully', async () => {
      const user = userEvent.setup();
      
      // Simular error en el módulo
      mockLegacyModules.BibliaRV1960Optimized.buscarTexto.mockRejectedValue(
        new Error('Error de API bíblica')
      );

      render(<BibleContainer />);

      const searchInput = screen.getByPlaceholderText(/buscar/i) || screen.getByRole('textbox');
      await user.type(searchInput, 'texto de prueba');

      const searchButton = screen.getByRole('button', { name: /buscar/i });
      await user.click(searchButton);

      // Verificar manejo de error
      await waitFor(() => {
        expect(screen.getByText(/error/i) || screen.getByText(/no se pudo/i)).toBeInTheDocument();
      });
    });

    it('debe mostrar estadísticas bíblicas', async () => {
      const mockStats = {
        libros: 66,
        capitulos: 1189,
        versiculos: 31102,
        palabras: 783137
      };

      mockLegacyModules.BibliaRV1960Optimized.obtenerEstadisticas.mockReturnValue(mockStats);

      render(<BibleContainer />);

      // Buscar botón de estadísticas o similar
      const statsButton = screen.getByText(/estadísticas/i) || 
                         screen.getByText(/información/i);
      await userEvent.click(statsButton);

      await waitFor(() => {
        expect(mockLegacyModules.BibliaRV1960Optimized.obtenerEstadisticas).toHaveBeenCalled();
        expect(screen.getByText(/66/)).toBeInTheDocument(); // número de libros
        expect(screen.getByText(/31102/)).toBeInTheDocument(); // número de versículos
      });
    });
  });

  describe('StudyContainer + Módulo Analítico Legacy', () => {
    it('debe integrar análisis de texto con módulo legacy', async () => {
      const user = userEvent.setup();
      
      const mockAnalysis = {
        sentimiento: 'positivo',
        palabrasClave: ['fe', 'esperanza', 'amor'],
        temas: ['religioso', 'esperanza'],
        complejidad: 'media',
        legibilidad: 8.5
      };

      mockLegacyModules.AnalisisAvanzadoOptimizado.analizarTexto.mockResolvedValue(mockAnalysis);

      render(<StudyContainer />);

      // Encontrar área de texto o input para análisis
      const textInput = screen.getByPlaceholderText(/texto/i) || 
                       screen.getByRole('textbox', { name: /analizar/i });
      
      await user.type(textInput, 'Porque de tal manera amó Dios al mundo...');

      // Buscar botón de análisis
      const analyzeButton = screen.getByRole('button', { name: /analizar/i });
      await user.click(analyzeButton);

      await waitFor(() => {
        expect(mockLegacyModules.AnalisisAvanzadoOptimizado.analizarTexto).toHaveBeenCalledWith(
          'Porque de tal manera amó Dios al mundo...'
        );
      });

      // Verificar que se muestran los resultados
      await waitFor(() => {
        expect(screen.getByText(/positivo/i)).toBeInTheDocument();
        expect(screen.getByText(/fe/i)).toBeInTheDocument();
        expect(screen.getByText(/esperanza/i)).toBeInTheDocument();
      });
    });

    it('debe generar visualizaciones desde el componente', async () => {
      const testData = [
        { categoria: 'Libros leídos', valor: 12 },
        { categoria: 'Tiempo estudio', valor: 45 },
        { categoria: 'Versículos memorizados', valor: 28 }
      ];

      const mockVisualization = {
        tipo: 'barras',
        datos: testData,
        configuracion: {
          width: 400,
          height: 300
        }
      };

      mockLegacyModules.AnalisisAvanzadoOptimizado.generarVisualizacion.mockResolvedValue(mockVisualization);

      render(<StudyContainer />);

      // Buscar botón para generar gráfico
      const chartButton = screen.getByText(/gráfico/i) || 
                         screen.getByText(/visualización/i);
      await userEvent.click(chartButton);

      await waitFor(() => {
        expect(mockLegacyModules.AnalisisAvanzadoOptimizado.generarVisualizacion).toHaveBeenCalled();
      });

      // Verificar que se muestra la visualización
      await waitFor(() => {
        expect(screen.getByText(/libros leídos/i)).toBeInTheDocument();
      });
    });

    it('debe obtener patrones de estudio', async () => {
      const mockPatterns = {
        frecuencias: { 'mañana': 60, 'tarde': 30, 'noche': 10 },
        tendencias: 'creciente',
        recomendaciones: ['Continuar con estudios matutinos', 'Incrementar tiempo de estudio']
      };

      mockLegacyModules.AnalisisAvanzadoOptimizado.obtenerPatrones.mockReturnValue(mockPatterns);

      render(<StudyContainer />);

      const patternsButton = screen.getByText(/patrones/i) || 
                            screen.getByText(/análisis/i);
      await userEvent.click(patternsButton);

      await waitFor(() => {
        expect(mockLegacyModules.AnalisisAvanzadoOptimizado.obtenerPatrones).toHaveBeenCalled();
        expect(screen.getByText(/mañana/i)).toBeInTheDocument();
        expect(screen.getByText(/creciente/i)).toBeInTheDocument();
      });
    });
  });

  describe('SocialContainer + Módulo Social Legacy', () => {
    it('debe integrar funciones sociales con módulo legacy', async () => {
      const mockProfile = {
        id: 'user123',
        nombre: 'Juan Pérez',
        email: 'juan@example.com',
        nivelEstudio: 'intermedio',
        librosLeidos: 8,
        tiempoEstudio: 150
      };

      const mockFriends = [
        { id: 'friend1', nombre: 'María García', estado: 'activo' },
        { id: 'friend2', nombre: 'Pedro López', estado: 'ocupado' }
      ];

      mockLegacyModules.SocialAvanzadoOptimizado.obtenerPerfil.mockReturnValue(mockProfile);
      mockLegacyModules.SocialAvanzadoOptimizado.obtenerAmigos.mockReturnValue(mockFriends);

      render(<SocialContainer />);

      await waitFor(() => {
        expect(mockLegacyModules.SocialAvanzadoOptimizado.obtenerPerfil).toHaveBeenCalled();
        expect(mockLegacyModules.SocialAvanzadoOptimizado.obtenerAmigos).toHaveBeenCalled();
      });

      // Verificar que se muestra información del perfil
      await waitFor(() => {
        expect(screen.getByText(/juan pérez/i)).toBeInTheDocument();
        expect(screen.getByText(/intermedio/i)).toBeInTheDocument();
      });

      // Verificar que se muestran los amigos
      await waitFor(() => {
        expect(screen.getByText(/maría garcía/i)).toBeInTheDocument();
        expect(screen.getByText(/pedro lópez/i)).toBeInTheDocument();
      });
    });

    it('debe manejar notificaciones sociales', async () => {
      const user = userEvent.setup();
      
      const mockNotifications = [
        {
          id: 'notif1',
          tipo: 'mensaje',
          contenido: 'Tienes un nuevo mensaje de María',
          fecha: '2024-01-15T10:30:00Z',
          leida: false
        },
        {
          id: 'notif2',
          tipo: 'evento',
          contenido: 'Recordatorio: Estudio grupal mañana',
          fecha: '2024-01-15T09:00:00Z',
          leida: false
        }
      ];

      mockLegacyModules.SocialAvanzadoOptimizado.obtenerNotificaciones.mockReturnValue(mockNotifications);
      mockLegacyModules.SocialAvanzadoOptimizado.marcarNotificacionLeida.mockResolvedValue(true);

      render(<SocialContainer />);

      await waitFor(() => {
        expect(mockLegacyModules.SocialAvanzadoOptimizado.obtenerNotificaciones).toHaveBeenCalled();
      });

      // Verificar que se muestran las notificaciones
      await waitFor(() => {
        expect(screen.getByText(/nuevo mensaje de maría/i)).toBeInTheDocument();
        expect(screen.getByText(/estudio grupal mañana/i)).toBeInTheDocument();
      });

      // Marcar notificación como leída
      const markReadButton = screen.getAllByRole('button', { name: /marcar/i })[0];
      await user.click(markReadButton);

      await waitFor(() => {
        expect(mockLegacyModules.SocialAvanzadoOptimizado.marcarNotificacionLeida).toHaveBeenCalledWith('notif1');
      });
    });

    it('debe actualizar perfil de usuario', async () => {
      const user = userEvent.setup();
      
      mockLegacyModules.SocialAvanzadoOptimizado.actualizarPerfil.mockResolvedValue(true);

      render(<SocialContainer />);

      // Buscar botón de editar perfil
      const editButton = screen.getByRole('button', { name: /editar/i }) ||
                        screen.getByText(/configuración/i);
      await user.click(editButton);

      // Encontrar campo de nombre y actualizarlo
      const nameInput = screen.getByDisplayValue(/juan/i) || 
                       screen.getByRole('textbox', { name: /nombre/i });
      await user.clear(nameInput);
      await user.type(nameInput, 'Juan Carlos Pérez');

      // Guardar cambios
      const saveButton = screen.getByRole('button', { name: /guardar/i });
      await user.click(saveButton);

      await waitFor(() => {
        expect(mockLegacyModules.SocialAvanzadoOptimizado.actualizarPerfil).toHaveBeenCalledWith(
          expect.objectContaining({
            nombre: 'Juan Carlos Pérez'
          })
        );
      });
    });
  });

  describe('Integración Cross-Module', () => {
    it('debe permitir flujo completo: búsqueda -> análisis -> compartir', async () => {
      const user = userEvent.setup();
      
      // Configurar mocks para flujo completo
      const searchResults = [
        {
          libro: 'Filipenses',
          capitulo: 4,
          versiculo: 13,
          texto: 'Todo lo puedo en Cristo que me fortalece.',
          id: 'fil-4-13'
        }
      ];

      const textAnalysis = {
        sentimiento: 'positivo',
        temas: ['fortaleza', 'fe'],
        palabrasClave: ['Cristo', 'fortalece']
      };

      mockLegacyModules.BibliaRV1960Optimized.buscarTexto.mockResolvedValue(searchResults);
      mockLegacyModules.AnalisisAvanzadoOptimizado.analizarTexto.mockResolvedValue(textAnalysis);
      mockLegacyModules.SocialAvanzadoOptimizado.obtenerAmigos.mockReturnValue([
        { id: 'friend1', nombre: 'María García' }
      ]);

      // Renderizar componentes (en contexto de app completa)
      const { container } = render(
        <div>
          <BibleContainer />
          <StudyContainer />
          <SocialContainer />
        </div>
      );

      // 1. Buscar versículo
      const searchInput = screen.getByPlaceholderText(/buscar/i);
      await user.type(searchInput, 'Todo lo puedo');

      const searchButton = screen.getByRole('button', { name: /buscar/i });
      await user.click(searchButton);

      await waitFor(() => {
        expect(mockLegacyModules.BibliaRV1960Optimized.buscarTexto).toHaveBeenCalledWith('Todo lo puedo');
        expect(screen.getByText(/filipenses/i)).toBeInTheDocument();
      });

      // 2. Analizar texto encontrado
      const analyzeButton = screen.getByRole('button', { name: /analizar/i });
      await user.click(analyzeButton);

      await waitFor(() => {
        expect(mockLegacyModules.AnalisisAvanzadoOptimizado.analizarTexto).toHaveBeenCalledWith(
          'Todo lo puedo en Cristo que me fortalece.'
        );
        expect(screen.getByText(/positivo/i)).toBeInTheDocument();
      });

      // 3. Compartir con amigos (verificar que el módulo social esté activo)
      const shareButton = screen.getByRole('button', { name: /compartir/i });
      await user.click(shareButton);

      await waitFor(() => {
        expect(screen.getByText(/maría garcía/i)).toBeInTheDocument();
      });
    });

    it('debe sincronizar caches entre módulos', async () => {
      // Limpiar todos los caches
      legacyBridge.clearAllCaches();

      expect(mockLegacyModules.BibliaRV1960Optimized.limpiarCache).toHaveBeenCalled();
      expect(mockLegacyModules.AnalisisAvanzadoOptimizado.limpiarCache).toHaveBeenCalled();
      expect(mockLegacyModules.SocialAvanzadoOptimizado.limpiarCache).toHaveBeenCalled();
    });

    it('debe manejar health check de todos los módulos', async () => {
      // Configurar mocks para health check
      mockLegacyModules.BibliaRV1960Optimized.obtenerEstadisticas.mockReturnValue({ libros: 66 });
      mockLegacyModules.AnalisisAvanzadoOptimizado.obtenerEstadisticas.mockReturnValue({ media: 5 });
      mockLegacyModules.SocialAvanzadoOptimizado.obtenerPerfil.mockReturnValue({ id: 'user1' });

      const healthStatus = await legacyBridge.healthCheck();

      expect(healthStatus.bible).toBe(true);
      expect(healthStatus.analytics).toBe(true);
      expect(healthStatus.social).toBe(true);
      expect(healthStatus.overall).toBe(true);
    });
  });

  describe('Performance y Optimización', () => {
    it('debe cargar módulos de forma lazy', async () => {
      // Verificar que los scripts se cargan dinámicamente
      expect(mockCreateElement).toHaveBeenCalledWith('script');
      expect(mockAppendChild).toHaveBeenCalled();
    });

    it('debe tener tiempos de respuesta aceptables en integración', async () => {
      const startTime = performance.now();

      // Ejecutar operaciones típicas de usuario
      await legacyBridge.searchBibleText('test');
      await legacyBridge.analyzeText('test text');
      legacyBridge.getUserProfile();

      const endTime = performance.now();
      const totalTime = endTime - startTime;

      // Debe completarse en menos de 200ms
      expect(totalTime).toBeLessThan(200);
    });

    it('debe manejar errores de conexión entre módulos', async () => {
      const user = userEvent.setup();
      
      // Simular fallo en módulo bíblico
      mockLegacyModules.BibliaRV1960Optimized.buscarTexto.mockRejectedValue(
        new Error('Network Error')
      );

      render(<BibleContainer />);

      const searchInput = screen.getByPlaceholderText(/buscar/i);
      await user.type(searchInput, 'test');

      const searchButton = screen.getByRole('button', { name: /buscar/i });
      await user.click(searchButton);

      // Verificar que el error se maneja gracefully
      await waitFor(() => {
        expect(screen.getByText(/error/i) || screen.getByText(/no disponible/i)).toBeInTheDocument();
      });

      // Verificar que otros módulos siguen funcionando
      const socialData = legacyBridge.getUserProfile();
      expect(socialData).toBeDefined();
    });
  });
});

describe('Validación de Arquitectura Legacy-Modern', () => {
  it('debe mantener compatibilidad con versiones anteriores', () => {
    // Verificar que los módulos legacy exponen las APIs esperadas
    expect(mockLegacyModules.BibliaRV1960Optimized.buscarTexto).toBeDefined();
    expect(mockLegacyModules.AnalisisAvanzadoOptimizado.analizarTexto).toBeDefined();
    expect(mockLegacyModules.SocialAvanzadoOptimizado.obtenerPerfil).toBeDefined();
  });

  it('debe proporcionar bridge coherente', () => {
    // Verificar que el bridge expone métodos consistentes
    expect(typeof legacyBridge.searchBibleText).toBe('function');
    expect(typeof legacyBridge.analyzeText).toBe('function');
    expect(typeof legacyBridge.getUserProfile).toBe('function');
  });

  it('debe mantener tipos TypeScript consistentes', () => {
    // Verificar tipos de retorno
    const profile = legacyBridge.getUserProfile();
    const friends = legacyBridge.getFriends();
    const notifications = legacyBridge.getNotifications();

    expect(Array.isArray(friends)).toBe(true);
    expect(Array.isArray(notifications)).toBe(true);
    expect(typeof profile === 'object').toBe(true);
  });
});
