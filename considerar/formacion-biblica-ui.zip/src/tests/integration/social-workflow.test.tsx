/**
 * Integration Tests - Social Workflow
 * Tests de integración para flujos completos de funcionalidades sociales
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { App } from '../../App';

// Mock de módulos principales
vi.mock('../../lib/social-engine');
vi.mock('../../lib/notification-system');
vi.mock('../../lib/real-time-collaboration');
vi.mock('../../lib/ml-engine');

describe('Social Workflow Integration Tests', () => {
  const user = userEvent.setup();

  beforeEach(() => {
    vi.clearAllMocks();
    
    // Reset localStorage
    localStorage.clear();
    
    // Mock de datos iniciales
    localStorage.setItem('formacion-biblica-user', JSON.stringify({
      id: 'test-user',
      name: 'Test User',
      email: 'test@example.com'
    }));
  });

  describe('Complete Community Creation Workflow', () => {
    it('should allow user to create a community and receive notifications', async () => {
      render(<App />);

      // Navegar a la sección social
      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      // Esperar que cargue la interfaz social
      await waitFor(() => {
        expect(screen.getByText('Comunidades')).toBeInTheDocument();
      });

      // Crear nueva comunidad
      const createCommunityButton = screen.getByText('Crear Comunidad');
      await user.click(createCommunityButton);

      // Llenar formulario de comunidad
      const nameInput = screen.getByPlaceholderText('Nombre de la comunidad');
      await user.type(nameInput, 'Estudio de Apocalipsis');

      const descriptionInput = screen.getByPlaceholderText('Describe tu comunidad...');
      await user.type(descriptionInput, 'Comunidad dedicada al estudio profundo del libro de Apocalipsis');

      // Seleccionar categoría
      const categorySelect = screen.getByLabelText('Categoría');
      await user.click(categorySelect);
      await user.click(screen.getByText('Profético'));

      // Enviar formulario
      const submitButton = screen.getByText('Crear Comunidad');
      await user.click(submitButton);

      // Verificar que la comunidad fue creada
      await waitFor(() => {
        expect(screen.getByText('Estudio de Apocalipsis')).toBeInTheDocument();
      });

      // Verificar que se recibió notificación
      await waitFor(() => {
        expect(screen.getByText('Comunidad creada exitosamente')).toBeInTheDocument();
      });
    });

    it('should validate community creation form', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const createCommunityButton = screen.getByText('Crear Comunidad');
      await user.click(createCommunityButton);

      // Intentar enviar formulario vacío
      const submitButton = screen.getByText('Crear Comunidad');
      await user.click(submitButton);

      // Verificar mensajes de validación
      await waitFor(() => {
        expect(screen.getByText('El nombre es requerido')).toBeInTheDocument();
        expect(screen.getByText('La descripción es requerida')).toBeInTheDocument();
      });
    });
  });

  describe('Study Group Management Workflow', () => {
    it('should allow creating and joining study groups', async () => {
      render(<App />);

      // Navegar a grupos de estudio
      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const groupsTab = screen.getByText('Grupos de Estudio');
      await user.click(groupsTab);

      // Crear nuevo grupo
      const createGroupButton = screen.getByText('Crear Grupo');
      await user.click(createGroupButton);

      // Llenar formulario
      const groupNameInput = screen.getByPlaceholderText('Nombre del grupo');
      await user.type(groupNameInput, 'Estudio de Salmos');

      const bookSelect = screen.getByLabelText('Libro a estudiar');
      await user.click(bookSelect);
      await user.click(screen.getByText('Salmos'));

      const maxMembersInput = screen.getByLabelText('Máximo de miembros');
      await user.clear(maxMembersInput);
      await user.type(maxMembersInput, '8');

      // Configurar horario
      const frequencySelect = screen.getByLabelText('Frecuencia');
      await user.click(frequencySelect);
      await user.click(screen.getByText('Semanal'));

      const timeInput = screen.getByLabelText('Hora');
      await user.type(timeInput, '19:00');

      // Crear grupo
      const submitGroupButton = screen.getByText('Crear Grupo');
      await user.click(submitGroupButton);

      // Verificar creación
      await waitFor(() => {
        expect(screen.getByText('Estudio de Salmos')).toBeInTheDocument();
        expect(screen.getByText('8 miembros máximo')).toBeInTheDocument();
      });

      // Verificar que aparece en la lista de grupos del usuario
      expect(screen.getByText('Líder del grupo')).toBeInTheDocument();
    });

    it('should show study group recommendations', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const groupsTab = screen.getByText('Grupos de Estudio');
      await user.click(groupsTab);

      // Buscar grupos recomendados
      const recommendationsTab = screen.getByText('Recomendados');
      await user.click(recommendationsTab);

      await waitFor(() => {
        expect(screen.getByText('Grupos Recomendados para Ti')).toBeInTheDocument();
      });

      // Verificar que se muestran razones de recomendación
      expect(screen.getByText('Basado en tus intereses')).toBeInTheDocument();
    });
  });

  describe('Mentorship Request Workflow', () => {
    it('should allow requesting and managing mentorships', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const mentorshipsTab = screen.getByText('Mentorías');
      await user.click(mentorshipsTab);

      // Solicitar mentoría
      const requestButton = screen.getByText('Solicitar Mentoría');
      await user.click(requestButton);

      // Llenar formulario de solicitud
      const subjectInput = screen.getByPlaceholderText('Tema de mentoría');
      await user.type(subjectInput, 'Hermenéutica Bíblica');

      const goalsTextarea = screen.getByPlaceholderText('Describe tus objetivos...');
      await user.type(goalsTextarea, 'Quiero aprender a interpretar correctamente las Escrituras');

      const durationSelect = screen.getByLabelText('Duración preferida');
      await user.click(durationSelect);
      await user.click(screen.getByText('3 meses'));

      // Enviar solicitud
      const submitMentorshipButton = screen.getByText('Enviar Solicitud');
      await user.click(submitMentorshipButton);

      // Verificar que la solicitud fue enviada
      await waitFor(() => {
        expect(screen.getByText('Solicitud enviada exitosamente')).toBeInTheDocument();
      });

      // Verificar que aparece en solicitudes pendientes
      expect(screen.getByText('Hermenéutica Bíblica')).toBeInTheDocument();
      expect(screen.getByText('Pendiente')).toBeInTheDocument();
    });

    it('should show mentor recommendations', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const mentorshipsTab = screen.getByText('Mentorías');
      await user.click(mentorshipsTab);

      const findMentorTab = screen.getByText('Encontrar Mentor');
      await user.click(findMentorTab);

      await waitFor(() => {
        expect(screen.getByText('Mentores Recomendados')).toBeInTheDocument();
      });

      // Verificar información de mentores
      expect(screen.getByText('Especialidad')).toBeInTheDocument();
      expect(screen.getByText('Experiencia')).toBeInTheDocument();
      expect(screen.getByText('Compatibilidad')).toBeInTheDocument();
    });
  });

  describe('Real-time Collaboration Workflow', () => {
    it('should allow starting collaborative study sessions', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const collaborationTab = screen.getByText('Colaboración');
      await user.click(collaborationTab);

      // Iniciar sesión colaborativa
      const startSessionButton = screen.getByText('Iniciar Sesión');
      await user.click(startSessionButton);

      // Configurar sesión
      const sessionNameInput = screen.getByPlaceholderText('Nombre de la sesión');
      await user.type(sessionNameInput, 'Estudio de Juan 3:16');

      const sessionTypeSelect = screen.getByLabelText('Tipo de sesión');
      await user.click(sessionTypeSelect);
      await user.click(screen.getByText('Estudio de Versículo'));

      // Crear sesión
      const createSessionButton = screen.getByText('Crear Sesión');
      await user.click(createSessionButton);

      // Verificar que la sesión fue creada
      await waitFor(() => {
        expect(screen.getByText('Sesión iniciada: Estudio de Juan 3:16')).toBeInTheDocument();
      });

      // Verificar herramientas colaborativas disponibles
      expect(screen.getByText('Chat en Vivo')).toBeInTheDocument();
      expect(screen.getByText('Anotaciones Compartidas')).toBeInTheDocument();
      expect(screen.getByText('Pizarra Virtual')).toBeInTheDocument();
    });

    it('should handle joining existing collaboration sessions', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const collaborationTab = screen.getByText('Colaboración');
      await user.click(collaborationTab);

      // Ver sesiones activas
      const activeSessionsTab = screen.getByText('Sesiones Activas');
      await user.click(activeSessionsTab);

      await waitFor(() => {
        expect(screen.getByText('Sesiones en Curso')).toBeInTheDocument();
      });

      // Unirse a una sesión
      const joinButton = screen.getByText('Unirse');
      await user.click(joinButton);

      // Verificar que se unió a la sesión
      await waitFor(() => {
        expect(screen.getByText('Te has unido a la sesión')).toBeInTheDocument();
      });
    });
  });

  describe('Gamification and Challenges Workflow', () => {
    it('should allow creating and participating in challenges', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const challengesTab = screen.getByText('Desafíos');
      await user.click(challengesTab);

      // Crear nuevo desafío
      const createChallengeButton = screen.getByText('Crear Desafío');
      await user.click(createChallengeButton);

      // Llenar formulario de desafío
      const titleInput = screen.getByPlaceholderText('Título del desafío');
      await user.type(titleInput, 'Leer Proverbios en 31 días');

      const descriptionTextarea = screen.getByPlaceholderText('Describe el desafío...');
      await user.type(descriptionTextarea, 'Lee un capítulo de Proverbios cada día durante un mes');

      const typeSelect = screen.getByLabelText('Tipo de desafío');
      await user.click(typeSelect);
      await user.click(screen.getByText('Individual'));

      const difficultySelect = screen.getByLabelText('Dificultad');
      await user.click(difficultySelect);
      await user.click(screen.getByText('Fácil'));

      // Configurar recompensas
      const pointsInput = screen.getByLabelText('Puntos a otorgar');
      await user.clear(pointsInput);
      await user.type(pointsInput, '500');

      // Crear desafío
      const submitChallengeButton = screen.getByText('Crear Desafío');
      await user.click(submitChallengeButton);

      // Verificar creación
      await waitFor(() => {
        expect(screen.getByText('Leer Proverbios en 31 días')).toBeInTheDocument();
        expect(screen.getByText('500 puntos')).toBeInTheDocument();
      });
    });

    it('should track challenge progress', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const challengesTab = screen.getByText('Desafíos');
      await user.click(challengesTab);

      // Ver progreso de desafíos activos
      const myProgressTab = screen.getByText('Mi Progreso');
      await user.click(myProgressTab);

      await waitFor(() => {
        expect(screen.getByText('Desafíos Activos')).toBeInTheDocument();
      });

      // Verificar barra de progreso
      const progressBars = screen.getAllByRole('progressbar');
      expect(progressBars.length).toBeGreaterThan(0);

      // Verificar estadísticas
      expect(screen.getByText('Días completados')).toBeInTheDocument();
      expect(screen.getByText('Racha actual')).toBeInTheDocument();
    });
  });

  describe('Cross-Module Integration', () => {
    it('should sync notifications across social activities', async () => {
      render(<App />);

      // Realizar actividad social (crear comunidad)
      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const createCommunityButton = screen.getByText('Crear Comunidad');
      await user.click(createCommunityButton);

      // Completar creación rápida
      const nameInput = screen.getByPlaceholderText('Nombre de la comunidad');
      await user.type(nameInput, 'Test Community');

      const submitButton = screen.getByText('Crear Comunidad');
      await user.click(submitButton);

      // Verificar notificación
      await waitFor(() => {
        expect(screen.getByText('Comunidad creada exitosamente')).toBeInTheDocument();
      });

      // Navegar a centro de notificaciones
      const notificationsButton = screen.getByLabelText('Notificaciones');
      await user.click(notificationsButton);

      // Verificar que la notificación aparece en el centro
      await waitFor(() => {
        expect(screen.getByText('Nueva comunidad creada')).toBeInTheDocument();
      });
    });

    it('should recommend content based on social activity', async () => {
      render(<App />);

      // Unirse a un grupo de estudio de Salmos
      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      const groupsTab = screen.getByText('Grupos de Estudio');
      await user.click(groupsTab);

      const joinGroupButton = screen.getByText('Unirse al Grupo');
      await user.click(joinGroupButton);

      // Navegar a recomendaciones
      const studyButton = screen.getByText('Estudio');
      await user.click(studyButton);

      // Verificar recomendaciones basadas en actividad social
      await waitFor(() => {
        expect(screen.getByText('Recomendado por tu actividad social')).toBeInTheDocument();
        expect(screen.getByText('Salmos')).toBeInTheDocument();
      });
    });

    it('should update analytics based on social engagement', async () => {
      render(<App />);

      // Realizar múltiples actividades sociales
      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      // Crear comunidad
      const createCommunityButton = screen.getByText('Crear Comunidad');
      await user.click(createCommunityButton);
      // ... completar formulario rápido

      // Unirse a grupo
      const groupsTab = screen.getByText('Grupos de Estudio');
      await user.click(groupsTab);
      // ... unirse a grupo

      // Participar en desafío
      const challengesTab = screen.getByText('Desafíos');
      await user.click(challengesTab);
      // ... unirse a desafío

      // Verificar analytics
      const analyticsButton = screen.getByText('Análisis');
      await user.click(analyticsButton);

      await waitFor(() => {
        expect(screen.getByText('Participación Social')).toBeInTheDocument();
        expect(screen.getByText('Engagement Score')).toBeInTheDocument();
      });
    });
  });

  describe('Performance Under Load', () => {
    it('should handle multiple simultaneous operations', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      // Simular múltiples operaciones simultáneas
      const operations = [
        () => user.click(screen.getByText('Crear Comunidad')),
        () => user.click(screen.getByText('Grupos de Estudio')),
        () => user.click(screen.getByText('Mentorías')),
        () => user.click(screen.getByText('Colaboración')),
        () => user.click(screen.getByText('Desafíos'))
      ];

      // Ejecutar operaciones rápidamente
      await Promise.all(operations.map(op => op()));

      // Verificar que la aplicación sigue respondiendo
      await waitFor(() => {
        expect(screen.getByTestId('social-container')).toBeInTheDocument();
      });
    });

    it('should maintain responsiveness with large datasets', async () => {
      // Mock de gran cantidad de datos
      const largeCommunityList = Array.from({ length: 100 }, (_, i) => ({
        id: `comm-${i}`,
        name: `Community ${i}`,
        members: Array.from({ length: 50 }, (_, j) => `user-${j}`)
      }));

      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      // Verificar que la lista se renderiza sin problemas de performance
      await waitFor(() => {
        expect(screen.getByText('Comunidades')).toBeInTheDocument();
      }, { timeout: 3000 });

      // Probar scroll virtual si está implementado
      const communityList = screen.getByTestId('communities-list');
      expect(communityList).toBeInTheDocument();
    });
  });

  describe('Error Recovery', () => {
    it('should recover from network errors gracefully', async () => {
      // Simular error de red
      const originalFetch = global.fetch;
      global.fetch = vi.fn().mockRejectedValue(new Error('Network error'));

      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      // Verificar que se muestra mensaje de error apropiado
      await waitFor(() => {
        expect(screen.getByText('Error de conexión')).toBeInTheDocument();
      });

      // Simular recuperación de red
      global.fetch = originalFetch;

      // Verificar que la aplicación se recupera
      const retryButton = screen.getByText('Reintentar');
      await user.click(retryButton);

      await waitFor(() => {
        expect(screen.getByText('Comunidades')).toBeInTheDocument();
      });
    });

    it('should handle partial failures in social operations', async () => {
      render(<App />);

      const socialButton = await screen.findByText('Social');
      await user.click(socialButton);

      // Simular fallo parcial (algunas operaciones fallan, otras no)
      const createCommunityButton = screen.getByText('Crear Comunidad');
      await user.click(createCommunityButton);

      // Llenar formulario con datos que causarán error parcial
      const nameInput = screen.getByPlaceholderText('Nombre de la comunidad');
      await user.type(nameInput, 'Test Community');

      const submitButton = screen.getByText('Crear Comunidad');
      await user.click(submitButton);

      // Verificar manejo de error parcial
      await waitFor(() => {
        expect(screen.getByText('Algunos campos no pudieron ser guardados')).toBeInTheDocument();
      });
    });
  });
});
