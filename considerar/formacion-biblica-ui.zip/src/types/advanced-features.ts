/**
 * Tipos TypeScript para Funcionalidades Avanzadas
 * Aplicación de Formación Bíblica - Nuevas Características
 */

// =====================================================================
// TIPOS PARA SISTEMA DE ESTUDIOS PERSONALIZADOS
// =====================================================================

export interface ReadingPlan {
  id: string;
  name: string;
  description: string;
  type: 'sequential' | 'thematic' | 'chronological' | 'custom';
  duration: number; // días
  books: string[];
  dailyReadings: DailyReading[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  tags: string[];
  createdBy: string;
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface DailyReading {
  day: number;
  readings: BibleReading[];
  reflection?: string;
  questions?: string[];
  estimatedTime: number; // minutos
}

export interface BibleReading {
  book: string;
  chapter: number;
  startVerse?: number;
  endVerse?: number;
  focus?: string; // tema o enfoque específico
}

export interface StudyProgress {
  planId: string;
  userId: string;
  currentDay: number;
  completedDays: number[];
  totalDays: number;
  startDate: Date;
  lastReadDate?: Date;
  notes: StudyNote[];
  timeSpent: number; // minutos totales
  completed: boolean;
}

export interface StudyNote {
  id: string;
  day: number;
  reading: BibleReading;
  content: string;
  type: 'note' | 'reflection' | 'question' | 'prayer';
  tags: string[];
  createdAt: Date;
  isPrivate: boolean;
}

export interface StudyReminder {
  id: string;
  userId: string;
  planId: string;
  time: string; // formato HH:MM
  days: number[]; // 0-6 (domingo-sábado)
  enabled: boolean;
  message: string;
}

// =====================================================================
// TIPOS PARA HERRAMIENTAS DE ESTUDIO AVANZADAS
// =====================================================================

export interface BibleVersion {
  id: string;
  name: string;
  abbreviation: string;
  language: string;
  year: number;
  description: string;
  available: boolean;
}

export interface VersionComparison {
  reference: string;
  versions: {
    versionId: string;
    text: string;
    differences?: TextDifference[];
  }[];
}

export interface TextDifference {
  type: 'addition' | 'deletion' | 'modification';
  position: number;
  oldText?: string;
  newText?: string;
}

export interface PersonalNote {
  id: string;
  userId: string;
  reference: string; // ej: "Juan 3:16"
  content: string;
  type: 'note' | 'commentary' | 'reflection' | 'question';
  tags: string[];
  color?: string;
  isPrivate: boolean;
  createdAt: Date;
  updatedAt: Date;
  linkedNotes?: string[]; // IDs de notas relacionadas
}

export interface HighlightTheme {
  id: string;
  name: string;
  color: string;
  description: string;
  keywords: string[];
  autoHighlight: boolean;
}

export interface TextHighlight {
  id: string;
  userId: string;
  reference: string;
  startWord: number;
  endWord: number;
  themeId: string;
  text: string;
  createdAt: Date;
}

export interface Concordance {
  word: string;
  strongNumber?: string;
  definition: string;
  occurrences: ConcordanceOccurrence[];
  relatedWords: string[];
  etymology?: string;
}

export interface ConcordanceOccurrence {
  reference: string;
  context: string;
  translation: string;
}

// =====================================================================
// TIPOS PARA ANÁLISIS TEXTUAL CON IA
// =====================================================================

export interface SemanticAnalysis {
  reference: string;
  themes: Theme[];
  emotions: Emotion[];
  characters: Character[];
  literaryDevices: LiteraryDevice[];
  historicalContext: HistoricalContext;
  theologicalConcepts: TheologicalConcept[];
  summary: string;
  keyVerses: string[];
  relatedPassages: RelatedPassage[];
}

export interface Theme {
  id: string;
  name: string;
  description: string;
  relevance: number; // 0-1
  verses: string[];
  relatedThemes: string[];
}

export interface Emotion {
  type: string;
  intensity: number; // 0-1
  context: string;
  verses: string[];
}

export interface Character {
  name: string;
  role: string;
  description: string;
  appearances: string[];
  significance: string;
}

export interface LiteraryDevice {
  type: string;
  description: string;
  examples: string[];
  purpose: string;
}

export interface HistoricalContext {
  period: string;
  location: string;
  culturalBackground: string;
  politicalSituation: string;
  religiousContext: string;
  significance: string;
}

export interface TheologicalConcept {
  concept: string;
  definition: string;
  biblicalBasis: string[];
  relatedConcepts: string[];
  applications: string[];
}

export interface RelatedPassage {
  reference: string;
  relationship: 'parallel' | 'contrast' | 'fulfillment' | 'background' | 'application';
  description: string;
  relevance: number;
}

export interface AIInsight {
  id: string;
  reference: string;
  type: 'theme' | 'application' | 'cross_reference' | 'historical' | 'linguistic';
  title: string;
  content: string;
  confidence: number; // 0-1
  sources: string[];
  createdAt: Date;
}

// =====================================================================
// TIPOS PARA SISTEMA DE GAMIFICACIÓN
// =====================================================================

export interface UserLevel {
  level: number;
  title: string;
  description: string;
  requiredXP: number;
  benefits: string[];
  icon: string;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  category: 'reading' | 'study' | 'social' | 'knowledge' | 'consistency' | 'special';
  type: 'milestone' | 'streak' | 'challenge' | 'exploration' | 'mastery';
  difficulty: 'easy' | 'medium' | 'hard' | 'legendary';
  points: number;
  requirements: AchievementRequirement[];
  icon: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  isSecret: boolean;
  unlockedBy?: string[];
}

export interface AchievementRequirement {
  type: 'read_books' | 'read_chapters' | 'study_days' | 'notes_created' | 'social_interactions' | 'quiz_score';
  target: number;
  timeframe?: number; // días
}

export interface UserAchievement {
  achievementId: string;
  userId: string;
  unlockedAt: Date;
  progress: number; // 0-1
  notified: boolean;
}

export interface Challenge {
  id: string;
  name: string;
  description: string;
  type: 'daily' | 'weekly' | 'monthly' | 'seasonal' | 'special';
  category: 'reading' | 'memorization' | 'study' | 'social' | 'reflection';
  startDate: Date;
  endDate: Date;
  requirements: ChallengeRequirement[];
  rewards: ChallengeReward[];
  difficulty: 'easy' | 'medium' | 'hard';
  participants: number;
  maxParticipants?: number;
  isActive: boolean;
}

export interface ChallengeRequirement {
  type: string;
  description: string;
  target: number;
  currentProgress?: number;
}

export interface ChallengeReward {
  type: 'xp' | 'badge' | 'title' | 'unlock';
  value: string | number;
  description: string;
}

export interface Leaderboard {
  id: string;
  name: string;
  type: 'global' | 'friends' | 'community' | 'challenge';
  period: 'daily' | 'weekly' | 'monthly' | 'all_time';
  metric: 'total_xp' | 'reading_streak' | 'chapters_read' | 'study_time' | 'achievements';
  entries: LeaderboardEntry[];
  lastUpdated: Date;
}

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  userName: string;
  avatar?: string;
  score: number;
  change: number; // cambio desde último período
  badge?: string;
}

// =====================================================================
// TIPOS PARA FUNCIONALIDADES MULTIMEDIA
// =====================================================================

export interface AudioSettings {
  voice: string;
  speed: number; // 0.5 - 2.0
  volume: number; // 0-1
  autoplay: boolean;
  language: string;
}

export interface AudioTrack {
  reference: string;
  audioUrl: string;
  duration: number;
  voice: string;
  language: string;
  quality: 'low' | 'medium' | 'high';
}

export interface ContextualImage {
  id: string;
  reference: string;
  url: string;
  title: string;
  description: string;
  type: 'illustration' | 'map' | 'artifact' | 'painting' | 'photo';
  source: string;
  license: string;
  relevance: number;
}

export interface BibleMap {
  id: string;
  name: string;
  description: string;
  period: string;
  imageUrl: string;
  interactiveData: MapLocation[];
  relatedPassages: string[];
}

export interface MapLocation {
  id: string;
  name: string;
  coordinates: { x: number; y: number };
  description: string;
  type: 'city' | 'region' | 'landmark' | 'route' | 'battle';
  biblicalEvents: BibleEvent[];
}

export interface BibleEvent {
  reference: string;
  description: string;
  date?: string;
  significance: string;
}

export interface Timeline {
  id: string;
  name: string;
  description: string;
  startYear: number;
  endYear: number;
  events: TimelineEvent[];
  categories: TimelineCategory[];
}

export interface TimelineEvent {
  id: string;
  title: string;
  date: string;
  description: string;
  references: string[];
  category: string;
  importance: number; // 1-5
  imageUrl?: string;
}

export interface TimelineCategory {
  id: string;
  name: string;
  color: string;
  description: string;
}

// =====================================================================
// TIPOS PARA COLABORACIÓN Y GRUPOS DE ESTUDIO
// =====================================================================

export interface StudyGroup {
  id: string;
  name: string;
  description: string;
  type: 'public' | 'private' | 'invite_only';
  category: 'general' | 'youth' | 'adult' | 'family' | 'ministry' | 'academic';
  memberCount: number;
  maxMembers?: number;
  createdBy: string;
  moderators: string[];
  currentStudy?: string; // plan de estudio actual
  meetingSchedule?: MeetingSchedule;
  rules: string[];
  tags: string[];
  createdAt: Date;
  isActive: boolean;
}

export interface MeetingSchedule {
  type: 'weekly' | 'biweekly' | 'monthly' | 'custom';
  dayOfWeek: number; // 0-6
  time: string; // HH:MM
  timezone: string;
  duration: number; // minutos
  isVirtual: boolean;
  meetingLink?: string;
}

export interface GroupMember {
  userId: string;
  groupId: string;
  role: 'member' | 'moderator' | 'leader';
  joinedAt: Date;
  lastActivity: Date;
  permissions: GroupPermission[];
  isActive: boolean;
}

export interface GroupPermission {
  type: 'post' | 'moderate' | 'invite' | 'schedule' | 'admin';
  granted: boolean;
}

export interface Discussion {
  id: string;
  groupId: string;
  authorId: string;
  reference?: string;
  title: string;
  content: string;
  type: 'question' | 'reflection' | 'announcement' | 'prayer_request' | 'study_note';
  tags: string[];
  isPinned: boolean;
  replies: DiscussionReply[];
  reactions: Reaction[];
  createdAt: Date;
  updatedAt: Date;
}

export interface DiscussionReply {
  id: string;
  authorId: string;
  content: string;
  parentReplyId?: string;
  reactions: Reaction[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Reaction {
  userId: string;
  type: 'like' | 'love' | 'pray' | 'amen' | 'question' | 'insight';
  createdAt: Date;
}

export interface LiveSession {
  id: string;
  groupId: string;
  hostId: string;
  title: string;
  description: string;
  scheduledAt: Date;
  startedAt?: Date;
  endedAt?: Date;
  status: 'scheduled' | 'live' | 'ended' | 'cancelled';
  participants: SessionParticipant[];
  maxParticipants?: number;
  isRecorded: boolean;
  recordingUrl?: string;
  agenda: SessionAgenda[];
}

export interface SessionParticipant {
  userId: string;
  joinedAt: Date;
  leftAt?: Date;
  role: 'host' | 'moderator' | 'participant';
  permissions: SessionPermission[];
}

export interface SessionPermission {
  type: 'speak' | 'share_screen' | 'chat' | 'control';
  granted: boolean;
}

export interface SessionAgenda {
  id: string;
  title: string;
  description: string;
  duration: number; // minutos
  type: 'introduction' | 'reading' | 'discussion' | 'prayer' | 'reflection' | 'closing';
  reference?: string;
  materials?: string[];
}

// =====================================================================
// TIPOS PARA HERRAMIENTAS DE PREDICACIÓN
// =====================================================================

export interface SermonOutline {
  id: string;
  title: string;
  mainText: string;
  theme: string;
  type: 'expository' | 'topical' | 'textual' | 'narrative';
  occasion?: string;
  audience: string;
  duration: number; // minutos
  points: SermonPoint[];
  introduction: SermonSection;
  conclusion: SermonSection;
  illustrations: Illustration[];
  applications: Application[];
  crossReferences: string[];
  tags: string[];
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
  isPublic: boolean;
}

export interface SermonPoint {
  id: string;
  order: number;
  title: string;
  mainIdea: string;
  subPoints: SubPoint[];
  supportingTexts: string[];
  explanation: string;
  illustration?: string;
  application?: string;
}

export interface SubPoint {
  id: string;
  title: string;
  description: string;
  supportingText?: string;
}

export interface SermonSection {
  content: string;
  duration: number;
  notes: string[];
  transitions: string[];
}

export interface Illustration {
  id: string;
  title: string;
  content: string;
  type: 'story' | 'analogy' | 'example' | 'quote' | 'statistic' | 'image';
  source?: string;
  topic: string;
  tags: string[];
  effectiveness: number; // 1-5
  ageGroup: string[];
  context: string[];
}

export interface Application {
  id: string;
  title: string;
  description: string;
  type: 'personal' | 'family' | 'community' | 'workplace' | 'ministry';
  actionSteps: string[];
  reflection: string;
  challenge: string;
}

export interface SermonSeries {
  id: string;
  title: string;
  description: string;
  theme: string;
  duration: number; // semanas
  sermons: SermonInSeries[];
  createdBy: string;
  isComplete: boolean;
  tags: string[];
}

export interface SermonInSeries {
  sermonId: string;
  order: number;
  title: string;
  mainText: string;
  date?: Date;
  status: 'planned' | 'in_progress' | 'completed';
}

// =====================================================================
// TIPOS PARA DASHBOARD DE MÉTRICAS
// =====================================================================

export interface UserMetrics {
  userId: string;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'all_time';
  readingStats: ReadingStats;
  studyStats: StudyStats;
  socialStats: SocialStats;
  gamificationStats: GamificationStats;
  generalStats: GeneralStats;
  lastUpdated: Date;
}

export interface ReadingStats {
  booksRead: number;
  chaptersRead: number;
  versesRead: number;
  timeSpent: number; // minutos
  averageSessionDuration: number;
  readingStreak: number;
  favoriteBooks: BookStats[];
  readingPattern: ReadingPattern[];
  completion: {
    oldTestament: number; // porcentaje
    newTestament: number; // porcentaje
    total: number; // porcentaje
  };
}

export interface BookStats {
  book: string;
  chaptersRead: number;
  totalChapters: number;
  timeSpent: number;
  lastRead: Date;
  completionPercentage: number;
}

export interface ReadingPattern {
  date: string;
  chaptersRead: number;
  timeSpent: number;
  sessionCount: number;
}

export interface StudyStats {
  plansCompleted: number;
  currentPlans: number;
  totalStudyTime: number;
  notesCreated: number;
  reflectionsWritten: number;
  questionsAnswered: number;
  averageStudySession: number;
  favoriteTopics: TopicStats[];
}

export interface TopicStats {
  topic: string;
  studyCount: number;
  timeSpent: number;
  notesCount: number;
}

export interface SocialStats {
  groupsJoined: number;
  discussionsStarted: number;
  repliesPosted: number;
  reactionsGiven: number;
  reactionsReceived: number;
  friendsCount: number;
  mentorshipSessions: number;
}

export interface GamificationStats {
  totalXP: number;
  currentLevel: number;
  achievementsUnlocked: number;
  challengesCompleted: number;
  streakDays: number;
  leaderboardRank: number;
  badgesEarned: BadgeStats[];
}

export interface BadgeStats {
  badgeId: string;
  unlockedAt: Date;
  rarity: string;
  category: string;
}

export interface GeneralStats {
  accountAge: number; // días
  loginStreak: number;
  totalSessions: number;
  averageSessionTime: number;
  featuresUsed: FeatureUsage[];
  goals: UserGoal[];
}

export interface FeatureUsage {
  feature: string;
  usageCount: number;
  lastUsed: Date;
  timeSpent: number;
}

export interface UserGoal {
  id: string;
  type: 'reading' | 'study' | 'social' | 'custom';
  title: string;
  description: string;
  target: number;
  current: number;
  deadline?: Date;
  isActive: boolean;
  createdAt: Date;
}

export interface Analytics {
  pageViews: PageView[];
  userEngagement: EngagementMetric[];
  featureAdoption: FeatureAdoption[];
  performanceMetrics: PerformanceMetric[];
}

export interface PageView {
  page: string;
  views: number;
  uniqueViews: number;
  averageTime: number;
  bounceRate: number;
  date: string;
}

export interface EngagementMetric {
  metric: string;
  value: number;
  change: number;
  period: string;
  date: string;
}

export interface FeatureAdoption {
  feature: string;
  activeUsers: number;
  adoptionRate: number;
  retentionRate: number;
  date: string;
}

export interface PerformanceMetric {
  metric: string;
  value: number;
  threshold: number;
  status: 'good' | 'warning' | 'critical';
  date: string;
}

// =====================================================================
// TIPOS AUXILIARES Y UTILIDADES
// =====================================================================

export interface APIResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  metadata?: {
    total?: number;
    page?: number;
    limit?: number;
    hasMore?: boolean;
  };
}

export interface PaginationParams {
  page: number;
  limit: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  filters?: Record<string, any>;
}

export interface SearchParams {
  query: string;
  type?: string[];
  filters?: Record<string, any>;
  limit?: number;
  includeContent?: boolean;
}

export interface NotificationSettings {
  reminders: boolean;
  achievements: boolean;
  social: boolean;
  challenges: boolean;
  groupActivity: boolean;
  email: boolean;
  push: boolean;
  frequency: 'immediate' | 'daily' | 'weekly';
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'auto';
  language: string;
  defaultBibleVersion: string;
  readingFontSize: number;
  autoSave: boolean;
  notifications: NotificationSettings;
  privacy: PrivacySettings;
  accessibility: AccessibilitySettings;
}

export interface PrivacySettings {
  profileVisibility: 'public' | 'friends' | 'private';
  activityVisibility: 'public' | 'friends' | 'private';
  allowFriendRequests: boolean;
  allowGroupInvites: boolean;
  showOnLeaderboards: boolean;
}

export interface AccessibilitySettings {
  highContrast: boolean;
  largeText: boolean;
  reducedMotion: boolean;
  screenReader: boolean;
  keyboardNavigation: boolean;
}

// =====================================================================
// CONTEXTO Y ESTADOS GLOBALES
// =====================================================================

export interface AppState {
  user: User | null;
  currentPlan: ReadingPlan | null;
  activeStudySession: StudySession | null;
  notifications: Notification[];
  preferences: UserPreferences;
  isLoading: boolean;
  error: string | null;
}

export interface User {
  id: string;
  email: string;
  username: string;
  displayName: string;
  avatar?: string;
  level: number;
  xp: number;
  joinedAt: Date;
  lastActiveAt: Date;
  isVerified: boolean;
  roles: UserRole[];
  preferences: UserPreferences;
  stats: UserMetrics;
}

export interface UserRole {
  type: 'user' | 'moderator' | 'admin' | 'teacher' | 'pastor';
  permissions: string[];
  grantedAt: Date;
  grantedBy: string;
}

export interface StudySession {
  id: string;
  userId: string;
  planId?: string;
  startTime: Date;
  endTime?: Date;
  activities: StudyActivity[];
  notes: StudyNote[];
  progress: StudyProgress;
}

export interface StudyActivity {
  type: 'reading' | 'note_taking' | 'reflection' | 'prayer' | 'discussion';
  reference?: string;
  duration: number;
  completed: boolean;
  timestamp: Date;
}

export interface Notification {
  id: string;
  type: 'reminder' | 'achievement' | 'social' | 'challenge' | 'system';
  title: string;
  message: string;
  data?: any;
  read: boolean;
  createdAt: Date;
  expiresAt?: Date;
  actions?: NotificationAction[];
}

export interface NotificationAction {
  type: 'link' | 'action' | 'dismiss';
  label: string;
  url?: string;
  action?: string;
  data?: any;
}
