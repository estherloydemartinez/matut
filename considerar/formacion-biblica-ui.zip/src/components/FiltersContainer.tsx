import { motion } from 'framer-motion'
import { Filter, Droplets, Zap } from 'lucide-react'

export default function FiltersContainer() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="discord-card p-6 rounded-lg">
        <div className="flex items-center space-x-3 mb-6">
          <Filter className="w-6 h-6 text-discord-primary" />
          <h2 className="text-xl font-semibold text-discord-text-primary">Filtros Analíticos</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="discord-card p-6 rounded-lg bg-red-900/20 border border-red-500/30">
            <div className="flex items-center space-x-3 mb-4">
              <Droplets className="w-8 h-8 text-red-400" />
              <div>
                <h3 className="text-lg font-semibold text-discord-text-primary">Filtro Sangre</h3>
                <p className="text-sm text-discord-text-secondary">Pasajes relacionados con la sangre de Cristo</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="p-3 bg-discord-secondary rounded-lg">
                <h4 className="font-medium text-discord-text-primary mb-2">Categorías disponibles:</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <span className="px-2 py-1 bg-red-500/20 rounded text-red-300">Pacto</span>
                  <span className="px-2 py-1 bg-red-500/20 rounded text-red-300">Sacrificio</span>
                  <span className="px-2 py-1 bg-red-500/20 rounded text-red-300">Redención</span>
                  <span className="px-2 py-1 bg-red-500/20 rounded text-red-300">Expiación</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="discord-card p-6 rounded-lg bg-blue-900/20 border border-blue-500/30">
            <div className="flex items-center space-x-3 mb-4">
              <Zap className="w-8 h-8 text-blue-400" />
              <div>
                <h3 className="text-lg font-semibold text-discord-text-primary">Filtro Agua</h3>
                <p className="text-sm text-discord-text-secondary">Pasajes relacionados con el agua en las Escrituras</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="p-3 bg-discord-secondary rounded-lg">
                <h4 className="font-medium text-discord-text-primary mb-2">Categorías disponibles:</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <span className="px-2 py-1 bg-blue-500/20 rounded text-blue-300">Bautismo</span>
                  <span className="px-2 py-1 bg-blue-500/20 rounded text-blue-300">Purificación</span>
                  <span className="px-2 py-1 bg-blue-500/20 rounded text-blue-300">Vida eterna</span>
                  <span className="px-2 py-1 bg-blue-500/20 rounded text-blue-300">Espíritu</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-6 text-center">
          <p className="text-discord-text-muted">
            Los filtros analíticos se cargarán desde los datos optimizados
          </p>
        </div>
      </div>
    </motion.div>
  )
}
