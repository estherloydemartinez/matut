import { motion } from 'framer-motion'
import { BookOpen, PenTool, Lightbulb, Target } from 'lucide-react'

export default function StudyContainer() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="discord-card p-6 rounded-lg">
        <div className="flex items-center space-x-3 mb-4">
          <Lightbulb className="w-6 h-6 text-discord-primary" />
          <h2 className="text-xl font-semibold text-discord-text-primary">Modo de Estudio</h2>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main study area */}
          <div className="lg:col-span-2">
            <div className="discord-card p-6 rounded-lg bg-discord-tertiary">
              <div className="text-center py-12">
                <BookOpen className="w-16 h-16 mx-auto text-discord-text-muted mb-4" />
                <h3 className="text-lg font-medium text-discord-text-primary mb-2">
                  Selecciona un pasaje para estudiar
                </h3>
                <p className="text-discord-text-secondary">
                  Elige un libro y capítulo desde la sección Biblia para comenzar tu estudio detallado
                </p>
              </div>
            </div>
          </div>
          
          {/* Study tools sidebar */}
          <div className="space-y-4">
            <div className="discord-card p-4 rounded-lg">
              <h4 className="font-medium text-discord-text-primary mb-3 flex items-center">
                <Target className="w-4 h-4 mr-2" />
                Herramientas de Estudio
              </h4>
              <div className="space-y-2 text-sm">
                <button className="w-full text-left p-2 rounded hover:bg-discord-modifier-hover transition-colors text-discord-text-secondary">
                  📝 Notas personales
                </button>
                <button className="w-full text-left p-2 rounded hover:bg-discord-modifier-hover transition-colors text-discord-text-secondary">
                  🔍 Análisis contextual
                </button>
                <button className="w-full text-left p-2 rounded hover:bg-discord-modifier-hover transition-colors text-discord-text-secondary">
                  📖 Referencias cruzadas
                </button>
                <button className="w-full text-left p-2 rounded hover:bg-discord-modifier-hover transition-colors text-discord-text-secondary">
                  🎯 Aplicación práctica
                </button>
              </div>
            </div>
            
            <div className="discord-card p-4 rounded-lg">
              <h4 className="font-medium text-discord-text-primary mb-3 flex items-center">
                <PenTool className="w-4 h-4 mr-2" />
                Mis Notas
              </h4>
              <div className="text-center py-4">
                <p className="text-discord-text-muted text-sm">
                  Tus notas de estudio aparecerán aquí
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
