import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { toast } from '@/hooks/use-toast';

// Importar los componentes de funcionalidades avanzadas
import PersonalizedStudySystem from './PersonalizedStudySystem';
import AdvancedStudyTools from './AdvancedStudyTools';
import GamificationSystem from './GamificationSystem';
import MetricsDashboard from './MetricsDashboard';

import { 
  Sparkles,
  BookOpen, 
  Search, 
  Trophy, 
  BarChart3,
  Users,
  Mic,
  Image as ImageIcon,
  Map,
  MessageSquare,
  Edit3,
  Target,
  Settings,
  Info,
  CheckCircle,
  AlertTriangle,
  Lightbulb,
  Rocket,
  Star
} from 'lucide-react';

interface FeatureStatus {
  id: string;
  name: string;
  description: string;
  status: 'available' | 'beta' | 'coming_soon' | 'disabled';
  component?: React.ComponentType;
  icon: React.ReactNode;
  category: 'study' | 'social' | 'multimedia' | 'analysis' | 'gamification' | 'tools';
}

const AdvancedFeaturesHub: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState<string>('overview');
  const [showWelcome, setShowWelcome] = useState(false);
  const [systemStatus, setSystemStatus] = useState<'loading' | 'ready' | 'error'>('loading');

  // Definir todas las funcionalidades avanzadas disponibles
  const features: FeatureStatus[] = [
    {
      id: 'personalized-study',
      name: 'Estudios Personalizados',
      description: 'Crea y sigue planes de lectura adaptados a tus necesidades',
      status: 'available',
      component: PersonalizedStudySystem,
      icon: <BookOpen className="w-6 h-6" />,
      category: 'study'
    },
    {
      id: 'advanced-tools',
      name: 'Herramientas de Estudio',
      description: 'Compara versiones, toma notas y usa concordancia avanzada',
      status: 'available',
      component: AdvancedStudyTools,
      icon: <Search className="w-6 h-6" />,
      category: 'tools'
    },
    {
      id: 'gamification',
      name: 'Sistema de Gamificación',
      description: 'Gana puntos, desbloquea logros y compite con otros usuarios',
      status: 'available',
      component: GamificationSystem,
      icon: <Trophy className="w-6 h-6" />,
      category: 'gamification'
    },
    {
      id: 'metrics',
      name: 'Dashboard de Métricas',
      description: 'Analiza tu progreso con estadísticas detalladas',
      status: 'available',
      component: MetricsDashboard,
      icon: <BarChart3 className="w-6 h-6" />,
      category: 'analysis'
    },
    {
      id: 'ai-analysis',
      name: 'Análisis con IA',
      description: 'Análisis semántico inteligente de textos bíblicos',
      status: 'beta',
      icon: <Lightbulb className="w-6 h-6" />,
      category: 'analysis'
    },
    {
      id: 'collaboration',
      name: 'Grupos de Estudio',
      description: 'Colabora con otros usuarios en grupos de estudio',
      status: 'beta',
      icon: <Users className="w-6 h-6" />,
      category: 'social'
    },
    {
      id: 'multimedia',
      name: 'Funciones Multimedia',
      description: 'Audio, imágenes contextuales y mapas bíblicos',
      status: 'beta',
      icon: <ImageIcon className="w-6 h-6" />,
      category: 'multimedia'
    },
    {
      id: 'preaching-tools',
      name: 'Herramientas de Predicación',
      description: 'Crea bosquejos de sermones y gestiona ilustraciones',
      status: 'coming_soon',
      icon: <Edit3 className="w-6 h-6" />,
      category: 'tools'
    }
  ];

  // Verificar el estado del sistema al cargar
  useEffect(() => {
    checkSystemStatus();
    
    // Mostrar bienvenida si es la primera vez
    const hasSeenWelcome = localStorage.getItem('advancedFeaturesWelcome');
    if (!hasSeenWelcome) {
      setShowWelcome(true);
      localStorage.setItem('advancedFeaturesWelcome', 'true');
    }
  }, []);

  const checkSystemStatus = async () => {
    try {
      // Verificar si el módulo avanzado está disponible
      if (typeof window !== 'undefined' && window.AdvancedFeaturesModule) {
        await window.AdvancedFeaturesModule.initialize();
        setSystemStatus('ready');
        
        toast({
          title: "Funcionalidades Avanzadas Cargadas",
          description: "Todas las funcionalidades están listas para usar",
        });
      } else {
        // Simular inicialización para desarrollo
        setTimeout(() => {
          setSystemStatus('ready');
        }, 2000);
      }
    } catch (error) {
      console.error('Error initializing advanced features:', error);
      setSystemStatus('error');
      
      toast({
        title: "Error de Inicialización",
        description: "Algunas funcionalidades avanzadas pueden no estar disponibles",
        variant: "destructive"
      });
    }
  };

  const getFeaturesByCategory = (category: string) => {
    return features.filter(feature => feature.category === category);
  };

  const getStatusBadge = (status: FeatureStatus['status']) => {
    switch (status) {
      case 'available':
        return <Badge className="bg-green-100 text-green-800">Disponible</Badge>;
      case 'beta':
        return <Badge className="bg-blue-100 text-blue-800">Beta</Badge>;
      case 'coming_soon':
        return <Badge className="bg-gray-100 text-gray-800">Próximamente</Badge>;
      case 'disabled':
        return <Badge className="bg-red-100 text-red-800">Deshabilitado</Badge>;
      default:
        return null;
    }
  };

  const renderFeatureCard = (feature: FeatureStatus) => (
    <Card 
      key={feature.id} 
      className={`cursor-pointer transition-all hover:shadow-md ${
        feature.status === 'disabled' || feature.status === 'coming_soon' 
          ? 'opacity-50 cursor-not-allowed' 
          : 'hover:border-primary'
      }`}
      onClick={() => {
        if (feature.status === 'available' || feature.status === 'beta') {
          setActiveFeature(feature.id);
        } else {
          toast({
            title: "Funcionalidad no disponible",
            description: `${feature.name} estará disponible pronto`,
            variant: "destructive"
          });
        }
      }}
    >
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0 p-2 bg-primary/10 rounded-lg">
            {feature.icon}
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-semibold text-lg">{feature.name}</h3>
              {getStatusBadge(feature.status)}
            </div>
            <p className="text-gray-600 text-sm">{feature.description}</p>
            
            {feature.status === 'beta' && (
              <div className="mt-2 text-xs text-blue-600 flex items-center gap-1">
                <Info className="w-3 h-3" />
                En pruebas - Pueden existir errores
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  // Componente de vista general
  const OverviewPanel = () => (
    <div className="space-y-6">
      {/* Estado del sistema */}
      <Alert className={
        systemStatus === 'ready' ? 'border-green-200 bg-green-50' :
        systemStatus === 'error' ? 'border-red-200 bg-red-50' :
        'border-blue-200 bg-blue-50'
      }>
        <div className="flex items-center gap-2">
          {systemStatus === 'ready' && <CheckCircle className="w-4 h-4 text-green-600" />}
          {systemStatus === 'error' && <AlertTriangle className="w-4 h-4 text-red-600" />}
          {systemStatus === 'loading' && <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />}
        </div>
        <AlertTitle>
          {systemStatus === 'ready' && 'Sistema Listo'}
          {systemStatus === 'error' && 'Error del Sistema'}
          {systemStatus === 'loading' && 'Cargando...'}
        </AlertTitle>
        <AlertDescription>
          {systemStatus === 'ready' && 'Todas las funcionalidades avanzadas están operativas'}
          {systemStatus === 'error' && 'Algunas funcionalidades pueden no estar disponibles'}
          {systemStatus === 'loading' && 'Inicializando funcionalidades avanzadas...'}
        </AlertDescription>
      </Alert>

      {/* Funcionalidades por categoría */}
      <div className="space-y-8">
        {/* Estudio */}
        <div>
          <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Herramientas de Estudio
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {getFeaturesByCategory('study').map(renderFeatureCard)}
            {getFeaturesByCategory('tools').map(renderFeatureCard)}
          </div>
        </div>

        {/* Análisis */}
        <div>
          <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Análisis y Métricas
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {getFeaturesByCategory('analysis').map(renderFeatureCard)}
          </div>
        </div>

        {/* Gamificación */}
        <div>
          <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Trophy className="w-5 h-5" />
            Gamificación
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {getFeaturesByCategory('gamification').map(renderFeatureCard)}
          </div>
        </div>

        {/* Social y Multimedia */}
        <div>
          <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Users className="w-5 h-5" />
            Social y Multimedia
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {getFeaturesByCategory('social').map(renderFeatureCard)}
            {getFeaturesByCategory('multimedia').map(renderFeatureCard)}
          </div>
        </div>
      </div>

      {/* Estadísticas rápidas */}
      <Card>
        <CardHeader>
          <CardTitle>Estadísticas del Sistema</CardTitle>
          <CardDescription>Estado actual de las funcionalidades avanzadas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {features.filter(f => f.status === 'available').length}
              </div>
              <div className="text-sm text-gray-600">Disponibles</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {features.filter(f => f.status === 'beta').length}
              </div>
              <div className="text-sm text-gray-600">En Beta</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-600">
                {features.filter(f => f.status === 'coming_soon').length}
              </div>
              <div className="text-sm text-gray-600">Próximamente</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {features.length}
              </div>
              <div className="text-sm text-gray-600">Total</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Renderizar el componente activo
  const renderActiveFeature = () => {
    const feature = features.find(f => f.id === activeFeature);
    
    if (!feature || !feature.component) {
      return <OverviewPanel />;
    }

    const FeatureComponent = feature.component;
    return <FeatureComponent />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold flex items-center gap-3">
            <Sparkles className="w-8 h-8 text-purple-600" />
            Funcionalidades Avanzadas
          </h1>
          <p className="text-gray-600 mt-2">
            Descubre herramientas poderosas para enriquecer tu estudio bíblico
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => setActiveFeature('overview')}
            className={activeFeature === 'overview' ? 'bg-primary text-primary-foreground' : ''}
          >
            <Target className="w-4 h-4 mr-2" />
            Resumen
          </Button>
          <Button variant="outline" onClick={() => setShowWelcome(true)}>
            <Info className="w-4 h-4 mr-2" />
            Ayuda
          </Button>
        </div>
      </div>

      {/* Navegación de funcionalidades */}
      {activeFeature !== 'overview' && (
        <div className="border-b">
          <div className="flex gap-2 pb-4">
            <Button 
              variant="ghost" 
              onClick={() => setActiveFeature('overview')}
              className="text-sm"
            >
              ← Volver al resumen
            </Button>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <span>/</span>
              <span className="font-medium">
                {features.find(f => f.id === activeFeature)?.name}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Contenido principal */}
      <div className="min-h-[600px]">
        {systemStatus === 'loading' ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Cargando Funcionalidades Avanzadas</h3>
              <p className="text-gray-600">Inicializando todos los sistemas...</p>
            </div>
          </div>
        ) : (
          renderActiveFeature()
        )}
      </div>

      {/* Dialog de bienvenida */}
      <Dialog open={showWelcome} onOpenChange={setShowWelcome}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Rocket className="w-6 h-6 text-purple-600" />
              ¡Bienvenido a las Funcionalidades Avanzadas!
            </DialogTitle>
            <DialogDescription>
              Descubre todas las herramientas poderosas disponibles para enriquecer tu estudio bíblico
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <h4 className="font-semibold">Estudios Personalizados</h4>
                </div>
                <p className="text-sm text-gray-600">
                  Crea planes de lectura adaptados a tu ritmo y objetivos
                </p>
              </div>
              
              <div className="p-4 border rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="w-5 h-5 text-yellow-600" />
                  <h4 className="font-semibold">Gamificación</h4>
                </div>
                <p className="text-sm text-gray-600">
                  Gana puntos y logros mientras estudias la Biblia
                </p>
              </div>
              
              <div className="p-4 border rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 className="w-5 h-5 text-green-600" />
                  <h4 className="font-semibold">Análisis Detallado</h4>
                </div>
                <p className="text-sm text-gray-600">
                  Visualiza tu progreso con métricas y estadísticas
                </p>
              </div>
              
              <div className="p-4 border rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Search className="w-5 h-5 text-purple-600" />
                  <h4 className="font-semibold">Herramientas Avanzadas</h4>
                </div>
                <p className="text-sm text-gray-600">
                  Compara versiones, toma notas y usa concordancia
                </p>
              </div>
            </div>

            <Alert>
              <Star className="w-4 h-4" />
              <AlertTitle>Consejo</AlertTitle>
              <AlertDescription>
                Comienza con los "Estudios Personalizados" para crear tu primer plan de lectura, 
                luego explora otras funcionalidades según tus necesidades.
              </AlertDescription>
            </Alert>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowWelcome(false)}>
                Cerrar
              </Button>
              <Button 
                onClick={() => {
                  setActiveFeature('personalized-study');
                  setShowWelcome(false);
                }}
              >
                Comenzar Tour
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdvancedFeaturesHub;
