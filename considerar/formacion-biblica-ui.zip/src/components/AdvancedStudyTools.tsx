import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from '@/hooks/use-toast';
import { 
  Search, 
  BookOpen, 
  GitCompare, 
  Highlighter, 
  StickyNote, 
  Plus,
  Edit,
  Trash2,
  Tag,
  Eye,
  EyeOff,
  Share2,
  Filter,
  Download,
  Upload,
  Bookmark,
  Star,
  Link,
  Palette
} from 'lucide-react';

interface BibleVersion {
  id: string;
  name: string;
  abbreviation: string;
  language: string;
  year: number;
  description: string;
  available: boolean;
}

interface VersionComparison {
  reference: string;
  versions: {
    versionId: string;
    text: string;
    differences?: TextDifference[];
  }[];
}

interface TextDifference {
  type: 'addition' | 'deletion' | 'modification';
  position: number;
  oldText?: string;
  newText?: string;
}

interface PersonalNote {
  id: string;
  userId: string;
  reference: string;
  content: string;
  type: 'note' | 'commentary' | 'reflection' | 'question';
  tags: string[];
  color?: string;
  isPrivate: boolean;
  createdAt: Date;
  updatedAt: Date;
  linkedNotes?: string[];
}

interface TextHighlight {
  id: string;
  userId: string;
  reference: string;
  startWord: number;
  endWord: number;
  themeId: string;
  text: string;
  createdAt: Date;
}

interface HighlightTheme {
  id: string;
  name: string;
  color: string;
  description: string;
  keywords: string[];
  autoHighlight: boolean;
}

const AdvancedStudyTools: React.FC = () => {
  const [activeTab, setActiveTab] = useState('compare-versions');
  const [availableVersions] = useState<BibleVersion[]>([
    { id: 'rv1960', name: 'Reina-Valera 1960', abbreviation: 'RV1960', language: 'es', year: 1960, description: 'Versión tradicional en español', available: true },
    { id: 'nvi', name: 'Nueva Versión Internacional', abbreviation: 'NVI', language: 'es', year: 1999, description: 'Traducción moderna y clara', available: true },
    { id: 'lbla', name: 'La Biblia de las Américas', abbreviation: 'LBLA', language: 'es', year: 1986, description: 'Traducción literal y precisa', available: true },
    { id: 'ntv', name: 'Nueva Traducción Viviente', abbreviation: 'NTV', language: 'es', year: 2010, description: 'Lenguaje contemporáneo', available: true }
  ]);
  
  // Estados para comparación de versiones
  const [selectedVersions, setSelectedVersions] = useState<string[]>(['rv1960', 'nvi']);
  const [comparisonReference, setComparisonReference] = useState('Juan 3:16');
  const [comparison, setComparison] = useState<VersionComparison | null>(null);
  const [isComparing, setIsComparing] = useState(false);

  // Estados para notas personales
  const [personalNotes, setPersonalNotes] = useState<PersonalNote[]>([]);
  const [isCreatingNote, setIsCreatingNote] = useState(false);
  const [editingNote, setEditingNote] = useState<PersonalNote | null>(null);
  const [newNote, setNewNote] = useState<Partial<PersonalNote>>({
    reference: '',
    content: '',
    type: 'note',
    tags: [],
    color: '#ffeb3b',
    isPrivate: true
  });
  const [noteFilter, setNoteFilter] = useState({
    type: 'all',
    tag: '',
    search: ''
  });

  // Estados para highlights
  const [highlights, setHighlights] = useState<TextHighlight[]>([]);
  const [highlightThemes, setHighlightThemes] = useState<HighlightTheme[]>([
    { id: 'love', name: 'Amor', color: '#ff4444', description: 'Versículos sobre amor', keywords: ['amor', 'amar', 'amado'], autoHighlight: false },
    { id: 'faith', name: 'Fe', color: '#4444ff', description: 'Versículos sobre fe', keywords: ['fe', 'creer', 'confianza'], autoHighlight: false },
    { id: 'hope', name: 'Esperanza', color: '#44ff44', description: 'Versículos sobre esperanza', keywords: ['esperanza', 'esperar'], autoHighlight: false },
    { id: 'salvation', name: 'Salvación', color: '#ff8800', description: 'Versículos sobre salvación', keywords: ['salvación', 'salvar', 'salvador'], autoHighlight: false }
  ]);

  // Estados para concordancia
  const [concordanceSearch, setConcordanceSearch] = useState('');
  const [concordanceResults, setConcordanceResults] = useState<any>(null);
  const [searchingConcordance, setSearchingConcordance] = useState(false);

  // Cargar datos al montar el componente
  useEffect(() => {
    loadPersonalNotes();
    loadHighlights();
  }, []);

  // Funciones para comparación de versiones
  const compareVersions = useCallback(async () => {
    if (selectedVersions.length < 2 || !comparisonReference.trim()) {
      toast({
        title: "Error",
        description: "Selecciona al menos 2 versiones y una referencia válida",
        variant: "destructive"
      });
      return;
    }

    setIsComparing(true);
    try {
      if (window.AdvancedFeaturesModule) {
        const result = await window.AdvancedFeaturesModule.AdvancedStudyTools.compareVersions(
          comparisonReference,
          selectedVersions
        );
        setComparison(result);
        
        toast({
          title: "Comparación completada",
          description: `Se han comparado ${selectedVersions.length} versiones`,
        });
      }
    } catch (error) {
      console.error('Error comparing versions:', error);
      toast({
        title: "Error",
        description: "No se pudieron comparar las versiones",
        variant: "destructive"
      });
    } finally {
      setIsComparing(false);
    }
  }, [selectedVersions, comparisonReference]);

  // Funciones para notas personales
  const loadPersonalNotes = useCallback(async () => {
    try {
      // Simular carga de notas desde localStorage o API
      const savedNotes = localStorage.getItem('personalNotes');
      if (savedNotes) {
        setPersonalNotes(JSON.parse(savedNotes));
      }
    } catch (error) {
      console.error('Error loading personal notes:', error);
    }
  }, []);

  const savePersonalNote = useCallback(async (note: Partial<PersonalNote>) => {
    try {
      if (!note.reference || !note.content) {
        toast({
          title: "Error",
          description: "La referencia y el contenido son obligatorios",
          variant: "destructive"
        });
        return;
      }

      const noteData: PersonalNote = {
        id: editingNote?.id || Date.now().toString(),
        userId: 'current_user',
        reference: note.reference,
        content: note.content,
        type: note.type || 'note',
        tags: note.tags || [],
        color: note.color || '#ffeb3b',
        isPrivate: note.isPrivate !== false,
        createdAt: editingNote?.createdAt || new Date(),
        updatedAt: new Date(),
        linkedNotes: note.linkedNotes || []
      };

      if (window.AdvancedFeaturesModule) {
        if (editingNote) {
          await window.AdvancedFeaturesModule.AdvancedStudyTools.updatePersonalNote(noteData.id, noteData);
        } else {
          await window.AdvancedFeaturesModule.AdvancedStudyTools.addPersonalNote(noteData);
        }
      }

      // Actualizar estado local
      setPersonalNotes(prev => {
        const filtered = prev.filter(n => n.id !== noteData.id);
        return [...filtered, noteData];
      });

      // Guardar en localStorage
      const updatedNotes = personalNotes.filter(n => n.id !== noteData.id);
      updatedNotes.push(noteData);
      localStorage.setItem('personalNotes', JSON.stringify(updatedNotes));

      setIsCreatingNote(false);
      setEditingNote(null);
      setNewNote({
        reference: '',
        content: '',
        type: 'note',
        tags: [],
        color: '#ffeb3b',
        isPrivate: true
      });

      toast({
        title: editingNote ? "Nota actualizada" : "Nota creada",
        description: `La nota para ${noteData.reference} ha sido ${editingNote ? 'actualizada' : 'creada'}`,
      });

    } catch (error) {
      console.error('Error saving personal note:', error);
      toast({
        title: "Error",
        description: "No se pudo guardar la nota",
        variant: "destructive"
      });
    }
  }, [editingNote, personalNotes]);

  const deleteNote = useCallback(async (noteId: string) => {
    try {
      setPersonalNotes(prev => prev.filter(n => n.id !== noteId));
      
      // Actualizar localStorage
      const updatedNotes = personalNotes.filter(n => n.id !== noteId);
      localStorage.setItem('personalNotes', JSON.stringify(updatedNotes));
      
      toast({
        title: "Nota eliminada",
        description: "La nota ha sido eliminada exitosamente",
      });
    } catch (error) {
      console.error('Error deleting note:', error);
      toast({
        title: "Error",
        description: "No se pudo eliminar la nota",
        variant: "destructive"
      });
    }
  }, [personalNotes]);

  // Funciones para highlights
  const loadHighlights = useCallback(async () => {
    try {
      const savedHighlights = localStorage.getItem('textHighlights');
      if (savedHighlights) {
        setHighlights(JSON.parse(savedHighlights));
      }
    } catch (error) {
      console.error('Error loading highlights:', error);
    }
  }, []);

  const addHighlight = useCallback(async (highlightData: Partial<TextHighlight>) => {
    try {
      const highlight: TextHighlight = {
        id: Date.now().toString(),
        userId: 'current_user',
        reference: highlightData.reference || '',
        startWord: highlightData.startWord || 0,
        endWord: highlightData.endWord || 0,
        themeId: highlightData.themeId || 'love',
        text: highlightData.text || '',
        createdAt: new Date()
      };

      if (window.AdvancedFeaturesModule) {
        await window.AdvancedFeaturesModule.AdvancedStudyTools.highlightText(highlight);
      }

      setHighlights(prev => [...prev, highlight]);
      
      // Guardar en localStorage
      const updatedHighlights = [...highlights, highlight];
      localStorage.setItem('textHighlights', JSON.stringify(updatedHighlights));

      toast({
        title: "Texto resaltado",
        description: "El texto ha sido resaltado exitosamente",
      });

    } catch (error) {
      console.error('Error adding highlight:', error);
      toast({
        title: "Error",
        description: "No se pudo resaltar el texto",
        variant: "destructive"
      });
    }
  }, [highlights]);

  // Funciones para concordancia
  const searchConcordance = useCallback(async () => {
    if (!concordanceSearch.trim()) return;

    setSearchingConcordance(true);
    try {
      if (window.AdvancedFeaturesModule) {
        const results = await window.AdvancedFeaturesModule.AdvancedStudyTools.searchConcordance(concordanceSearch);
        setConcordanceResults(results);
      }
    } catch (error) {
      console.error('Error searching concordance:', error);
      toast({
        title: "Error",
        description: "Error al buscar en la concordancia",
        variant: "destructive"
      });
    } finally {
      setSearchingConcordance(false);
    }
  }, [concordanceSearch]);

  // Filtrar notas
  const filteredNotes = personalNotes.filter(note => {
    if (noteFilter.type !== 'all' && note.type !== noteFilter.type) return false;
    if (noteFilter.tag && !note.tags.includes(noteFilter.tag)) return false;
    if (noteFilter.search && !note.content.toLowerCase().includes(noteFilter.search.toLowerCase()) && 
        !note.reference.toLowerCase().includes(noteFilter.search.toLowerCase())) return false;
    return true;
  });

  // Componente para comparación de versiones
  const VersionComparisonPanel = () => (
    <div className="space-y-6">
      {/* Configuración de comparación */}
      <Card>
        <CardHeader>
          <CardTitle>Configurar Comparación</CardTitle>
          <CardDescription>Selecciona las versiones y referencia a comparar</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Referencia bíblica</label>
            <Input
              value={comparisonReference}
              onChange={(e) => setComparisonReference(e.target.value)}
              placeholder="Ej: Juan 3:16, Salmo 23:1-3"
            />
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block">Versiones a comparar</label>
            <div className="grid grid-cols-2 gap-2">
              {availableVersions.filter(v => v.available).map(version => (
                <div key={version.id} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id={version.id}
                    checked={selectedVersions.includes(version.id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedVersions(prev => [...prev, version.id]);
                      } else {
                        setSelectedVersions(prev => prev.filter(id => id !== version.id));
                      }
                    }}
                  />
                  <label htmlFor={version.id} className="text-sm">
                    {version.abbreviation} - {version.name}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <Button 
            onClick={compareVersions}
            disabled={isComparing || selectedVersions.length < 2}
            className="w-full"
          >
            <GitCompare className="w-4 h-4 mr-2" />
            {isComparing ? 'Comparando...' : 'Comparar Versiones'}
          </Button>
        </CardContent>
      </Card>

      {/* Resultados de comparación */}
      {comparison && (
        <Card>
          <CardHeader>
            <CardTitle>Comparación: {comparison.reference}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {comparison.versions.map((version, index) => {
                const versionInfo = availableVersions.find(v => v.id === version.versionId);
                return (
                  <div key={version.versionId} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline">
                        {versionInfo?.abbreviation || version.versionId}
                      </Badge>
                      {version.differences && version.differences.length > 0 && (
                        <Badge variant="secondary">
                          {version.differences.length} diferencias
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm leading-relaxed">{version.text}</p>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  // Componente para notas personales
  const PersonalNotesPanel = () => (
    <div className="space-y-6">
      {/* Filtros y acciones */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Notas Personales</CardTitle>
              <CardDescription>Gestiona tus notas y comentarios bíblicos</CardDescription>
            </div>
            <Button onClick={() => setIsCreatingNote(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Nueva Nota
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <Input
              placeholder="Buscar en notas..."
              value={noteFilter.search}
              onChange={(e) => setNoteFilter(prev => ({ ...prev, search: e.target.value }))}
              className="flex-1"
            />
            <Select 
              value={noteFilter.type} 
              onValueChange={(value) => setNoteFilter(prev => ({ ...prev, type: value }))}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="note">Notas</SelectItem>
                <SelectItem value="commentary">Comentarios</SelectItem>
                <SelectItem value="reflection">Reflexiones</SelectItem>
                <SelectItem value="question">Preguntas</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Lista de notas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredNotes.map(note => (
          <Card key={note.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{note.reference}</CardTitle>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge 
                      variant="outline" 
                      style={{ backgroundColor: note.color + '20', borderColor: note.color }}
                    >
                      {note.type}
                    </Badge>
                    {note.isPrivate ? (
                      <EyeOff className="w-4 h-4 text-gray-400" />
                    ) : (
                      <Eye className="w-4 h-4 text-gray-400" />
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      setEditingNote(note);
                      setNewNote(note);
                      setIsCreatingNote(true);
                    }}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => deleteNote(note.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-2">{note.content}</p>
              {note.tags.length > 0 && (
                <div className="flex flex-wrap gap-1">
                  {note.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      <Tag className="w-3 h-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
              <div className="text-xs text-gray-400 mt-2">
                {new Date(note.createdAt).toLocaleDateString()}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredNotes.length === 0 && (
        <div className="text-center py-12">
          <StickyNote className="w-16 h-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-xl font-semibold mb-2">No hay notas</h3>
          <p className="text-gray-600">Crea tu primera nota para comenzar</p>
        </div>
      )}

      {/* Dialog para crear/editar nota */}
      <Dialog open={isCreatingNote} onOpenChange={setIsCreatingNote}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingNote ? 'Editar Nota' : 'Nueva Nota'}</DialogTitle>
            <DialogDescription>
              {editingNote ? 'Modifica los detalles de tu nota' : 'Crea una nueva nota personal'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Referencia bíblica</label>
              <Input
                value={newNote.reference || ''}
                onChange={(e) => setNewNote(prev => ({ ...prev, reference: e.target.value }))}
                placeholder="Ej: Juan 3:16"
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Tipo de nota</label>
              <Select 
                value={newNote.type} 
                onValueChange={(value: 'note' | 'commentary' | 'reflection' | 'question') => 
                  setNewNote(prev => ({ ...prev, type: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="note">Nota</SelectItem>
                  <SelectItem value="commentary">Comentario</SelectItem>
                  <SelectItem value="reflection">Reflexión</SelectItem>
                  <SelectItem value="question">Pregunta</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">Contenido</label>
              <Textarea
                value={newNote.content || ''}
                onChange={(e) => setNewNote(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Escribe tu nota aquí..."
                rows={6}
              />
            </div>

            <div>
              <label className="text-sm font-medium">Color</label>
              <div className="flex gap-2 mt-1">
                {['#ffeb3b', '#4caf50', '#2196f3', '#ff9800', '#9c27b0', '#f44336'].map(color => (
                  <button
                    key={color}
                    onClick={() => setNewNote(prev => ({ ...prev, color }))}
                    className={`w-8 h-8 rounded-full border-2 ${
                      newNote.color === color ? 'border-gray-800' : 'border-gray-300'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="private"
                checked={newNote.isPrivate}
                onChange={(e) => setNewNote(prev => ({ ...prev, isPrivate: e.target.checked }))}
              />
              <label htmlFor="private" className="text-sm">Nota privada</label>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsCreatingNote(false)}>
                Cancelar
              </Button>
              <Button onClick={() => savePersonalNote(newNote)}>
                {editingNote ? 'Actualizar' : 'Crear'} Nota
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );

  // Componente para concordancia
  const ConcordancePanel = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Búsqueda en Concordancia</CardTitle>
          <CardDescription>Busca palabras y conceptos en toda la Biblia</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              value={concordanceSearch}
              onChange={(e) => setConcordanceSearch(e.target.value)}
              placeholder="Buscar palabra o concepto..."
              className="flex-1"
              onKeyPress={(e) => e.key === 'Enter' && searchConcordance()}
            />
            <Button 
              onClick={searchConcordance}
              disabled={searchingConcordance}
            >
              <Search className="w-4 h-4 mr-2" />
              {searchingConcordance ? 'Buscando...' : 'Buscar'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {concordanceResults && (
        <Card>
          <CardHeader>
            <CardTitle>Resultados para "{concordanceSearch}"</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold mb-2">Definición</h4>
                  <p className="text-sm text-gray-600">{concordanceResults.definition}</p>
                </div>
                {concordanceResults.strongNumber && (
                  <div>
                    <h4 className="font-semibold mb-2">Número Strong</h4>
                    <Badge>{concordanceResults.strongNumber}</Badge>
                  </div>
                )}
              </div>
              
              {concordanceResults.occurrences && concordanceResults.occurrences.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2">Ocurrencias ({concordanceResults.occurrences.length})</h4>
                  <ScrollArea className="h-64">
                    <div className="space-y-2">
                      {concordanceResults.occurrences.map((occurrence: any, index: number) => (
                        <div key={index} className="p-3 border rounded">
                          <div className="font-medium text-sm">{occurrence.reference}</div>
                          <div className="text-sm text-gray-600 mt-1">{occurrence.context}</div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Herramientas de Estudio Avanzadas</h2>
          <p className="text-gray-600">Compara versiones, toma notas y profundiza en el estudio bíblico</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="compare-versions">
            <GitCompare className="w-4 h-4 mr-2" />
            Comparar
          </TabsTrigger>
          <TabsTrigger value="personal-notes">
            <StickyNote className="w-4 h-4 mr-2" />
            Notas
          </TabsTrigger>
          <TabsTrigger value="highlights">
            <Highlighter className="w-4 h-4 mr-2" />
            Resaltado
          </TabsTrigger>
          <TabsTrigger value="concordance">
            <Search className="w-4 h-4 mr-2" />
            Concordancia
          </TabsTrigger>
        </TabsList>

        <TabsContent value="compare-versions">
          <VersionComparisonPanel />
        </TabsContent>

        <TabsContent value="personal-notes">
          <PersonalNotesPanel />
        </TabsContent>

        <TabsContent value="highlights">
          <div className="text-center py-12">
            <Highlighter className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Sistema de Resaltado</h3>
            <p className="text-gray-600">Funcionalidad en desarrollo</p>
          </div>
        </TabsContent>

        <TabsContent value="concordance">
          <ConcordancePanel />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdvancedStudyTools;
