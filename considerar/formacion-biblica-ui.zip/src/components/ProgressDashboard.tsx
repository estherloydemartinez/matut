import { motion } from 'framer-motion'
import { BarChart3, BookOpen, Clock, Target, TrendingUp, Award } from 'lucide-react'
import { useAppState } from '../contexts/AppStateContext'

export default function ProgressDashboard() {
  const { userProgress } = useAppState()

  const stats = [
    {
      icon: <BookOpen className="w-6 h-6" />,
      label: 'Capítulos Leídos',
      value: userProgress.chaptersRead,
      total: userProgress.totalChapters,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    },
    {
      icon: <Clock className="w-6 h-6" />,
      label: 'Horas de Estudio',
      value: userProgress.studyHours,
      total: null,
      color: 'text-green-400',
      bgColor: 'bg-green-500/20'
    },
    {
      icon: <Target className="w-6 h-6" />,
      label: 'Lecciones Completadas',
      value: userProgress.completedLessons,
      total: userProgress.totalLessons,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20'
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      label: 'Racha de Días',
      value: userProgress.streak,
      total: null,
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/20'
    }
  ]

  const progressPercentage = (userProgress.chaptersRead / userProgress.totalChapters) * 100

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="discord-card p-6 rounded-lg">
        <div className="flex items-center space-x-3 mb-6">
          <BarChart3 className="w-6 h-6 text-discord-primary" />
          <h2 className="text-xl font-semibold text-discord-text-primary">Dashboard de Progreso</h2>
        </div>
        
        {/* Statistics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className={`discord-card p-6 rounded-lg ${stat.bgColor} border border-opacity-30`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg bg-discord-secondary ${stat.color}`}>
                  {stat.icon}
                </div>
                {stat.total && (
                  <div className="text-right">
                    <div className="text-2xl font-bold text-discord-text-primary">
                      {Math.round((stat.value / stat.total) * 100)}%
                    </div>
                  </div>
                )}
              </div>
              
              <h3 className="font-medium text-discord-text-primary mb-2">{stat.label}</h3>
              
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-discord-text-primary">
                  {stat.value}
                </span>
                {stat.total && (
                  <span className="text-discord-text-muted">/ {stat.total}</span>
                )}
              </div>
              
              {stat.total && (
                <div className="mt-3">
                  <div className="w-full bg-discord-quaternary rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(stat.value / stat.total) * 100}%` }}
                      transition={{ duration: 1, delay: index * 0.2 }}
                      className={`h-2 rounded-full ${stat.color.replace('text-', 'bg-')}`}
                    />
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
        
        {/* Progress Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Overall Progress */}
          <div className="discord-card p-6 rounded-lg bg-discord-tertiary">
            <h3 className="text-lg font-semibold text-discord-text-primary mb-4 flex items-center">
              <Award className="w-5 h-5 mr-2 text-yellow-400" />
              Progreso General
            </h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-discord-text-secondary">Lectura de la Biblia</span>
                  <span className="text-discord-text-primary font-medium">
                    {Math.round(progressPercentage)}%
                  </span>
                </div>
                <div className="w-full bg-discord-quaternary rounded-full h-3">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progressPercentage}%` }}
                    transition={{ duration: 2 }}
                    className="h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
                  />
                </div>
              </div>
              
              <div className="p-4 bg-discord-secondary rounded-lg">
                <p className="text-discord-text-secondary text-sm">
                  <strong className="text-discord-text-primary">¡Excelente progreso!</strong>
                  {' '}Has leído {userProgress.chaptersRead} capítulos de {userProgress.totalChapters}.
                  {progressPercentage > 10 && ' Mantén el buen trabajo.'}
                </p>
              </div>
            </div>
          </div>
          
          {/* Recent Activity */}
          <div className="discord-card p-6 rounded-lg bg-discord-tertiary">
            <h3 className="text-lg font-semibold text-discord-text-primary mb-4">
              Actividad Reciente
            </h3>
            
            <div className="space-y-3">
              <div className="p-3 bg-discord-secondary rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-discord-text-primary font-medium">Última sesión</span>
                  <span className="text-discord-text-muted text-sm">
                    {new Date(userProgress.lastActiveDate).toLocaleDateString()}
                  </span>
                </div>
              </div>
              
              <div className="p-3 bg-discord-secondary rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-discord-text-secondary">Racha actual</span>
                  <span className="text-discord-text-primary font-bold">
                    {userProgress.streak} días
                  </span>
                </div>
              </div>
              
              <div className="p-3 bg-discord-secondary rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-discord-text-secondary">Tiempo promedio</span>
                  <span className="text-discord-text-primary">
                    {userProgress.studyHours > 0 ? 
                      `${Math.round(userProgress.studyHours / Math.max(userProgress.streak, 1))}h por día` :
                      'Sin datos'
                    }
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Achievements */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-discord-text-primary mb-4">
            Logros Recientes
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {userProgress.chaptersRead >= 10 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-4 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-lg border border-yellow-500/30"
              >
                <div className="flex items-center space-x-3">
                  <div className="text-2xl">📚</div>
                  <div>
                    <h4 className="font-medium text-discord-text-primary">Lector Constante</h4>
                    <p className="text-xs text-discord-text-secondary">10+ capítulos leídos</p>
                  </div>
                </div>
              </motion.div>
            )}
            
            {userProgress.streak >= 7 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.1 }}
                className="p-4 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg border border-green-500/30"
              >
                <div className="flex items-center space-x-3">
                  <div className="text-2xl">🔥</div>
                  <div>
                    <h4 className="font-medium text-discord-text-primary">Racha Semanal</h4>
                    <p className="text-xs text-discord-text-secondary">7+ días consecutivos</p>
                  </div>
                </div>
              </motion.div>
            )}
            
            {userProgress.studyHours >= 5 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 }}
                className="p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg border border-purple-500/30"
              >
                <div className="flex items-center space-x-3">
                  <div className="text-2xl">⏰</div>
                  <div>
                    <h4 className="font-medium text-discord-text-primary">Estudiante Dedicado</h4>
                    <p className="text-xs text-discord-text-secondary">5+ horas de estudio</p>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  )
}
