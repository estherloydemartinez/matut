import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from '@/hooks/use-toast';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown,
  BookOpen, 
  Clock, 
  Target, 
  Users, 
  Star, 
  Calendar as CalendarIcon,
  Award,
  Activity,
  Brain,
  Heart,
  Zap,
  Download,
  RefreshCw,
  Filter,
  Eye,
  BarChart3,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon
} from 'lucide-react';

interface UserMetrics {
  userId: string;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'all_time';
  readingStats: ReadingStats;
  studyStats: StudyStats;
  socialStats: SocialStats;
  gamificationStats: GamificationStats;
  generalStats: GeneralStats;
  lastUpdated: Date;
}

interface ReadingStats {
  booksRead: number;
  chaptersRead: number;
  versesRead: number;
  timeSpent: number;
  averageSessionDuration: number;
  readingStreak: number;
  favoriteBooks: BookStats[];
  readingPattern: ReadingPattern[];
  completion: {
    oldTestament: number;
    newTestament: number;
    total: number;
  };
}

interface BookStats {
  book: string;
  chaptersRead: number;
  totalChapters: number;
  timeSpent: number;
  lastRead: Date;
  completionPercentage: number;
}

interface ReadingPattern {
  date: string;
  chaptersRead: number;
  timeSpent: number;
  sessionCount: number;
}

interface StudyStats {
  plansCompleted: number;
  currentPlans: number;
  totalStudyTime: number;
  notesCreated: number;
  reflectionsWritten: number;
  questionsAnswered: number;
  averageStudySession: number;
  favoriteTopics: TopicStats[];
}

interface TopicStats {
  topic: string;
  studyCount: number;
  timeSpent: number;
  notesCount: number;
}

interface SocialStats {
  groupsJoined: number;
  discussionsStarted: number;
  repliesPosted: number;
  reactionsGiven: number;
  reactionsReceived: number;
  friendsCount: number;
  mentorshipSessions: number;
}

interface GamificationStats {
  totalXP: number;
  currentLevel: number;
  achievementsUnlocked: number;
  challengesCompleted: number;
  streakDays: number;
  leaderboardRank: number;
  badgesEarned: BadgeStats[];
}

interface BadgeStats {
  badgeId: string;
  unlockedAt: Date;
  rarity: string;
  category: string;
}

interface GeneralStats {
  accountAge: number;
  loginStreak: number;
  totalSessions: number;
  averageSessionTime: number;
  featuresUsed: FeatureUsage[];
  goals: UserGoal[];
}

interface FeatureUsage {
  feature: string;
  usageCount: number;
  lastUsed: Date;
  timeSpent: number;
}

interface UserGoal {
  id: string;
  type: 'reading' | 'study' | 'social' | 'custom';
  title: string;
  description: string;
  target: number;
  current: number;
  deadline?: Date;
  isActive: boolean;
  createdAt: Date;
}

const MetricsDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedPeriod, setSelectedPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('weekly');
  const [userMetrics, setUserMetrics] = useState<UserMetrics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [insights, setInsights] = useState<any[]>([]);
  const [progressReport, setProgressReport] = useState<any>(null);

  // Colores para gráficos
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  // Cargar métricas al montar el componente
  useEffect(() => {
    loadUserMetrics();
  }, [selectedPeriod]);

  const loadUserMetrics = useCallback(async () => {
    setIsLoading(true);
    try {
      if (window.AdvancedFeaturesModule) {
        const metrics = window.AdvancedFeaturesModule.MetricsDashboard.getUserMetrics('current_user');
        setUserMetrics(metrics);
        
        // Generar reporte de progreso
        const report = await window.AdvancedFeaturesModule.MetricsDashboard.generateProgressReport('current_user', selectedPeriod);
        setProgressReport(report);
        
        if (report?.insights) {
          setInsights(report.insights);
        }
      } else {
        // Datos simulados para desarrollo
        setUserMetrics(generateMockMetrics());
        setInsights(generateMockInsights());
      }
    } catch (error) {
      console.error('Error loading user metrics:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las métricas",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [selectedPeriod]);

  // Generar datos simulados para desarrollo
  const generateMockMetrics = (): UserMetrics => ({
    userId: 'current_user',
    period: selectedPeriod,
    readingStats: {
      booksRead: 8,
      chaptersRead: 156,
      versesRead: 3420,
      timeSpent: 2340, // minutos
      averageSessionDuration: 25,
      readingStreak: 14,
      favoriteBooks: [
        { book: 'Salmos', chaptersRead: 45, totalChapters: 150, timeSpent: 450, lastRead: new Date(), completionPercentage: 30 },
        { book: 'Proverbios', chaptersRead: 20, totalChapters: 31, timeSpent: 280, lastRead: new Date(), completionPercentage: 65 },
        { book: 'Juan', chaptersRead: 21, totalChapters: 21, timeSpent: 320, lastRead: new Date(), completionPercentage: 100 }
      ],
      readingPattern: generateReadingPattern(),
      completion: {
        oldTestament: 15,
        newTestament: 35,
        total: 22
      }
    },
    studyStats: {
      plansCompleted: 3,
      currentPlans: 2,
      totalStudyTime: 1890,
      notesCreated: 67,
      reflectionsWritten: 23,
      questionsAnswered: 145,
      averageStudySession: 35,
      favoriteTopics: [
        { topic: 'Fe', studyCount: 12, timeSpent: 240, notesCount: 15 },
        { topic: 'Amor', studyCount: 8, timeSpent: 180, notesCount: 10 },
        { topic: 'Esperanza', studyCount: 6, timeSpent: 120, notesCount: 8 }
      ]
    },
    socialStats: {
      groupsJoined: 4,
      discussionsStarted: 12,
      repliesPosted: 45,
      reactionsGiven: 128,
      reactionsReceived: 89,
      friendsCount: 23,
      mentorshipSessions: 5
    },
    gamificationStats: {
      totalXP: 2450,
      currentLevel: 4,
      achievementsUnlocked: 12,
      challengesCompleted: 8,
      streakDays: 14,
      leaderboardRank: 4,
      badgesEarned: [
        { badgeId: 'reader', unlockedAt: new Date(), rarity: 'common', category: 'reading' },
        { badgeId: 'scholar', unlockedAt: new Date(), rarity: 'rare', category: 'study' }
      ]
    },
    generalStats: {
      accountAge: 90,
      loginStreak: 7,
      totalSessions: 89,
      averageSessionTime: 42,
      featuresUsed: [
        { feature: 'Bible Reading', usageCount: 156, lastUsed: new Date(), timeSpent: 2340 },
        { feature: 'Study Plans', usageCount: 23, lastUsed: new Date(), timeSpent: 890 },
        { feature: 'Social Groups', usageCount: 45, lastUsed: new Date(), timeSpent: 567 }
      ],
      goals: [
        { id: '1', type: 'reading', title: 'Leer toda la Biblia', description: 'Completar lectura en 1 año', target: 365, current: 156, deadline: new Date(Date.now() + 200 * 24 * 60 * 60 * 1000), isActive: true, createdAt: new Date() }
      ]
    },
    lastUpdated: new Date()
  });

  const generateReadingPattern = (): ReadingPattern[] => {
    const pattern = [];
    for (let i = 30; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      pattern.push({
        date: date.toISOString().split('T')[0],
        chaptersRead: Math.floor(Math.random() * 4) + 1,
        timeSpent: Math.floor(Math.random() * 60) + 20,
        sessionCount: Math.floor(Math.random() * 3) + 1
      });
    }
    return pattern;
  };

  const generateMockInsights = () => [
    {
      type: 'positive',
      title: 'Excelente consistencia',
      description: 'Has mantenido una racha de lectura de 14 días consecutivos',
      icon: '🔥'
    },
    {
      type: 'neutral',
      title: 'Progreso en metas',
      description: 'Estás al 43% de tu meta anual de lectura',
      icon: '📈'
    },
    {
      type: 'suggestion',
      title: 'Participa más en grupos',
      description: 'Considera unirte a más discusiones grupales para enriquecer tu estudio',
      icon: '👥'
    }
  ];

  const refreshMetrics = useCallback(async () => {
    await loadUserMetrics();
    toast({
      title: "Métricas actualizadas",
      description: "Los datos han sido actualizados exitosamente",
    });
  }, [loadUserMetrics]);

  // Componente de vista general
  const OverviewPanel = () => {
    if (!userMetrics) return <div>Cargando...</div>;

    const { readingStats, studyStats, socialStats, gamificationStats } = userMetrics;

    return (
      <div className="space-y-6">
        {/* Métricas principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-500" />
                <div>
                  <div className="text-2xl font-bold">{readingStats.chaptersRead}</div>
                  <div className="text-sm text-gray-600">Capítulos leídos</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-green-500" />
                <div>
                  <div className="text-2xl font-bold">{Math.round(studyStats.totalStudyTime / 60)}h</div>
                  <div className="text-sm text-gray-600">Tiempo de estudio</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-yellow-500" />
                <div>
                  <div className="text-2xl font-bold">{gamificationStats.achievementsUnlocked}</div>
                  <div className="text-sm text-gray-600">Logros obtenidos</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-500" />
                <div>
                  <div className="text-2xl font-bold">{socialStats.groupsJoined}</div>
                  <div className="text-sm text-gray-600">Grupos unidos</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Insights y recomendaciones */}
        {insights.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Insights Personalizados</CardTitle>
              <CardDescription>Análisis de tu progreso y recomendaciones</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {insights.map((insight, index) => (
                  <div key={index} className={`p-4 rounded-lg border ${
                    insight.type === 'positive' ? 'bg-green-50 border-green-200' :
                    insight.type === 'neutral' ? 'bg-blue-50 border-blue-200' :
                    'bg-yellow-50 border-yellow-200'
                  }`}>
                    <div className="flex items-start gap-3">
                      <div className="text-2xl">{insight.icon}</div>
                      <div>
                        <div className="font-semibold">{insight.title}</div>
                        <div className="text-sm text-gray-600">{insight.description}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Progreso en la Biblia */}
        <Card>
          <CardHeader>
            <CardTitle>Progreso de Lectura Bíblica</CardTitle>
            <CardDescription>Tu avance en el Antiguo y Nuevo Testamento</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Antiguo Testamento</span>
                  <span>{readingStats.completion.oldTestament}%</span>
                </div>
                <Progress value={readingStats.completion.oldTestament} className="h-3" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Nuevo Testamento</span>
                  <span>{readingStats.completion.newTestament}%</span>
                </div>
                <Progress value={readingStats.completion.newTestament} className="h-3" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Total</span>
                  <span>{readingStats.completion.total}%</span>
                </div>
                <Progress value={readingStats.completion.total} className="h-3" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Gráfico de actividad */}
        <Card>
          <CardHeader>
            <CardTitle>Actividad de Lectura (Últimos 30 días)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={readingStats.readingPattern}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date" 
                  tickFormatter={(value) => new Date(value).toLocaleDateString('es-ES', { month: 'short', day: 'numeric' })}
                />
                <YAxis />
                <Tooltip 
                  labelFormatter={(value) => new Date(value).toLocaleDateString('es-ES')}
                  formatter={(value, name) => [value, name === 'chaptersRead' ? 'Capítulos' : 'Minutos']}
                />
                <Area 
                  type="monotone" 
                  dataKey="chaptersRead" 
                  stackId="1"
                  stroke="#8884d8" 
                  fill="#8884d8"
                  fillOpacity={0.6}
                />
                <Area 
                  type="monotone" 
                  dataKey="timeSpent" 
                  stackId="2"
                  stroke="#82ca9d" 
                  fill="#82ca9d"
                  fillOpacity={0.6}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Componente de estadísticas de lectura
  const ReadingStatsPanel = () => {
    if (!userMetrics) return <div>Cargando...</div>;

    const { readingStats } = userMetrics;

    return (
      <div className="space-y-6">
        {/* Estadísticas principales */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <BookOpen className="w-8 h-8 mx-auto mb-2 text-blue-500" />
              <div className="text-3xl font-bold">{readingStats.booksRead}</div>
              <div className="text-sm text-gray-600">Libros completados</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-green-500" />
              <div className="text-3xl font-bold">{readingStats.chaptersRead}</div>
              <div className="text-sm text-gray-600">Capítulos leídos</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Clock className="w-8 h-8 mx-auto mb-2 text-orange-500" />
              <div className="text-3xl font-bold">{Math.round(readingStats.timeSpent / 60)}</div>
              <div className="text-sm text-gray-600">Horas invertidas</div>
            </CardContent>
          </Card>
        </div>

        {/* Libros favoritos */}
        <Card>
          <CardHeader>
            <CardTitle>Libros Más Leídos</CardTitle>
            <CardDescription>Tus libros favoritos y progreso</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {readingStats.favoriteBooks.map((book, index) => (
                <div key={book.book} className="border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <div className="font-semibold">{book.book}</div>
                    <Badge variant="outline">{book.completionPercentage}% completado</Badge>
                  </div>
                  <Progress value={book.completionPercentage} className="h-2 mb-2" />
                  <div className="grid grid-cols-3 gap-4 text-sm text-gray-600">
                    <div>
                      <div className="font-medium">Capítulos</div>
                      <div>{book.chaptersRead}/{book.totalChapters}</div>
                    </div>
                    <div>
                      <div className="font-medium">Tiempo</div>
                      <div>{Math.round(book.timeSpent / 60)}h</div>
                    </div>
                    <div>
                      <div className="font-medium">Última lectura</div>
                      <div>{book.lastRead.toLocaleDateString()}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Gráfico de barras de actividad semanal */}
        <Card>
          <CardHeader>
            <CardTitle>Patrón de Lectura Semanal</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={readingStats.readingPattern.slice(-7)}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date"
                  tickFormatter={(value) => new Date(value).toLocaleDateString('es-ES', { weekday: 'short' })}
                />
                <YAxis />
                <Tooltip 
                  labelFormatter={(value) => new Date(value).toLocaleDateString('es-ES')}
                />
                <Bar dataKey="chaptersRead" fill="#8884d8" name="Capítulos" />
                <Bar dataKey="sessionCount" fill="#82ca9d" name="Sesiones" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Componente de estadísticas de estudio
  const StudyStatsPanel = () => {
    if (!userMetrics) return <div>Cargando...</div>;

    const { studyStats } = userMetrics;

    return (
      <div className="space-y-6">
        {/* Métricas de estudio */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-blue-500" />
              <div className="text-2xl font-bold">{studyStats.plansCompleted}</div>
              <div className="text-sm text-gray-600">Planes completados</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Brain className="w-8 h-8 mx-auto mb-2 text-green-500" />
              <div className="text-2xl font-bold">{studyStats.notesCreated}</div>
              <div className="text-sm text-gray-600">Notas creadas</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Heart className="w-8 h-8 mx-auto mb-2 text-red-500" />
              <div className="text-2xl font-bold">{studyStats.reflectionsWritten}</div>
              <div className="text-sm text-gray-600">Reflexiones</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Clock className="w-8 h-8 mx-auto mb-2 text-orange-500" />
              <div className="text-2xl font-bold">{studyStats.averageStudySession}</div>
              <div className="text-sm text-gray-600">Min. promedio</div>
            </CardContent>
          </Card>
        </div>

        {/* Temas favoritos - gráfico de pie */}
        <Card>
          <CardHeader>
            <CardTitle>Temas de Estudio Favoritos</CardTitle>
            <CardDescription>Distribución de tiempo por tema</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={studyStats.favoriteTopics}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ topic, timeSpent }) => `${topic}: ${timeSpent}min`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="timeSpent"
                  >
                    {studyStats.favoriteTopics.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>

              <div className="space-y-3">
                {studyStats.favoriteTopics.map((topic, index) => (
                  <div key={topic.topic} className="flex items-center justify-between p-3 border rounded">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: COLORS[index % COLORS.length] }}
                      />
                      <div>
                        <div className="font-medium">{topic.topic}</div>
                        <div className="text-sm text-gray-600">{topic.studyCount} estudios</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">{Math.round(topic.timeSpent / 60)}h</div>
                      <div className="text-sm text-gray-600">{topic.notesCount} notas</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Componente de estadísticas sociales
  const SocialStatsPanel = () => {
    if (!userMetrics) return <div>Cargando...</div>;

    const { socialStats } = userMetrics;

    const socialData = [
      { name: 'Discusiones', value: socialStats.discussionsStarted },
      { name: 'Respuestas', value: socialStats.repliesPosted },
      { name: 'Reacciones Dadas', value: socialStats.reactionsGiven },
      { name: 'Reacciones Recibidas', value: socialStats.reactionsReceived }
    ];

    return (
      <div className="space-y-6">
        {/* Métricas sociales */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <Users className="w-8 h-8 mx-auto mb-2 text-blue-500" />
              <div className="text-2xl font-bold">{socialStats.groupsJoined}</div>
              <div className="text-sm text-gray-600">Grupos unidos</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Activity className="w-8 h-8 mx-auto mb-2 text-green-500" />
              <div className="text-2xl font-bold">{socialStats.discussionsStarted}</div>
              <div className="text-sm text-gray-600">Discusiones iniciadas</div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 text-center">
              <Heart className="w-8 h-8 mx-auto mb-2 text-red-500" />
              <div className="text-2xl font-bold">{socialStats.friendsCount}</div>
              <div className="text-sm text-gray-600">Amigos</div>
            </CardContent>
          </Card>
        </div>

        {/* Gráfico de actividad social */}
        <Card>
          <CardHeader>
            <CardTitle>Actividad Social</CardTitle>
            <CardDescription>Tu participación en la comunidad</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={socialData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Engagement metrics */}
        <Card>
          <CardHeader>
            <CardTitle>Métricas de Compromiso</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <div className="text-sm font-medium mb-2">Reacciones</div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Dadas</span>
                    <span className="font-bold">{socialStats.reactionsGiven}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Recibidas</span>
                    <span className="font-bold">{socialStats.reactionsReceived}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Ratio</span>
                    <span className="font-bold">
                      {socialStats.reactionsGiven > 0 ? 
                        (socialStats.reactionsReceived / socialStats.reactionsGiven).toFixed(2) : 
                        '0.00'
                      }
                    </span>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="text-sm font-medium mb-2">Participación</div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Respuestas por discusión</span>
                    <span className="font-bold">
                      {socialStats.discussionsStarted > 0 ? 
                        (socialStats.repliesPosted / socialStats.discussionsStarted).toFixed(1) : 
                        '0.0'
                      }
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Sesiones de mentoría</span>
                    <span className="font-bold">{socialStats.mentorshipSessions}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Dashboard de Métricas</h2>
          <p className="text-gray-600">Analiza tu progreso y rendimiento en el estudio bíblico</p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedPeriod} onValueChange={(value: any) => setSelectedPeriod(value)}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Diario</SelectItem>
              <SelectItem value="weekly">Semanal</SelectItem>
              <SelectItem value="monthly">Mensual</SelectItem>
              <SelectItem value="yearly">Anual</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={refreshMetrics} disabled={isLoading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Actualizar
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4" />
            <p>Cargando métricas...</p>
          </div>
        </div>
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">
              <BarChart3 className="w-4 h-4 mr-2" />
              Resumen
            </TabsTrigger>
            <TabsTrigger value="reading">
              <BookOpen className="w-4 h-4 mr-2" />
              Lectura
            </TabsTrigger>
            <TabsTrigger value="study">
              <Brain className="w-4 h-4 mr-2" />
              Estudio
            </TabsTrigger>
            <TabsTrigger value="social">
              <Users className="w-4 h-4 mr-2" />
              Social
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <OverviewPanel />
          </TabsContent>

          <TabsContent value="reading">
            <ReadingStatsPanel />
          </TabsContent>

          <TabsContent value="study">
            <StudyStatsPanel />
          </TabsContent>

          <TabsContent value="social">
            <SocialStatsPanel />
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
};

export default MetricsDashboard;
