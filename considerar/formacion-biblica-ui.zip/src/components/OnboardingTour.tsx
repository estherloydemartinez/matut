import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ChevronLeft, ChevronRight, BookOpen, Lightbulb, Users, BarChart3 } from 'lucide-react'

interface OnboardingTourProps {
  isOpen: boolean
  onClose: () => void
}

const tourSteps = [
  {
    title: '¡Bienvenido a Formación Bíblica Avanzada!',
    description: 'Tu plataforma integral para el estudio profundo de las Escrituras. Te guiaremos por las principales funcionalidades.',
    icon: <BookOpen className="w-12 h-12 text-discord-primary" />,
    image: '📖'
  },
  {
    title: 'Explora la Biblia',
    description: 'Accede al texto completo de la Biblia Reina Valera 1960. Navega por libros y capítulos, selecciona versículos y crea marcadores.',
    icon: <BookOpen className="w-8 h-8 text-blue-400" />,
    features: ['Navegación intuitiva', 'Selección de versículos', 'Marcadores personales', 'Búsqueda avanzada']
  },
  {
    title: 'Herramientas de Estudio',
    description: 'Utiliza herramientas avanzadas para profundizar en tu estudio bíblico con comentarios, notas y análisis contextual.',
    icon: <Lightbulb className="w-8 h-8 text-yellow-400" />,
    features: ['Notas personales', 'Comentarios bíblicos', 'Referencias cruzadas', 'Análisis contextual']
  },
  {
    title: 'Filtros Analíticos',
    description: 'Descubre pasajes relacionados por temas específicos como sangre, agua y otros elementos simbólicos importantes.',
    icon: <BarChart3 className="w-8 h-8 text-purple-400" />,
    features: ['Filtro de Sangre', 'Filtro de Agua', 'Categorización temática', 'Análisis simbólico']
  },
  {
    title: 'Comunidad y Colaboración',
    description: 'Conecta con otros estudiantes, participa en discusiones y comparte insights sobre el estudio bíblico.',
    icon: <Users className="w-8 h-8 text-green-400" />,
    features: ['Discusiones grupales', 'Canales temáticos', 'Compartir descubrimientos', 'Comunidad de aprendizaje']
  },
  {
    title: 'Atajos de Teclado',
    description: 'Navega más eficientemente usando estos atajos de teclado.',
    shortcuts: [
      { keys: 'Ctrl + K', description: 'Búsqueda global' },
      { keys: 'Ctrl + ,', description: 'Configuración' },
      { keys: 'Ctrl + H', description: 'Ayuda/Tutorial' },
      { keys: '1-6', description: 'Navegación entre secciones' }
    ]
  }
]

export default function OnboardingTour({ isOpen, onClose }: OnboardingTourProps) {
  const [currentStep, setCurrentStep] = useState(0)

  const nextStep = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      onClose()
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const goToStep = (step: number) => {
    setCurrentStep(step)
  }

  if (!isOpen) return null

  const currentTourStep = tourSteps[currentStep]

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="w-full max-w-2xl bg-discord-secondary rounded-lg shadow-elevation-high overflow-hidden"
        >
          {/* Header */}
          <div className="p-6 border-b border-discord-modifier-hover">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {currentTourStep.icon}
                <div>
                  <h2 className="text-xl font-semibold text-discord-text-primary">
                    {currentTourStep.title}
                  </h2>
                  <p className="text-sm text-discord-text-muted">
                    Paso {currentStep + 1} de {tourSteps.length}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-lg hover:bg-discord-modifier-hover transition-colors"
              >
                <X className="w-5 h-5 text-discord-text-muted" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                {currentTourStep.image && (
                  <div className="text-center mb-6">
                    <div className="text-6xl mb-4">{currentTourStep.image}</div>
                  </div>
                )}

                <p className="text-discord-text-secondary mb-6 leading-relaxed">
                  {currentTourStep.description}
                </p>

                {currentTourStep.features && (
                  <div className="space-y-3 mb-6">
                    <h4 className="font-medium text-discord-text-primary">Características principales:</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {currentTourStep.features.map((feature, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-center space-x-2 p-2 bg-discord-tertiary rounded-lg"
                        >
                          <div className="w-2 h-2 bg-discord-primary rounded-full"></div>
                          <span className="text-discord-text-secondary text-sm">{feature}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {currentTourStep.shortcuts && (
                  <div className="space-y-3 mb-6">
                    <h4 className="font-medium text-discord-text-primary">Atajos útiles:</h4>
                    <div className="space-y-2">
                      {currentTourStep.shortcuts.map((shortcut, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="flex items-center justify-between p-3 bg-discord-tertiary rounded-lg"
                        >
                          <span className="text-discord-text-secondary">{shortcut.description}</span>
                          <kbd className="px-2 py-1 bg-discord-input rounded text-xs font-mono text-discord-text-primary">
                            {shortcut.keys}
                          </kbd>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-discord-modifier-hover bg-discord-tertiary">
            {/* Progress indicator */}
            <div className="flex justify-center space-x-2 mb-4">
              {tourSteps.map((_, index) => (
                <motion.button
                  key={index}
                  onClick={() => goToStep(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentStep
                      ? 'bg-discord-primary'
                      : index < currentStep
                      ? 'bg-discord-primary/50'
                      : 'bg-discord-modifier-hover'
                  }`}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                />
              ))}
            </div>

            {/* Navigation buttons */}
            <div className="flex justify-between items-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={prevStep}
                disabled={currentStep === 0}
                className="flex items-center space-x-2 px-4 py-2 bg-discord-input rounded-lg hover:bg-discord-modifier-hover transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-discord-text-primary"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Anterior</span>
              </motion.button>

              <span className="text-discord-text-muted text-sm">
                {currentStep + 1} / {tourSteps.length}
              </span>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={nextStep}
                className="flex items-center space-x-2 px-4 py-2 bg-discord-primary rounded-lg hover:bg-discord-primary/80 transition-colors text-white"
              >
                <span>{currentStep === tourSteps.length - 1 ? 'Finalizar' : 'Siguiente'}</span>
                {currentStep !== tourSteps.length - 1 && <ChevronRight className="w-4 h-4" />}
              </motion.button>
            </div>

            {/* Skip option */}
            <div className="text-center mt-4">
              <button
                onClick={onClose}
                className="text-discord-text-muted hover:text-discord-text-secondary text-sm transition-colors"
              >
                Saltar tutorial
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
