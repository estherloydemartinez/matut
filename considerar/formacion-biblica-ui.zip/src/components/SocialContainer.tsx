import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Users, MessageCircle, Trophy, Star, Clock, 
  TrendingUp, Heart, BookOpen, Target, Video,
  UserPlus, Settings, Search, Filter, Plus,
  Zap, Crown, Shield, Gift, Bell, Share2,
  PenTool, Calendar, Globe, Lock, Eye,
  Mic, MicOff, VideoOff, Phone, PhoneOff,
  Monitor, Hand, MessageSquare, Palette,
  Send, Smile, Paperclip, MoreVertical,
  ThumbsUp, ThumbsDown, Brain, Award,
  Bookmark, Flag, ExternalLink, Download
} from 'lucide-react';

// Importar sistemas sociales
import { globalSocialEngine, type User, type Community, type StudyGroup, type SocialChallenge } from '@/lib/social-engine';
import { globalRealTimeCollaboration, type ChatMessage, type CollaborativeAnnotation, type RealTimeParticipant } from '@/lib/real-time-collaboration';
import { legacyBridge } from '@/lib/legacy-integration';

const SocialContainer: React.FC = () => {
  // Estados principales
  const [activeTab, setActiveTab] = useState('communities');
  const [activeUsers, setActiveUsers] = useState(127);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  // Estados de comunidades
  const [communities, setCommunities] = useState<Community[]>([]);
  const [selectedCommunity, setSelectedCommunity] = useState<Community | null>(null);
  
  // Estados de grupos de estudio
  const [studyGroups, setStudyGroups] = useState<StudyGroup[]>([]);
  const [recommendedGroups, setRecommendedGroups] = useState<StudyGroup[]>([]);
  
  // Estados de mentorías
  const [mentors, setMentors] = useState<User[]>([]);
  const [mentorships, setMentorships] = useState<any[]>([]);
  
  // Estados de colaboración en tiempo real
  const [activeSession, setActiveSession] = useState<any>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [annotations, setAnnotations] = useState<CollaborativeAnnotation[]>([]);
  const [participants, setParticipants] = useState<RealTimeParticipant[]>([]);
  
  // Estados de desafíos y gamificación
  const [challenges, setChallenges] = useState<SocialChallenge[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  
  // Estados de UI
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [createDialogType, setCreateDialogType] = useState<'community' | 'group' | 'challenge'>('community');
  const [isVideoCallActive, setIsVideoCallActive] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);

  // Estados de módulos legacy
  const [legacyProfile, setLegacyProfile] = useState<any>(null);
  const [legacyFriends, setLegacyFriends] = useState<any[]>([]);
  const [legacyNotifications, setLegacyNotifications] = useState<any[]>([]);
  const [legacyEvents, setLegacyEvents] = useState<any[]>([]);
  const [legacyModuleStatus, setLegacyModuleStatus] = useState({ initialized: false, social: false });

  // Inicialización
  useEffect(() => {
    initializeSocialData();
    setupEventListeners();
    
    return () => {
      cleanupEventListeners();
    };
  }, []);

  const initializeSocialData = async () => {
    try {
      // Inicializar módulos legacy
      await initializeLegacyModules();

      // Cargar datos desde el motor social
      const allCommunities = globalSocialEngine.getAllCommunities();
      const allGroups = globalSocialEngine.getAllStudyGroups();
      
      setCommunities(allCommunities);
      setStudyGroups(allGroups);
      
      // Simular usuario actual
      const user = globalSocialEngine.getUser('user1');
      setCurrentUser(user || null);
      
      // Cargar recomendaciones
      if (user) {
        const recommended = await globalSocialEngine.findRecommendedStudyGroups(user.id);
        setRecommendedGroups(recommended);
        
        const recommendedMentors = await globalSocialEngine.findRecommendedMentors(user.id, user.interests);
        setMentors(recommendedMentors);
      }
      
    } catch (error) {
      console.error('Error initializing social data:', error);
    }
  };

  // Inicialización de módulos legacy
  const initializeLegacyModules = async () => {
    try {
      await legacyBridge.waitForInitialization();
      const status = legacyBridge.getModulesStatus();
      setLegacyModuleStatus(status);

      if (status.social) {
        // Cargar datos desde módulo social legacy
        const profile = legacyBridge.getUserProfile();
        const friends = legacyBridge.getFriends();
        const notifications = legacyBridge.getNotifications();
        const events = legacyBridge.getSocialEvents();

        setLegacyProfile(profile);
        setLegacyFriends(friends);
        setLegacyNotifications(notifications);
        setLegacyEvents(events);

        console.log('Legacy social module initialized:', { profile, friends: friends.length, notifications: notifications.length });
      }
    } catch (error) {
      console.error('Error initializing legacy modules:', error);
    }
  };

  const setupEventListeners = () => {
    // Event listeners para el motor social
    globalSocialEngine.addEventListener('community-created', handleCommunityCreated);
    globalSocialEngine.addEventListener('study-group-created', handleGroupCreated);
    globalSocialEngine.addEventListener('challenge-created', handleChallengeCreated);
    
    // Event listeners para colaboración en tiempo real
    globalRealTimeCollaboration.addEventListener('chat-message-sent', handleChatMessage);
    globalRealTimeCollaboration.addEventListener('annotation-added', handleAnnotationAdded);
    globalRealTimeCollaboration.addEventListener('participant-joined', handleParticipantJoined);
  };

  const cleanupEventListeners = () => {
    globalSocialEngine.removeEventListener('community-created', handleCommunityCreated);
    globalSocialEngine.removeEventListener('study-group-created', handleGroupCreated);
    globalSocialEngine.removeEventListener('challenge-created', handleChallengeCreated);
    
    globalRealTimeCollaboration.removeEventListener('chat-message-sent', handleChatMessage);
    globalRealTimeCollaboration.removeEventListener('annotation-added', handleAnnotationAdded);
    globalRealTimeCollaboration.removeEventListener('participant-joined', handleParticipantJoined);
  };

  // Event handlers
  const handleCommunityCreated = (event: Event) => {
    const detail = (event as CustomEvent).detail;
    setCommunities(prev => [...prev, detail.community]);
  };

  const handleGroupCreated = (event: Event) => {
    const detail = (event as CustomEvent).detail;
    setStudyGroups(prev => [...prev, detail.studyGroup]);
  };

  const handleChallengeCreated = (event: Event) => {
    const detail = (event as CustomEvent).detail;
    setChallenges(prev => [...prev, detail.challenge]);
  };

  const handleChatMessage = (event: Event) => {
    const detail = (event as CustomEvent).detail;
    setChatMessages(prev => [...prev, detail.message]);
  };

  const handleAnnotationAdded = (event: Event) => {
    const detail = (event as CustomEvent).detail;
    setAnnotations(prev => [...prev, detail.annotation]);
  };

  const handleParticipantJoined = (event: Event) => {
    const detail = (event as CustomEvent).detail;
    setParticipants(prev => [...prev, detail.participant]);
  };

  // Funciones de acción
  const createCommunity = async (data: any) => {
    if (!currentUser) return;
    
    try {
      await globalSocialEngine.createCommunity(currentUser.id, data);
      setShowCreateDialog(false);
    } catch (error) {
      console.error('Error creating community:', error);
    }
  };

  const createStudyGroup = async (data: any) => {
    if (!currentUser) return;
    
    try {
      await globalSocialEngine.createStudyGroup(currentUser.id, data);
      setShowCreateDialog(false);
    } catch (error) {
      console.error('Error creating study group:', error);
    }
  };

  const joinCommunity = async (communityId: string) => {
    if (!currentUser) return;
    
    try {
      await globalSocialEngine.joinCommunity(currentUser.id, communityId);
      // Actualizar UI
      const community = communities.find(c => c.id === communityId);
      if (community && !community.members.includes(currentUser.id)) {
        community.members.push(currentUser.id);
        community.memberCount++;
        setCommunities([...communities]);
      }
    } catch (error) {
      console.error('Error joining community:', error);
    }
  };

  const startVideoCall = async () => {
    try {
      const videoCall = await globalRealTimeCollaboration.startVideoCall('current-session');
      setIsVideoCallActive(true);
    } catch (error) {
      console.error('Error starting video call:', error);
    }
  };

  const sendChatMessage = async (content: string) => {
    if (!activeSession) return;
    
    try {
      await globalRealTimeCollaboration.sendChatMessage(activeSession.id, content);
    } catch (error) {
      console.error('Error sending chat message:', error);
    }
  };

  // Funciones de interacción con módulos legacy
  const markNotificationAsRead = async (notificationId: string) => {
    try {
      const success = await legacyBridge.markNotificationAsRead(notificationId);
      if (success) {
        setLegacyNotifications(prev => 
          prev.map(notif => 
            notif.id === notificationId ? { ...notif, leida: true } : notif
          )
        );
      }
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const updateLegacyProfile = async (profileData: any) => {
    try {
      const success = await legacyBridge.updateUserProfile(profileData);
      if (success) {
        setLegacyProfile(prev => ({ ...prev, ...profileData }));
      }
      return success;
    } catch (error) {
      console.error('Error updating profile:', error);
      return false;
    }
  };

  const refreshLegacyData = async () => {
    if (!legacyModuleStatus.social) return;

    try {
      const profile = legacyBridge.getUserProfile();
      const friends = legacyBridge.getFriends();
      const notifications = legacyBridge.getNotifications();
      const events = legacyBridge.getSocialEvents();

      setLegacyProfile(profile);
      setLegacyFriends(friends);
      setLegacyNotifications(notifications);
      setLegacyEvents(events);
    } catch (error) {
      console.error('Error refreshing legacy data:', error);
    }
  };

  // Componente para mostrar datos legacy
  const renderLegacyStatus = () => (
    <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-blue-900">Estado del Módulo Social Optimizado</h3>
          <p className="text-sm text-blue-700">
            {legacyModuleStatus.social ? 
              '✅ Módulo cargado - Funciones avanzadas disponibles' : 
              '⚠️ Módulo no disponible - Usando funciones básicas'
            }
          </p>
        </div>
        {legacyModuleStatus.social && (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={refreshLegacyData}
            className="text-blue-700 border-blue-300"
          >
            Actualizar
          </Button>
        )}
      </div>
      
      {legacyProfile && (
        <div className="mt-3 text-sm text-blue-800">
          👤 {legacyProfile.nombre} | 
          📚 {legacyProfile.librosLeidos || 0} libros leídos | 
          ⏱️ {legacyProfile.tiempoEstudio || 0} minutos de estudio
        </div>
      )}
    </div>
  );

  const renderLegacyNotifications = () => (
    <Card className="mt-4">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Notificaciones ({legacyNotifications.filter(n => !n.leida).length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-64">
          <div className="space-y-2">
            {legacyNotifications.slice(0, 10).map((notification) => (
              <div 
                key={notification.id}
                className={`p-3 rounded-lg border ${
                  notification.leida ? 'bg-gray-50 border-gray-200' : 'bg-blue-50 border-blue-200'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="text-sm font-medium">{notification.contenido}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(notification.fecha).toLocaleString()}
                    </p>
                  </div>
                  {!notification.leida && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => markNotificationAsRead(notification.id)}
                      className="text-xs"
                    >
                      Marcar leída
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );

  // Componentes de renderizado
  const renderCommunities = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Comunidades</h2>
          <p className="text-gray-600">Únete a comunidades de estudio y crecimiento espiritual</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => {
              setCreateDialogType('community');
              setShowCreateDialog(true);
            }}
            className="flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Crear Comunidad
          </Button>
        </div>
      </div>

      {/* Filtros y búsqueda */}
      <div className="flex gap-4">
        <div className="flex-1">
          <Input
            placeholder="Buscar comunidades..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>
        <Button variant="outline" size="icon">
          <Filter className="w-4 h-4" />
        </Button>
      </div>

      {/* Lista de comunidades */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {communities
          .filter(community => 
            community.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            community.description.toLowerCase().includes(searchQuery.toLowerCase())
          )
          .map((community) => (
            <Card key={community.id} className="hover:shadow-lg transition-all duration-200">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      {community.visibility === 'private' && <Lock className="w-4 h-4" />}
                      {community.visibility === 'public' && <Globe className="w-4 h-4" />}
                      {community.name}
                    </CardTitle>
                    <CardDescription className="mt-1">
                      {community.description}
                    </CardDescription>
                  </div>
                  <Badge variant="secondary">
                    {community.category}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Estadísticas */}
                <div className="flex justify-between text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {community.memberCount} miembros
                  </div>
                  <div className="flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    {Math.round((community.analytics?.engagementRate || 0) * 100)}% activos
                  </div>
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1">
                  {community.tags.slice(0, 3).map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {community.tags.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{community.tags.length - 3} más
                    </Badge>
                  )}
                </div>

                {/* Acciones */}
                <div className="flex gap-2">
                  {community.members.includes(currentUser?.id || '') ? (
                    <Button className="flex-1" variant="outline">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Entrar
                    </Button>
                  ) : (
                    <Button 
                      className="flex-1"
                      onClick={() => joinCommunity(community.id)}
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Unirse
                    </Button>
                  )}
                  <Button variant="outline" size="icon">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
      </div>
    </div>
  );

  const renderStudyGroups = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Grupos de Estudio</h2>
          <p className="text-gray-600">Estudia la Biblia en grupos pequeños con compañeros de fe</p>
        </div>
        <Button 
          onClick={() => {
            setCreateDialogType('group');
            setShowCreateDialog(true);
          }}
          className="flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Crear Grupo
        </Button>
      </div>

      {/* Grupos recomendados */}
      {recommendedGroups.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-500" />
            Recomendados para ti
          </h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {recommendedGroups.slice(0, 3).map((group) => (
              <Card key={group.id} className="border-2 border-yellow-200 hover:border-yellow-300 transition-colors">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Crown className="w-4 h-4 text-yellow-500" />
                    {group.name}
                  </CardTitle>
                  <CardDescription>
                    {group.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Información del grupo */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Miembros:</span>
                      <span>{group.members.length}/{group.capacity}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Progreso:</span>
                      <span>{Math.round(group.progress.completionRate * 100)}%</span>
                    </div>
                    <Progress value={group.progress.completionRate * 100} className="w-full" />
                  </div>

                  {/* Horario */}
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" />
                    {group.schedule.frequency} • {group.schedule.duration}min
                  </div>

                  {/* Acciones */}
                  <Button className="w-full">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Unirse al Grupo
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Todos los grupos */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Todos los Grupos</h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {studyGroups.map((group) => (
            <Card key={group.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{group.name}</CardTitle>
                    <CardDescription className="mt-1">
                      {group.description}
                    </CardDescription>
                  </div>
                  <Badge 
                    className={
                      group.type === 'open' ? 'bg-green-100 text-green-800' :
                      group.type === 'closed' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }
                  >
                    {group.type === 'open' ? 'Abierto' : 
                     group.type === 'closed' ? 'Cerrado' : 'Por invitación'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Estadísticas del grupo */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Participantes:</span>
                    <span>{group.members.length}/{group.capacity}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Progreso:</span>
                    <span>{Math.round(group.progress.completionRate * 100)}%</span>
                  </div>
                  <Progress value={group.progress.completionRate * 100} className="w-full" />
                </div>

                {/* Información de horario */}
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="w-4 h-4" />
                  Próxima reunión: Hoy 7:00 PM
                </div>

                {/* Miembros destacados */}
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Miembros:</span>
                  <div className="flex -space-x-2">
                    {group.members.slice(0, 3).map((member, index) => (
                      <Avatar key={index} className="w-6 h-6 border-2 border-white">
                        <AvatarFallback className="text-xs">
                          {member.userId.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    ))}
                    {group.members.length > 3 && (
                      <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center text-xs text-gray-600 border-2 border-white">
                        +{group.members.length - 3}
                      </div>
                    )}
                  </div>
                </div>

                {/* Acciones */}
                <div className="flex gap-2">
                  <Button variant="default" size="sm" className="flex-1">
                    Unirse
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    Ver detalles
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const renderMentorships = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Sistema de Mentorías</h2>
          <p className="text-gray-600">Conecta con mentores experimentados o mentoriza a otros</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Search className="w-4 h-4 mr-2" />
            Buscar Mentor
          </Button>
          <Button>
            <Crown className="w-4 h-4 mr-2" />
            Ser Mentor
          </Button>
        </div>
      </div>

      {/* Mentores recomendados */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Star className="w-5 h-5 text-yellow-500" />
          Mentores Recomendados
        </h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {mentors.map((mentor) => (
            <Card key={mentor.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start gap-3">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={mentor.avatar} />
                    <AvatarFallback>
                      {mentor.displayName.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      {mentor.displayName}
                      <Badge className="bg-yellow-100 text-yellow-800">
                        Nivel {mentor.level}
                      </Badge>
                    </CardTitle>
                    <CardDescription>
                      {mentor.bio}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Estadísticas del mentor */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="text-center">
                    <div className="font-semibold text-lg">{mentor.stats.averageRating}</div>
                    <div className="text-gray-600">Calificación</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-lg">{mentor.stats.completedCourses}</div>
                    <div className="text-gray-600">Cursos</div>
                  </div>
                </div>

                {/* Especialidades */}
                <div>
                  <p className="text-sm font-medium mb-2">Especialidades:</p>
                  <div className="flex flex-wrap gap-1">
                    {mentor.interests.slice(0, 3).map((interest, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Acciones */}
                <div className="flex gap-2">
                  <Button className="flex-1">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Solicitar Mentoría
                  </Button>
                  <Button variant="outline" size="icon">
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Mis mentorías activas */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Mis Mentorías Activas</h3>
        <div className="space-y-4">
          {mentorships.length === 0 ? (
            <Card className="p-8 text-center">
              <div className="text-gray-500 mb-4">
                <Crown className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                <p>No tienes mentorías activas</p>
                <p className="text-sm">Busca un mentor o conviértete en uno</p>
              </div>
              <Button>
                <Search className="w-4 h-4 mr-2" />
                Explorar Mentores
              </Button>
            </Card>
          ) : (
            mentorships.map((mentorship, index) => (
              <Card key={index} className="p-4">
                {/* Contenido de mentorías activas */}
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );

  const renderCollaboration = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Colaboración en Tiempo Real</h2>
          <p className="text-gray-600">Estudia, discute y anota la Biblia con otros en tiempo real</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setIsChatOpen(!isChatOpen)}>
            <MessageSquare className="w-4 h-4 mr-2" />
            Chat
          </Button>
          <Button onClick={startVideoCall}>
            <Video className="w-4 h-4 mr-2" />
            Videollamada
          </Button>
        </div>
      </div>

      {/* Sesión activa */}
      {activeSession && (
        <Card className="border-2 border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              Sesión Activa: {activeSession.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex -space-x-2">
                  {participants.slice(0, 5).map((participant, index) => (
                    <Avatar key={index} className="w-8 h-8 border-2 border-white">
                      <AvatarFallback className="text-xs">
                        {participant.name.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  ))}
                  {participants.length > 5 && (
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-xs text-gray-600 border-2 border-white">
                      +{participants.length - 5}
                    </div>
                  )}
                </div>
                <span className="text-sm text-gray-600">
                  {participants.length} participante{participants.length !== 1 ? 's' : ''}
                </span>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Palette className="w-4 h-4 mr-2" />
                  Pizarra
                </Button>
                <Button variant="outline" size="sm">
                  <PenTool className="w-4 h-4 mr-2" />
                  Anotar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Grid de colaboración */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Anotaciones colaborativas */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PenTool className="w-5 h-5" />
              Anotaciones Colaborativas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64">
              <div className="space-y-3">
                {annotations.map((annotation) => (
                  <div key={annotation.id} className="border rounded-lg p-3">
                    <div className="flex items-start gap-2">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback className="text-xs">
                          {annotation.userId.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium">Usuario</span>
                          <Badge variant="outline" className="text-xs">
                            {annotation.type}
                          </Badge>
                          {annotation.verse && (
                            <Badge variant="secondary" className="text-xs">
                              {annotation.verse.book} {annotation.verse.chapter}:{annotation.verse.verse}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm">{annotation.content}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Button variant="ghost" size="sm" className="h-6 px-2">
                            <ThumbsUp className="w-3 h-3 mr-1" />
                            {annotation.reactions.length}
                          </Button>
                          <Button variant="ghost" size="sm" className="h-6 px-2">
                            <MessageCircle className="w-3 h-3 mr-1" />
                            {annotation.replies.length}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Chat en tiempo real */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              Chat en Tiempo Real
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64 mb-4">
              <div className="space-y-3">
                {chatMessages.map((message) => (
                  <div key={message.id} className="flex items-start gap-2">
                    <Avatar className="w-6 h-6">
                      <AvatarFallback className="text-xs">
                        {message.userId.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium">Usuario</span>
                        <span className="text-xs text-gray-500">
                          {message.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-sm">{message.content}</p>
                      {message.reactions.length > 0 && (
                        <div className="flex gap-1 mt-1">
                          {message.reactions.map((reaction, index) => (
                            <span key={index} className="text-xs bg-gray-100 rounded px-1">
                              {reaction.emoji}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
            <div className="flex gap-2">
              <Input 
                placeholder="Escribe un mensaje..."
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    sendChatMessage(e.currentTarget.value);
                    e.currentTarget.value = '';
                  }
                }}
              />
              <Button size="icon">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderGamification = () => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Gamificación y Desafíos</h2>
          <p className="text-gray-600">Participa en desafíos y compite amigablemente con la comunidad</p>
        </div>
        <Button 
          onClick={() => {
            setCreateDialogType('challenge');
            setShowCreateDialog(true);
          }}
          className="flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          Crear Desafío
        </Button>
      </div>

      {/* Estadísticas del usuario */}
      {currentUser && (
        <Card className="bg-gradient-to-r from-purple-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{currentUser.level}</div>
                <div className="text-sm opacity-90">Nivel</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{currentUser.reputation}</div>
                <div className="text-sm opacity-90">Reputación</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{currentUser.stats.streakDays}</div>
                <div className="text-sm opacity-90">Racha (días)</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{currentUser.badges.length}</div>
                <div className="text-sm opacity-90">Logros</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Desafíos activos */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Desafíos Activos</h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {challenges.map((challenge) => (
            <Card key={challenge.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{challenge.title}</CardTitle>
                  <Badge 
                    className={
                      challenge.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                      challenge.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }
                  >
                    {challenge.difficulty === 'easy' ? 'Fácil' :
                     challenge.difficulty === 'medium' ? 'Medio' : 'Difícil'}
                  </Badge>
                </div>
                <CardDescription>
                  {challenge.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Información del desafío */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Participantes:</span>
                    <span>{challenge.participants.length}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Puntos:</span>
                    <span className="font-semibold text-yellow-600">{challenge.points}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Tiempo restante:</span>
                    <span>5 días</span>
                  </div>
                </div>

                {/* Recompensas */}
                <div>
                  <p className="text-sm font-medium mb-2">Recompensas:</p>
                  <div className="flex gap-1">
                    {challenge.rewards.map((reward, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {reward.type === 'points' ? `${reward.value} pts` : 
                         reward.type === 'badge' ? '🏆 Badge' : '🎁 Item'}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Acciones */}
                <Button className="w-full">
                  <Target className="w-4 h-4 mr-2" />
                  Participar
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Tabla de Líderes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {/* Mock leaderboard data */}
            {[
              { name: 'Pastor Martínez', points: 2500, level: 4, position: 1 },
              { name: 'Ana Rodríguez', points: 1800, level: 3, position: 2 },
              { name: 'Carlos López', points: 1200, level: 2, position: 3 },
              { name: 'María González', points: 950, level: 2, position: 4 },
              { name: 'Tú', points: currentUser?.reputation || 0, level: currentUser?.level || 0, position: 5 }
            ].map((user, index) => (
              <div key={index} className={`flex items-center gap-3 p-3 rounded-lg ${user.name === 'Tú' ? 'bg-blue-50 border-2 border-blue-200' : 'bg-gray-50'}`}>
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 font-semibold text-sm">
                  {user.position}
                </div>
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="text-xs">
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="font-medium">{user.name}</div>
                  <div className="text-sm text-gray-600">Nivel {user.level}</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{user.points}</div>
                  <div className="text-sm text-gray-600">puntos</div>
                </div>
                {user.position <= 3 && (
                  <div className="text-lg">
                    {user.position === 1 ? '🥇' : user.position === 2 ? '🥈' : '🥉'}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header principal */}
      <div className="bg-gradient-to-r from-purple-600 via-blue-600 to-teal-600 text-white p-8 rounded-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-2">Comunidad de Formación Bíblica</h1>
            <p className="text-blue-100 text-lg">Conecta, aprende y crece junto a otros estudiantes de la Biblia</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold">{activeUsers}</div>
            <div className="text-sm text-blue-200">usuarios activos</div>
            <div className="flex items-center gap-1 mt-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-green-200">En línea ahora</span>
            </div>
          </div>
        </div>
      </div>

      {/* Estado del módulo legacy */}
      {renderLegacyStatus()}

      {/* Tabs principales */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="communities" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            Comunidades
          </TabsTrigger>
          <TabsTrigger value="groups" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Grupos
          </TabsTrigger>
          <TabsTrigger value="mentorships" className="flex items-center gap-2">
            <Crown className="w-4 h-4" />
            Mentorías
          </TabsTrigger>
          <TabsTrigger value="collaboration" className="flex items-center gap-2">
            <Video className="w-4 h-4" />
            Colaboración
          </TabsTrigger>
          <TabsTrigger value="gamification" className="flex items-center gap-2">
            <Trophy className="w-4 h-4" />
            Desafíos
          </TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="communities">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                {renderCommunities()}
              </div>
              <div className="lg:col-span-1">
                {legacyModuleStatus.social && renderLegacyNotifications()}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="groups">
            {renderStudyGroups()}
          </TabsContent>

          <TabsContent value="mentorships">
            {renderMentorships()}
          </TabsContent>

          <TabsContent value="collaboration">
            {renderCollaboration()}
          </TabsContent>

          <TabsContent value="gamification">
            {renderGamification()}
          </TabsContent>
        </div>
      </Tabs>

      {/* Dialog para crear contenido */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              Crear {createDialogType === 'community' ? 'Comunidad' : 
                     createDialogType === 'group' ? 'Grupo de Estudio' : 'Desafío'}
            </DialogTitle>
            <DialogDescription>
              {createDialogType === 'community' ? 'Crea una nueva comunidad de estudio' :
               createDialogType === 'group' ? 'Forma un nuevo grupo de estudio' : 
               'Diseña un nuevo desafío para la comunidad'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Input placeholder="Nombre" />
            <Textarea placeholder="Descripción" />
            {createDialogType === 'community' && (
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Categoría" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="estudio">Estudio Bíblico</SelectItem>
                  <SelectItem value="oracion">Oración</SelectItem>
                  <SelectItem value="teologia">Teología</SelectItem>
                  <SelectItem value="ministerio">Ministerio</SelectItem>
                </SelectContent>
              </Select>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={() => {
                if (createDialogType === 'community') {
                  createCommunity({ name: 'Nueva Comunidad', description: 'Descripción' });
                } else if (createDialogType === 'group') {
                  createStudyGroup({ name: 'Nuevo Grupo', description: 'Descripción' });
                }
              }}>
                Crear
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SocialContainer;
