import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { toast } from '@/hooks/use-toast';
import { 
  Trophy, 
  Star, 
  Target, 
  TrendingUp, 
  Award, 
  Medal, 
  Crown, 
  Flame,
  BookOpen,
  Users,
  Calendar,
  Timer,
  Zap,
  Gift,
  Lock,
  Unlock,
  ChevronRight,
  CheckCircle,
  Play,
  Pause
} from 'lucide-react';

interface UserLevel {
  level: number;
  title: string;
  description: string;
  requiredXP: number;
  benefits: string[];
  icon: string;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  category: 'reading' | 'study' | 'social' | 'knowledge' | 'consistency' | 'special';
  type: 'milestone' | 'streak' | 'challenge' | 'exploration' | 'mastery';
  difficulty: 'easy' | 'medium' | 'hard' | 'legendary';
  points: number;
  requirements: AchievementRequirement[];
  icon: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
  isSecret: boolean;
  unlockedBy?: string[];
}

interface AchievementRequirement {
  type: 'read_books' | 'read_chapters' | 'study_days' | 'notes_created' | 'social_interactions' | 'quiz_score';
  target: number;
  timeframe?: number;
}

interface UserAchievement {
  achievementId: string;
  userId: string;
  unlockedAt: Date;
  progress: number;
  notified: boolean;
}

interface Challenge {
  id: string;
  name: string;
  description: string;
  type: 'daily' | 'weekly' | 'monthly' | 'seasonal' | 'special';
  category: 'reading' | 'memorization' | 'study' | 'social' | 'reflection';
  startDate: Date;
  endDate: Date;
  requirements: ChallengeRequirement[];
  rewards: ChallengeReward[];
  difficulty: 'easy' | 'medium' | 'hard';
  participants: number;
  maxParticipants?: number;
  isActive: boolean;
}

interface ChallengeRequirement {
  type: string;
  description: string;
  target: number;
  currentProgress?: number;
}

interface ChallengeReward {
  type: 'xp' | 'badge' | 'title' | 'unlock';
  value: string | number;
  description: string;
}

interface LeaderboardEntry {
  rank: number;
  userId: string;
  userName: string;
  avatar?: string;
  score: number;
  change: number;
  badge?: string;
}

const GamificationSystem: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [userLevel, setUserLevel] = useState(1);
  const [userXP, setUserXP] = useState(0);
  const [userAchievements, setUserAchievements] = useState<UserAchievement[]>([]);
  const [availableAchievements] = useState<Achievement[]>([
    {
      id: 'first_reading',
      name: 'Primer Paso',
      description: 'Completa tu primera lectura bíblica',
      category: 'reading',
      type: 'milestone',
      difficulty: 'easy',
      points: 10,
      requirements: [{ type: 'read_chapters', target: 1 }],
      icon: '📖',
      rarity: 'common',
      isSecret: false
    },
    {
      id: 'week_streak',
      name: 'Constancia Semanal',
      description: 'Lee durante 7 días consecutivos',
      category: 'consistency',
      type: 'streak',
      difficulty: 'medium',
      points: 50,
      requirements: [{ type: 'study_days', target: 7, timeframe: 7 }],
      icon: '🔥',
      rarity: 'uncommon',
      isSecret: false
    },
    {
      id: 'hundred_chapters',
      name: 'Lector Dedicado',
      description: 'Lee 100 capítulos bíblicos',
      category: 'reading',
      type: 'milestone',
      difficulty: 'hard',
      points: 200,
      requirements: [{ type: 'read_chapters', target: 100 }],
      icon: '🏆',
      rarity: 'rare',
      isSecret: false
    },
    {
      id: 'social_butterfly',
      name: 'Mariposa Social',
      description: 'Participa en 10 discusiones grupales',
      category: 'social',
      type: 'milestone',
      difficulty: 'medium',
      points: 75,
      requirements: [{ type: 'social_interactions', target: 10 }],
      icon: '🦋',
      rarity: 'uncommon',
      isSecret: false
    },
    {
      id: 'secret_scholar',
      name: 'Erudito Secreto',
      description: '???',
      category: 'special',
      type: 'mastery',
      difficulty: 'legendary',
      points: 500,
      requirements: [{ type: 'notes_created', target: 50 }],
      icon: '🎓',
      rarity: 'legendary',
      isSecret: true
    }
  ]);

  const [activeChallenges, setActiveChallenges] = useState<Challenge[]>([
    {
      id: 'daily_reading',
      name: 'Lectura Diaria',
      description: 'Lee un capítulo cada día esta semana',
      type: 'weekly',
      category: 'reading',
      startDate: new Date(),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      requirements: [
        { type: 'daily_reading', description: 'Leer 1 capítulo por día', target: 7, currentProgress: 3 }
      ],
      rewards: [
        { type: 'xp', value: 100, description: '100 puntos de experiencia' },
        { type: 'badge', value: 'weekly_reader', description: 'Insignia de Lector Semanal' }
      ],
      difficulty: 'easy',
      participants: 245,
      isActive: true
    },
    {
      id: 'memorization_challenge',
      name: 'Versículos de Memoria',
      description: 'Memoriza 5 versículos este mes',
      type: 'monthly',
      category: 'memorization',
      startDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
      endDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0),
      requirements: [
        { type: 'memorize_verses', description: 'Memorizar versículos', target: 5, currentProgress: 2 }
      ],
      rewards: [
        { type: 'xp', value: 300, description: '300 puntos de experiencia' },
        { type: 'title', value: 'Memorizador', description: 'Título especial' }
      ],
      difficulty: 'medium',
      participants: 89,
      isActive: true
    }
  ]);

  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([
    { rank: 1, userId: '1', userName: 'María García', score: 2450, change: 50, badge: '👑' },
    { rank: 2, userId: '2', userName: 'Juan Pérez', score: 2380, change: -20, badge: '🥈' },
    { rank: 3, userId: '3', userName: 'Ana López', score: 2200, change: 100, badge: '🥉' },
    { rank: 4, userId: 'current', userName: 'Tú', score: 1950, change: 75 },
    { rank: 5, userId: '5', userName: 'Carlos Ruiz', score: 1890, change: 25 }
  ]);

  const [levelData] = useState<UserLevel[]>([
    { level: 1, title: 'Principiante', description: 'Comenzando el viaje', requiredXP: 0, benefits: ['Acceso básico'], icon: '🌱' },
    { level: 2, title: 'Estudiante', description: 'Aprendiendo constantemente', requiredXP: 100, benefits: ['Notas personales'], icon: '📚' },
    { level: 3, title: 'Devoto', description: 'Dedicado al estudio', requiredXP: 300, benefits: ['Grupos de estudio'], icon: '🙏' },
    { level: 4, title: 'Erudito', description: 'Conocimiento profundo', requiredXP: 600, benefits: ['Herramientas avanzadas'], icon: '🎓' },
    { level: 5, title: 'Maestro', description: 'Guía de otros', requiredXP: 1000, benefits: ['Crear contenido'], icon: '👨‍🏫' }
  ]);

  const [selectedAchievement, setSelectedAchievement] = useState<Achievement | null>(null);

  // Cargar datos del usuario al montar
  useEffect(() => {
    loadUserProgress();
    loadUserAchievements();
  }, []);

  const loadUserProgress = useCallback(async () => {
    try {
      if (window.AdvancedFeaturesModule) {
        const level = window.AdvancedFeaturesModule.GamificationSystem.getUserLevel();
        const xp = window.AdvancedFeaturesModule.GamificationSystem.getUserXP();
        setUserLevel(level);
        setUserXP(xp);
      }
    } catch (error) {
      console.error('Error loading user progress:', error);
    }
  }, []);

  const loadUserAchievements = useCallback(async () => {
    try {
      if (window.AdvancedFeaturesModule) {
        const achievements = window.AdvancedFeaturesModule.GamificationSystem.getUserAchievements();
        setUserAchievements(achievements);
      }
    } catch (error) {
      console.error('Error loading user achievements:', error);
    }
  }, []);

  const joinChallenge = useCallback(async (challengeId: string) => {
    try {
      if (window.AdvancedFeaturesModule) {
        await window.AdvancedFeaturesModule.GamificationSystem.joinChallenge(challengeId);
        
        toast({
          title: "¡Te has unido al desafío!",
          description: "Buena suerte completando el desafío",
        });
      }
    } catch (error) {
      console.error('Error joining challenge:', error);
      toast({
        title: "Error",
        description: "No se pudo unir al desafío",
        variant: "destructive"
      });
    }
  }, []);

  // Calcular progreso al siguiente nivel
  const getNextLevel = () => {
    return levelData.find(l => l.level === userLevel + 1);
  };

  const getCurrentLevelData = () => {
    return levelData.find(l => l.level === userLevel) || levelData[0];
  };

  const getProgressToNextLevel = () => {
    const nextLevel = getNextLevel();
    const currentLevel = getCurrentLevelData();
    if (!nextLevel) return 100;
    
    const progress = ((userXP - currentLevel.requiredXP) / (nextLevel.requiredXP - currentLevel.requiredXP)) * 100;
    return Math.min(progress, 100);
  };

  // Componente de vista general
  const OverviewPanel = () => {
    const currentLevel = getCurrentLevelData();
    const nextLevel = getNextLevel();
    const progressPercent = getProgressToNextLevel();

    return (
      <div className="space-y-6">
        {/* Tarjeta de nivel y XP */}
        <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm opacity-90">Nivel actual</div>
                <div className="text-3xl font-bold flex items-center gap-2">
                  <span>{currentLevel.icon}</span>
                  <span>Nivel {userLevel}</span>
                </div>
                <div className="text-lg opacity-90">{currentLevel.title}</div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">{userXP.toLocaleString()}</div>
                <div className="text-sm opacity-90">Puntos XP</div>
              </div>
            </div>
            
            {nextLevel && (
              <div className="mt-4">
                <div className="flex justify-between text-sm mb-2">
                  <span>Progreso al Nivel {nextLevel.level}</span>
                  <span>{Math.round(progressPercent)}%</span>
                </div>
                <Progress value={progressPercent} className="h-2 bg-white/20" />
                <div className="text-xs opacity-90 mt-1">
                  {nextLevel.requiredXP - userXP} XP restantes para {nextLevel.title}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Estadísticas rápidas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <Trophy className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
              <div className="text-2xl font-bold">{userAchievements.length}</div>
              <div className="text-sm text-gray-600">Logros obtenidos</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <Target className="w-8 h-8 mx-auto mb-2 text-blue-500" />
              <div className="text-2xl font-bold">{activeChallenges.length}</div>
              <div className="text-sm text-gray-600">Desafíos activos</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-green-500" />
              <div className="text-2xl font-bold">#{leaderboard.find(l => l.userId === 'current')?.rank || 'N/A'}</div>
              <div className="text-sm text-gray-600">Posición global</div>
            </CardContent>
          </Card>
        </div>

        {/* Desafíos activos destacados */}
        <Card>
          <CardHeader>
            <CardTitle>Desafíos Activos</CardTitle>
            <CardDescription>Completa estos desafíos para ganar recompensas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeChallenges.slice(0, 2).map(challenge => (
                <div key={challenge.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-semibold">{challenge.name}</div>
                      <div className="text-sm text-gray-600">{challenge.description}</div>
                    </div>
                    <Badge variant={challenge.difficulty === 'easy' ? 'secondary' : 
                                  challenge.difficulty === 'medium' ? 'default' : 'destructive'}>
                      {challenge.difficulty}
                    </Badge>
                  </div>
                  
                  {challenge.requirements.map((req, index) => (
                    <div key={index} className="mt-2">
                      <div className="flex justify-between text-sm mb-1">
                        <span>{req.description}</span>
                        <span>{req.currentProgress || 0}/{req.target}</span>
                      </div>
                      <Progress value={((req.currentProgress || 0) / req.target) * 100} className="h-2" />
                    </div>
                  ))}
                  
                  <div className="flex justify-between items-center mt-3">
                    <div className="text-sm text-gray-500">
                      {challenge.participants} participantes
                    </div>
                    <div className="text-sm text-gray-500">
                      Termina: {new Date(challenge.endDate).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  // Componente de logros
  const AchievementsPanel = () => {
    const unlockedAchievements = availableAchievements.filter(a => 
      userAchievements.some(ua => ua.achievementId === a.id)
    );
    const lockedAchievements = availableAchievements.filter(a => 
      !userAchievements.some(ua => ua.achievementId === a.id) && !a.isSecret
    );
    const secretAchievements = availableAchievements.filter(a => a.isSecret && 
      !userAchievements.some(ua => ua.achievementId === a.id)
    );

    return (
      <div className="space-y-6">
        {/* Filtros por categoría */}
        <Card>
          <CardHeader>
            <CardTitle>Logros</CardTitle>
            <CardDescription>Desbloquea logros completando diferentes actividades</CardDescription>
          </CardHeader>
        </Card>

        {/* Logros desbloqueados */}
        {unlockedAchievements.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              Logros Desbloqueados ({unlockedAchievements.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {unlockedAchievements.map(achievement => {
                const userAchievement = userAchievements.find(ua => ua.achievementId === achievement.id);
                return (
                  <Card 
                    key={achievement.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow border-yellow-200 bg-yellow-50"
                    onClick={() => setSelectedAchievement(achievement)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="text-2xl">{achievement.icon}</div>
                        <div className="flex-1">
                          <div className="font-semibold">{achievement.name}</div>
                          <div className="text-sm text-gray-600 mb-2">{achievement.description}</div>
                          <div className="flex items-center gap-2">
                            <Badge 
                              variant="outline"
                              className={`border-${achievement.rarity === 'legendary' ? 'purple' : 
                                       achievement.rarity === 'epic' ? 'orange' : 
                                       achievement.rarity === 'rare' ? 'blue' : 'gray'}-500`}
                            >
                              {achievement.rarity}
                            </Badge>
                            <div className="text-sm text-gray-500">
                              +{achievement.points} XP
                            </div>
                          </div>
                          {userAchievement && (
                            <div className="text-xs text-gray-400 mt-1">
                              Desbloqueado: {new Date(userAchievement.unlockedAt).toLocaleDateString()}
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Logros bloqueados */}
        {lockedAchievements.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Lock className="w-5 h-5 text-gray-500" />
              Por Desbloquear ({lockedAchievements.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {lockedAchievements.map(achievement => (
                <Card 
                  key={achievement.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow opacity-70"
                  onClick={() => setSelectedAchievement(achievement)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="text-2xl grayscale">{achievement.icon}</div>
                      <div className="flex-1">
                        <div className="font-semibold">{achievement.name}</div>
                        <div className="text-sm text-gray-600 mb-2">{achievement.description}</div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">
                            {achievement.rarity}
                          </Badge>
                          <div className="text-sm text-gray-500">
                            +{achievement.points} XP
                          </div>
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {achievement.requirements.map(req => req.type).join(', ')}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Logros secretos */}
        {secretAchievements.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-purple-500" />
              Logros Secretos ({secretAchievements.length})
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {secretAchievements.map(achievement => (
                <Card key={achievement.id} className="border-dashed">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl mb-2">❓</div>
                    <div className="font-semibold">Logro Secreto</div>
                    <div className="text-sm text-gray-600">???</div>
                    <Badge variant="outline" className="mt-2">Misterioso</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Dialog de detalles del logro */}
        <Dialog open={!!selectedAchievement} onOpenChange={() => setSelectedAchievement(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <span className="text-2xl">{selectedAchievement?.icon}</span>
                {selectedAchievement?.name}
              </DialogTitle>
              <DialogDescription>
                {selectedAchievement?.description}
              </DialogDescription>
            </DialogHeader>
            
            {selectedAchievement && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm font-medium">Categoría</div>
                    <div className="text-sm text-gray-600 capitalize">{selectedAchievement.category}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium">Dificultad</div>
                    <Badge variant={selectedAchievement.difficulty === 'easy' ? 'secondary' : 
                                  selectedAchievement.difficulty === 'medium' ? 'default' : 'destructive'}>
                      {selectedAchievement.difficulty}
                    </Badge>
                  </div>
                  <div>
                    <div className="text-sm font-medium">Puntos</div>
                    <div className="text-sm text-gray-600">+{selectedAchievement.points} XP</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium">Rareza</div>
                    <Badge variant="outline">{selectedAchievement.rarity}</Badge>
                  </div>
                </div>
                
                <div>
                  <div className="text-sm font-medium mb-2">Requisitos</div>
                  <div className="space-y-1">
                    {selectedAchievement.requirements.map((req, index) => (
                      <div key={index} className="text-sm text-gray-600">
                        • {req.type.replace('_', ' ')}: {req.target}
                        {req.timeframe && ` (en ${req.timeframe} días)`}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    );
  };

  // Componente de desafíos
  const ChallengesPanel = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Desafíos Activos</CardTitle>
          <CardDescription>Participa en desafíos para ganar recompensas especiales</CardDescription>
        </CardHeader>
      </Card>

      <div className="space-y-4">
        {activeChallenges.map(challenge => (
          <Card key={challenge.id}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="text-xl font-semibold">{challenge.name}</h3>
                    <Badge variant={challenge.type === 'daily' ? 'default' : 
                                  challenge.type === 'weekly' ? 'secondary' : 'outline'}>
                      {challenge.type}
                    </Badge>
                    <Badge variant={challenge.difficulty === 'easy' ? 'secondary' : 
                                  challenge.difficulty === 'medium' ? 'default' : 'destructive'}>
                      {challenge.difficulty}
                    </Badge>
                  </div>
                  <p className="text-gray-600">{challenge.description}</p>
                </div>
                <Button onClick={() => joinChallenge(challenge.id)}>
                  <Play className="w-4 h-4 mr-2" />
                  Unirse
                </Button>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="text-sm font-medium mb-2">Progreso</div>
                  {challenge.requirements.map((req, index) => (
                    <div key={index} className="mb-2">
                      <div className="flex justify-between text-sm mb-1">
                        <span>{req.description}</span>
                        <span>{req.currentProgress || 0}/{req.target}</span>
                      </div>
                      <Progress value={((req.currentProgress || 0) / req.target) * 100} className="h-2" />
                    </div>
                  ))}
                </div>

                <div>
                  <div className="text-sm font-medium mb-2">Recompensas</div>
                  <div className="flex flex-wrap gap-2">
                    {challenge.rewards.map((reward, index) => (
                      <Badge key={index} variant="outline" className="flex items-center gap-1">
                        {reward.type === 'xp' && <Zap className="w-3 h-3" />}
                        {reward.type === 'badge' && <Award className="w-3 h-3" />}
                        {reward.type === 'title' && <Crown className="w-3 h-3" />}
                        {reward.description}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between items-center text-sm text-gray-500 pt-2 border-t">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {challenge.participants} participantes
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      Termina: {new Date(challenge.endDate).toLocaleDateString()}
                    </span>
                  </div>
                  <Badge variant="outline" className="capitalize">
                    {challenge.category}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // Componente de leaderboard
  const LeaderboardPanel = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Tabla de Clasificación</CardTitle>
          <CardDescription>Compite con otros usuarios y ve tu posición</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {leaderboard.map(entry => (
              <div 
                key={entry.userId} 
                className={`flex items-center justify-between p-3 rounded-lg ${
                  entry.userId === 'current' ? 'bg-blue-50 border border-blue-200' : 'hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 min-w-[60px]">
                    <span className="font-bold">{entry.rank}</span>
                    {entry.badge && <span>{entry.badge}</span>}
                  </div>
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={entry.avatar} />
                    <AvatarFallback>{entry.userName.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{entry.userName}</div>
                    {entry.userId === 'current' && (
                      <div className="text-xs text-blue-600">Tú</div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="font-bold">{entry.score.toLocaleString()}</div>
                    <div className={`text-xs flex items-center gap-1 ${
                      entry.change > 0 ? 'text-green-600' : 
                      entry.change < 0 ? 'text-red-600' : 'text-gray-500'
                    }`}>
                      {entry.change > 0 ? '↗' : entry.change < 0 ? '↘' : '→'}
                      {Math.abs(entry.change)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Sistema de Gamificación</h2>
          <p className="text-gray-600">Gana puntos, desbloquea logros y compite con otros usuarios</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">
            <TrendingUp className="w-4 h-4 mr-2" />
            Resumen
          </TabsTrigger>
          <TabsTrigger value="achievements">
            <Trophy className="w-4 h-4 mr-2" />
            Logros
          </TabsTrigger>
          <TabsTrigger value="challenges">
            <Target className="w-4 h-4 mr-2" />
            Desafíos
          </TabsTrigger>
          <TabsTrigger value="leaderboard">
            <Medal className="w-4 h-4 mr-2" />
            Ranking
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewPanel />
        </TabsContent>

        <TabsContent value="achievements">
          <AchievementsPanel />
        </TabsContent>

        <TabsContent value="challenges">
          <ChallengesPanel />
        </TabsContent>

        <TabsContent value="leaderboard">
          <LeaderboardPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default GamificationSystem;
