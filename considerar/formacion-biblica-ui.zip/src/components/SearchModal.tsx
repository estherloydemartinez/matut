import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, X, Clock, ArrowRight } from 'lucide-react'
import { useAppState } from '../contexts/AppStateContext'
import { useData } from '../contexts/DataContext'

interface SearchModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<any[]>([])
  const [isSearching, setIsSearching] = useState(false)
  
  const { searchHistory, addToSearchHistory } = useAppState()
  const { searchBible } = useData()

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) {
      setResults([])
      return
    }

    setIsSearching(true)
    try {
      const searchResults = await searchBible(searchQuery)
      setResults(searchResults)
      addToSearchHistory(searchQuery)
    } catch (error) {
      console.error('Search error:', error)
      setResults([])
    } finally {
      setIsSearching(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch(query)
    } else if (e.key === 'Escape') {
      onClose()
    }
  }

  useEffect(() => {
    if (isOpen) {
      setQuery('')
      setResults([])
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-center pt-20"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl mx-4 bg-discord-secondary rounded-lg shadow-elevation-high overflow-hidden"
        >
          {/* Search Header */}
          <div className="p-4 border-b border-discord-modifier-hover">
            <div className="flex items-center space-x-3">
              <Search className="w-5 h-5 text-discord-text-muted" />
              <input
                type="text"
                placeholder="Buscar en la Biblia..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 bg-transparent text-discord-text-primary placeholder-discord-text-muted outline-none"
                autoFocus
              />
              <button
                onClick={onClose}
                className="p-1 rounded hover:bg-discord-modifier-hover transition-colors"
              >
                <X className="w-5 h-5 text-discord-text-muted" />
              </button>
            </div>
          </div>

          {/* Search Content */}
          <div className="max-h-96 overflow-y-auto scrollbar-discord">
            {query.trim() === '' ? (
              /* Search History */
              <div className="p-4">
                <h3 className="text-sm font-medium text-discord-text-secondary mb-3 flex items-center">
                  <Clock className="w-4 h-4 mr-2" />
                  Búsquedas recientes
                </h3>
                {searchHistory.length > 0 ? (
                  <div className="space-y-1">
                    {searchHistory.map((term, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          setQuery(term)
                          handleSearch(term)
                        }}
                        className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-discord-modifier-hover transition-colors text-left"
                      >
                        <span className="text-discord-text-primary">{term}</span>
                        <ArrowRight className="w-4 h-4 text-discord-text-muted" />
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="text-discord-text-muted text-sm">No hay búsquedas recientes</p>
                )}
              </div>
            ) : isSearching ? (
              /* Loading */
              <div className="p-8 text-center">
                <div className="animate-pulse space-y-3">
                  <div className="h-4 bg-discord-modifier-hover rounded w-3/4 mx-auto"></div>
                  <div className="h-4 bg-discord-modifier-hover rounded w-1/2 mx-auto"></div>
                  <div className="h-4 bg-discord-modifier-hover rounded w-2/3 mx-auto"></div>
                </div>
              </div>
            ) : results.length > 0 ? (
              /* Search Results */
              <div className="p-4">
                <h3 className="text-sm font-medium text-discord-text-secondary mb-3">
                  {results.length} resultado{results.length !== 1 ? 's' : ''} encontrado{results.length !== 1 ? 's' : ''}
                </h3>
                <div className="space-y-3">
                  {results.map((result, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="p-3 rounded-lg hover:bg-discord-modifier-hover transition-colors cursor-pointer"
                      onClick={() => {
                        // Navigate to the verse
                        onClose()
                      }}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="text-sm font-medium text-discord-primary mb-1">
                            {result.book} {result.chapter}:{result.verse}
                          </div>
                          <div className="text-discord-text-secondary text-sm leading-relaxed">
                            {result.text}
                          </div>
                        </div>
                        <div className="ml-3 text-xs text-discord-text-muted">
                          Relevancia: {result.relevance}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            ) : query.trim() !== '' ? (
              /* No Results */
              <div className="p-8 text-center">
                <Search className="w-12 h-12 mx-auto text-discord-text-muted mb-4 opacity-50" />
                <h3 className="text-discord-text-primary font-medium mb-2">
                  No se encontraron resultados
                </h3>
                <p className="text-discord-text-muted text-sm">
                  Intenta con diferentes términos de búsqueda
                </p>
              </div>
            ) : null}
          </div>

          {/* Search Footer */}
          <div className="p-3 border-t border-discord-modifier-hover bg-discord-tertiary">
            <div className="flex items-center justify-between text-xs text-discord-text-muted">
              <span>Presiona Enter para buscar</span>
              <span>ESC para cerrar</span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
