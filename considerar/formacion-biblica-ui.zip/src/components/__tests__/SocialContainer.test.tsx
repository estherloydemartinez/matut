/**
 * Tests para SocialContainer Component
 * Testing completo del componente social principal
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { SocialContainer } from '../SocialContainer';

// Mock de dependencias
vi.mock('../ui/button', () => ({
  Button: ({ children, onClick, disabled, ...props }: any) => (
    <button onClick={onClick} disabled={disabled} {...props}>
      {children}
    </button>
  )
}));

vi.mock('../ui/tabs', () => ({
  Tabs: ({ children, defaultValue, onValueChange, ...props }: any) => (
    <div data-testid="tabs" data-default-value={defaultValue} {...props}>
      {children}
    </div>
  ),
  TabsList: ({ children, ...props }: any) => (
    <div data-testid="tabs-list" {...props}>
      {children}
    </div>
  ),
  TabsTrigger: ({ children, value, onClick, ...props }: any) => (
    <button 
      data-testid={`tab-trigger-${value}`} 
      onClick={onClick} 
      {...props}
    >
      {children}
    </button>
  ),
  TabsContent: ({ children, value, ...props }: any) => (
    <div data-testid={`tab-content-${value}`} {...props}>
      {children}
    </div>
  )
}));

vi.mock('../ui/card', () => ({
  Card: ({ children, ...props }: any) => (
    <div data-testid="card" {...props}>
      {children}
    </div>
  ),
  CardHeader: ({ children, ...props }: any) => (
    <div data-testid="card-header" {...props}>
      {children}
    </div>
  ),
  CardTitle: ({ children, ...props }: any) => (
    <h3 data-testid="card-title" {...props}>
      {children}
    </h3>
  ),
  CardContent: ({ children, ...props }: any) => (
    <div data-testid="card-content" {...props}>
      {children}
    </div>
  )
}));

vi.mock('../ui/badge', () => ({
  Badge: ({ children, variant, ...props }: any) => (
    <span data-testid="badge" data-variant={variant} {...props}>
      {children}
    </span>
  )
}));

vi.mock('../ui/input', () => ({
  Input: ({ placeholder, value, onChange, ...props }: any) => (
    <input 
      placeholder={placeholder} 
      value={value} 
      onChange={onChange} 
      data-testid="input"
      {...props} 
    />
  )
}));

vi.mock('../ui/dialog', () => ({
  Dialog: ({ children, open, onOpenChange }: any) => (
    <div data-testid="dialog" data-open={open}>
      {open && children}
    </div>
  ),
  DialogContent: ({ children, ...props }: any) => (
    <div data-testid="dialog-content" {...props}>
      {children}
    </div>
  ),
  DialogHeader: ({ children, ...props }: any) => (
    <div data-testid="dialog-header" {...props}>
      {children}
    </div>
  ),
  DialogTitle: ({ children, ...props }: any) => (
    <h2 data-testid="dialog-title" {...props}>
      {children}
    </h2>
  ),
  DialogTrigger: ({ children, ...props }: any) => (
    <div data-testid="dialog-trigger" {...props}>
      {children}
    </div>
  )
}));

vi.mock('../ui/progress', () => ({
  Progress: ({ value, ...props }: any) => (
    <div data-testid="progress" data-value={value} {...props}>
      <div style={{ width: `${value}%` }}>Progress: {value}%</div>
    </div>
  )
}));

// Mock de iconos
vi.mock('lucide-react', () => ({
  Users: () => <div data-testid="users-icon">Users</div>,
  BookOpen: () => <div data-testid="book-open-icon">BookOpen</div>,
  GraduationCap: () => <div data-testid="graduation-cap-icon">GraduationCap</div>,
  MessageCircle: () => <div data-testid="message-circle-icon">MessageCircle</div>,
  Trophy: () => <div data-testid="trophy-icon">Trophy</div>,
  Plus: () => <div data-testid="plus-icon">Plus</div>,
  Search: () => <div data-testid="search-icon">Search</div>,
  Calendar: () => <div data-testid="calendar-icon">Calendar</div>,
  MapPin: () => <div data-testid="map-pin-icon">MapPin</div>,
  Clock: () => <div data-testid="clock-icon">Clock</div>,
  User: () => <div data-testid="user-icon">User</div>,
  Star: () => <div data-testid="star-icon">Star</div>,
  Play: () => <div data-testid="play-icon">Play</div>,
  Video: () => <div data-testid="video-icon">Video</div>
}));

// Mock de Social Engine
const mockSocialEngine = {
  getUserCommunities: vi.fn(() => [
    {
      id: 'comm1',
      name: 'Estudio de Génesis',
      description: 'Comunidad para estudiar el libro de Génesis',
      category: 'Bible Study',
      members: ['user1', 'user2'],
      stats: { totalMembers: 2, engagementRate: 0.8 }
    }
  ]),
  getUserStudyGroups: vi.fn(() => [
    {
      id: 'group1',
      name: 'Grupo Jóvenes',
      book: 'Salmos',
      members: ['user1', 'user2', 'user3'],
      schedule: { frequency: 'weekly', time: '19:00' }
    }
  ]),
  getUserMentorships: vi.fn(() => [
    {
      id: 'mentor1',
      mentor: 'mentor-user',
      student: 'student-user',
      subject: 'Hermenéutica Bíblica',
      status: 'active'
    }
  ]),
  getActiveChallenges: vi.fn(() => [
    {
      id: 'challenge1',
      title: 'Leer Salmos en 30 días',
      participants: ['user1', 'user2'],
      type: 'individual',
      progress: 0.6
    }
  ]),
  createCommunity: vi.fn(() => Promise.resolve('new-comm-id')),
  createStudyGroup: vi.fn(() => Promise.resolve('new-group-id')),
  createChallenge: vi.fn(() => Promise.resolve('new-challenge-id')),
  requestMentorship: vi.fn(() => Promise.resolve('new-mentorship-id')),
  searchCommunities: vi.fn(() => []),
  getUserProgress: vi.fn(() => ({
    chaptersRead: 50,
    timeSpent: 1200,
    streak: 7,
    achievements: ['early-bird', 'consistent-reader']
  })),
  getCommunityMetrics: vi.fn(() => ({
    memberCount: 25,
    engagementRate: 0.75,
    totalPosts: 45
  })),
  getGlobalSocialAnalytics: vi.fn(() => ({
    totalUsers: 1000,
    totalCommunities: 50,
    totalStudyGroups: 75,
    activeMentorships: 30
  }))
};

vi.mock('../../lib/social-engine', () => ({
  globalSocialEngine: mockSocialEngine
}));

// Mock de Real-time Collaboration
const mockRealTimeCollaboration = {
  getActiveConnections: vi.fn(() => [
    { userId: 'user1', status: 'active', type: 'study_session' }
  ]),
  getRecentCollaborations: vi.fn(() => [
    {
      id: 'collab1',
      type: 'annotation',
      participants: ['user1', 'user2'],
      content: 'Annotation on Genesis 1:1'
    }
  ]),
  startCollaborativeSession: vi.fn(() => Promise.resolve('session-id')),
  joinSession: vi.fn(() => Promise.resolve(true))
};

vi.mock('../../lib/real-time-collaboration', () => ({
  globalRealTimeCollaboration: mockRealTimeCollaboration
}));

describe('SocialContainer Component', () => {
  const user = userEvent.setup();

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Rendering and Initial State', () => {
    it('should render all main tabs', () => {
      render(<SocialContainer />);

      expect(screen.getByTestId('tab-trigger-communities')).toBeInTheDocument();
      expect(screen.getByTestId('tab-trigger-groups')).toBeInTheDocument();
      expect(screen.getByTestId('tab-trigger-mentorships')).toBeInTheDocument();
      expect(screen.getByTestId('tab-trigger-collaboration')).toBeInTheDocument();
      expect(screen.getByTestId('tab-trigger-challenges')).toBeInTheDocument();
    });

    it('should show communities tab by default', () => {
      render(<SocialContainer />);

      const tabsContainer = screen.getByTestId('tabs');
      expect(tabsContainer).toHaveAttribute('data-default-value', 'communities');
    });

    it('should display social metrics overview', () => {
      render(<SocialContainer />);

      // Verificar que se muestran métricas
      expect(screen.getByText('Total Usuarios')).toBeInTheDocument();
      expect(screen.getByText('1000')).toBeInTheDocument();
      expect(screen.getByText('Comunidades')).toBeInTheDocument();
      expect(screen.getByText('50')).toBeInTheDocument();
    });
  });

  describe('Communities Tab', () => {
    it('should display user communities', async () => {
      render(<SocialContainer />);

      await waitFor(() => {
        expect(screen.getByText('Estudio de Génesis')).toBeInTheDocument();
        expect(screen.getByText('2 miembros')).toBeInTheDocument();
      });
    });

    it('should allow creating new community', async () => {
      render(<SocialContainer />);

      const createButton = screen.getByText('Crear Comunidad');
      await user.click(createButton);

      await waitFor(() => {
        expect(screen.getByTestId('dialog')).toHaveAttribute('data-open', 'true');
        expect(screen.getByText('Crear Nueva Comunidad')).toBeInTheDocument();
      });
    });

    it('should handle community creation form submission', async () => {
      render(<SocialContainer />);

      // Abrir diálogo de creación
      const createButton = screen.getByText('Crear Comunidad');
      await user.click(createButton);

      // Llenar formulario
      const nameInput = screen.getByPlaceholderText('Nombre de la comunidad');
      await user.type(nameInput, 'Nueva Comunidad Test');

      const descriptionInput = screen.getByPlaceholderText('Describe tu comunidad...');
      await user.type(descriptionInput, 'Descripción de prueba');

      // Enviar formulario
      const submitButton = screen.getByText('Crear Comunidad');
      await user.click(submitButton);

      await waitFor(() => {
        expect(mockSocialEngine.createCommunity).toHaveBeenCalledWith(
          'user1',
          expect.objectContaining({
            name: 'Nueva Comunidad Test',
            description: 'Descripción de prueba'
          })
        );
      });
    });

    it('should allow searching communities', async () => {
      render(<SocialContainer />);

      const searchInput = screen.getByPlaceholderText('Buscar comunidades...');
      await user.type(searchInput, 'Génesis');

      await waitFor(() => {
        expect(mockSocialEngine.searchCommunities).toHaveBeenCalledWith('Génesis');
      });
    });
  });

  describe('Study Groups Tab', () => {
    it('should display user study groups', async () => {
      render(<SocialContainer />);

      // Cambiar a tab de grupos
      const groupsTab = screen.getByTestId('tab-trigger-groups');
      await user.click(groupsTab);

      await waitFor(() => {
        expect(screen.getByText('Grupo Jóvenes')).toBeInTheDocument();
        expect(screen.getByText('Salmos')).toBeInTheDocument();
        expect(screen.getByText('3 miembros')).toBeInTheDocument();
      });
    });

    it('should show study group schedule', async () => {
      render(<SocialContainer />);

      const groupsTab = screen.getByTestId('tab-trigger-groups');
      await user.click(groupsTab);

      await waitFor(() => {
        expect(screen.getByText('Semanal')).toBeInTheDocument();
        expect(screen.getByText('19:00')).toBeInTheDocument();
      });
    });

    it('should allow creating new study group', async () => {
      render(<SocialContainer />);

      const groupsTab = screen.getByTestId('tab-trigger-groups');
      await user.click(groupsTab);

      const createButton = screen.getByText('Crear Grupo');
      await user.click(createButton);

      await waitFor(() => {
        expect(screen.getByText('Crear Nuevo Grupo de Estudio')).toBeInTheDocument();
      });
    });
  });

  describe('Mentorships Tab', () => {
    it('should display user mentorships', async () => {
      render(<SocialContainer />);

      const mentorshipsTab = screen.getByTestId('tab-trigger-mentorships');
      await user.click(mentorshipsTab);

      await waitFor(() => {
        expect(screen.getByText('Hermenéutica Bíblica')).toBeInTheDocument();
        expect(screen.getByText('Activa')).toBeInTheDocument();
      });
    });

    it('should allow requesting mentorship', async () => {
      render(<SocialContainer />);

      const mentorshipsTab = screen.getByTestId('tab-trigger-mentorships');
      await user.click(mentorshipsTab);

      const requestButton = screen.getByText('Solicitar Mentoría');
      await user.click(requestButton);

      await waitFor(() => {
        expect(screen.getByText('Solicitar Mentoría')).toBeInTheDocument();
      });
    });
  });

  describe('Collaboration Tab', () => {
    it('should display active collaborations', async () => {
      render(<SocialContainer />);

      const collaborationTab = screen.getByTestId('tab-trigger-collaboration');
      await user.click(collaborationTab);

      await waitFor(() => {
        expect(screen.getByText('Annotation on Genesis 1:1')).toBeInTheDocument();
      });
    });

    it('should show online users', async () => {
      render(<SocialContainer />);

      const collaborationTab = screen.getByTestId('tab-trigger-collaboration');
      await user.click(collaborationTab);

      await waitFor(() => {
        expect(screen.getByText('Usuarios en Línea')).toBeInTheDocument();
        expect(screen.getByText('1 usuario conectado')).toBeInTheDocument();
      });
    });

    it('should allow starting new collaboration session', async () => {
      render(<SocialContainer />);

      const collaborationTab = screen.getByTestId('tab-trigger-collaboration');
      await user.click(collaborationTab);

      const startButton = screen.getByText('Iniciar Sesión');
      await user.click(startButton);

      await waitFor(() => {
        expect(mockRealTimeCollaboration.startCollaborativeSession).toHaveBeenCalled();
      });
    });
  });

  describe('Challenges Tab', () => {
    it('should display active challenges', async () => {
      render(<SocialContainer />);

      const challengesTab = screen.getByTestId('tab-trigger-challenges');
      await user.click(challengesTab);

      await waitFor(() => {
        expect(screen.getByText('Leer Salmos en 30 días')).toBeInTheDocument();
        expect(screen.getByText('2 participantes')).toBeInTheDocument();
      });
    });

    it('should show challenge progress', async () => {
      render(<SocialContainer />);

      const challengesTab = screen.getByTestId('tab-trigger-challenges');
      await user.click(challengesTab);

      await waitFor(() => {
        const progressBar = screen.getByTestId('progress');
        expect(progressBar).toHaveAttribute('data-value', '60');
      });
    });

    it('should allow creating new challenge', async () => {
      render(<SocialContainer />);

      const challengesTab = screen.getByTestId('tab-trigger-challenges');
      await user.click(challengesTab);

      const createButton = screen.getByText('Crear Desafío');
      await user.click(createButton);

      await waitFor(() => {
        expect(screen.getByText('Crear Nuevo Desafío')).toBeInTheDocument();
      });
    });
  });

  describe('Responsive Behavior', () => {
    it('should adapt to mobile viewport', () => {
      // Mock mobile viewport
      Object.defineProperty(window, 'innerWidth', {
        writable: true,
        configurable: true,
        value: 375,
      });
      
      render(<SocialContainer />);

      // Verificar que el componente se renderiza en móvil
      expect(screen.getByTestId('tabs')).toBeInTheDocument();
    });

    it('should handle tablet viewport correctly', () => {
      Object.defineProperty(window, 'innerWidth', {
        writable: true,
        configurable: true,
        value: 768,
      });
      
      render(<SocialContainer />);

      // Verificar renderizado en tablet
      expect(screen.getByTestId('tabs')).toBeInTheDocument();
    });
  });

  describe('Accessibility', () => {
    it('should have proper ARIA labels', () => {
      render(<SocialContainer />);

      const tabsList = screen.getByTestId('tabs-list');
      expect(tabsList).toBeInTheDocument();

      // Verificar que los botones tienen texto descriptivo
      expect(screen.getByText('Comunidades')).toBeInTheDocument();
      expect(screen.getByText('Grupos de Estudio')).toBeInTheDocument();
      expect(screen.getByText('Mentorías')).toBeInTheDocument();
    });

    it('should support keyboard navigation', async () => {
      render(<SocialContainer />);

      const firstTab = screen.getByTestId('tab-trigger-communities');
      const secondTab = screen.getByTestId('tab-trigger-groups');

      // Simular navegación con Tab
      firstTab.focus();
      expect(document.activeElement).toBe(firstTab);

      // Simular flecha derecha para moverse al siguiente tab
      fireEvent.keyDown(firstTab, { key: 'ArrowRight' });
      expect(document.activeElement).toBe(secondTab);
    });

    it('should have proper heading hierarchy', () => {
      render(<SocialContainer />);

      // Verificar estructura de headings
      const headings = screen.getAllByRole('heading');
      expect(headings.length).toBeGreaterThan(0);
    });
  });

  describe('Performance', () => {
    it('should not cause memory leaks', () => {
      const { unmount } = render(<SocialContainer />);
      
      // Simular unmount del componente
      unmount();
      
      // Verificar que no hay referencias colgantes
      expect(mockSocialEngine.getUserCommunities).toHaveBeenCalled();
    });

    it('should handle rapid tab switching', async () => {
      render(<SocialContainer />);

      const tabs = [
        'communities',
        'groups', 
        'mentorships',
        'collaboration',
        'challenges'
      ];

      // Cambiar rápidamente entre tabs
      for (const tab of tabs) {
        const tabElement = screen.getByTestId(`tab-trigger-${tab}`);
        await user.click(tabElement);
      }

      // Verificar que no hay errores
      expect(screen.getByTestId('tabs')).toBeInTheDocument();
    });
  });

  describe('Error Handling', () => {
    it('should handle API errors gracefully', async () => {
      // Mock error en social engine
      mockSocialEngine.getUserCommunities.mockImplementation(() => {
        throw new Error('API Error');
      });

      render(<SocialContainer />);

      // El componente debería renderizarse sin crashear
      expect(screen.getByTestId('tabs')).toBeInTheDocument();
    });

    it('should handle empty data states', () => {
      // Mock datos vacíos
      mockSocialEngine.getUserCommunities.mockReturnValue([]);
      mockSocialEngine.getUserStudyGroups.mockReturnValue([]);
      mockSocialEngine.getUserMentorships.mockReturnValue([]);

      render(<SocialContainer />);

      // Verificar que se muestran estados vacíos apropiados
      expect(screen.getByTestId('tabs')).toBeInTheDocument();
    });

    it('should handle network disconnection', async () => {
      // Simular desconexión de red
      Object.defineProperty(navigator, 'onLine', {
        writable: true,
        value: false,
      });

      render(<SocialContainer />);

      // El componente debería manejar el estado offline
      expect(screen.getByTestId('tabs')).toBeInTheDocument();
    });
  });

  describe('Integration with Social Engine', () => {
    it('should properly initialize with social engine data', async () => {
      render(<SocialContainer />);

      await waitFor(() => {
        expect(mockSocialEngine.getUserCommunities).toHaveBeenCalledWith('user1');
        expect(mockSocialEngine.getUserStudyGroups).toHaveBeenCalledWith('user1');
        expect(mockSocialEngine.getUserMentorships).toHaveBeenCalledWith('user1');
      });
    });

    it('should sync state with global social engine', async () => {
      render(<SocialContainer />);

      // Simular cambio en social engine
      mockSocialEngine.getUserCommunities.mockReturnValue([
        {
          id: 'new-comm',
          name: 'Nueva Comunidad',
          description: 'Descripción nueva',
          category: 'Prayer',
          members: ['user1'],
          stats: { totalMembers: 1, engagementRate: 1.0 }
        }
      ]);

      // Re-render para simular actualización
      const { rerender } = render(<SocialContainer />);
      rerender(<SocialContainer />);

      await waitFor(() => {
        expect(screen.getByText('Nueva Comunidad')).toBeInTheDocument();
      });
    });
  });
});
