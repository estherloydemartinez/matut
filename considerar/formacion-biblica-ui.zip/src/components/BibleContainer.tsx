import { useState, useEffect, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  ChevronLeft, 
  ChevronRight, 
  BookOpen, 
  Search,
  Bookmark,
  Share2,
  Copy,
  Type,
  ZoomIn,
  ZoomOut
} from 'lucide-react'
import { useData } from '../contexts/DataContext'
import { useAppState } from '../contexts/AppStateContext'
import { legacyBridge } from '../lib/legacy-integration'
import toast from 'react-hot-toast'

const BOOKS_OF_BIBLE = [
  // Old Testament
  { name: 'Génesis', chapters: 50, testament: 'old' },
  { name: 'Éxodo', chapters: 40, testament: 'old' },
  { name: 'Levítico', chapters: 27, testament: 'old' },
  { name: 'Números', chapters: 36, testament: 'old' },
  { name: 'Deuteronomio', chapters: 34, testament: 'old' },
  { name: 'Josué', chapters: 24, testament: 'old' },
  { name: 'Jueces', chapters: 21, testament: 'old' },
  { name: 'Rut', chapters: 4, testament: 'old' },
  { name: '1 Samuel', chapters: 31, testament: 'old' },
  { name: '2 Samuel', chapters: 24, testament: 'old' },
  { name: '1 Reyes', chapters: 22, testament: 'old' },
  { name: '2 Reyes', chapters: 25, testament: 'old' },
  { name: '1 Crónicas', chapters: 29, testament: 'old' },
  { name: '2 Crónicas', chapters: 36, testament: 'old' },
  { name: 'Esdras', chapters: 10, testament: 'old' },
  { name: 'Nehemías', chapters: 13, testament: 'old' },
  { name: 'Ester', chapters: 10, testament: 'old' },
  { name: 'Job', chapters: 42, testament: 'old' },
  { name: 'Salmos', chapters: 150, testament: 'old' },
  { name: 'Proverbios', chapters: 31, testament: 'old' },
  { name: 'Eclesiastés', chapters: 12, testament: 'old' },
  { name: 'Cantares', chapters: 8, testament: 'old' },
  { name: 'Isaías', chapters: 66, testament: 'old' },
  { name: 'Jeremías', chapters: 52, testament: 'old' },
  { name: 'Lamentaciones', chapters: 5, testament: 'old' },
  { name: 'Ezequiel', chapters: 48, testament: 'old' },
  { name: 'Daniel', chapters: 12, testament: 'old' },
  { name: 'Oseas', chapters: 14, testament: 'old' },
  { name: 'Joel', chapters: 3, testament: 'old' },
  { name: 'Amós', chapters: 9, testament: 'old' },
  { name: 'Abdías', chapters: 1, testament: 'old' },
  { name: 'Jonás', chapters: 4, testament: 'old' },
  { name: 'Miqueas', chapters: 7, testament: 'old' },
  { name: 'Nahúm', chapters: 3, testament: 'old' },
  { name: 'Habacuc', chapters: 3, testament: 'old' },
  { name: 'Sofonías', chapters: 3, testament: 'old' },
  { name: 'Hageo', chapters: 2, testament: 'old' },
  { name: 'Zacarías', chapters: 14, testament: 'old' },
  { name: 'Malaquías', chapters: 4, testament: 'old' },
  
  // New Testament
  { name: 'Mateo', chapters: 28, testament: 'new' },
  { name: 'Marcos', chapters: 16, testament: 'new' },
  { name: 'Lucas', chapters: 24, testament: 'new' },
  { name: 'Juan', chapters: 21, testament: 'new' },
  { name: 'Hechos', chapters: 28, testament: 'new' },
  { name: 'Romanos', chapters: 16, testament: 'new' },
  { name: '1 Corintios', chapters: 16, testament: 'new' },
  { name: '2 Corintios', chapters: 13, testament: 'new' },
  { name: 'Gálatas', chapters: 6, testament: 'new' },
  { name: 'Efesios', chapters: 6, testament: 'new' },
  { name: 'Filipenses', chapters: 4, testament: 'new' },
  { name: 'Colosenses', chapters: 4, testament: 'new' },
  { name: '1 Tesalonicenses', chapters: 5, testament: 'new' },
  { name: '2 Tesalonicenses', chapters: 3, testament: 'new' },
  { name: '1 Timoteo', chapters: 6, testament: 'new' },
  { name: '2 Timoteo', chapters: 4, testament: 'new' },
  { name: 'Tito', chapters: 3, testament: 'new' },
  { name: 'Filemón', chapters: 1, testament: 'new' },
  { name: 'Hebreos', chapters: 13, testament: 'new' },
  { name: 'Santiago', chapters: 5, testament: 'new' },
  { name: '1 Pedro', chapters: 5, testament: 'new' },
  { name: '2 Pedro', chapters: 3, testament: 'new' },
  { name: '1 Juan', chapters: 5, testament: 'new' },
  { name: '2 Juan', chapters: 1, testament: 'new' },
  { name: '3 Juan', chapters: 1, testament: 'new' },
  { name: 'Judas', chapters: 1, testament: 'new' },
  { name: 'Apocalipsis', chapters: 22, testament: 'new' }
]

export default function BibleContainer() {
  const { 
    currentBook, 
    setCurrentBook, 
    currentChapter, 
    setCurrentChapter,
    selectedVerses,
    setSelectedVerses,
    fontSize,
    addNotification
  } = useAppState()
  
  const { getChapter, isBibleLoading, bibleError } = useData()
  
  const [searchTerm, setSearchTerm] = useState('')
  const [globalSearchTerm, setGlobalSearchTerm] = useState('')
  const [globalSearchResults, setGlobalSearchResults] = useState<any[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [showGlobalSearch, setShowGlobalSearch] = useState(false)
  const [legacyModuleStatus, setLegacyModuleStatus] = useState({ initialized: false })
  const [bookmarks, setBookmarks] = useState<string[]>(() => {
    const saved = localStorage.getItem('formacion-biblica-bookmarks')
    return saved ? JSON.parse(saved) : []
  })

  const currentBookData = BOOKS_OF_BIBLE.find(book => book.name === currentBook)
  const chapterData = getChapter(currentBook, currentChapter)

  // Initialize legacy bridge
  useEffect(() => {
    const initializeLegacy = async () => {
      try {
        await legacyBridge.waitForInitialization()
        const status = legacyBridge.getModulesStatus()
        setLegacyModuleStatus(status)
        console.log('Legacy bridge initialized:', status)
      } catch (error) {
        console.error('Failed to initialize legacy bridge:', error)
      }
    }
    initializeLegacy()
  }, [])

  // Debug logging
  useEffect(() => {
    console.log('BibleContainer Debug:', {
      currentBook,
      currentChapter,
      chapterData,
      hasChapterData: !!chapterData,
      chapterDataKeys: chapterData ? Object.keys(chapterData) : null
    })
  }, [currentBook, currentChapter, chapterData])

  // Get verses as array for easier handling
  const verses = useMemo(() => {
    if (!chapterData) {
      console.log('No chapter data available for:', currentBook, currentChapter)
      return []
    }
    const versesArray = Object.entries(chapterData).map(([num, text]) => ({
      number: parseInt(num),
      text: text as string
    }))
    console.log('Verses processed:', versesArray.length, 'verses')
    return versesArray
  }, [chapterData, currentBook, currentChapter])

  // Filter verses by search term
  const filteredVerses = useMemo(() => {
    if (!searchTerm) return verses
    return verses.filter(verse => 
      verse.text.toLowerCase().includes(searchTerm.toLowerCase())
    )
  }, [verses, searchTerm])

  // Navigation functions
  const goToPreviousChapter = () => {
    if (currentChapter > 1) {
      setCurrentChapter(currentChapter - 1)
    } else {
      // Go to previous book's last chapter
      const currentBookIndex = BOOKS_OF_BIBLE.findIndex(book => book.name === currentBook)
      if (currentBookIndex > 0) {
        const previousBook = BOOKS_OF_BIBLE[currentBookIndex - 1]
        setCurrentBook(previousBook.name)
        setCurrentChapter(previousBook.chapters)
      }
    }
    setSelectedVerses([])
  }

  const goToNextChapter = () => {
    const maxChapters = currentBookData?.chapters || 1
    if (currentChapter < maxChapters) {
      setCurrentChapter(currentChapter + 1)
    } else {
      // Go to next book's first chapter
      const currentBookIndex = BOOKS_OF_BIBLE.findIndex(book => book.name === currentBook)
      if (currentBookIndex < BOOKS_OF_BIBLE.length - 1) {
        const nextBook = BOOKS_OF_BIBLE[currentBookIndex + 1]
        setCurrentBook(nextBook.name)
        setCurrentChapter(1)
      }
    }
    setSelectedVerses([])
  }

  // Verse selection functions
  const toggleVerseSelection = (verseNumber: number) => {
    setSelectedVerses((prev: number[]) => {
      if (prev.includes(verseNumber)) {
        return prev.filter(v => v !== verseNumber)
      } else {
        return [...prev, verseNumber].sort((a, b) => a - b)
      }
    })
  }

  // Bookmark functions
  const toggleBookmark = () => {
    const bookmarkKey = `${currentBook} ${currentChapter}`
    setBookmarks(prev => {
      const updated = prev.includes(bookmarkKey)
        ? prev.filter(b => b !== bookmarkKey)
        : [...prev, bookmarkKey]
      
      localStorage.setItem('formacion-biblica-bookmarks', JSON.stringify(updated))
      
      addNotification({
        type: prev.includes(bookmarkKey) ? 'info' : 'success',
        message: prev.includes(bookmarkKey) 
          ? 'Marcador eliminado' 
          : 'Marcador agregado'
      })
      
      return updated
    })
  }

  // Global search using legacy bridge
  const performGlobalSearch = async () => {
    if (!globalSearchTerm.trim()) {
      toast.error('Ingresa un término de búsqueda')
      return
    }

    if (!legacyModuleStatus.initialized || !legacyModuleStatus.bible) {
      toast.error('Módulo bíblico no disponible')
      return
    }

    setIsSearching(true)
    try {
      const results = await legacyBridge.searchBibleText(globalSearchTerm)
      setGlobalSearchResults(results)
      setShowGlobalSearch(true)
      
      addNotification({
        type: 'success',
        message: `Se encontraron ${results.length} resultados`
      })
    } catch (error) {
      console.error('Search error:', error)
      toast.error('Error al realizar la búsqueda')
    } finally {
      setIsSearching(false)
    }
  }

  // Get chapter from legacy bridge
  const getLegacyChapter = async (book: string, chapter: number) => {
    if (!legacyModuleStatus.bible) return null
    
    try {
      return await legacyBridge.getBibleChapter(book, chapter)
    } catch (error) {
      console.error('Error getting legacy chapter:', error)
      return null
    }
  }

  // Get verse from legacy bridge
  const getLegacyVerse = async (book: string, chapter: number, verse: number) => {
    if (!legacyModuleStatus.bible) return null
    
    try {
      return await legacyBridge.getBibleVerse(book, chapter, verse)
    } catch (error) {
      console.error('Error getting legacy verse:', error)
      return null
    }
  }

  // Get Bible statistics
  const getBibleStats = () => {
    if (!legacyModuleStatus.bible) return null
    
    try {
      return legacyBridge.getBibleStats()
    } catch (error) {
      console.error('Error getting Bible stats:', error)
      return null
    }
  }

  // Copy functions
  const copySelectedVerses = () => {
    if (selectedVerses.length === 0) {
      toast.error('Selecciona al menos un versículo')
      return
    }

    const selectedText = selectedVerses
      .map(verseNum => {
        const verse = verses.find(v => v.number === verseNum)
        return verse ? `${currentBook} ${currentChapter}:${verseNum} - ${verse.text}` : ''
      })
      .filter(Boolean)
      .join('\n')

    navigator.clipboard.writeText(selectedText).then(() => {
      toast.success('Versículos copiados al portapapeles')
    })
  }

  const shareSelectedVerses = () => {
    if (selectedVerses.length === 0) {
      toast.error('Selecciona al menos un versículo')
      return
    }

    const selectedText = selectedVerses
      .map(verseNum => {
        const verse = verses.find(v => v.number === verseNum)
        return verse ? `${currentBook} ${currentChapter}:${verseNum} - ${verse.text}` : ''
      })
      .filter(Boolean)
      .join('\n')

    if (navigator.share) {
      navigator.share({
        title: `${currentBook} ${currentChapter}`,
        text: selectedText
      })
    } else {
      copySelectedVerses()
    }
  }

  if (isBibleLoading) {
    return (
      <div className="discord-card p-8 rounded-lg text-center">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-discord-modifier-hover rounded w-1/3 mx-auto"></div>
          <div className="space-y-2">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="h-4 bg-discord-modifier-hover rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (bibleError) {
    return (
      <div className="discord-card p-8 rounded-lg text-center text-discord-text-danger">
        <p>Error al cargar la Biblia: {bibleError}</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header with navigation and controls */}
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="discord-card p-6 rounded-lg"
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Book and chapter selector */}
          <div className="flex items-center space-x-4">
            <select
              value={currentBook}
              onChange={(e) => {
                setCurrentBook(e.target.value)
                setCurrentChapter(1)
                setSelectedVerses([])
              }}
              className="discord-input text-lg font-semibold bg-discord-input"
            >
              <optgroup label="Antiguo Testamento">
                {BOOKS_OF_BIBLE.filter(book => book.testament === 'old').map(book => (
                  <option key={book.name} value={book.name}>{book.name}</option>
                ))}
              </optgroup>
              <optgroup label="Nuevo Testamento">
                {BOOKS_OF_BIBLE.filter(book => book.testament === 'new').map(book => (
                  <option key={book.name} value={book.name}>{book.name}</option>
                ))}
              </optgroup>
            </select>

            <div className="flex items-center space-x-2">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={goToPreviousChapter}
                className="p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors"
                disabled={currentBook === 'Génesis' && currentChapter === 1}
              >
                <ChevronLeft className="w-5 h-5" />
              </motion.button>

              <select
                value={currentChapter}
                onChange={(e) => {
                  setCurrentChapter(parseInt(e.target.value))
                  setSelectedVerses([])
                }}
                className="discord-input font-semibold min-w-20 text-center"
              >
                {currentBookData && [...Array(currentBookData.chapters)].map((_, i) => (
                  <option key={i + 1} value={i + 1}>Capítulo {i + 1}</option>
                ))}
              </select>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={goToNextChapter}
                className="p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors"
                disabled={currentBook === 'Apocalipsis' && currentChapter === 22}
              >
                <ChevronRight className="w-5 h-5" />
              </motion.button>
            </div>
          </div>

          {/* Search and actions */}
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-discord-text-muted" />
              <input
                type="text"
                placeholder="Buscar en el capítulo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="discord-input pl-10 min-w-64"
              />
            </div>

            {/* Global search */}
            <div className="relative">
              <input
                type="text"
                placeholder="Buscar en toda la Biblia..."
                value={globalSearchTerm}
                onChange={(e) => setGlobalSearchTerm(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && performGlobalSearch()}
                className="discord-input pl-3 min-w-64"
                data-testid="global-search-input"
              />
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={performGlobalSearch}
              disabled={isSearching || !legacyModuleStatus.bible}
              className="p-2 rounded-lg bg-discord-primary hover:bg-discord-primary-dark transition-colors disabled:opacity-50"
              title="Buscar en toda la Biblia"
              data-testid="search-button"
            >
              {isSearching ? (
                <div className="w-5 h-5 animate-spin border-2 border-white border-t-transparent rounded-full" />
              ) : (
                <Search className="w-5 h-5 text-white" />
              )}
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleBookmark}
              className={`p-2 rounded-lg transition-colors ${
                bookmarks.includes(`${currentBook} ${currentChapter}`)
                  ? 'bg-discord-primary text-white'
                  : 'bg-discord-input hover:bg-discord-modifier-hover'
              }`}
              title="Agregar marcador"
            >
              <Bookmark className="w-5 h-5" />
            </motion.button>

            {selectedVerses.length > 0 && (
              <>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={copySelectedVerses}
                  className="p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors"
                  title="Copiar versículos seleccionados"
                >
                  <Copy className="w-5 h-5" />
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={shareSelectedVerses}
                  className="p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors"
                  title="Compartir versículos"
                >
                  <Share2 className="w-5 h-5" />
                </motion.button>
              </>
            )}
          </div>
        </div>

        {/* Selected verses indicator */}
        <AnimatePresence>
          {selectedVerses.length > 0 && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mt-4 p-3 bg-discord-modifier-selected rounded-lg"
            >
              <p className="text-sm text-discord-text-secondary">
                {selectedVerses.length} versículo{selectedVerses.length !== 1 ? 's' : ''} seleccionado{selectedVerses.length !== 1 ? 's' : ''}: {selectedVerses.join(', ')}
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Legacy module status indicator */}
        {legacyModuleStatus.initialized && (
          <div className="mt-4 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
            <p className="text-sm text-green-400">
              ✅ Módulos optimizados cargados - Búsqueda avanzada disponible
            </p>
          </div>
        )}
      </motion.div>

      {/* Global search results */}
      <AnimatePresence>
        {showGlobalSearch && globalSearchResults.length > 0 && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            className="discord-card p-6 rounded-lg"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-discord-text-primary">
                Resultados de búsqueda: "{globalSearchTerm}"
              </h3>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowGlobalSearch(false)}
                className="p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors"
              >
                ✕
              </motion.button>
            </div>

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {globalSearchResults.map((result, index) => (
                <motion.div
                  key={`${result.libro}-${result.capitulo}-${result.versiculo || index}`}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => {
                    setCurrentBook(result.libro)
                    setCurrentChapter(result.capitulo)
                    setShowGlobalSearch(false)
                    if (result.versiculo) {
                      setSelectedVerses([result.versiculo])
                    }
                  }}
                  className="p-4 rounded-lg bg-discord-modifier-hover hover:bg-discord-modifier-selected cursor-pointer transition-colors"
                >
                  <div className="flex items-start space-x-3">
                    <span className="text-sm font-semibold text-discord-primary min-w-fit">
                      {result.libro} {result.capitulo}{result.versiculo ? `:${result.versiculo}` : ''}
                    </span>
                    <p className="text-discord-text-primary text-sm">
                      {result.texto || result.contenido}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-4 text-center">
              <p className="text-sm text-discord-text-muted">
                {globalSearchResults.length} resultado{globalSearchResults.length !== 1 ? 's' : ''} encontrado{globalSearchResults.length !== 1 ? 's' : ''}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bible content */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="discord-card p-6 rounded-lg"
      >
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-discord-text-primary mb-2">
            {currentBook} {currentChapter}
          </h1>
          <p className="text-discord-text-secondary">
            {filteredVerses.length} versículo{filteredVerses.length !== 1 ? 's' : ''}
            {searchTerm && ` (filtrado por "${searchTerm}")`}
          </p>
        </div>

        <div className={`space-y-4 ${fontSize === 'small' ? 'text-sm' : fontSize === 'large' ? 'text-lg' : 'text-base'}`}>
          <AnimatePresence>
            {filteredVerses.map((verse, index) => (
              <motion.div
                key={verse.number}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => toggleVerseSelection(verse.number)}
                className={`
                  p-3 rounded-lg cursor-pointer transition-all duration-fast group
                  ${selectedVerses.includes(verse.number)
                    ? 'bg-discord-modifier-selected border-l-4 border-discord-primary'
                    : 'hover:bg-discord-modifier-hover'
                  }
                `}
              >
                <div className="flex items-start space-x-3">
                  <motion.span
                    whileHover={{ scale: 1.1 }}
                    className={`
                      inline-flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold transition-colors
                      ${selectedVerses.includes(verse.number)
                        ? 'bg-discord-primary text-white'
                        : 'bg-discord-modifier-hover text-discord-text-secondary group-hover:bg-discord-primary group-hover:text-white'
                      }
                    `}
                  >
                    {verse.number}
                  </motion.span>
                  <p className="flex-1 text-discord-text-primary leading-relaxed">
                    {verse.text}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredVerses.length === 0 && searchTerm && (
          <div className="text-center py-8 text-discord-text-muted">
            <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No se encontraron versículos que contengan "{searchTerm}"</p>
          </div>
        )}
      </motion.div>
    </div>
  )
}
