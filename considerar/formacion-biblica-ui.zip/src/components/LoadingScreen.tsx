import { motion } from 'framer-motion'
import { BookOpen, Cross, Heart } from 'lucide-react'

export default function LoadingScreen() {
  return (
    <div className="min-h-screen bg-discord-tertiary flex items-center justify-center">
      <div className="text-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="relative mx-auto w-24 h-24 mb-6">
            {/* Cross icon with pulse animation */}
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                opacity: [0.7, 1, 0.7]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute inset-0 flex items-center justify-center"
            >
              <Cross className="w-16 h-16 text-discord-primary" />
            </motion.div>
            
            {/* Book icon with rotation */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ 
                duration: 8,
                repeat: Infinity,
                ease: "linear"
              }}
              className="absolute top-0 right-0"
            >
              <BookOpen className="w-6 h-6 text-discord-text-secondary" />
            </motion.div>
            
            {/* Heart icon with bounce */}
            <motion.div
              animate={{ y: [-2, 2, -2] }}
              transition={{ 
                duration: 1.5,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute bottom-0 left-0"
            >
              <Heart className="w-6 h-6 text-red-400 fill-current" />
            </motion.div>
          </div>
          
          <motion.h1
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="text-3xl font-bold text-discord-text-primary mb-2"
          >
            Formación Bíblica Avanzada
          </motion.h1>
          
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="text-discord-text-secondary mb-8"
          >
            Preparando tu experiencia de estudio...
          </motion.p>
        </motion.div>
        
        {/* Loading progress bar */}
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: "100%" }}
          transition={{ duration: 2, ease: "easeInOut" }}
          className="w-64 mx-auto mb-4"
        >
          <div className="h-1 bg-discord-quaternary rounded-full overflow-hidden">
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: "100%" }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "linear"
              }}
              className="h-full w-1/3 bg-gradient-to-r from-transparent via-discord-primary to-transparent"
            />
          </div>
        </motion.div>
        
        {/* Loading dots */}
        <div className="flex justify-center space-x-2">
          {[0, 1, 2].map((index) => (
            <motion.div
              key={index}
              initial={{ scale: 0.8, opacity: 0.3 }}
              animate={{ 
                scale: [0.8, 1.2, 0.8],
                opacity: [0.3, 1, 0.3]
              }}
              transition={{
                duration: 1,
                repeat: Infinity,
                delay: index * 0.2,
                ease: "easeInOut"
              }}
              className="w-2 h-2 bg-discord-primary rounded-full"
            />
          ))}
        </div>
        
        {/* Inspirational text */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="mt-8 text-discord-text-muted text-sm italic"
        >
          <p>"Lámpara es a mis pies tu palabra, y lumbrera a mi camino."</p>
          <p className="mt-1 text-xs">- Salmos 119:105</p>
        </motion.div>
      </div>
    </div>
  )
}
