import { motion } from 'framer-motion'
import { ChevronRight, Home } from 'lucide-react'
import { useAppState } from '../contexts/AppStateContext'
import { ActiveSection } from '../App'

interface BreadcrumbItem {
  label: string
  section?: ActiveSection
  isActive?: boolean
}

const sectionLabels: Record<ActiveSection, string> = {
  biblia: 'Biblia',
  estudio: 'Estudio',
  filtros: 'Filtros Analíticos', 
  social: 'Comunidad',
  recursos: 'Recursos',
  dashboard: 'Dashboard'
}

export default function Breadcrumbs() {
  const { 
    activeSection, 
    setActiveSection, 
    currentBook, 
    currentChapter,
    isStudyMode 
  } = useAppState()

  const buildBreadcrumbs = (): BreadcrumbItem[] => {
    const breadcrumbs: BreadcrumbItem[] = [
      { label: 'Inicio', section: 'dashboard' }
    ]

    // Add current section
    breadcrumbs.push({
      label: sectionLabels[activeSection],
      section: activeSection
    })

    // Add specific breadcrumbs based on context
    if (activeSection === 'biblia' && currentBook) {
      breadcrumbs.push({
        label: currentBook,
        isActive: true
      })
      
      if (currentChapter) {
        breadcrumbs.push({
          label: `Capítulo ${currentChapter}`,
          isActive: true
        })
      }
    }

    if (activeSection === 'estudio' && isStudyMode) {
      breadcrumbs.push({
        label: 'Modo Activo',
        isActive: true
      })
    }

    return breadcrumbs
  }

  const breadcrumbs = buildBreadcrumbs()

  const handleBreadcrumbClick = (item: BreadcrumbItem) => {
    if (item.section && !item.isActive) {
      setActiveSection(item.section)
    }
  }

  return (
    <motion.nav
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center space-x-2 px-4 py-3 bg-discord-secondary/50 rounded-lg mb-4 text-sm"
      aria-label="Breadcrumb"
    >
      <motion.div
        whileHover={{ scale: 1.1 }}
        className="p-1"
      >
        <Home className="w-4 h-4 text-discord-text-muted" />
      </motion.div>

      {breadcrumbs.map((item, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.1 }}
          className="flex items-center space-x-2"
        >
          {/* Separator */}
          {index > 0 && (
            <ChevronRight className="w-4 h-4 text-discord-text-muted" />
          )}

          {/* Breadcrumb item */}
          {item.section && !item.isActive ? (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleBreadcrumbClick(item)}
              className="text-discord-text-secondary hover:text-discord-text-primary transition-colors duration-fast underline-offset-4 hover:underline"
            >
              {item.label}
            </motion.button>
          ) : (
            <span
              className={`${
                item.isActive
                  ? 'text-discord-text-primary font-medium'
                  : 'text-discord-text-secondary'
              }`}
            >
              {item.label}
            </span>
          )}
        </motion.div>
      ))}

      {/* Current section indicator */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.3 }}
        className="ml-auto"
      >
        <div className="flex items-center space-x-2 px-3 py-1 bg-discord-primary/20 text-discord-primary rounded-full text-xs">
          <div className="w-2 h-2 bg-discord-primary rounded-full animate-pulse"></div>
          <span className="font-medium">Activo</span>
        </div>
      </motion.div>
    </motion.nav>
  )
}
