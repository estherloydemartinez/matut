import { motion } from 'framer-motion'
import { 
  Search, 
  Settings, 
  Moon, 
  Sun, 
  Bell, 
  User,
  Menu,
  X
} from 'lucide-react'
import { useState } from 'react'
import { useTheme } from '../contexts/ThemeContext'
import { useAppState } from '../contexts/AppStateContext'

interface HeaderProps {
  compact?: boolean
}

export default function Header({ compact = false }: HeaderProps) {
  const { theme, toggleTheme } = useTheme()
  const { 
    setIsSearchModalOpen, 
    setIsSettingsModalOpen, 
    notifications,
    activeSection,
    setActiveSection 
  } = useAppState()
  
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const headerVariants = {
    initial: { y: -20, opacity: 0 },
    animate: { y: 0, opacity: 1 },
    transition: { duration: 0.3 }
  }

  const unreadNotifications = notifications.filter(n => n.type !== 'info').length

  if (compact) {
    return (
      <motion.header 
        {...headerVariants}
        className="mb-6"
      >
        <div className="flex items-center justify-between">
          <motion.h1 
            className="text-xl font-bold text-discord-text-primary"
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            Formación Bíblica
          </motion.h1>
          
          <div className="flex items-center space-x-2">
            {/* Search button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsSearchModalOpen(true)}
              className="p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary hover:text-discord-text-primary"
              title="Buscar (Ctrl+K)"
            >
              <Search className="w-4 h-4" />
            </motion.button>

            {/* Theme toggle */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary hover:text-discord-text-primary"
              title={`Cambiar a tema ${theme === 'dark' ? 'claro' : 'oscuro'}`}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </motion.button>

            {/* Settings */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsSettingsModalOpen(true)}
              className="p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary hover:text-discord-text-primary"
              title="Configuración (Ctrl+,)"
            >
              <Settings className="w-4 h-4" />
            </motion.button>
          </div>
        </div>
      </motion.header>
    )
  }

  return (
    <motion.header 
      {...headerVariants}
      className="mb-6"
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        {/* Logo and title */}
        <div className="flex items-center justify-between w-full md:w-auto">
          <motion.div 
            className="flex items-center space-x-3"
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
              <motion.div
                animate={{ rotate: [0, 5, -5, 0] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
              >
                📖
              </motion.div>
            </div>
            
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-discord-text-primary">
                Formación Bíblica Avanzada
              </h1>
              <p className="text-sm text-discord-text-muted hidden md:block">
                Sistema integral de estudio bíblico
              </p>
            </div>
          </motion.div>

          {/* Mobile menu button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary"
          >
            {isMobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </motion.button>
        </div>

        {/* Desktop actions */}
        <div className="hidden md:flex items-center space-x-3">
          {/* Quick search */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setIsSearchModalOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-discord-input rounded-lg hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary group"
          >
            <Search className="w-4 h-4" />
            <span className="text-sm">Buscar...</span>
            <div className="text-xs bg-discord-modifier-hover px-2 py-1 rounded group-hover:bg-discord-modifier-active transition-colors">
              ⌘K
            </div>
          </motion.button>

          {/* Notifications */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative p-3 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary hover:text-discord-text-primary"
            title="Notificaciones"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifications > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-xs text-white font-medium"
              >
                {unreadNotifications > 9 ? '9+' : unreadNotifications}
              </motion.div>
            )}
          </motion.button>

          {/* Theme toggle */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleTheme}
            className="p-3 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary hover:text-discord-text-primary"
            title={`Cambiar a tema ${theme === 'dark' ? 'claro' : 'oscuro'}`}
          >
            <motion.div
              initial={{ rotate: 0 }}
              animate={{ rotate: theme === 'dark' ? 0 : 180 }}
              transition={{ duration: 0.3 }}
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5" />
              ) : (
                <Moon className="w-5 h-5" />
              )}
            </motion.div>
          </motion.button>

          {/* Settings */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsSettingsModalOpen(true)}
            className="p-3 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary hover:text-discord-text-primary"
            title="Configuración (Ctrl+,)"
          >
            <motion.div
              whileHover={{ rotate: 90 }}
              transition={{ duration: 0.2 }}
            >
              <Settings className="w-5 h-5" />
            </motion.div>
          </motion.button>

          {/* User profile */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="p-3 rounded-lg bg-discord-input hover:bg-discord-modifier-hover transition-colors duration-fast text-discord-text-secondary hover:text-discord-text-primary"
            title="Perfil de usuario"
          >
            <User className="w-5 h-5" />
          </motion.button>
        </div>

        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="md:hidden w-full mt-4 p-4 bg-discord-secondary rounded-lg"
          >
            <div className="space-y-3">
              <button
                onClick={() => {
                  setIsSearchModalOpen(true)
                  setIsMobileMenuOpen(false)
                }}
                className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-discord-modifier-hover transition-colors text-discord-text-secondary"
              >
                <Search className="w-5 h-5" />
                <span>Buscar</span>
              </button>

              <button
                onClick={() => {
                  toggleTheme()
                  setIsMobileMenuOpen(false)
                }}
                className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-discord-modifier-hover transition-colors text-discord-text-secondary"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5" />
                ) : (
                  <Moon className="w-5 h-5" />
                )}
                <span>Cambiar tema</span>
              </button>

              <button
                onClick={() => {
                  setIsSettingsModalOpen(true)
                  setIsMobileMenuOpen(false)
                }}
                className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-discord-modifier-hover transition-colors text-discord-text-secondary"
              >
                <Settings className="w-5 h-5" />
                <span>Configuración</span>
              </button>
            </div>
          </motion.div>
        )}

        {/* Progress indicator for current section */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.3 }}
          className="h-1 bg-discord-primary rounded-full w-full md:hidden"
        />
      </div>
    </motion.header>
  )
}
