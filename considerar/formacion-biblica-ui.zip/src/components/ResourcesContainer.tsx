import { motion } from 'framer-motion'
import { FolderOpen, BookOpen, Video, HeadphonesIcon, Download } from 'lucide-react'

export default function ResourcesContainer() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="discord-card p-6 rounded-lg">
        <div className="flex items-center space-x-3 mb-6">
          <FolderOpen className="w-6 h-6 text-discord-primary" />
          <h2 className="text-xl font-semibold text-discord-text-primary">Recursos de Estudio</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Commentaries */}
          <div className="discord-card p-6 rounded-lg bg-discord-tertiary">
            <div className="flex items-center space-x-3 mb-4">
              <BookOpen className="w-8 h-8 text-green-400" />
              <div>
                <h3 className="text-lg font-semibold text-discord-text-primary">Comentarios</h3>
                <p className="text-sm text-discord-text-secondary">Estudios exegéticos</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="p-3 bg-discord-secondary rounded-lg">
                <h4 className="font-medium text-discord-text-primary">Matthew Henry</h4>
                <p className="text-xs text-discord-text-muted">Comentario completo</p>
              </div>
              <div className="p-3 bg-discord-secondary rounded-lg">
                <h4 className="font-medium text-discord-text-primary">John MacArthur</h4>
                <p className="text-xs text-discord-text-muted">Análisis verso por verso</p>
              </div>
            </div>
          </div>
          
          {/* Video Resources */}
          <div className="discord-card p-6 rounded-lg bg-discord-tertiary">
            <div className="flex items-center space-x-3 mb-4">
              <Video className="w-8 h-8 text-red-400" />
              <div>
                <h3 className="text-lg font-semibold text-discord-text-primary">Videos</h3>
                <p className="text-sm text-discord-text-secondary">Enseñanzas audiovisuales</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="p-3 bg-discord-secondary rounded-lg">
                <h4 className="font-medium text-discord-text-primary">Hermenéutica Bíblica</h4>
                <p className="text-xs text-discord-text-muted">Serie de 12 videos</p>
              </div>
              <div className="p-3 bg-discord-secondary rounded-lg">
                <h4 className="font-medium text-discord-text-primary">Contexto Histórico</h4>
                <p className="text-xs text-discord-text-muted">Documentales</p>
              </div>
            </div>
          </div>
          
          {/* Audio Resources */}
          <div className="discord-card p-6 rounded-lg bg-discord-tertiary">
            <div className="flex items-center space-x-3 mb-4">
              <HeadphonesIcon className="w-8 h-8 text-purple-400" />
              <div>
                <h3 className="text-lg font-semibold text-discord-text-primary">Audio</h3>
                <p className="text-sm text-discord-text-secondary">Predicaciones y música</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="p-3 bg-discord-secondary rounded-lg">
                <h4 className="font-medium text-discord-text-primary">Predicaciones</h4>
                <p className="text-xs text-discord-text-muted">Colección de sermones</p>
              </div>
              <div className="p-3 bg-discord-secondary rounded-lg">
                <h4 className="font-medium text-discord-text-primary">Música Cristiana</h4>
                <p className="text-xs text-discord-text-muted">Himnos y cánticos</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-discord-text-primary mb-4 flex items-center">
            <Download className="w-5 h-5 mr-2" />
            Descargas Recientes
          </h3>
          <div className="discord-card p-4 rounded-lg bg-discord-tertiary">
            <div className="text-center py-8">
              <p className="text-discord-text-muted">
                Tus descargas aparecerán aquí
              </p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}
