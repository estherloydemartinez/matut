import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from '@/hooks/use-toast';
import { 
  BookOpen, 
  Plus, 
  Play, 
  Pause, 
  CheckCircle, 
  Calendar as CalendarIcon,
  Clock,
  Target,
  TrendingUp,
  Star,
  Users,
  Bell,
  Edit,
  Trash2,
  Share2
} from 'lucide-react';

interface ReadingPlan {
  id: string;
  name: string;
  description: string;
  type: 'sequential' | 'thematic' | 'chronological' | 'custom';
  duration: number;
  books: string[];
  dailyReadings: DailyReading[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  tags: string[];
  createdBy: string;
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
}

interface DailyReading {
  day: number;
  readings: BibleReading[];
  reflection?: string;
  questions?: string[];
  estimatedTime: number;
}

interface BibleReading {
  book: string;
  chapter: number;
  startVerse?: number;
  endVerse?: number;
  focus?: string;
}

interface StudyProgress {
  planId: string;
  userId: string;
  currentDay: number;
  completedDays: number[];
  totalDays: number;
  startDate: Date;
  lastReadDate?: Date;
  notes: StudyNote[];
  timeSpent: number;
  completed: boolean;
}

interface StudyNote {
  id: string;
  day: number;
  reading: BibleReading;
  content: string;
  type: 'note' | 'reflection' | 'question' | 'prayer';
  tags: string[];
  createdAt: Date;
  isPrivate: boolean;
}

const PersonalizedStudySystem: React.FC = () => {
  const [activeTab, setActiveTab] = useState('my-plans');
  const [readingPlans, setReadingPlans] = useState<ReadingPlan[]>([]);
  const [currentPlan, setCurrentPlan] = useState<ReadingPlan | null>(null);
  const [studyProgress, setStudyProgress] = useState<Map<string, StudyProgress>>(new Map());
  const [isCreatingPlan, setIsCreatingPlan] = useState(false);
  const [newPlan, setNewPlan] = useState<Partial<ReadingPlan>>({
    name: '',
    description: '',
    type: 'sequential',
    duration: 30,
    books: [],
    difficulty: 'intermediate',
    tags: [],
    isPublic: false
  });
  const [availableBooks] = useState([
    'genesis', 'exodo', 'levitico', 'numeros', 'deuteronomio',
    'josue', 'jueces', 'rut', '1samuel', '2samuel',
    'mateo', 'marcos', 'lucas', 'juan', 'hechos',
    'romanos', '1corintios', '2corintios', 'galatas', 'efesios'
  ]);

  // Cargar planes existentes al montar el componente
  useEffect(() => {
    loadReadingPlans();
    loadStudyProgress();
  }, []);

  // Funciones de carga de datos
  const loadReadingPlans = useCallback(async () => {
    try {
      // Aquí se integraría con AdvancedFeaturesModule.PersonalizedStudySystem
      if (window.AdvancedFeaturesModule) {
        const plans = await window.AdvancedFeaturesModule.PersonalizedStudySystem.getAllPlans();
        setReadingPlans(plans);
      }
    } catch (error) {
      console.error('Error loading reading plans:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar los planes de lectura",
        variant: "destructive"
      });
    }
  }, []);

  const loadStudyProgress = useCallback(async () => {
    try {
      // Cargar progreso de todos los planes del usuario
      const progressMap = new Map<string, StudyProgress>();
      
      readingPlans.forEach(plan => {
        if (window.AdvancedFeaturesModule) {
          const progress = window.AdvancedFeaturesModule.PersonalizedStudySystem.getStudyProgress(plan.id);
          if (progress) {
            progressMap.set(plan.id, progress);
          }
        }
      });
      
      setStudyProgress(progressMap);
    } catch (error) {
      console.error('Error loading study progress:', error);
    }
  }, [readingPlans]);

  // Función para crear un nuevo plan
  const createReadingPlan = useCallback(async () => {
    try {
      if (!newPlan.name || !newPlan.description) {
        toast({
          title: "Error",
          description: "Por favor completa el nombre y descripción del plan",
          variant: "destructive"
        });
        return;
      }

      if (window.AdvancedFeaturesModule) {
        const plan = await window.AdvancedFeaturesModule.PersonalizedStudySystem.createReadingPlan(newPlan);
        setReadingPlans(prev => [...prev, plan]);
        setIsCreatingPlan(false);
        setNewPlan({
          name: '',
          description: '',
          type: 'sequential',
          duration: 30,
          books: [],
          difficulty: 'intermediate',
          tags: [],
          isPublic: false
        });
        
        toast({
          title: "Plan creado",
          description: `El plan "${plan.name}" ha sido creado exitosamente`,
        });
      }
    } catch (error) {
      console.error('Error creating reading plan:', error);
      toast({
        title: "Error",
        description: "No se pudo crear el plan de lectura",
        variant: "destructive"
      });
    }
  }, [newPlan]);

  // Función para iniciar una sesión de estudio
  const startStudySession = useCallback(async (planId: string, day: number) => {
    try {
      if (window.AdvancedFeaturesModule) {
        const session = await window.AdvancedFeaturesModule.PersonalizedStudySystem.startStudySession(planId, day);
        
        toast({
          title: "Sesión iniciada",
          description: `Sesión de estudio del día ${day} iniciada`,
        });
        
        // Actualizar progreso
        loadStudyProgress();
      }
    } catch (error) {
      console.error('Error starting study session:', error);
      toast({
        title: "Error",
        description: "No se pudo iniciar la sesión de estudio",
        variant: "destructive"
      });
    }
  }, [loadStudyProgress]);

  // Función para completar una lectura
  const completeReading = useCallback(async (sessionId: string, readingIndex: number) => {
    try {
      if (window.AdvancedFeaturesModule) {
        await window.AdvancedFeaturesModule.PersonalizedStudySystem.completeReading(sessionId, readingIndex);
        
        toast({
          title: "Lectura completada",
          description: "Has completado esta lectura exitosamente",
        });
        
        // Actualizar progreso
        loadStudyProgress();
      }
    } catch (error) {
      console.error('Error completing reading:', error);
      toast({
        title: "Error",
        description: "No se pudo marcar la lectura como completada",
        variant: "destructive"
      });
    }
  }, [loadStudyProgress]);

  // Componente para mostrar planes de lectura
  const ReadingPlansGrid = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {readingPlans.map(plan => {
        const progress = studyProgress.get(plan.id);
        const completionPercentage = progress ? 
          (progress.completedDays.length / progress.totalDays) * 100 : 0;
        
        return (
          <Card key={plan.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <CardDescription className="mt-1">{plan.description}</CardDescription>
                </div>
                <Badge variant={plan.difficulty === 'beginner' ? 'secondary' : 
                               plan.difficulty === 'intermediate' ? 'default' : 'destructive'}>
                  {plan.difficulty}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Información del plan */}
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <CalendarIcon className="w-4 h-4" />
                    <span>{plan.duration} días</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <BookOpen className="w-4 h-4" />
                    <span>{plan.books.length} libros</span>
                  </div>
                  {plan.isPublic && (
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>Público</span>
                    </div>
                  )}
                </div>

                {/* Progreso */}
                {progress && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progreso</span>
                      <span>{Math.round(completionPercentage)}%</span>
                    </div>
                    <Progress value={completionPercentage} className="h-2" />
                    <div className="text-xs text-gray-500">
                      Día {progress.currentDay} de {progress.totalDays}
                    </div>
                  </div>
                )}

                {/* Tags */}
                {plan.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {plan.tags.map(tag => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}

                {/* Acciones */}
                <div className="flex gap-2">
                  {progress ? (
                    <Button 
                      onClick={() => startStudySession(plan.id, progress.currentDay)}
                      className="flex-1"
                      size="sm"
                    >
                      <Play className="w-4 h-4 mr-1" />
                      Continuar
                    </Button>
                  ) : (
                    <Button 
                      onClick={() => startStudySession(plan.id, 1)}
                      className="flex-1"
                      size="sm"
                    >
                      <Play className="w-4 h-4 mr-1" />
                      Comenzar
                    </Button>
                  )}
                  <Button variant="outline" size="sm">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}

      {/* Card para crear nuevo plan */}
      <Card className="border-dashed border-2 hover:border-primary transition-colors">
        <CardContent className="flex flex-col items-center justify-center h-full min-h-[300px]">
          <Button 
            onClick={() => setIsCreatingPlan(true)}
            variant="ghost"
            className="h-auto flex-col gap-2"
          >
            <Plus className="w-8 h-8" />
            <div className="text-center">
              <div className="font-medium">Crear nuevo plan</div>
              <div className="text-sm text-gray-500">Personaliza tu estudio bíblico</div>
            </div>
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  // Componente para crear plan
  const CreatePlanDialog = () => (
    <Dialog open={isCreatingPlan} onOpenChange={setIsCreatingPlan}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Crear Nuevo Plan de Lectura</DialogTitle>
          <DialogDescription>
            Personaliza tu plan de estudio bíblico según tus necesidades
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Información básica */}
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Nombre del plan</label>
              <Input
                value={newPlan.name || ''}
                onChange={(e) => setNewPlan(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Ej: Lectura completa de la Biblia"
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Descripción</label>
              <Textarea
                value={newPlan.description || ''}
                onChange={(e) => setNewPlan(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe el objetivo y contenido de tu plan..."
              />
            </div>
          </div>

          {/* Configuración del plan */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Tipo de plan</label>
              <Select 
                value={newPlan.type} 
                onValueChange={(value: 'sequential' | 'thematic' | 'chronological' | 'custom') => 
                  setNewPlan(prev => ({ ...prev, type: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sequential">Secuencial</SelectItem>
                  <SelectItem value="thematic">Temático</SelectItem>
                  <SelectItem value="chronological">Cronológico</SelectItem>
                  <SelectItem value="custom">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium">Dificultad</label>
              <Select 
                value={newPlan.difficulty} 
                onValueChange={(value: 'beginner' | 'intermediate' | 'advanced') => 
                  setNewPlan(prev => ({ ...prev, difficulty: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Principiante</SelectItem>
                  <SelectItem value="intermediate">Intermedio</SelectItem>
                  <SelectItem value="advanced">Avanzado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium">Duración (días)</label>
            <Input
              type="number"
              value={newPlan.duration || 30}
              onChange={(e) => setNewPlan(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
              min="1"
              max="365"
            />
          </div>

          {/* Selección de libros */}
          <div>
            <label className="text-sm font-medium mb-2 block">Libros incluidos</label>
            <div className="grid grid-cols-3 gap-2 max-h-40 overflow-y-auto p-2 border rounded">
              {availableBooks.map(book => (
                <div key={book} className="flex items-center space-x-2">
                  <Checkbox
                    id={book}
                    checked={newPlan.books?.includes(book)}
                    onCheckedChange={(checked) => {
                      setNewPlan(prev => ({
                        ...prev,
                        books: checked 
                          ? [...(prev.books || []), book]
                          : (prev.books || []).filter(b => b !== book)
                      }));
                    }}
                  />
                  <label htmlFor={book} className="text-sm capitalize cursor-pointer">
                    {book}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Opciones adicionales */}
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="public"
                checked={newPlan.isPublic}
                onCheckedChange={(checked) => 
                  setNewPlan(prev => ({ ...prev, isPublic: !!checked }))
                }
              />
              <label htmlFor="public" className="text-sm">
                Hacer público (otros usuarios pueden usar este plan)
              </label>
            </div>
          </div>

          {/* Acciones */}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsCreatingPlan(false)}>
              Cancelar
            </Button>
            <Button onClick={createReadingPlan}>
              Crear Plan
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );

  // Componente para mostrar estadísticas
  const StudyStats = () => {
    const [stats, setStats] = useState<any>(null);

    useEffect(() => {
      const loadStats = async () => {
        if (window.AdvancedFeaturesModule) {
          const userStats = await window.AdvancedFeaturesModule.PersonalizedStudySystem.getStudyStats('current_user');
          setStats(userStats);
        }
      };
      loadStats();
    }, []);

    if (!stats) return <div>Cargando estadísticas...</div>;

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-blue-500" />
              <div>
                <div className="text-2xl font-bold">{stats.totalPlans}</div>
                <div className="text-sm text-gray-600">Planes totales</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <div>
                <div className="text-2xl font-bold">{stats.completedPlans}</div>
                <div className="text-sm text-gray-600">Planes completados</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-orange-500" />
              <div>
                <div className="text-2xl font-bold">{Math.round(stats.totalStudyTime / 60)}h</div>
                <div className="text-sm text-gray-600">Tiempo total</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-purple-500" />
              <div>
                <div className="text-2xl font-bold">{stats.currentStreak}</div>
                <div className="text-sm text-gray-600">Racha actual</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Sistema de Estudios Personalizados</h2>
          <p className="text-gray-600">Crea y sigue planes de lectura adaptados a tus necesidades</p>
        </div>
        <Button onClick={() => setIsCreatingPlan(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Plan
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="my-plans">Mis Planes</TabsTrigger>
          <TabsTrigger value="discover">Descubrir</TabsTrigger>
          <TabsTrigger value="stats">Estadísticas</TabsTrigger>
        </TabsList>

        <TabsContent value="my-plans" className="space-y-6">
          <ReadingPlansGrid />
        </TabsContent>

        <TabsContent value="discover" className="space-y-6">
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Descubre nuevos planes</h3>
            <p className="text-gray-600">Explora planes creados por la comunidad</p>
            <Button className="mt-4">
              Explorar planes públicos
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="stats" className="space-y-6">
          <StudyStats />
        </TabsContent>
      </Tabs>

      <CreatePlanDialog />
    </div>
  );
};

export default PersonalizedStudySystem;
