import { motion, AnimatePresence } from 'framer-motion'
import { 
  BookOpen, 
  Lightbulb, 
  Filter, 
  Users, 
  FolderOpen,
  BarChart3,
  ChevronRight,
  Hash,
  Sparkles,
  Brain
} from 'lucide-react'
import { useAppState } from '../contexts/AppStateContext'
import { ActiveSection } from '../App'

interface NavigationProps {
  vertical?: boolean
}

interface NavItem {
  id: ActiveSection
  label: string
  icon: React.ReactNode
  description: string
  shortcut?: string
  badge?: number
}

const navItems: NavItem[] = [
  {
    id: 'biblia',
    label: 'Biblia',
    icon: <BookOpen className="w-5 h-5" />,
    description: 'Texto completo de la Biblia Reina Valera 1960',
    shortcut: '1'
  },
  {
    id: 'estudio',
    label: 'Estudio',
    icon: <Lightbulb className="w-5 h-5" />,
    description: 'Herramientas avanzadas de estudio bíblico',
    shortcut: '2'
  },
  {
    id: 'filtros',
    label: 'Filtros',
    icon: <Filter className="w-5 h-5" />,
    description: 'Filtros analíticos por temas',
    shortcut: '3'
  },
  {
    id: 'social',
    label: 'Social',
    icon: <Users className="w-5 h-5" />,
    description: 'Comunidad y discusiones',
    shortcut: '4'
  },
  {
    id: 'recursos',
    label: 'Recursos',
    icon: <FolderOpen className="w-5 h-5" />,
    description: 'Materiales y herramientas adicionales',
    shortcut: '5'
  },
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: <BarChart3 className="w-5 h-5" />,
    description: 'Progreso y estadísticas de estudio',
    shortcut: '6'
  },
  {
    id: 'avanzado',
    label: 'Avanzado',
    icon: <Sparkles className="w-5 h-5" />,
    description: 'Funcionalidades avanzadas y herramientas especializadas',
    shortcut: '7'
  },
  {
    id: 'analytics',
    label: 'Analytics IA',
    icon: <Brain className="w-5 h-5" />,
    description: 'Análisis avanzado con Machine Learning y NLP',
    shortcut: '8'
  }
]

export default function Navigation({ vertical = false }: NavigationProps) {
  const { activeSection, setActiveSection } = useAppState()

  const handleSectionChange = (section: ActiveSection) => {
    setActiveSection(section)
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: vertical ? 0 : 20, x: vertical ? -20 : 0, opacity: 0 },
    visible: {
      y: 0,
      x: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 30
      }
    }
  }

  if (vertical) {
    return (
      <motion.nav
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-2"
      >
        {navItems.map((item) => (
          <motion.button
            key={item.id}
            variants={itemVariants}
            whileHover={{ x: 4 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleSectionChange(item.id)}
            className={`
              w-full flex items-center justify-between p-3 rounded-lg text-left transition-all duration-fast group
              ${activeSection === item.id
                ? 'bg-discord-primary text-white shadow-elevation-medium'
                : 'hover:bg-discord-modifier-hover text-discord-text-secondary hover:text-discord-text-primary'
              }
            `}
          >
            <div className="flex items-center space-x-3">
              <motion.div
                animate={activeSection === item.id ? { scale: [1, 1.1, 1] } : {}}
                transition={{ duration: 0.3 }}
              >
                {item.icon}
              </motion.div>
              
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <span className="font-medium">{item.label}</span>
                  {item.badge && (
                    <motion.span
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="px-2 py-1 text-xs bg-red-500 text-white rounded-full"
                    >
                      {item.badge}
                    </motion.span>
                  )}
                </div>
                <p className="text-xs text-discord-text-muted group-hover:text-discord-text-secondary transition-colors">
                  {item.description}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {item.shortcut && (
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  className="w-6 h-6 bg-discord-modifier-hover rounded flex items-center justify-center text-xs font-mono"
                >
                  {item.shortcut}
                </motion.div>
              )}
              
              <motion.div
                animate={activeSection === item.id ? { x: 0 } : { x: -10 }}
                className={`transition-all duration-fast ${
                  activeSection === item.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-50'
                }`}
              >
                <ChevronRight className="w-4 h-4" />
              </motion.div>
            </div>
          </motion.button>
        ))}

        {/* Quick actions section */}
        <motion.div
          variants={itemVariants}
          className="pt-4 mt-4 border-t border-discord-modifier-hover"
        >
          <h4 className="text-xs font-semibold text-discord-text-muted uppercase tracking-wider mb-2">
            Acciones Rápidas
          </h4>
          
          <div className="space-y-1">
            <button className="w-full flex items-center space-x-3 p-2 rounded hover:bg-discord-modifier-hover transition-colors text-discord-text-muted hover:text-discord-text-secondary text-sm">
              <Hash className="w-4 h-4" />
              <span>Búsqueda Rápida</span>
            </button>
          </div>
        </motion.div>
      </motion.nav>
    )
  }

  return (
    <motion.nav 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="discord-card p-2 rounded-lg"
    >
      <div className="flex flex-wrap justify-center md:justify-start gap-2">
        {navItems.map((item) => (
          <motion.button
            key={item.id}
            variants={itemVariants}
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleSectionChange(item.id)}
            className={`
              flex items-center space-x-2 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-fast relative group
              ${activeSection === item.id
                ? 'bg-discord-primary text-white shadow-elevation-medium'
                : 'hover:bg-discord-modifier-hover text-discord-text-secondary hover:text-discord-text-primary'
              }
            `}
            title={item.description}
          >
            <motion.div
              animate={activeSection === item.id ? { 
                rotate: [0, 10, -10, 0],
                scale: [1, 1.1, 1]
              } : {}}
              transition={{ duration: 0.5 }}
            >
              {item.icon}
            </motion.div>
            
            <span className="hidden sm:inline">{item.label}</span>
            
            {/* Keyboard shortcut indicator */}
            {item.shortcut && (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="hidden md:flex w-5 h-5 bg-discord-modifier-hover rounded text-xs items-center justify-center font-mono opacity-60 group-hover:opacity-100 transition-opacity"
              >
                {item.shortcut}
              </motion.div>
            )}

            {/* Badge indicator */}
            {item.badge && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center text-xs text-white font-medium"
              >
                {item.badge > 9 ? '9+' : item.badge}
              </motion.div>
            )}

            {/* Active indicator */}
            <AnimatePresence>
              {activeSection === item.id && (
                <motion.div
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  exit={{ scaleX: 0 }}
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-white rounded-full"
                />
              )}
            </AnimatePresence>
          </motion.button>
        ))}
      </div>

      {/* Progress indicator */}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="mt-4 h-1 bg-discord-modifier-hover rounded-full overflow-hidden"
      >
        <motion.div
          initial={{ x: '-100%' }}
          animate={{ x: `${(navItems.findIndex(item => item.id === activeSection) / (navItems.length - 1)) * 100 - 100}%` }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="h-full w-full bg-discord-primary"
        />
      </motion.div>
    </motion.nav>
  )
}
