/**
 * Hub de Análisis Avanzado con ML, NLP y Visualizaciones
 * Integra todos los sistemas analíticos en una interfaz unificada
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Brain, 
  Search, 
  Filter, 
  BarChart3, 
  Network, 
  Target, 
  Sparkles,
  TrendingUp,
  Eye,
  Lightbulb,
  BookOpen,
  Heart,
  Droplets,
  Star,
  Shield,
  Zap
} from 'lucide-react';

// Importar nuestros sistemas ML
import { globalMLEngine } from '@/lib/ml-engine';
import { globalIntelligentFilters } from '@/lib/intelligent-filters';
import { globalSemanticSearch } from '@/lib/semantic-search';
import { createVisualization } from '@/lib/advanced-visualizations';

// =====================================================================
// TIPOS Y INTERFACES
// =====================================================================

interface AnalysisResult {
  type: 'sentiment' | 'topics' | 'semantic' | 'filters' | 'recommendations';
  data: any;
  timestamp: number;
  executionTime: number;
}

interface FilterConfig {
  id: string;
  active: boolean;
  weight: number;
}

interface SearchConfig {
  type: 'semantic' | 'keyword' | 'fuzzy' | 'contextual' | 'hybrid';
  filters: {
    testament?: 'AT' | 'NT' | 'both';
    sentiment?: 'positive' | 'negative' | 'neutral';
    books?: string[];
  };
  options: {
    limit: number;
    threshold: number;
    expandQuery: boolean;
    autoCorrect: boolean;
  };
}

// =====================================================================
// COMPONENTE PRINCIPAL
// =====================================================================

export default function AdvancedAnalyticsHub() {
  // Estados principales
  const [activeTab, setActiveTab] = useState('search');
  const [isLoading, setIsLoading] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult[]>([]);
  const [selectedText, setSelectedText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchConfig, setSearchConfig] = useState<SearchConfig>({
    type: 'hybrid',
    filters: { testament: 'both' },
    options: { limit: 20, threshold: 0.3, expandQuery: true, autoCorrect: true }
  });

  // Estados para filtros
  const [availableFilters, setAvailableFilters] = useState<any[]>([]);
  const [activeFilters, setActiveFilters] = useState<FilterConfig[]>([]);
  const [filterResults, setFilterResults] = useState<any[]>([]);

  // Estados para visualizaciones
  const [visualizationContainer, setVisualizationContainer] = useState<HTMLElement | null>(null);
  const [currentVisualization, setCurrentVisualization] = useState<any>(null);

  // Estados para análisis ML
  const [textAnalysis, setTextAnalysis] = useState<any>(null);
  const [semanticResults, setSemanticResults] = useState<any[]>([]);
  const [recommendations, setRecommendations] = useState<any[]>([]);

  // Datos mock para demostración
  const mockVerses = useMemo(() => [
    {
      id: 1,
      libro: 'Juan',
      capitulo: 3,
      versiculo: 16,
      texto: 'Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito, para que todo aquel que en él cree, no se pierda, mas tenga vida eterna.',
      testament: 'NT'
    },
    {
      id: 2,
      libro: 'Romanos',
      capitulo: 8,
      versiculo: 28,
      texto: 'Y sabemos que a los que aman a Dios, todas las cosas les ayudan a bien, esto es, a los que conforme a su propósito son llamados.',
      testament: 'NT'
    },
    {
      id: 3,
      libro: 'Salmos',
      capitulo: 23,
      versiculo: 1,
      texto: 'Jehová es mi pastor; nada me faltará.',
      testament: 'AT'
    },
    {
      id: 4,
      libro: 'Isaías',
      capitulo: 53,
      versiculo: 5,
      texto: 'Mas él herido fue por nuestras rebeliones, molido por nuestros pecados; el castigo de nuestra paz fue sobre él, y por su llaga fuimos nosotros curados.',
      testament: 'AT'
    },
    {
      id: 5,
      libro: 'Filipenses',
      capitulo: 4,
      versiculo: 13,
      texto: 'Todo lo puedo en Cristo que me fortalece.',
      testament: 'NT'
    }
  ], []);

  // =====================================================================
  // EFECTOS Y INICIALIZACIÓN
  // =====================================================================

  useEffect(() => {
    initializeAnalytics();
    loadAvailableFilters();
  }, []);

  useEffect(() => {
    if (visualizationContainer && !currentVisualization) {
      const viz = createVisualization(visualizationContainer, {
        theme: 'light',
        interactive: true,
        responsive: true
      });
      setCurrentVisualization(viz);
    }
  }, [visualizationContainer]);

  // =====================================================================
  // FUNCIONES DE INICIALIZACIÓN
  // =====================================================================

  const initializeAnalytics = async () => {
    try {
      setIsLoading(true);
      
      // Verificar que los sistemas ML estén inicializados
      console.log('Inicializando sistemas de análisis avanzado...');
      
      // Simular inicialización
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log('Sistemas de análisis listos');
    } catch (error) {
      console.error('Error inicializando analytics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadAvailableFilters = () => {
    const filters = globalIntelligentFilters.getAllFilters();
    setAvailableFilters(filters);
    
    // Activar algunos filtros por defecto
    const defaultActive = filters.slice(0, 3).map(filter => ({
      id: filter.id,
      active: true,
      weight: 1.0
    }));
    setActiveFilters(defaultActive);
  };

  // =====================================================================
  // ANÁLISIS DE TEXTO CON ML
  // =====================================================================

  const analyzeText = useCallback(async (text: string) => {
    if (!text.trim()) return;

    setIsLoading(true);
    const startTime = performance.now();

    try {
      // Análisis completo con ML Engine
      const analysis = await globalMLEngine.analyzeText(text);
      
      const executionTime = performance.now() - startTime;
      
      setTextAnalysis(analysis);
      
      const result: AnalysisResult = {
        type: 'sentiment',
        data: analysis,
        timestamp: Date.now(),
        executionTime
      };
      
      setAnalysisResults(prev => [result, ...prev.slice(0, 9)]);
      
      console.log('Análisis de texto completado:', analysis);
    } catch (error) {
      console.error('Error en análisis de texto:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // =====================================================================
  // BÚSQUEDA SEMÁNTICA
  // =====================================================================

  const performSemanticSearch = useCallback(async () => {
    if (!searchQuery.trim()) return;

    setIsLoading(true);
    const startTime = performance.now();

    try {
      const searchResults = await globalSemanticSearch.search({
        text: searchQuery,
        type: searchConfig.type,
        filters: searchConfig.filters,
        options: searchConfig.options
      }, mockVerses);

      const executionTime = performance.now() - startTime;

      setSemanticResults(searchResults);

      const result: AnalysisResult = {
        type: 'semantic',
        data: searchResults,
        timestamp: Date.now(),
        executionTime
      };

      setAnalysisResults(prev => [result, ...prev.slice(0, 9)]);

      console.log('Búsqueda semántica completada:', searchResults);
    } catch (error) {
      console.error('Error en búsqueda semántica:', error);
    } finally {
      setIsLoading(false);
    }
  }, [searchQuery, searchConfig, mockVerses]);

  // =====================================================================
  // APLICACIÓN DE FILTROS INTELIGENTES
  // =====================================================================

  const applyIntelligentFilters = useCallback(async () => {
    if (activeFilters.length === 0) return;

    setIsLoading(true);
    const startTime = performance.now();

    try {
      const results = [];
      
      for (const filterConfig of activeFilters.filter(f => f.active)) {
        const filterResults = await globalIntelligentFilters.applyFilter(
          filterConfig.id, 
          mockVerses
        );
        results.push(...filterResults);
      }

      const executionTime = performance.now() - startTime;

      setFilterResults(results);

      const result: AnalysisResult = {
        type: 'filters',
        data: results,
        timestamp: Date.now(),
        executionTime
      };

      setAnalysisResults(prev => [result, ...prev.slice(0, 9)]);

      console.log('Filtros aplicados:', results);
    } catch (error) {
      console.error('Error aplicando filtros:', error);
    } finally {
      setIsLoading(false);
    }
  }, [activeFilters, mockVerses]);

  // =====================================================================
  // GENERACIÓN DE RECOMENDACIONES
  // =====================================================================

  const generateRecommendations = useCallback(async (currentVerse: any) => {
    setIsLoading(true);
    const startTime = performance.now();

    try {
      const recs = await globalMLEngine.generateRecommendations(
        currentVerse,
        mockVerses,
        [], // historial del usuario
        5
      );

      const executionTime = performance.now() - startTime;

      setRecommendations(recs);

      const result: AnalysisResult = {
        type: 'recommendations',
        data: recs,
        timestamp: Date.now(),
        executionTime
      };

      setAnalysisResults(prev => [result, ...prev.slice(0, 9)]);

      console.log('Recomendaciones generadas:', recs);
    } catch (error) {
      console.error('Error generando recomendaciones:', error);
    } finally {
      setIsLoading(false);
    }
  }, [mockVerses]);

  // =====================================================================
  // RENDERIZADO DE COMPONENTES
  // =====================================================================

  const renderTextAnalysis = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Heart className="h-4 w-4" />
              Análisis de Sentimiento
            </CardTitle>
          </CardHeader>
          <CardContent>
            {textAnalysis?.sentiment ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Polaridad:</span>
                  <Badge variant={
                    textAnalysis.sentiment.label === 'positivo' ? 'default' : 
                    textAnalysis.sentiment.label === 'negativo' ? 'destructive' : 'secondary'
                  }>
                    {textAnalysis.sentiment.label}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Puntuación:</span>
                    <span>{(textAnalysis.sentiment.score * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={(textAnalysis.sentiment.score + 1) * 50} className="h-2" />
                </div>
                <div className="flex justify-between text-sm">
                  <span>Confianza:</span>
                  <span>{(textAnalysis.sentiment.confidence * 100).toFixed(1)}%</span>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Ingresa texto para analizar</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Brain className="h-4 w-4" />
              Tópicos Identificados
            </CardTitle>
          </CardHeader>
          <CardContent>
            {textAnalysis?.topics && textAnalysis.topics.length > 0 ? (
              <div className="space-y-2">
                {textAnalysis.topics.slice(0, 3).map((topic: any, index: number) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium capitalize">{topic.topic}</span>
                      <span className="text-xs text-muted-foreground">
                        {(topic.probability * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={topic.probability * 100} className="h-1" />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No se detectaron tópicos</p>
            )}
          </CardContent>
        </Card>
      </div>

      {textAnalysis?.entities && textAnalysis.entities.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Target className="h-4 w-4" />
              Entidades Extraídas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {textAnalysis.entities.map((entity: any, index: number) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {entity.entity} ({entity.type})
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const renderSemanticSearch = () => (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Búsqueda Semántica Avanzada
          </CardTitle>
          <CardDescription>
            Encuentra versículos por significado, no solo por palabras exactas
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Buscar por concepto o significado..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && performSemanticSearch()}
            />
            <Button onClick={performSemanticSearch} disabled={isLoading}>
              <Search className="h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label className="text-sm">Tipo de Búsqueda</Label>
              <Select 
                value={searchConfig.type} 
                onValueChange={(value: any) => setSearchConfig(prev => ({ ...prev, type: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="semantic">Semántica</SelectItem>
                  <SelectItem value="keyword">Palabras Clave</SelectItem>
                  <SelectItem value="fuzzy">Difusa</SelectItem>
                  <SelectItem value="contextual">Contextual</SelectItem>
                  <SelectItem value="hybrid">Híbrida</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm">Testamento</Label>
              <Select 
                value={searchConfig.filters.testament} 
                onValueChange={(value: any) => setSearchConfig(prev => ({ 
                  ...prev, 
                  filters: { ...prev.filters, testament: value }
                }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="both">Ambos</SelectItem>
                  <SelectItem value="AT">Antiguo Testamento</SelectItem>
                  <SelectItem value="NT">Nuevo Testamento</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm">Límite de Resultados</Label>
              <Select 
                value={searchConfig.options.limit.toString()} 
                onValueChange={(value) => setSearchConfig(prev => ({ 
                  ...prev, 
                  options: { ...prev.options, limit: parseInt(value) }
                }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {semanticResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Resultados de Búsqueda</CardTitle>
            <CardDescription>
              {semanticResults.length} versículos encontrados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64">
              <div className="space-y-3">
                {semanticResults.map((result: any, index: number) => (
                  <div key={index} className="border rounded-lg p-3 space-y-2">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium">
                        {result.verse.libro} {result.verse.capitulo}:{result.verse.versiculo}
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {(result.score * 100).toFixed(1)}%
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {result.verse.texto}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {result.explanation}
                    </p>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const renderIntelligentFilters = () => (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros Inteligentes
          </CardTitle>
          <CardDescription>
            Filtros avanzados con análisis semántico y contextual
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {availableFilters.map((filter) => {
              const config = activeFilters.find(f => f.id === filter.id);
              const isActive = config?.active || false;
              
              const getFilterIcon = (filterId: string) => {
                switch (filterId) {
                  case 'blood': return <Droplets className="h-4 w-4 text-red-500" />;
                  case 'water': return <Droplets className="h-4 w-4 text-blue-500" />;
                  case 'love': return <Heart className="h-4 w-4 text-pink-500" />;
                  case 'faith': return <Star className="h-4 w-4 text-yellow-500" />;
                  case 'hope': return <Lightbulb className="h-4 w-4 text-orange-500" />;
                  case 'forgiveness': return <Shield className="h-4 w-4 text-green-500" />;
                  case 'wisdom': return <Brain className="h-4 w-4 text-purple-500" />;
                  default: return <Zap className="h-4 w-4" />;
                }
              };

              return (
                <Card 
                  key={filter.id} 
                  className={`cursor-pointer transition-all ${isActive ? 'ring-2 ring-primary' : ''}`}
                  onClick={() => {
                    setActiveFilters(prev => {
                      const existing = prev.find(f => f.id === filter.id);
                      if (existing) {
                        return prev.map(f => f.id === filter.id ? { ...f, active: !f.active } : f);
                      } else {
                        return [...prev, { id: filter.id, active: true, weight: 1.0 }];
                      }
                    });
                  }}
                >
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2">
                      {getFilterIcon(filter.id)}
                      <div className="flex-1">
                        <div className="font-medium text-sm">{filter.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {filter.description.slice(0, 50)}...
                        </div>
                      </div>
                      {isActive && (
                        <Badge variant="default" className="text-xs">
                          Activo
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <Button onClick={applyIntelligentFilters} disabled={isLoading || activeFilters.filter(f => f.active).length === 0}>
            <Filter className="h-4 w-4 mr-2" />
            Aplicar Filtros
          </Button>
        </CardContent>
      </Card>

      {filterResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Resultados Filtrados</CardTitle>
            <CardDescription>
              {filterResults.length} versículos que coinciden con los filtros
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-64">
              <div className="space-y-3">
                {filterResults.map((result: any, index: number) => (
                  <div key={index} className="border rounded-lg p-3 space-y-2">
                    <div className="flex justify-between items-start">
                      <div className="text-sm font-medium">
                        {result.verse.libro} {result.verse.capitulo}:{result.verse.versiculo}
                      </div>
                      <div className="flex gap-1">
                        <Badge variant="secondary" className="text-xs">
                          {(result.matchScore * 100).toFixed(1)}%
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {(result.confidence * 100).toFixed(0)}% conf.
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {result.verse.texto}
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {result.matchReasons.map((reason: string, idx: number) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {reason.slice(0, 20)}...
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const renderVisualizationsPanel = () => (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Visualizaciones Avanzadas
          </CardTitle>
          <CardDescription>
            Gráficos interactivos y análisis visual de datos bíblicos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button 
                variant="outline" 
                onClick={() => generateSemanticNetwork()}
                className="h-auto p-4 flex flex-col items-center gap-2"
              >
                <Network className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-medium">Red Semántica</div>
                  <div className="text-xs text-muted-foreground">
                    Conexiones entre conceptos
                  </div>
                </div>
              </Button>

              <Button 
                variant="outline" 
                onClick={() => generateHeatmap()}
                className="h-auto p-4 flex flex-col items-center gap-2"
              >
                <TrendingUp className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-medium">Mapa de Calor</div>
                  <div className="text-xs text-muted-foreground">
                    Distribución de temas
                  </div>
                </div>
              </Button>

              <Button 
                variant="outline" 
                onClick={() => generateTimeline()}
                className="h-auto p-4 flex flex-col items-center gap-2"
              >
                <BookOpen className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-medium">Timeline Histórico</div>
                  <div className="text-xs text-muted-foreground">
                    Eventos cronológicos
                  </div>
                </div>
              </Button>

              <Button 
                variant="outline" 
                onClick={() => generateFrequencyChart()}
                className="h-auto p-4 flex flex-col items-center gap-2"
              >
                <BarChart3 className="h-8 w-8" />
                <div className="text-center">
                  <div className="font-medium">Análisis de Frecuencia</div>
                  <div className="text-xs text-muted-foreground">
                    Términos más comunes
                  </div>
                </div>
              </Button>
            </div>

            <div 
              ref={setVisualizationContainer}
              className="w-full h-96 border border-border rounded-lg bg-background"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderRecommendationsPanel = () => (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Sistema de Recomendaciones
          </CardTitle>
          <CardDescription>
            Sugerencias inteligentes basadas en análisis semántico
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-sm">
              <Label>Selecciona un versículo para generar recomendaciones:</Label>
              <div className="mt-2 grid gap-2">
                {mockVerses.slice(0, 3).map((verse) => (
                  <Button
                    key={verse.id}
                    variant="outline"
                    onClick={() => generateRecommendations(verse)}
                    className="h-auto p-3 text-left justify-start"
                  >
                    <div>
                      <div className="font-medium text-sm">
                        {verse.libro} {verse.capitulo}:{verse.versiculo}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {verse.texto.slice(0, 60)}...
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {recommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Recomendaciones Generadas</CardTitle>
            <CardDescription>
              Versículos relacionados encontrados por IA
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recommendations.map((rec: any, index: number) => (
                <div key={index} className="border rounded-lg p-3 space-y-2">
                  <div className="flex justify-between items-start">
                    <div className="text-sm font-medium">
                      {rec.verse.libro} {rec.verse.capitulo}:{rec.verse.versiculo}
                    </div>
                    <div className="flex gap-1">
                      <Badge variant="secondary" className="text-xs">
                        {(rec.score * 100).toFixed(1)}%
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {rec.category}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {rec.verse.texto}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    <strong>Razón:</strong> {rec.reason}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  // =====================================================================
  // FUNCIONES DE VISUALIZACIÓN
  // =====================================================================

  const generateSemanticNetwork = () => {
    if (!currentVisualization) return;

    const nodes = [
      { id: 'amor', label: 'Amor', value: 10, group: 'theological' },
      { id: 'fe', label: 'Fe', value: 8, group: 'theological' },
      { id: 'esperanza', label: 'Esperanza', value: 6, group: 'theological' },
      { id: 'dios', label: 'Dios', value: 12, group: 'divine' },
      { id: 'cristo', label: 'Cristo', value: 11, group: 'divine' }
    ];

    const links = [
      { source: 'dios', target: 'amor', value: 8, type: 'strong' },
      { source: 'cristo', target: 'amor', value: 7, type: 'strong' },
      { source: 'fe', target: 'esperanza', value: 6, type: 'medium' },
      { source: 'amor', target: 'fe', value: 5, type: 'medium' }
    ];

    currentVisualization.createSemanticNetwork(nodes, links);
  };

  const generateHeatmap = () => {
    if (!currentVisualization) return;

    const data = [
      { x: 'Génesis', y: 'Amor', value: 0.3 },
      { x: 'Génesis', y: 'Fe', value: 0.5 },
      { x: 'Juan', y: 'Amor', value: 0.9 },
      { x: 'Juan', y: 'Fe', value: 0.7 },
      { x: 'Romanos', y: 'Fe', value: 0.8 },
      { x: 'Romanos', y: 'Justicia', value: 0.6 }
    ];

    currentVisualization.createThematicHeatmap(data);
  };

  const generateTimeline = () => {
    if (!currentVisualization) return;

    const events = [
      { date: '2000-01-01', event: 'Creación', category: 'Genesis', importance: 10 },
      { date: '1500-01-01', event: 'Éxodo', category: 'Historia', importance: 8 },
      { date: '0001-01-01', event: 'Nacimiento de Cristo', category: 'Nuevo Testamento', importance: 10 },
      { date: '0033-01-01', event: 'Crucifixión', category: 'Nuevo Testamento', importance: 10 }
    ];

    currentVisualization.createHistoricalTimeline(events);
  };

  const generateFrequencyChart = () => {
    if (!currentVisualization) return;

    const data = [
      { term: 'amor', frequency: 120, category: 'theological' },
      { term: 'fe', frequency: 95, category: 'theological' },
      { term: 'dios', frequency: 200, category: 'divine' },
      { term: 'cristo', frequency: 150, category: 'divine' },
      { term: 'paz', frequency: 80, category: 'theological' }
    ];

    currentVisualization.createFrequencyAnalysis(data);
  };

  // =====================================================================
  // RENDER PRINCIPAL
  // =====================================================================

  return (
    <div className="w-full max-w-7xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Brain className="h-8 w-8" />
          Análisis Avanzado con IA
        </h1>
        <p className="text-muted-foreground">
          Machine Learning, NLP y Visualizaciones para el Estudio Bíblico
        </p>
      </div>

      {/* Panel de Análisis de Texto */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Análisis de Texto con ML
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Ingresa texto bíblico para analizar..."
              value={selectedText}
              onChange={(e) => setSelectedText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && analyzeText(selectedText)}
            />
            <Button onClick={() => analyzeText(selectedText)} disabled={isLoading}>
              <Brain className="h-4 w-4" />
            </Button>
          </div>
          {renderTextAnalysis()}
        </CardContent>
      </Card>

      {/* Tabs principales */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="search">Búsqueda Semántica</TabsTrigger>
          <TabsTrigger value="filters">Filtros Inteligentes</TabsTrigger>
          <TabsTrigger value="visualizations">Visualizaciones</TabsTrigger>
          <TabsTrigger value="recommendations">Recomendaciones</TabsTrigger>
        </TabsList>

        <TabsContent value="search">
          {renderSemanticSearch()}
        </TabsContent>

        <TabsContent value="filters">
          {renderIntelligentFilters()}
        </TabsContent>

        <TabsContent value="visualizations">
          {renderVisualizationsPanel()}
        </TabsContent>

        <TabsContent value="recommendations">
          {renderRecommendationsPanel()}
        </TabsContent>
      </Tabs>

      {/* Panel de Historial de Análisis */}
      {analysisResults.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Historial de Análisis</CardTitle>
            <CardDescription>
              Últimos resultados de análisis con IA
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-32">
              <div className="space-y-2">
                {analysisResults.map((result, index) => (
                  <div key={index} className="flex justify-between items-center p-2 border rounded">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {result.type}
                      </Badge>
                      <span className="text-sm">
                        {new Date(result.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {result.executionTime.toFixed(0)}ms
                    </span>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {isLoading && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50">
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              <div>
                <div className="font-medium">Procesando con IA...</div>
                <div className="text-sm text-muted-foreground">
                  Aplicando algoritmos de machine learning
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
