import { motion, AnimatePresence } from 'framer-motion'
import { Settings, X, Type, Moon, Sun, Volume2, Bell } from 'lucide-react'
import { useTheme } from '../contexts/ThemeContext'
import { useAppState } from '../contexts/AppStateContext'

interface SettingsModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const { theme, toggleTheme } = useTheme()
  const { fontSize, setFontSize } = useAppState()

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-md bg-discord-secondary rounded-lg shadow-elevation-high overflow-hidden"
        >
          {/* Header */}
          <div className="p-6 border-b border-discord-modifier-hover">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Settings className="w-6 h-6 text-discord-primary" />
                <h2 className="text-lg font-semibold text-discord-text-primary">
                  Configuración
                </h2>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-lg hover:bg-discord-modifier-hover transition-colors"
              >
                <X className="w-5 h-5 text-discord-text-muted" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">
            {/* Theme Setting */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-discord-text-primary flex items-center">
                {theme === 'dark' ? (
                  <Moon className="w-4 h-4 mr-2" />
                ) : (
                  <Sun className="w-4 h-4 mr-2" />
                )}
                Tema
              </h3>
              <div className="flex items-center justify-between">
                <span className="text-discord-text-secondary">
                  Tema {theme === 'dark' ? 'oscuro' : 'claro'}
                </span>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={toggleTheme}
                  className="px-4 py-2 bg-discord-input rounded-lg hover:bg-discord-modifier-hover transition-colors text-discord-text-primary"
                >
                  Cambiar
                </motion.button>
              </div>
            </div>

            {/* Font Size Setting */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-discord-text-primary flex items-center">
                <Type className="w-4 h-4 mr-2" />
                Tamaño de fuente
              </h3>
              <div className="space-y-2">
                {(['small', 'medium', 'large'] as const).map((size) => (
                  <motion.button
                    key={size}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setFontSize(size)}
                    className={`w-full p-3 rounded-lg text-left transition-colors ${
                      fontSize === size
                        ? 'bg-discord-primary text-white'
                        : 'bg-discord-input hover:bg-discord-modifier-hover text-discord-text-primary'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="capitalize">{size === 'small' ? 'Pequeño' : size === 'medium' ? 'Mediano' : 'Grande'}</span>
                      <span className={`${
                        size === 'small' ? 'text-sm' : 
                        size === 'medium' ? 'text-base' : 'text-lg'
                      }`}>
                        Aa
                      </span>
                    </div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Audio Settings */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-discord-text-primary flex items-center">
                <Volume2 className="w-4 h-4 mr-2" />
                Audio
              </h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-discord-text-secondary">Sonidos de notificación</span>
                  <input
                    type="checkbox"
                    className="w-4 h-4 text-discord-primary bg-discord-input border-discord-modifier-hover rounded focus:ring-discord-primary"
                    defaultChecked
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-discord-text-secondary">Audio de versículos</span>
                  <input
                    type="checkbox"
                    className="w-4 h-4 text-discord-primary bg-discord-input border-discord-modifier-hover rounded focus:ring-discord-primary"
                  />
                </div>
              </div>
            </div>

            {/* Notification Settings */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-discord-text-primary flex items-center">
                <Bell className="w-4 h-4 mr-2" />
                Notificaciones
              </h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-discord-text-secondary">Recordatorios de lectura</span>
                  <input
                    type="checkbox"
                    className="w-4 h-4 text-discord-primary bg-discord-input border-discord-modifier-hover rounded focus:ring-discord-primary"
                    defaultChecked
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-discord-text-secondary">Nuevos comentarios</span>
                  <input
                    type="checkbox"
                    className="w-4 h-4 text-discord-primary bg-discord-input border-discord-modifier-hover rounded focus:ring-discord-primary"
                    defaultChecked
                  />
                </div>
              </div>
            </div>

            {/* Data Management */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium text-discord-text-primary">
                Gestión de datos
              </h3>
              <div className="space-y-2">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full p-3 bg-discord-input rounded-lg hover:bg-discord-modifier-hover transition-colors text-discord-text-primary text-left"
                >
                  Exportar progreso
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full p-3 bg-red-500/20 rounded-lg hover:bg-red-500/30 transition-colors text-red-400 text-left"
                >
                  Limpiar datos locales
                </motion.button>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-discord-modifier-hover bg-discord-tertiary">
            <div className="flex justify-end space-x-3">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onClose}
                className="px-4 py-2 bg-discord-input rounded-lg hover:bg-discord-modifier-hover transition-colors text-discord-text-primary"
              >
                Cerrar
              </motion.button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
