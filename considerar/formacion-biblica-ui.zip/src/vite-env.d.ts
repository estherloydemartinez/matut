/// <reference types="vite/client" />

// Declaraciones globales para las funcionalidades avanzadas
declare global {
  interface Window {
    AdvancedFeaturesModule?: {
      PersonalizedStudySystem: {
        createReadingPlan: (planData: any) => Promise<any>;
        startStudySession: (planId: string, day: number) => Promise<any>;
        completeReading: (sessionId: string, readingIndex: number) => Promise<void>;
        addStudyNote: (planId: string, day: number, noteData: any) => Promise<any>;
        getStudyProgress: (planId: string) => any;
        getStudyStats: (userId: string) => Promise<any>;
        getAllPlans: () => Promise<any[]>;
        getCurrentSession: () => any;
      };
      AdvancedStudyTools: {
        initialize: () => Promise<void>;
        compareVersions: (reference: string, versionIds: string[]) => Promise<any>;
        addPersonalNote: (noteData: any) => Promise<any>;
        updatePersonalNote: (noteId: string, updates: any) => Promise<any>;
        highlightText: (highlightData: any) => Promise<any>;
        searchConcordance: (word: string) => Promise<any>;
        getNotesForReference: (reference: string) => any[];
        getHighlightsForReference: (reference: string) => any[];
        searchPersonalNotes: (query: string) => any[];
      };
      GamificationSystem: {
        initialize: () => Promise<void>;
        awardXP: (amount: number, reason: string) => Promise<void>;
        checkAchievements: (context: any) => Promise<void>;
        createChallenge: (challengeData: any) => Promise<any>;
        joinChallenge: (challengeId: string) => Promise<void>;
        getUserLevel: () => number;
        getUserXP: () => number;
        getUserAchievements: () => any[];
        getLeaderboard: (type: string) => any;
        updateLeaderboard: (type: string, userId: string, score: number) => Promise<void>;
      };
      MetricsDashboard: {
        initialize: () => Promise<void>;
        updateUserMetrics: (userId: string, activity: any) => Promise<void>;
        generateProgressReport: (userId: string, period: string) => Promise<any>;
        getGlobalStats: () => any;
        getUserMetrics: (userId: string) => any;
        getAnalytics: () => any;
      };
      initialize: () => Promise<void>;
    };
    BibliaRV1960Optimized?: any;
    AnalisisAvanzadoOptimizado?: any;
    SocialAvanzadoOptimizado?: any;
  }
}

export {};
