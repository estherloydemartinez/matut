import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Toaster } from 'react-hot-toast'
import { useHotkeys } from 'react-hotkeys-hook'

// Components
import Header from './components/Header'
import Navigation from './components/Navigation'
import Breadcrumbs from './components/Breadcrumbs'
import BibleContainer from './components/BibleContainer'
import StudyContainer from './components/StudyContainer'
import FiltersContainer from './components/FiltersContainer'
import SocialContainer from './components/SocialContainer'
import ResourcesContainer from './components/ResourcesContainer'
import SearchModal from './components/SearchModal'
import SettingsModal from './components/SettingsModal'
import OnboardingTour from './components/OnboardingTour'
import ProgressDashboard from './components/ProgressDashboard'
import LoadingScreen from './components/LoadingScreen'
import AdvancedFeaturesHub from './components/AdvancedFeaturesHub'
import AdvancedAnalyticsHub from './components/AdvancedAnalyticsHub'

// Contexts
import { ThemeProvider } from './contexts/ThemeContext'
import { AppStateProvider, useAppState } from './contexts/AppStateContext'
import { DataProvider } from './contexts/DataContext'

// Types
export type ActiveSection = 'biblia' | 'estudio' | 'filtros' | 'social' | 'recursos' | 'dashboard' | 'avanzado' | 'analytics'

function AppContent() {
  const { 
    activeSection, 
    setActiveSection, 
    isSearchModalOpen, 
    setIsSearchModalOpen,
    isSettingsModalOpen,
    setIsSettingsModalOpen,
    isOnboardingOpen,
    setIsOnboardingOpen,
    isLoading,
    setIsLoading
  } = useAppState()

  // Keyboard shortcuts
  useHotkeys('ctrl+k, cmd+k', (e) => {
    e.preventDefault()
    setIsSearchModalOpen(true)
  })

  useHotkeys('ctrl+,, cmd+,', (e) => {
    e.preventDefault()
    setIsSettingsModalOpen(true)
  })

  useHotkeys('ctrl+h, cmd+h', (e) => {
    e.preventDefault()
    setIsOnboardingOpen(true)
  })

  useHotkeys('1', () => setActiveSection('biblia'))
  useHotkeys('2', () => setActiveSection('estudio'))
  useHotkeys('3', () => setActiveSection('filtros'))
  useHotkeys('4', () => setActiveSection('social'))
  useHotkeys('5', () => setActiveSection('recursos'))
  useHotkeys('6', () => setActiveSection('dashboard'))
  useHotkeys('7', () => setActiveSection('avanzado'))
  useHotkeys('8', () => setActiveSection('analytics'))

  // Check if user has seen onboarding
  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('formacion-biblica-onboarding')
    if (!hasSeenOnboarding) {
      setIsOnboardingOpen(true)
    }
    setIsLoading(false)
  }, [setIsOnboardingOpen, setIsLoading])

  // Main content render
  const renderContent = () => {
    switch (activeSection) {
      case 'biblia':
        return <BibleContainer />
      case 'estudio':
        return <StudyContainer />
      case 'filtros':
        return <FiltersContainer />
      case 'social':
        return <SocialContainer />
      case 'recursos':
        return <ResourcesContainer />
      case 'dashboard':
        return <ProgressDashboard />
      case 'avanzado':
        return <AdvancedFeaturesHub />
      case 'analytics':
        return <AdvancedAnalyticsHub />
      default:
        return <BibleContainer />
    }
  }

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-discord-tertiary text-discord-primary">
      {/* Main Layout */}
      <div className="flex flex-col lg:flex-row">
        {/* Sidebar for desktop */}
        <aside className="hidden lg:block w-72 bg-discord-secondary min-h-screen">
          <div className="p-4 space-y-4">
            <Header compact />
            <Navigation vertical />
          </div>
        </aside>

        {/* Main content area */}
        <main className="flex-1">
          <div className="container mx-auto px-4 py-6">
            {/* Mobile header */}
            <div className="lg:hidden mb-6">
              <Header />
            </div>

            {/* Mobile navigation */}
            <div className="lg:hidden mb-6">
              <Navigation />
            </div>

            {/* Breadcrumbs */}
            <Breadcrumbs />

            {/* Page content with animations */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSection}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
              >
                {renderContent()}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Modals */}
      <SearchModal 
        isOpen={isSearchModalOpen} 
        onClose={() => setIsSearchModalOpen(false)} 
      />
      
      <SettingsModal 
        isOpen={isSettingsModalOpen} 
        onClose={() => setIsSettingsModalOpen(false)} 
      />

      {/* Onboarding Tour */}
      <OnboardingTour 
        isOpen={isOnboardingOpen} 
        onClose={() => {
          setIsOnboardingOpen(false)
          localStorage.setItem('formacion-biblica-onboarding', 'true')
        }} 
      />

      {/* Toast notifications */}
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: 'var(--bg-secondary)',
            color: 'var(--text-primary)',
            border: '1px solid var(--bg-input)',
          },
        }}
      />
    </div>
  )
}

function App() {
  return (
    <ThemeProvider>
      <AppStateProvider>
        <DataProvider>
          <AppContent />
        </DataProvider>
      </AppStateProvider>
    </ThemeProvider>
  )
}

export default App
