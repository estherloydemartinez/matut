import React, { createContext, useContext, useState, useEffect } from 'react'

interface BibleData {
  books: Array<{
    name: string
    chapters: number
    testament: 'old' | 'new'
  }>
  verses: Record<string, Record<number, Record<number, string>>>
}

interface StudyResources {
  commentaries: Array<{
    id: string
    title: string
    author: string
    content: string
  }>
  lessons: Array<{
    id: string
    title: string
    description: string
    level: 'beginner' | 'intermediate' | 'advanced'
    content: string
  }>
}

interface AnalyticalFilters {
  blood: Array<{
    category: string
    verses: Array<{
      book: string
      chapter: number
      verse: number
      text: string
    }>
  }>
  water: Array<{
    category: string
    verses: Array<{
      book: string
      chapter: number
      verse: number
      text: string
    }>
  }>
}

interface DataContextType {
  // Bible data
  bibleData: BibleData | null
  loadBibleData: () => Promise<void>
  
  // Study resources
  studyResources: StudyResources | null
  loadStudyResources: () => Promise<void>
  
  // Analytical filters
  analyticalFilters: AnalyticalFilters | null
  loadAnalyticalFilters: () => Promise<void>
  
  // Loading states
  isBibleLoading: boolean
  isStudyLoading: boolean
  isFiltersLoading: boolean
  
  // Error states
  bibleError: string | null
  studyError: string | null
  filtersError: string | null
  
  // Search functionality
  searchBible: (query: string) => Promise<Array<{
    book: string
    chapter: number
    verse: number
    text: string
    relevance: number
  }>>
  
  // Get specific content
  getChapter: (book: string, chapter: number) => Record<number, string> | null
  getVerse: (book: string, chapter: number, verse: number) => string | null
  
  // Social features
  socialData: {
    discussions: Array<{
      id: string
      title: string
      author: string
      date: string
      replies: number
      category: 'general' | 'teoria' | 'practica'
    }>
    messages: Array<{
      id: string
      author: string
      content: string
      timestamp: string
      replies?: Array<{
        id: string
        author: string
        content: string
        timestamp: string
      }>
    }>
  }
  loadSocialData: () => Promise<void>
}

const DataContext = createContext<DataContextType | undefined>(undefined)

export function DataProvider({ children }: { children: React.ReactNode }) {
  // Data states
  const [bibleData, setBibleData] = useState<BibleData | null>(null)
  const [studyResources, setStudyResources] = useState<StudyResources | null>(null)
  const [analyticalFilters, setAnalyticalFilters] = useState<AnalyticalFilters | null>(null)
  const [socialData, setSocialData] = useState<DataContextType['socialData']>({
    discussions: [],
    messages: []
  })
  
  // Loading states
  const [isBibleLoading, setIsBibleLoading] = useState(false)
  const [isStudyLoading, setIsStudyLoading] = useState(false)
  const [isFiltersLoading, setIsFiltersLoading] = useState(false)
  
  // Error states
  const [bibleError, setBibleError] = useState<string | null>(null)
  const [studyError, setStudyError] = useState<string | null>(null)
  const [filtersError, setFiltersError] = useState<string | null>(null)

  // Load Bible data from JavaScript files
  const loadBibleData = async () => {
    setIsBibleLoading(true)
    setBibleError(null)
    
    try {
      // Load the Bible script
      const script = document.createElement('script')
      script.src = '/js/biblia_rv1960_optimizado.js'
      script.async = true
      
      script.onload = () => {
        // Wait a bit for the script to fully initialize
        setTimeout(() => {
          if (window.bibliaRV1960) {
            console.log('✅ Bible data loaded successfully!')
            console.log('📖 Structure verification:')
            console.log('- Books available:', window.bibliaRV1960.books ? window.bibliaRV1960.books.length : 0)
            console.log('- Verses available:', !!window.bibliaRV1960.verses)
            
            if (window.bibliaRV1960.verses) {
              const books = Object.keys(window.bibliaRV1960.verses)
              console.log(`- Total books with verses: ${books.length}`)
              console.log('- Book list:', books.slice(0, 5).join(', '), books.length > 5 ? '...' : '')
              
              // Test Genesis specifically
              if (window.bibliaRV1960.verses['Génesis']) {
                const genesisChapters = Object.keys(window.bibliaRV1960.verses['Génesis'])
                console.log(`- Génesis chapters: ${genesisChapters.length}`)
                
                if (window.bibliaRV1960.verses['Génesis']['1']) {
                  const genesisVerse1 = Object.keys(window.bibliaRV1960.verses['Génesis']['1'])
                  console.log(`- Génesis chapter 1 verses: ${genesisVerse1.length}`)
                  console.log('- First verse sample:', window.bibliaRV1960.verses['Génesis']['1']['1'])
                }
              }
            }
            
            setBibleData(window.bibliaRV1960)
            setIsBibleLoading(false)
          } else {
            console.error('❌ Bible data not found on window object')
            console.log('Available on window:', Object.keys(window).filter(key => key.includes('biblia') || key.includes('Bible')))
            setBibleError('Datos bíblicos no disponibles')
            setIsBibleLoading(false)
          }
        }, 500)
      }
      
      script.onerror = () => {
        setBibleError('Error al cargar los datos de la Biblia')
        setIsBibleLoading(false)
      }
      
      document.head.appendChild(script)
    } catch (error) {
      setBibleError('Error al cargar los datos de la Biblia')
      setIsBibleLoading(false)
    }
  }

  // Load study resources
  const loadStudyResources = async () => {
    setIsStudyLoading(true)
    setStudyError(null)
    
    try {
      // Mock study resources data
      const resources: StudyResources = {
        commentaries: [
          {
            id: '1',
            title: 'Comentario Bíblico de Matthew Henry',
            author: 'Matthew Henry',
            content: 'Comentario exhaustivo sobre toda la Biblia...'
          },
          {
            id: '2',
            title: 'Comentario Exegético',
            author: 'John MacArthur',
            content: 'Análisis verso por verso...'
          }
        ],
        lessons: [
          {
            id: '1',
            title: 'Introducción al Estudio Bíblico',
            description: 'Fundamentos para el estudio sistemático de la Biblia',
            level: 'beginner',
            content: 'En esta lección aprenderemos...'
          },
          {
            id: '2',
            title: 'Hermenéutica Bíblica',
            description: 'Principios de interpretación bíblica',
            level: 'intermediate',
            content: 'La hermenéutica es el arte y ciencia...'
          }
        ]
      }
      
      setStudyResources(resources)
      setIsStudyLoading(false)
    } catch (error) {
      setStudyError('Error al cargar los recursos de estudio')
      setIsStudyLoading(false)
    }
  }

  // Load analytical filters
  const loadAnalyticalFilters = async () => {
    setIsFiltersLoading(true)
    setFiltersError(null)
    
    try {
      // Load the analytical functions script
      const script = document.createElement('script')
      script.src = '/js/funciones_analiticas_optimizado.js'
      script.async = true
      
      script.onload = () => {
        // Wait a bit for the script to fully initialize
        setTimeout(() => {
          if (window.filtrosAnaliticos) {
            console.log('Analytical filters loaded successfully:', window.filtrosAnaliticos)
            setAnalyticalFilters(window.filtrosAnaliticos)
            setIsFiltersLoading(false)
          } else {
            console.error('Analytical filters data not found on window object')
            setFiltersError('Filtros analíticos no disponibles')
            setIsFiltersLoading(false)
          }
        }, 100)
      }
      
      script.onerror = () => {
        setFiltersError('Error al cargar los filtros analíticos')
        setIsFiltersLoading(false)
      }
      
      document.head.appendChild(script)
    } catch (error) {
      setFiltersError('Error al cargar los filtros analíticos')
      setIsFiltersLoading(false)
    }
  }

  // Load social data
  const loadSocialData = async () => {
    try {
      // Load the social script
      const script = document.createElement('script')
      script.src = '/js/social_avanzado_optimizado.js'
      script.async = true
      
      script.onload = () => {
        // Access the global social data
        if (window.socialData) {
          setSocialData(window.socialData)
        }
      }
      
      document.head.appendChild(script)
    } catch (error) {
      console.error('Error loading social data:', error)
    }
  }

  // Search Bible functionality
  const searchBible = async (query: string) => {
    if (!bibleData) return []
    
    const results: Array<{
      book: string
      chapter: number
      verse: number
      text: string
      relevance: number
    }> = []
    
    const searchTerms = query.toLowerCase().split(' ')
    
    Object.entries(bibleData.verses).forEach(([book, chapters]) => {
      Object.entries(chapters).forEach(([chapterNum, verses]) => {
        Object.entries(verses).forEach(([verseNum, text]) => {
          const lowerText = text.toLowerCase()
          const relevance = searchTerms.reduce((score, term) => {
            const matches = (lowerText.match(new RegExp(term, 'g')) || []).length
            return score + matches
          }, 0)
          
          if (relevance > 0) {
            results.push({
              book,
              chapter: parseInt(chapterNum),
              verse: parseInt(verseNum),
              text,
              relevance
            })
          }
        })
      })
    })
    
    return results.sort((a, b) => b.relevance - a.relevance).slice(0, 50)
  }

  // Get specific chapter
  const getChapter = (book: string, chapter: number) => {
    // Try to get data directly from window if bibleData is not loaded yet
    const data = bibleData || (typeof window !== 'undefined' ? window.bibliaRV1960 : null)
    
    if (!data || !data.verses) {
      console.log('getChapter: No bible data available for', book, chapter)
      return null
    }
    
    const chapterData = data.verses[book]?.[chapter]
    if (chapterData) {
      console.log('getChapter: Successfully found data for', book, chapter, '- verses:', Object.keys(chapterData).length)
      return chapterData
    }
    
    console.log('getChapter: No chapter data found for', book, chapter)
    return null
  }

  // Get specific verse
  const getVerse = (book: string, chapter: number, verse: number) => {
    // Try to get data directly from window if bibleData is not loaded yet
    const data = bibleData || (typeof window !== 'undefined' ? window.bibliaRV1960 : null)
    
    if (!data || !data.verses) return null
    return data.verses[book]?.[chapter]?.[verse] || null
  }

  // Load initial data
  useEffect(() => {
    loadBibleData()
    loadStudyResources()
    loadAnalyticalFilters()
    loadSocialData()
  }, [])

  const value: DataContextType = {
    // Bible data
    bibleData,
    loadBibleData,
    
    // Study resources
    studyResources,
    loadStudyResources,
    
    // Analytical filters
    analyticalFilters,
    loadAnalyticalFilters,
    
    // Loading states
    isBibleLoading,
    isStudyLoading,
    isFiltersLoading,
    
    // Error states
    bibleError,
    studyError,
    filtersError,
    
    // Search functionality
    searchBible,
    
    // Get specific content
    getChapter,
    getVerse,
    
    // Social features
    socialData,
    loadSocialData,
  }

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider')
  }
  return context
}

// Type declarations for global variables
declare global {
  interface Window {
    bibliaRV1960: BibleData
    filtrosAnaliticos: AnalyticalFilters
    socialData: DataContextType['socialData']
  }
}
