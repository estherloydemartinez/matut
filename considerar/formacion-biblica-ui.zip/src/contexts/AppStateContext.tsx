import React, { createContext, useContext, useState, useCallback } from 'react'
import { ActiveSection } from '../App'

interface UserProgress {
  chaptersRead: number
  totalChapters: number
  studyHours: number
  completedLessons: number
  totalLessons: number
  lastActiveDate: string
  streak: number
}

interface AppStateContextType {
  // Navigation
  activeSection: ActiveSection
  setActiveSection: (section: ActiveSection) => void
  
  // Modals
  isSearchModalOpen: boolean
  setIsSearchModalOpen: (open: boolean) => void
  isSettingsModalOpen: boolean
  setIsSettingsModalOpen: (open: boolean) => void
  isOnboardingOpen: boolean
  setIsOnboardingOpen: (open: boolean) => void
  
  // Loading states
  isLoading: boolean
  setIsLoading: (loading: boolean) => void
  
  // Bible navigation
  currentBook: string
  setCurrentBook: (book: string) => void
  currentChapter: number
  setCurrentChapter: (chapter: number) => void
  selectedVerses: number[]
  setSelectedVerses: (verses: number[] | ((prev: number[]) => number[])) => void
  
  // Study mode
  isStudyMode: boolean
  setIsStudyMode: (mode: boolean) => void
  studyNotes: Record<string, string>
  setStudyNotes: (notes: Record<string, string>) => void
  
  // Filters
  activeFilters: string[]
  setActiveFilters: (filters: string[]) => void
  
  // User progress
  userProgress: UserProgress
  updateProgress: (progress: Partial<UserProgress>) => void
  
  // Settings
  fontSize: 'small' | 'medium' | 'large'
  setFontSize: (size: 'small' | 'medium' | 'large') => void
  
  // Search
  searchHistory: string[]
  addToSearchHistory: (query: string) => void
  
  // Notifications
  notifications: Array<{
    id: string
    type: 'success' | 'error' | 'warning' | 'info'
    message: string
    timestamp: number
  }>
  addNotification: (notification: Omit<AppStateContextType['notifications'][0], 'id' | 'timestamp'>) => void
  removeNotification: (id: string) => void
}

const AppStateContext = createContext<AppStateContextType | undefined>(undefined)

export function AppStateProvider({ children }: { children: React.ReactNode }) {
  // Navigation state
  const [activeSection, setActiveSection] = useState<ActiveSection>('biblia')
  
  // Modal states
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false)
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false)
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false)
  
  // Loading state
  const [isLoading, setIsLoading] = useState(true)
  
  // Bible navigation state
  const [currentBook, setCurrentBook] = useState('Genesis')
  const [currentChapter, setCurrentChapter] = useState(1)
  const [selectedVerses, setSelectedVerses] = useState<number[]>([])
  
  // Study mode state
  const [isStudyMode, setIsStudyMode] = useState(false)
  const [studyNotes, setStudyNotes] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem('formacion-biblica-study-notes')
    return saved ? JSON.parse(saved) : {}
  })
  
  // Filters state
  const [activeFilters, setActiveFilters] = useState<string[]>([])
  
  // User progress state
  const [userProgress, setUserProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('formacion-biblica-progress')
    return saved ? JSON.parse(saved) : {
      chaptersRead: 0,
      totalChapters: 1189, // Total chapters in the Bible
      studyHours: 0,
      completedLessons: 0,
      totalLessons: 50,
      lastActiveDate: new Date().toISOString(),
      streak: 0
    }
  })
  
  // Settings state
  const [fontSize, setFontSize] = useState<'small' | 'medium' | 'large'>(() => {
    const saved = localStorage.getItem('formacion-biblica-font-size')
    return (saved as 'small' | 'medium' | 'large') || 'medium'
  })
  
  // Search state
  const [searchHistory, setSearchHistory] = useState<string[]>(() => {
    const saved = localStorage.getItem('formacion-biblica-search-history')
    return saved ? JSON.parse(saved) : []
  })
  
  // Notifications state
  const [notifications, setNotifications] = useState<AppStateContextType['notifications']>([])

  // Update progress with localStorage persistence
  const updateProgress = useCallback((progress: Partial<UserProgress>) => {
    setUserProgress(prev => {
      const updated = { ...prev, ...progress }
      localStorage.setItem('formacion-biblica-progress', JSON.stringify(updated))
      return updated
    })
  }, [])

  // Add to search history
  const addToSearchHistory = useCallback((query: string) => {
    setSearchHistory(prev => {
      const updated = [query, ...prev.filter(q => q !== query)].slice(0, 10)
      localStorage.setItem('formacion-biblica-search-history', JSON.stringify(updated))
      return updated
    })
  }, [])

  // Add notification
  const addNotification = useCallback((notification: Omit<AppStateContextType['notifications'][0], 'id' | 'timestamp'>) => {
    const newNotification = {
      ...notification,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now()
    }
    
    setNotifications(prev => [...prev, newNotification])
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
      removeNotification(newNotification.id)
    }, 5000)
  }, [])

  // Remove notification
  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id))
  }, [])

  // Persist study notes to localStorage
  React.useEffect(() => {
    localStorage.setItem('formacion-biblica-study-notes', JSON.stringify(studyNotes))
  }, [studyNotes])

  // Persist font size to localStorage
  React.useEffect(() => {
    localStorage.setItem('formacion-biblica-font-size', fontSize)
  }, [fontSize])

  const value: AppStateContextType = {
    // Navigation
    activeSection,
    setActiveSection,
    
    // Modals
    isSearchModalOpen,
    setIsSearchModalOpen,
    isSettingsModalOpen,
    setIsSettingsModalOpen,
    isOnboardingOpen,
    setIsOnboardingOpen,
    
    // Loading
    isLoading,
    setIsLoading,
    
    // Bible navigation
    currentBook,
    setCurrentBook,
    currentChapter,
    setCurrentChapter,
    selectedVerses,
    setSelectedVerses,
    
    // Study mode
    isStudyMode,
    setIsStudyMode,
    studyNotes,
    setStudyNotes,
    
    // Filters
    activeFilters,
    setActiveFilters,
    
    // User progress
    userProgress,
    updateProgress,
    
    // Settings
    fontSize,
    setFontSize,
    
    // Search
    searchHistory,
    addToSearchHistory,
    
    // Notifications
    notifications,
    addNotification,
    removeNotification,
  }

  return (
    <AppStateContext.Provider value={value}>
      {children}
    </AppStateContext.Provider>
  )
}

export function useAppState() {
  const context = useContext(AppStateContext)
  if (context === undefined) {
    throw new Error('useAppState must be used within an AppStateProvider')
  }
  return context
}
