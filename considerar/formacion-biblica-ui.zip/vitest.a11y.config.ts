import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom', // jsdom para mejor soporte de accessibility APIs
    setupFiles: ['./src/tests/setup.ts'],
    include: ['src/tests/accessibility/**/*.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}'],
    exclude: ['node_modules', 'dist', '.idea', '.git', '.cache'],
    testTimeout: 20000, // Tiempo suficiente para auditorías de accesibilidad
    hookTimeout: 10000,
    // Configuración específica para accessibility testing
    pool: 'threads',
    poolOptions: {
      threads: {
        maxThreads: 1, // Tests de accesibilidad en secuencia
        minThreads: 1,
      },
    },
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, './src'),
    },
  },
});
