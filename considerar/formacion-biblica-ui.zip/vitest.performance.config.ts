import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'happy-dom',
    setupFiles: ['./src/tests/setup.ts'],
    include: ['src/tests/performance/**/*.{test,spec}.{js,mjs,cjs,ts,mts,cts,jsx,tsx}'],
    exclude: ['node_modules', 'dist', '.idea', '.git', '.cache'],
    testTimeout: 30000, // Más tiempo para tests de performance
    hookTimeout: 15000,
    // Configuración específica para performance testing
    isolate: false, // Permite compartir estado entre tests para mejor performance
    pool: 'threads',
    poolOptions: {
      threads: {
        singleThread: true, // Tests de performance en un solo hilo
      },
    },
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, './src'),
    },
  },
});
