#!/usr/bin/env node

/**
 * Comprehensive Test Runner
 * Ejecuta todos los tests y genera reporte completo
 */

const { execSync, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

// Configuración de colores para consola
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

class TestRunner {
  constructor() {
    this.results = {
      unit: { status: 'pending', duration: 0, coverage: 0 },
      integration: { status: 'pending', duration: 0 },
      e2e: { status: 'pending', duration: 0 },
      performance: { status: 'pending', duration: 0, metrics: {} },
      accessibility: { status: 'pending', duration: 0, violations: 0 },
      security: { status: 'pending', duration: 0, vulnerabilities: 0 }
    };
    
    this.startTime = Date.now();
  }

  log(message, color = 'reset') {
    console.log(`${colors[color]}${message}${colors.reset}`);
  }

  logSection(title) {
    console.log('\n' + '='.repeat(60));
    this.log(title.toUpperCase(), 'cyan');
    console.log('='.repeat(60));
  }

  async runCommand(command, description, options = {}) {
    this.log(`\n🔄 ${description}...`, 'yellow');
    
    const startTime = Date.now();
    
    try {
      const result = execSync(command, {
        stdio: options.silent ? 'pipe' : 'inherit',
        encoding: 'utf8',
        cwd: process.cwd(),
        ...options
      });
      
      const duration = Date.now() - startTime;
      this.log(`✅ ${description} completed in ${duration}ms`, 'green');
      
      return { success: true, output: result, duration };
    } catch (error) {
      const duration = Date.now() - startTime;
      this.log(`❌ ${description} failed after ${duration}ms`, 'red');
      
      if (!options.silent) {
        console.error(error.stdout?.toString() || error.message);
      }
      
      return { success: false, error, duration };
    }
  }

  async runUnitTests() {
    this.logSection('Unit Tests');
    
    const result = await this.runCommand(
      'npm run test:run',
      'Running unit tests with coverage'
    );
    
    this.results.unit.status = result.success ? 'passed' : 'failed';
    this.results.unit.duration = result.duration;
    
    // Extraer información de coverage si está disponible
    try {
      const coverageFile = path.join(process.cwd(), 'coverage', 'coverage-summary.json');
      if (fs.existsSync(coverageFile)) {
        const coverage = JSON.parse(fs.readFileSync(coverageFile, 'utf8'));
        this.results.unit.coverage = coverage.total.lines.pct;
      }
    } catch (error) {
      this.log('Could not read coverage data', 'yellow');
    }
    
    return result.success;
  }

  async runIntegrationTests() {
    this.logSection('Integration Tests');
    
    const result = await this.runCommand(
      'npm run test:integration',
      'Running integration tests'
    );
    
    this.results.integration.status = result.success ? 'passed' : 'failed';
    this.results.integration.duration = result.duration;
    
    return result.success;
  }

  async runE2ETests() {
    this.logSection('End-to-End Tests');
    
    // Verificar si el servidor de desarrollo está corriendo
    const devServer = await this.startDevServer();
    
    try {
      const result = await this.runCommand(
        'npm run test:e2e:run',
        'Running E2E tests with Cypress'
      );
      
      this.results.e2e.status = result.success ? 'passed' : 'failed';
      this.results.e2e.duration = result.duration;
      
      return result.success;
    } finally {
      if (devServer) {
        devServer.kill();
        this.log('Development server stopped', 'blue');
      }
    }
  }

  async startDevServer() {
    try {
      this.log('Starting development server...', 'blue');
      
      const server = spawn('npm', ['run', 'dev'], {
        stdio: 'pipe',
        detached: false
      });
      
      // Esperar a que el servidor esté listo
      await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Server start timeout'));
        }, 30000);
        
        server.stdout.on('data', (data) => {
          const output = data.toString();
          if (output.includes('Local:') || output.includes('localhost')) {
            clearTimeout(timeout);
            resolve();
          }
        });
        
        server.stderr.on('data', (data) => {
          const error = data.toString();
          if (error.includes('EADDRINUSE')) {
            clearTimeout(timeout);
            resolve(); // El servidor ya está corriendo
          }
        });
      });
      
      this.log('Development server is ready', 'green');
      return server;
    } catch (error) {
      this.log('Could not start development server - assuming it\'s already running', 'yellow');
      return null;
    }
  }

  async runPerformanceTests() {
    this.logSection('Performance Tests');
    
    const result = await this.runCommand(
      'npm run test:performance',
      'Running performance tests'
    );
    
    this.results.performance.status = result.success ? 'passed' : 'failed';
    this.results.performance.duration = result.duration;
    
    // Ejecutar Lighthouse si está disponible
    try {
      await this.runLighthouseAudit();
    } catch (error) {
      this.log('Lighthouse audit skipped', 'yellow');
    }
    
    return result.success;
  }

  async runLighthouseAudit() {
    this.log('Running Lighthouse performance audit...', 'blue');
    
    const result = await this.runCommand(
      'npm run lighthouse',
      'Lighthouse audit',
      { silent: true }
    );
    
    if (result.success) {
      // Procesar resultados de Lighthouse
      try {
        const reportPath = path.join(process.cwd(), 'reports', 'lighthouse.html');
        if (fs.existsSync(reportPath)) {
          this.log('Lighthouse report generated: reports/lighthouse.html', 'green');
        }
      } catch (error) {
        this.log('Could not process Lighthouse results', 'yellow');
      }
    }
  }

  async runAccessibilityTests() {
    this.logSection('Accessibility Tests');
    
    const result = await this.runCommand(
      'npm run test:accessibility',
      'Running accessibility tests'
    );
    
    this.results.accessibility.status = result.success ? 'passed' : 'failed';
    this.results.accessibility.duration = result.duration;
    
    return result.success;
  }

  async runSecurityAudit() {
    this.logSection('Security Audit');
    
    const result = await this.runCommand(
      'npm run audit:security',
      'Running security audit'
    );
    
    this.results.security.status = result.success ? 'passed' : 'failed';
    this.results.security.duration = result.duration;
    
    return result.success;
  }

  async runLintingAndTypeCheck() {
    this.logSection('Code Quality');
    
    // ESLint
    const lintResult = await this.runCommand(
      'npm run lint',
      'Running ESLint'
    );
    
    // TypeScript type checking
    const typeResult = await this.runCommand(
      'npx tsc --noEmit',
      'TypeScript type checking'
    );
    
    return lintResult.success && typeResult.success;
  }

  generateReport() {
    this.logSection('Test Results Summary');
    
    const totalDuration = Date.now() - this.startTime;
    
    console.log('\n📊 TEST RESULTS SUMMARY');
    console.log('─'.repeat(40));
    
    Object.entries(this.results).forEach(([testType, result]) => {
      const status = result.status === 'passed' ? '✅' : 
                    result.status === 'failed' ? '❌' : '⏸️';
      const duration = `${result.duration}ms`;
      
      this.log(`${status} ${testType.toUpperCase().padEnd(15)} ${duration.padStart(10)}`, 
        result.status === 'passed' ? 'green' : 
        result.status === 'failed' ? 'red' : 'yellow'
      );
      
      // Mostrar métricas adicionales
      if (testType === 'unit' && result.coverage) {
        this.log(`   Coverage: ${result.coverage}%`, 'blue');
      }
      
      if (testType === 'accessibility' && result.violations > 0) {
        this.log(`   Violations: ${result.violations}`, 'red');
      }
      
      if (testType === 'security' && result.vulnerabilities > 0) {
        this.log(`   Vulnerabilities: ${result.vulnerabilities}`, 'red');
      }
    });
    
    console.log('─'.repeat(40));
    this.log(`Total execution time: ${totalDuration}ms`, 'cyan');
    
    // Generar reporte detallado
    this.generateDetailedReport();
    
    // Determinar éxito general
    const allPassed = Object.values(this.results).every(r => r.status === 'passed');
    
    if (allPassed) {
      this.log('\n🎉 ALL TESTS PASSED!', 'green');
      return true;
    } else {
      this.log('\n💥 SOME TESTS FAILED!', 'red');
      return false;
    }
  }

  generateDetailedReport() {
    const reportData = {
      timestamp: new Date().toISOString(),
      duration: Date.now() - this.startTime,
      results: this.results,
      summary: {
        total: Object.keys(this.results).length,
        passed: Object.values(this.results).filter(r => r.status === 'passed').length,
        failed: Object.values(this.results).filter(r => r.status === 'failed').length,
        pending: Object.values(this.results).filter(r => r.status === 'pending').length
      }
    };
    
    // Crear directorio de reportes si no existe
    const reportsDir = path.join(process.cwd(), 'reports');
    if (!fs.existsSync(reportsDir)) {
      fs.mkdirSync(reportsDir, { recursive: true });
    }
    
    // Generar reporte JSON
    const jsonReportPath = path.join(reportsDir, 'test-results.json');
    fs.writeFileSync(jsonReportPath, JSON.stringify(reportData, null, 2));
    
    // Generar reporte HTML
    const htmlReport = this.generateHTMLReport(reportData);
    const htmlReportPath = path.join(reportsDir, 'test-results.html');
    fs.writeFileSync(htmlReportPath, htmlReport);
    
    this.log(`\n📄 Detailed reports generated:`, 'blue');
    this.log(`   JSON: ${jsonReportPath}`, 'blue');
    this.log(`   HTML: ${htmlReportPath}`, 'blue');
  }

  generateHTMLReport(data) {
    return `
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Results Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .metric { background: #f8f9fa; padding: 20px; border-radius: 6px; text-align: center; }
        .metric h3 { margin: 0 0 10px 0; color: #333; }
        .metric .value { font-size: 2em; font-weight: bold; }
        .passed { color: #28a745; }
        .failed { color: #dc3545; }
        .pending { color: #ffc107; }
        .results-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .results-table th, .results-table td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        .results-table th { background: #f8f9fa; font-weight: 600; }
        .status-badge { padding: 4px 8px; border-radius: 4px; color: white; font-size: 0.8em; }
        .badge-passed { background: #28a745; }
        .badge-failed { background: #dc3545; }
        .badge-pending { background: #ffc107; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Test Results Report</h1>
            <p>Generated on ${new Date(data.timestamp).toLocaleString()}</p>
            <p>Total execution time: ${data.duration}ms</p>
        </div>
        
        <div class="summary">
            <div class="metric">
                <h3>Total Tests</h3>
                <div class="value">${data.summary.total}</div>
            </div>
            <div class="metric">
                <h3>Passed</h3>
                <div class="value passed">${data.summary.passed}</div>
            </div>
            <div class="metric">
                <h3>Failed</h3>
                <div class="value failed">${data.summary.failed}</div>
            </div>
            <div class="metric">
                <h3>Pending</h3>
                <div class="value pending">${data.summary.pending}</div>
            </div>
        </div>
        
        <table class="results-table">
            <thead>
                <tr>
                    <th>Test Type</th>
                    <th>Status</th>
                    <th>Duration</th>
                    <th>Additional Info</th>
                </tr>
            </thead>
            <tbody>
                ${Object.entries(data.results).map(([type, result]) => `
                    <tr>
                        <td>${type.charAt(0).toUpperCase() + type.slice(1)}</td>
                        <td>
                            <span class="status-badge badge-${result.status}">
                                ${result.status.toUpperCase()}
                            </span>
                        </td>
                        <td>${result.duration}ms</td>
                        <td>
                            ${result.coverage ? `Coverage: ${result.coverage}%` : ''}
                            ${result.violations ? `Violations: ${result.violations}` : ''}
                            ${result.vulnerabilities ? `Vulnerabilities: ${result.vulnerabilities}` : ''}
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    </div>
</body>
</html>
    `;
  }

  async run() {
    this.log('🚀 Starting comprehensive test suite...', 'bright');
    
    try {
      // 1. Code Quality
      await this.runLintingAndTypeCheck();
      
      // 2. Unit Tests
      await this.runUnitTests();
      
      // 3. Integration Tests
      await this.runIntegrationTests();
      
      // 4. Performance Tests
      await this.runPerformanceTests();
      
      // 5. Accessibility Tests
      await this.runAccessibilityTests();
      
      // 6. Security Audit
      await this.runSecurityAudit();
      
      // 7. E2E Tests (al final porque son más lentos)
      await this.runE2ETests();
      
      // Generar reporte final
      const success = this.generateReport();
      
      process.exit(success ? 0 : 1);
      
    } catch (error) {
      this.log(`\n💥 Test runner encountered an error: ${error.message}`, 'red');
      console.error(error);
      process.exit(1);
    }
  }
}

// Ejecutar si es llamado directamente
if (require.main === module) {
  const runner = new TestRunner();
  runner.run();
}

module.exports = TestRunner;
