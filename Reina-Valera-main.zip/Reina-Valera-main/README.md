# Reina-Valera in JSON

The Reina–Valera is a Spanish translation of the Bible.

The Books of the Reina-Valera Bible are in JSON format. Each of the 66 books is a separate JSON file.

The source of these files is the USFM.

## Format of JSON file

As an example of the format, this is Psalm 1:

<img width="1326" alt="image" src="https://github.com/aruljohn/Reina-Valera/assets/3209045/30d4ec06-a41f-45de-bd2f-c4c8953732ad">
